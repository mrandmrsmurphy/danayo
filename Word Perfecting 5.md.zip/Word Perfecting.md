# Word Perfecting

Running log for the word-perfecting backlog sweep (see [[AIOS/checklists/checklist_words.md|Checklist: Word Pages]]). The first log (iterations 1–1040) grew to ~8,500 lines and was archived by the user to `Word Perfecting.md.zip`; a second log (iterations 1041–1782) was archived to `Word Perfecting 2.md.zip`; a third log (iterations 1783–2922) was archived to `Word Perfecting 3.md.zip`; a fourth log (iterations 2923–3555) was archived to `Word Perfecting 4.md.zip`. This file continues from there. Iteration numbering continues unbroken from the archived logs.

**Process**: one word per iteration (per standing pacing preference). Find the next candidate via `grep -L "^date-last-perfect" words/*.md`, sorted alphabetically by filename (Unicode/`LC_ALL=C` order), continuing from the last-processed filename's position in that sort. Check the word's own `characters:` constituents for a `stand_in` match (add the stand-in note if so), verify `羅馬字`/`諺文`/`注音` are the correct concatenation of each constituent's own fields, verify `kwin` via the AND-rule (all constituents' own `kwin` must be `true` for the compound to be `true`), fill blank cross-linguistic fields only when a real value can be verified (leave deliberately blank with a reason otherwise), and check for genuine Dan'a'yo-level homophones (not just same-spelling coincidences in a real language) before stamping `date-last-perfect`.

Next: 静寂.

### 2026-09-08, iteration 3556 — [[words/静寂|静寂]]
Legitimizing note added (静's own `stand_in` is [[静寂]] itself; 寂's own `stand_in` is [[寂滅]], so transitivity fails — no `#cranberry`). Pronunciation fields (jengjeg/정적/ㄐㄝㄫㄐㄝㄎ) and `kwin: true` (AND-rule: both constituents' own kwin true) already matched exactly — no bug. Confirmed `mandarin`'s two comma-joined tone variants (jìngjì, jìngjí) are both genuinely attested, not contamination. Both character pages already cited 静寂 correctly, 静's side with the `(stand-in for 静)` annotation. Filled blank `vietnamese: tĩnh tịch` — attested, mainly Buddhist register, noting Chinese/Vietnamese also freely reverse the order (寂静/tịch tĩnh, corresponding to the vault's own separate [[寂静]]). Removed blank `hsk_level`/`swadesh`, converted flow-style `aliases` to block-list. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 非常.

### 2026-09-08, iteration 3557 — [[words/非常|非常]]
No cranberry (非's own `stand_in` is itself, 常's is [[日常]] — neither points here). **Found and fixed a real bug**: `羅馬字`/`諺文` had been contaminated to `pisyang`/`피샹` instead of the correct concatenation of 非's own stored fields (`fi`/`삐`) — confirmed against the already-correct [[非洲]]/[[南非]], both correctly preserving `fi`/`삐`. `注音` had already stayed correct. `kwin: false` already correct (AND-rule, both constituents false). Filled blank `vietnamese: phi thường` — confirmed standard, everyday term. **Fixed a malformed citation** on `characters/非 (char).md` (bare "[[非常]] ..." text lacking ruby markup, unlike its siblings) and **added a missing citation** to `characters/常.md`'s `## Words` list. Quoted `hsk_level`, removed blank `swadesh`/empty `aliases`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 面田.

### 2026-09-08, iteration 3558 — [[words/面田|面田]]
No cranberry (面's own `stand_in` is [[表面]], 田's is [[田野]] — neither points here; 面/田 serve as phonetic transliteration characters standing in for the real 緬甸's own 緬/甸). **Found and fixed a real bug**: `注音` had a wrong glyph in its first syllable (ㄇ⼔ㄋ using ⼔, instead of 面's own stored ⼶) — corrected to ㄇ⼶ㄋㄉㄝㄋ, matching `羅馬字`/`諺文`'s already-correct myenden/면던. The same wrong-glyph bug had propagated into both `characters/面.md`'s and `characters/田.md`'s existing citations — fixed both. `kwin: false` already correct (AND-rule). Confirmed all five real-language fields (Miǎndiàn/min5din6/めんでん/면전/Miến Điện) are the real reading of the actual word 緬甸, per the same convention as the 露-transliteration family — めんでん and 면전 verified as real, historically dated (1798/1930) readings, now superseded by ミャンマー/미얀마 respectively but still correct as documented. Removed the redundant duplicate `品詞` field (kept `pos`). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 革命.

### 2026-09-08, iteration 3559 — [[words/革命|革命]]
No cranberry (革's own `stand_in` is [[皮革]], 命's is [[運命]] — neither points here). **Found and fixed a real bug**: `羅馬字` had been contaminated to `gagmyeng` instead of the correct concatenation of 革's own stored field (`kig`) — `諺文`/`注音` had already stayed correct (킥명/ㄎㄧㄎㄇ⼶ㄫ). `kwin: false` already correct (AND-rule: 革 false, 命 true). Both character pages already cited 革命 correctly. Confirmed `vietnamese`'s two comma-joined forms (cách mệnh, cách mạng) are both genuinely attested — modern standard vs. older literal reading — not contamination. Removed blank `hsk_level`/`swadesh`/empty `aliases`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 鞀鼓.

### 2026-09-08, iteration 3560 — [[words/鞀鼓|鞀鼓]]
No cranberry (鞀's own `stand_in` is [[鞀鼓]] itself — already documented in this file's pre-existing Notes; 鼓's own `stand_in` is 鼓 itself, so transitivity fails). Pronunciation fields (daugo/닷고/ㄉㄚㄨㄍㄛ) and `kwin: false` already matched constituents exactly — no bug. **Added missing "(stand-in for 鞀)" annotation** to `characters/鞀.md`'s existing citation (鼓's own citation needs none, correctly). Filled blank `vietnamese: đào cổ` — confirmed real, attested term for the same classical pellet-drum instrument. Quoted/reformatted `mandarin`/`cantonese`/`korean` for consistency. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 鞍装.

### 2026-09-08, iteration 3561 — [[words/鞍装|鞍装]]
Legitimizing note added (鞍's own `stand_in` is [[鞍装]] itself; 装's own `stand_in` is [[装]] itself, so transitivity fails — no `#cranberry`). `羅馬字`/`諺文` ('anjwang/안좡) already correctly matched constituents. **Found and fixed three real bugs**: `mandarin` had held [[鞍子]]'s own reading (ānzi) instead of this compound's own (ānzhuāng, a real attested term for "saddle equipment"); `japanese` had held 鞍's bare native reading (くら) instead of the compound's own on'yomi (あんそう, confirmed real via horse-racing terminology 装鞍所); `注音` had a spurious extra ㄋ before the final ㄫ, also propagated into both character pages' citations — all three fixed. Filled blank `cantonese: on1 zong1` and `vietnamese: yên ngựa` (the horse-specific term, vs. the more bicycle-associated yên xe). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 鞭打.

### 2026-09-08, iteration 3562 — [[words/鞭打|鞭打]]
No cranberry (打's own `stand_in` is [[打撃]], not this word — transitivity fails; 鞭's own `stand_in` is [[鞭打]] itself, already documented in the file's pre-existing Notes bullet). Pronunciation fields (byenda/변다/ㄅ⼶ㄋㄉㄚ) and `kwin: false` already matched constituents exactly — no bug. **Added missing "(stand-in for 鞭)" annotation** to `characters/鞭.md`'s existing citation (打's own citation needs none, correctly). All real-language fields (biāndǎ/bin1daa2/べんだ/편타/tiên đả) confirmed already correct, standard/attested words — a clean case. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check (grep hung briefly on the CJK glyphs, resolved via task notification) found no collision.

Next: 韓国.

### 2026-09-08, iteration 3563 — [[words/韓国|韓国]]
Legitimizing note added (韓's own `stand_in` is [[韓国]] itself; 国's own `stand_in` is [[国家]], so transitivity fails — no `#cranberry`). Pronunciation fields (hangog/한곡/ㄏㄚㄋㄍㄛㄎ) and `kwin: false` already matched constituents exactly — no bug. Both character pages already cited 韓国 correctly, 韓's side with the `(stand-in for 韓)` annotation. All real-language fields (Hánguó/hon4gwok3/かんこく/한국/Hàn Quốc) already correct, standard words in full agreement across all five languages — a clean case; just needed the Notes section written. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 韓国語.

### 2026-09-08, iteration 3564 — [[words/韓国語|韓国語]]
No cranberry (no constituent's own `stand_in` points here — 韓's is [[韓国]], 国's is [[国家]], 語's is [[言語]]). Pronunciation fields (hangog'yo/한곡요/ㄏㄚㄋㄍㄛㄎ·⼄) and `kwin: false` already matched constituents exactly — no bug. **Found and fixed two real bugs**: `mandarin` had held the shorter [[韓語]]'s own colloquial reading (Hányǔ) instead of this compound's own official/textbook term (Hánguóyǔ, distinct from 朝鮮語 for North Korean usage); `cantonese` was likewise missing the middle `gwok3` syllable (hon4jyu5 → hon4gwok3jyu5). **Added a missing citation** to `characters/韓.md`'s `## Words` list (国's/語's own lists already had it). Confirmed `vietnamese: tiếng Hàn Quốc` (fuller/precise form vs. colloquial tiếng Hàn) correctly matches this word's own "(South)" sense. Background exact-match homophone check (hung briefly on a plain-ASCII pattern for unclear reasons, resolved via task notification) found no collision. Stamped `date-last-perfect: 2026-09-08`.

Next: 韓服.

### 2026-09-08, iteration 3565 — [[words/韓服|韓服]]
No cranberry (韓's own `stand_in` is [[韓国]], 服's is [[服事]] — neither points here). Pronunciation fields (hanbug/한북/ㄏㄚㄋㄅㄨㄎ) and `kwin: false` already matched constituents exactly — no bug (한북 uses 服's own Dan'a'yo-derived 북, correctly distinct from real Korean's 한복). Both character pages already cited 韓服 correctly. Fixed `vietnamese`: was the bare English/Korean loanword "Hanbok" — replaced with the formal Sino-Vietnamese term Hàn phục (paralleling áo dài/sườn xám/kimono as national-dress terms), documenting that the loanword Hanbok remains more common in everyday use. Documented that Japanese real usage borrows the Korean pronunciation directly as ハンボク rather than using compositional on'yomi かんふく. Removed blank `hsk_level`/`swadesh`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 韮金.

### 2026-09-08, iteration 3566 — [[words/韮金|韮金]]
韮金 is 韮's own legitimizing compound (韮's `stand_in` points here, already noted in its own citation); 金's own `stand_in` is 金 itself, so transitivity fails, no `#cranberry`. Pronunciation fields (gyugim/규김/ㄍ⼜ㄍㄧㄇ) and `kwin: false` already correct. Per this neologism series' established convention (cf. [[丹金]], [[霓金]], [[露金]], [[青素]]), verified `mandarin`/`cantonese` (pǔ/pou2) correctly hold the real avoided element character's (镨/鐠) own reading — no bug found, a clean case. 韮's own citation already correctly annotated; 金 (char).md's citation gap is part of the already-documented ~55-file backlog. Removed the redundant duplicate `品詞` field (kept `pos`). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check (hung again on this environment, resolved via task notification) found no collision.

Next: 音声.

### 2026-09-08, iteration 3567 — [[words/音声|音声]]
No cranberry (音's own `stand_in` is [[音楽]], 声's is [[発声]] — neither points here). Pronunciation fields ('umsing/움싱/ㄨㄇㄙㄧㄫ) already matched constituents exactly — **added entirely missing `kwin: false`** (AND-rule, both constituents false). Fixed comma-joined native-synonym contamination in `korean` (음성, 말소리 → 음성 alone), documenting 말소리 as the native Korean alternative in Notes. Filled blank `vietnamese: âm thanh` — the ordinary, everyday Vietnamese word for "sound." Both character pages already cited 音声 correctly. Quoted `hsk_level`, converted flow-style `aliases` to block-list, removed blank `swadesh`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 音律.

### 2026-09-08, iteration 3568 — [[words/音律|音律]]
No cranberry (音's own `stand_in` is [[音楽]], 律's is [[法律]] — neither points here). Pronunciation fields ('umlud/움룯/ㄨㄇㄌㄨㄊ) and `kwin: false` already matched constituents exactly — no bug. Confirmed `korean: 음률` is correctly unshifted (no 렬/률→열/율 rule application, since 음 ends in ㅁ not a vowel/ㄴ) — not a bug. All other real-language fields (yīnlǜ/jam1leot6/おんりつ/âm luật) already correct standard terms for musical temperament/rhythm. **Added missing citation** to `characters/律.md`'s `## Words` list (音's own list already had it). Removed empty `aliases: []`, blank `hsk_level`/`swadesh`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 音波.

### 2026-09-08, iteration 3569 — [[words/音波|音波]]
No cranberry (音's own `stand_in` is [[音楽]], 波's is [[波浪]] — neither points here). Pronunciation fields ('umba/움바/ㄨㄇㄅㄚ) and `kwin: false` already matched constituents exactly — no bug. Both character pages already cited 音波 correctly. All real-language fields (yīnbō/jam1bo1/おんぱ/음파/âm ba) already correct standard words for "soundwave" — a clean case. Reformatted cantonese spacing, removed empty `aliases: []`/blank `hsk_level`/`swadesh`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 音程.

### 2026-09-08, iteration 3570 — [[words/音程|音程]]
No cranberry (音's own `stand_in` is [[音楽]], 程's is [[程度]] — neither points here). Pronunciation fields ('umding/움딩/ㄨㄇㄉㄧㄫ) and `kwin: false` already matched constituents exactly — no bug (おんてい confirmed correct: 程's own on'yomi is genuinely TEI). **Added missing citation** to `characters/程.md`'s `## Words` list (音's own list already had it). Filled blank `vietnamese: âm trình` — confirmed real, attested academic music-theory term (paralleling more common quãng âm). Removed empty `aliases: []`, blank `hsk_level`/`swadesh`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 音符.

### 2026-09-08, iteration 3571 — [[words/音符|音符]]
No cranberry (音's own `stand_in` is [[音楽]], 符's is [[符号]] — neither points here). Pronunciation fields ('umbu/움부/ㄨㄇㄅㄨ) and `kwin: false` already matched constituents exactly — no bug. Confirmed `korean: 음부` is a genuine real synonym of the more common 음표, not a bug. Both character pages already cited 音符 correctly. Filled blank `vietnamese: âm phù` — confirmed real, attested term. Incorporated the file's leftover raw `opposite 意符` note into proper Notes prose, documenting 音符's distinct linguistic sense ("phonetic component" vs. 意符 "semantic component" of a character) and flagging that 意符 has no vault word page yet. Removed empty `aliases: []`, blank `hsk_level`/`swadesh`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found only an expected substring hit within [[注音符号]]'s own longer compound — no genuine collision.

Next: 音節.

### 2026-09-08, iteration 3572 — [[words/音節|音節]]
No cranberry (音's own `stand_in` is [[音楽]], 節's is 節 itself — neither points here). Pronunciation fields ('umjed/움젇/ㄨㄇㄐㄝㄊ) and `kwin: false` already matched constituents exactly — no bug. Both character pages already cited 音節 correctly. **Found and fixed a real bug**: `aliases` had wrongly listed 音節 (the headword's own traditional form, identical to the filename) as an alias of itself — trimmed to just the genuine simplified variant 音节. All real-language fields (yīnjié/jam1zit3/おんせつ/음절/âm tiết) already correct standard words for "syllable" — a clean case otherwise. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 音素.

### 2026-09-08, iteration 3573 — [[words/音素|音素]]
No cranberry (音's own `stand_in` is [[音楽]], 素's is [[要素]] — neither points here). Pronunciation fields ('umso/움소/ㄨㄇㄙㄛ) and `kwin: false` already matched constituents exactly — no bug. **Found and fixed a real bug**: `japanese` had いんそ, using 音's secondary on'yomi IN instead of the compound's correct primary reading ON — confirmed おんそ is the sole correct linguistics reading, いんそ explicitly non-standard. Both character pages already cited 音素 correctly. All other real-language fields (yīnsù/jam1sou3/음소/âm tố) already correct standard terms for "phoneme." Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 音韻.

### 2026-09-08, iteration 3574 — [[words/音韻|音韻]]
No cranberry (音's own `stand_in` is [[音楽]], 韻's is [[押韻]] — neither points here). Pronunciation fields ('um'un/움운/ㄨㄇㄨㄋ) already matched constituents exactly — **added entirely missing `kwin: false`** (AND-rule: 音 false, 韻 true). **Found and fixed a real bug**: `vietnamese` had held "Âm vị," which is actually derived from the different compound 音位 ("phoneme," using 位) rather than 音韻 (韻's own vietnamese field is vần/vận) — corrected to the compositionally accurate âm vận. Fixed comma-joined native-synonym contamination in `korean` (음운, 목소리 → 음운 alone). Documented the systemic "phonology" sense of 音韻 vs. [[音素]]'s more individual "phoneme" sense, adding `phonology` to `english`. Both character pages already cited 音韻 correctly. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 韻母.

### 2026-09-08, iteration 3575 — [[words/韻母|韻母]]
No cranberry (韻's own `stand_in` is [[押韻]], 母's is [[母親]] — neither points here). Pronunciation fields ('unmou/운못/ㄨㄋㄇㄛㄨ) and `kwin: false` already matched constituents exactly — no bug. **Found and fixed a real bug**: `cantonese` had `wan5` instead of 韻's own stored jyutping `wan6` — corrected to `wan6 mou5`. Both character pages already cited 韻母 correctly. All other real-language fields (yùnmǔ/いんぼ/운모/vận mẫu) already correct standard terms for the phonological "final/rime." Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 頂点.

### 2026-09-08, iteration 3576 — [[words/頂点|頂点]]
Legitimizing note added (頂's own `stand_in` is [[頂点]] itself; 点's own `stand_in` is 点 itself, so transitivity fails — no `#cranberry`). Pronunciation fields (jengdem/정덤/ㄐㄝㄫㄉㄝㄇ) and `kwin: false` already matched constituents exactly — no bug. Both character pages already cited 頂点 correctly, 頂's side with the `(stand-in for 頂)` annotation. Filled blank `vietnamese: đỉnh điểm` — confirmed standard, everyday term. Fixed `characters:` disambiguation-suffix mismatch (点→点 (char)). A clean case otherwise — all real-language fields already correct standard words. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 頃.

### 2026-09-08, iteration 3577 — [[words/頃|頃]]
Legitimizing note added (this bare-character word is 頃's own legitimizer, `stand_in` points here). Pronunciation fields (keng/컹/ㄎㄝㄫ) already matched the character's own stored values exactly — no bug. **Found and fixed the literal-"null"-string bug** in `vietnamese` — replaced with `khoảnh` (attested, e.g. in khoảnh khắc "an instant"). Added entirely missing `kwin: false`, `pos: 名詞`, and `japanese: ころ` (documenting that this character functions as a standalone word almost exclusively via its native kun'yomi, not on'yomi ケイ). Fixed heading level (`# Notes`→`## Notes`) and the character page's own citation annotation (was "(stand-in for 頃 (char))", now the conventional "(stand-in for 頃)"). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found a shared syllable with [[傾]] (also ㅋㅔㅇ/ㄎㄝㄫ), but 傾's own `stand_in` is [[傾向]], not itself — no genuine word-level collision.

Next: 順序.

### 2026-09-08, iteration 3578 — [[words/順序|順序]]
Legitimizing note added (序's own `stand_in` is [[順序]] itself; 順's own `stand_in` is [[順次]], so transitivity fails — no `#cranberry`; incorporated the file's leftover raw "Stand-in for [[序]]" note into proper Notes prose). Pronunciation fields (syunsyo/슌쇼/ㄙ⼜ㄋㄙ⼄) and `kwin: false` already matched constituents exactly — no bug. **Added missing "(stand-in for 序)" annotation** to `characters/序.md`'s existing citation (順's own citation needs none, correctly). Filled blank `vietnamese: thuận tự` — confirmed real, attested term (alongside the more everyday native thứ tự). A clean case otherwise — all other real-language fields already correct standard words. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 順次.

### 2026-09-08, iteration 3579 — [[words/順次|順次]]
Legitimizing note added (順's own `stand_in` is [[順次]] itself, already annotated in its own citation; 次's own `stand_in` is [[次第]], so transitivity fails — no `#cranberry`; incorporated the file's leftover raw "Stand-in for [[順]]" note into proper Notes prose). Pronunciation fields (syunciǝ/슌츼/ㄙ⼜ㄋㄑㄧㄜ) and `kwin: false` already matched constituents exactly — no bug. Both character pages already cited 順次 correctly. Removed the redundant duplicate `品詞` field (kept `pos`). Filled blank `vietnamese: thuận thứ` — compositionally straightforward but not independently attested (modern Vietnamese uses native lần lượt/tuần tự instead). Removed blank `hsk_level`/`swadesh`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 頗.

### 2026-09-08, iteration 3580 — [[words/頗|頗]]
Legitimizing note added (this bare-character word is 頗's own legitimizer, `stand_in` points here; already annotated on the character's own citation). Pronunciation fields (fa/빠/ㄈㄚ) already matched the character's own stored values exactly — no bug (deliberately vacant-syllable-filling, not derived from real readings). Added entirely missing `pos: 修飾語`, `japanese: は` (documenting real Japanese more commonly uses native すこぶる), and `vietnamese: phả`. Reformatted `mandarin`'s two space-separated tone variants to comma-separated (both genuinely attested — pō standard, pǒ archaic/Classical). Fixed heading level (`# Notes`→`## Notes`). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found only the character's own page (expected), no genuine collision.

Next: 領土.

### 2026-09-08, iteration 3581 — [[words/領土|領土]]
Legitimizing note added (領's own `stand_in` is [[領土]] itself, already annotated in its own citation; 土's own `stand_in` is 土 itself, so transitivity fails — no `#cranberry`). Pronunciation fields (lingto/링토/ㄌㄧㄫㄊㄛ) and `kwin: false` already matched constituents exactly — no bug. **Found and fixed a real bug**: `korean` had 령토 (North Korean orthography) instead of the South Korean standard 영토, matching the same fix pattern as [[霊魂]]→영혼/[[霊柩]]→영구. **Added missing citation** to `characters/土 (char).md`'s `## Words` list (領's own list already had it). Fixed `characters:` disambiguation-suffix mismatch (土→土 (char)). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 頬.

### 2026-09-08, iteration 3582 — [[words/頬|頬]]
Legitimizing note added (this bare-character word is 頬's own legitimizer, `stand_in` points here; already annotated on the character's own citation). Pronunciation fields (geb/겁/ㄍㄝㄆ) already matched the character's own stored values exactly — no bug. **Found and fixed the literal-"null"-string bug** in `vietnamese` — replaced with `giáp` (the character's own stored reading). Added entirely missing `pos: 名詞` and `japanese: きょう` (matching the precedent already set on the reciprocal homophone [[鋏]], documenting native ほお as the everyday reading). Fixed heading level (`# Notes`→`## Notes`) and `characters:` unquoted-scalar format. Stamped `date-last-perfect: 2026-09-08`. Confirmed the existing [[鋏]] homophone callout remains correctly reciprocal — no new collisions.

Next: 頭.

### 2026-09-08, iteration 3583 — [[words/頭|頭]]
Legitimizing note added (this bare-character word is 頭's own legitimizer, `stand_in` points here; already annotated on the character's own citation). Pronunciation fields (tou/톳/ㄊㄛㄨ) already matched the character's own stored values exactly — no bug. Added entirely missing `pos: 名詞`, `japanese: あたま` (the ordinary native word; on'yomi とう/ず survive only bound), and `vietnamese: đầu`. **In passing**, filled a real gap on `characters/頭 (char).md`: `japanese_native` was stored as `ø` despite あたま/かしら being well-attested — added both. **Discovered and documented a genuine 3-way Dan'a'yo homophone cluster**: 頭/[[套]]/[[透]] all share 톳/ㄊㄛㄨ and are each their own legitimizer — none had been cross-referenced before (套 was already fully perfected but missing this; 透 not yet perfected). Added reciprocal `>[!warning] Homophones` callouts to all three files (透's other bugs left for when the sweep naturally reaches it). Stamped `date-last-perfect: 2026-09-08` on 頭.

Next: 頭骨.

### 2026-09-08, iteration 3584 — [[words/頭骨|頭骨]]
No cranberry (both 頭's and 骨's own `stand_in` are themselves). **Found and fixed a real bug**: `諺文`/`注音` had both been contaminated to a wrong-vowel form of 骨's syllable (굳/ㄍㄨㄊ instead of correct 곧/ㄍㄛㄊ) — `羅馬字` had already stayed correct (tougod). The same error had propagated into `characters/骨 (char).md`'s existing citation — fixed there too. `kwin: false` already correct. Both character pages already cited 頭骨 correctly (skulls-side annotation none needed). Filled blank `vietnamese: đầu cốt` — attested medical/anatomical term, everyday Vietnamese preferring native sọ/hộp sọ. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 頻.

### 2026-09-08, iteration 3585 — [[words/頻|頻]]
Legitimizing note added (this bare-character word is 頻's own legitimizer, `stand_in` points here; already annotated on the character's own citation). Pronunciation fields (pim/핌/ㄆㄧㄇ) already matched the character's own stored values exactly — no bug. Added entirely missing `kwin: false`, `pos: 修飾語`, and `japanese: ひん` (documenting native しきりに as the everyday word). `vietnamese: tần` was already correctly filled. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 題目.

### 2026-09-08, iteration 3586 — [[words/題目|題目]]
No cranberry (題's own `stand_in` is [[標題]], 目's is 目 itself — neither points here). Pronunciation fields (teimug/테묵/ㄊㄝㄧㄇㄨㄎ) and `kwin: false` already matched constituents exactly — no bug (だいもく confirmed correct: 題's own on'yomi is genuinely DAI, not TEI, distinct from its Dan'a'yo romanization). Both character pages already cited 題目 correctly. A clean case — all real-language fields (tímù/tai4muk6/だいもく/제목/đề mục) already correct standard words. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 額頭.

### 2026-09-08, iteration 3587 — [[words/額頭|額頭]]
Legitimizing note added (額's own `stand_in` is [[額頭]] itself, already annotated in its own citation; 頭's own `stand_in` is 頭 itself, so transitivity fails — no `#cranberry`). Pronunciation fields ('agtou/악톳/ㄚㄎㄊㄛㄨ) and `kwin: false` already matched constituents exactly — no bug. Both character pages already cited 額頭 correctly. Confirmed `japanese`/`korean`/`vietnamese` (ひたい/이마/trán) are correctly native forms, not compositional-reading bugs — none of the three languages has a live Sino-derived compound for "forehead," documented in Notes. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 顔色.

### 2026-09-08, iteration 3588 — [[words/顔色|顔色]]
No cranberry (顔's own `stand_in` is [[顔面]], 色's is [[色彩]] — neither points here). **Found and fixed a real bug**: `cantonese` had `yan2 se2`, an invalid non-jyutping romanization unrelated to either constituent — corrected to `ngaan4 sik1`, matching 顔's own `ngaan4` and 色's own `sik1`. Pronunciation fields ('ansig/안식/ㄚㄋㄙㄧㄎ) and `kwin: false` already matched constituents exactly. Filled blank `vietnamese: nhan sắc` — real and attested but narrowed specifically to "(a woman's) beauty" rather than the broader "complexion" sense elsewhere. **Fixed a malformed citation** on `characters/顔.md` (bare "[[顔色]] - complexion" lacking ruby/bopomofo, unlike its siblings; 色's own citation was already correctly formatted). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 顔面.

### 2026-09-08, iteration 3589 — [[words/顔面|顔面]]
Legitimizing note added (顔's own `stand_in` is [[顔面]] itself; 面's own `stand_in` is [[表面]], so transitivity fails — no `#cranberry`). Pronunciation fields ('anmyen/안면/ㄚㄋㄇ⼶ㄋ) already matched constituents exactly — **added entirely missing `kwin: true`** (AND-rule: both constituents' own kwin true, a rarer case). Fixed comma-joined native-synonym contamination in `korean` (안면, 얼굴, 낯 → 안면 alone). Confirmed `vietnamese: mặt` is correct as-is (native, no live Sino "nhan diện" attested). **Fixed a malformed citation** on `characters/顔.md` (bare "[[顔面]] - face" lacking ruby/bopomofo and the "(stand-in for 顔)" annotation it needs). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 顕現.

### 2026-09-08, iteration 3590 — [[words/顕現|顕現]]
No cranberry (顕's own `stand_in` is [[顕著]], 現's is 現 itself — neither points here). Pronunciation fields (henhyen/헌현/ㄏㄝㄋㄏ⼶ㄋ) and `kwin: false` already matched constituents exactly — no bug. Both character pages already cited 顕現 correctly. A clean case — all real-language fields (xiǎnxiàn/hin2jin6/けんげん/현현/hiển hiện) already correct standard terms, often in philosophical/religious registers. Removed blank `hsk_level`/`swadesh`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 顕示.

### 2026-09-08, iteration 3591 — [[words/顕示|顕示]]
No cranberry (顕's own `stand_in` is [[顕著]], 示's is [[開示]] — neither points here). Pronunciation fields (henge/헌거/ㄏㄝㄋㄍㄝ) already matched constituents exactly — **added entirely missing `kwin: false`**. **Found and fixed a real bug**: `cantonese` had `xian3 si4`, garbled pinyin-like text unrelated to either constituent's own jyutping — corrected to `hin2 si6`. Filled entirely blank `japanese: けんじ` and `korean: 현시` (both confirmed real, attested). `vietnamese: hiển thị` was already correctly filled (a common technical-display term today). Both character pages already cited 顕示 correctly. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 願意.

### 2026-09-08, iteration 3592 — [[words/願意|願意]]
Legitimizing note added (願's own `stand_in` is [[願意]] itself; 意's own `stand_in` is [[意味]], so transitivity fails — no `#cranberry`). Pronunciation fields ('wen'ǝ/원으/⼔ㄋㄜ) already matched constituents exactly — **added entirely missing `kwin: false`**. Both character pages already cited 願意 correctly, 願's side with the `(stand-in for 願)` annotation. Confirmed `japanese: がんい` is real but carries a narrower "content of a wish/petition" sense (formal/religious register) rather than plain "willing." Filled blank `vietnamese: nguyện ý` — confirmed real, standard term. `korean: 원의` already correctly filled. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 顚癇.

### 2026-09-08, iteration 3593 — [[words/顚癇|顚癇]]
**Added missing `#cranberry` tag**: both 顚's own `stand_in` and 癇's own `stand_in` point here to 顚癇 itself (A=B=AB, full transitivity) — neither character can stand alone, yet the tag was absent. **Found and fixed a real bug**: `羅馬字` had `dinhan` instead of the correct concatenation of 顚's own stored field (`den`) — `諺文`/`注音` had already stayed correct. Added entirely missing `kwin: false`. Fixed comma-joined contamination in `korean` (간질, 땡깡 → 간질 alone) — documented that 땡깡, though genuinely borrowed from Japanese てんかん, has fully shifted meaning to "tantrum" in modern Korean and is discouraged slang, not interchangeable with 간질. Confirmed `vietnamese: điên giản` is compositionally exact but not the standard medical term (native động kinh is standard). Both character pages already correctly cited and annotated. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 類人猿.

### 2026-09-08, iteration 3594 — [[words/類人猿|類人猿]]
No cranberry (no constituent's own `stand_in` points here). Pronunciation fields (luinin'on/뤼닌온/ㄌㄨㄧㄋㄧㄋㄛㄋ) and `kwin: false` already matched constituents exactly — no bug. **Found and fixed a real bug**: `japanese` had るいじんゑん, using the obsolete kana ゑ (abolished 1946) instead of modern え. Confirmed `korean: 유인원` is correct (류→유 word-initial 두음법칙). Filled blank `vietnamese: vượn người` — native, reversed-order standard term (no live Sino equivalent). **Added missing citation** to `characters/人 (char).md`'s `## Words` list and **fixed a malformed citation** on `characters/猿.md` (bare "[[類人猿]] - simian" lacking ruby/bopomofo). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 類似.

### 2026-09-08, iteration 3595 — [[words/類似|類似]]
No cranberry (類's own `stand_in` is [[種類]], 似's is 似 itself — neither points here). Pronunciation fields (luisa/뤼사/ㄌㄨㄧㄙㄚ) already matched constituents exactly — **added entirely missing `kwin: false`**. Fixed comma-joined native-synonym contamination in `korean` (유사,비슷 → 유사 alone). Fixed `characters:` disambiguation-suffix mismatch (似→似 (char)). Filled blank `vietnamese: loại tự` — compositionally straightforward but not independently attested; documented that the actual standard Vietnamese term, tương tự, is built on the different compound 相似 rather than 類似's own characters. Both character pages already cited 類似 correctly. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 類似格.

### 2026-09-08, iteration 3596 — [[words/類似格|類似格]]
No cranberry (no constituent's own `stand_in` points here). Pronunciation fields (luisagag/뤼사각/ㄌㄨㄧㄙㄚㄍㄚㄎ) and `kwin: false` already matched constituents exactly — no bug. All three character pages already cited 類似格 correctly. Filled blank `vietnamese: loại tự cách`, matching the established case-name convention (cf. [[呼格]] hô cách, [[属格]] thuộc cách) — this word names Dan'a'yo's own similative grammatical case, so the five real-language fields are compositional linguistic terminology rather than independently common words. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 風刺.

### 2026-09-08, iteration 3597 — [[words/風刺|風刺]]
No cranberry (both 風's and 刺's own `stand_in` are themselves). Pronunciation fields (fungcig/뿡칙/ㄈㄨㄫㄑㄧㄎ) and `kwin: false` already matched constituents exactly — no bug. Documented that this word is written with the alias 諷/讽 rather than bare 風, and that 諷 has its own distinct real-language readings for the "satirize" sense (fěng, phúng) differing from 風's own "wind" readings — a reading-split pattern. **Found and fixed real bugs**: `mandarin` had a spurious second variant `fèngcì` (諷 has no attested fèng reading) — trimmed to `fěngcì` alone; `english` had a typo (satarize→satirize). Filled blank `vietnamese: phúng thích` (attested, though châm biếm/trào phúng are more everyday). **In passing, fixed a real bug on `characters/風 (char).md`'s own self-citation** (showed ㄆㄨㄫ instead of the character's own stored ㄈㄨㄫ) **and on `words/風.md` itself** (same ㄆ→ㄈ typo, an already-stamped word page). Stamped `date-last-perfect: 2026-09-08` on 風刺. Background exact-match homophone check found no collision.

Next: 風潮.

### 2026-09-08, iteration 3598 — [[words/風潮|風潮]]
No cranberry (風's own `stand_in` is 風 itself, 潮's is [[潮汐]] — neither points here). Pronunciation fields (fungcau/뿡찻/ㄈㄨㄫㄑㄚㄨ) and `kwin: false` already matched constituents exactly — no bug. **Added missing "trend" to `english`** (already documented on the character page's own citation gloss, and confirmed the actual most common modern sense of 風潮). All real-language fields (fēngcháo/fung1ciu4/ふうちょう/풍조/phong trào) already correct — Vietnamese phong trào has narrowed specifically to the "movement, trend" sense and is one of the most common words in the language. Removed empty `aliases: []`, blank `hsk_level`/`swadesh`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 風笛.

### 2026-09-08, iteration 3599 — [[words/風笛|風笛]]
No cranberry (風's own `stand_in` is 風 itself, 笛's is [[口笛]] — neither points here). Pronunciation fields (fungdeg/뿡덕/ㄈㄨㄫㄉㄝㄎ) and `kwin: false` already matched constituents exactly — no bug. **Found and fixed a real bug**: `japanese` had バグパイプ (the bare English loanword) instead of the real, attested compositional alternate name ふうてき — confirmed both terms exist in Japanese, with バグパイプ more common in everyday use (documented in Notes). Confirmed `korean: 백파이프` (the loanword) is correct as-is — 풍적 exists but denotes wind-pipes more broadly, not the Scottish bagpipe specifically. `vietnamese: kèn túi` was already correct (native, no live Sino equivalent). Both character pages already cited 風笛 correctly. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 風采.

### 2026-09-08, iteration 3600 — [[words/風采|風采]]
Legitimizing note added (采's own `stand_in` is [[風采]] itself; 風's own `stand_in` is 風 itself, so transitivity fails — no `#cranberry`). Pronunciation fields (fungcai/뿡채/ㄈㄨㄫㄑㄚㄧ) already matched constituents exactly — **added entirely missing `kwin: false`**. **Fixed real empty-string bugs** in both `korean` and `vietnamese` (both `""`) — filled with confirmed real, standard terms 풍채 and phong thái. Removed the redundant duplicate `品詞` field (kept `pos`). Both character pages already cited 風采 correctly, 采's side with the `(stand-in for 采)` annotation. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 颯.

### 2026-09-08, iteration 3601 — [[words/颯|颯]]
Legitimizing note added (this bare-character word is 颯's own legitimizer, `stand_in` points here). Pronunciation fields (sab/삽/ㄙㄚㄆ) already matched the character's own stored values exactly — no bug. Added entirely missing `kwin: true` (matching the character's own kwin) and `japanese: さつ` (on'yomi, surviving mainly in 颯爽). **Added missing "(stand-in for 颯)" annotation** to the character's own citation. Fixed heading level (`# Notes`→`## Notes`). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 飛報.

### 2026-09-08, iteration 3602 — [[words/飛報|飛報]]
No cranberry (both 飛's and 報's own `stand_in` are themselves). **Found and fixed a real bug**: `羅馬字`/`諺文` had been contaminated to `pibau`/`피밧`, using 飛's other reading branch (ㄆㄧ, seen in [[飛行机]]/[[飛語]]) instead of this word's own primary branch — `注音` had already stayed correct (ㄈㄝㄧㄅㄚㄨ), confirmed against 飛's own citation of this exact word. `kwin: false` already correct. Both character pages already cited 飛報 correctly. Filled blank `vietnamese: phi báo` — confirmed real, attested term. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 飛机.

### 2026-09-08, iteration 3603 — [[words/飛机|飛机]]
No cranberry (飛's own `stand_in` is 飛 itself, 机's is [[机会]] — neither points here). **Found and fixed a real bug**: `羅馬字`/`諺文` had been contaminated to `pigiǝ`/`피긔`, using 飛's other reading branch (ㄆㄧ, seen in [[飛行机]]) instead of this word's own primary branch — confirmed via both 飛's and 机's own citations of this exact word. Added entirely missing `kwin: false`. Filled blank `korean: 비행기` (the real everyday word, built on the fuller 飛行機 rather than 飛机's own literal characters — same pattern as japanese ひこうき, already correctly filled). `vietnamese: phi cơ` already correctly matched 飛机's own literal characters. Both character pages already cited 飛机 correctly. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 飛行机.

### 2026-09-08, iteration 3604 — [[words/飛行机|飛行机]]
No cranberry (no constituent's own `stand_in` points here). Pronunciation fields (pihanggiǝ/피항긔/ㄆㄧㄏㄚㄫㄍㄧㄜ) and `kwin: false` already matched constituents exactly — confirmed correct as the ㄆㄧ-branch long form of [[飛机]] (verified via all three constituents' own citations). Filled blank `vietnamese: phi hành cơ` — compositionally straightforward but not independently attested (phi cơ or native máy bay are the actual Vietnamese terms). All three character pages already cited 飛行机 correctly. Removed empty `aliases: []`, blank `hsk_level`/`swadesh`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 飛語.

### 2026-09-08, iteration 3605 — [[words/飛語|飛語]]
No cranberry (飛's own `stand_in` is 飛 itself, 語's is [[言語]] — neither points here). Pronunciation fields (pi'yo/피요/ㄆㄧ·⼄) and `kwin: false` already matched constituents exactly — confirmed correct as the ㄆㄧ-branch (verified via both constituents' own citations). Both character pages already cited 飛語 correctly. Filled blank `vietnamese: phi ngữ` — confirmed real, attested term for "baseless rumor," matching the idiom 流言飛語/流言蜚語 already documented on the Japanese ひご side too. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 飛鳥.

### 2026-09-08, iteration 3606 — [[words/飛鳥|飛鳥]]
No cranberry (both 飛's and 鳥's own `stand_in` are themselves). **Found and fixed a real bug**: `羅馬字`/`諺文` had been contaminated to `picou`/`피촛`, using 飛's other reading branch (ㄆㄧ) instead of this word's own primary branch — confirmed via both 飛's and 鳥's own citations of this exact word (`注音` had already stayed correct). `kwin: false` already correct. Confirmed the three distinct `japanese` readings (ひちょう/とぶとり/あすか, including the special Asuka place-name reading) are all genuinely real and not contamination. Removed the redundant duplicate `品詞` field. Both character pages already cited 飛鳥 correctly. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 食堂.

### 2026-09-08, iteration 3607 — [[words/食堂|食堂]]
No cranberry (食's own `stand_in` is 食 itself, 堂's is [[会堂]] — neither points here). Pronunciation fields (sigdang/식당/ㄙㄧㄎㄉㄚㄫ) and `kwin: true` (AND-rule: both constituents' own kwin true) already matched constituents exactly — no bug. Both character pages already cited 食堂 correctly. Filled blank `vietnamese: thực đường` — compositionally straightforward but not independently attested (native nhà ăn or loanword căng tin are the actual Vietnamese terms). Removed empty `aliases: []`, blank `hsk_level`/`swadesh`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 食指.

### 2026-09-08, iteration 3608 — [[words/食指|食指]]
No cranberry (食's own `stand_in` is 食 itself, 指's is [[手指]] — neither points here). Pronunciation fields (sigjiǝ/식즤/ㄙㄧㄎㄐㄧㄜ) and `kwin: false` already matched constituents exactly — no bug. **Found and fixed a real bug**: `cantonese` had `si2 zi3`, matching neither constituent's own stored reading — corrected to `sik6 zi2`. Filled blank `vietnamese: thực chỉ` — confirmed real, attested term (also used to mean "number of diners"). Confirmed `japanese: しょくし` and `korean: 식지` are both real, formal alternatives to the more common native terms (人差し指/검지). Both character pages already cited 食指 correctly. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 食費.

### 2026-09-08, iteration 3609 — [[words/食費|食費]]
No cranberry (both 食's and 費's own `stand_in` are themselves). **Found and fixed a real bug**: `mandarin` had held the longer alias 伙食费's own reading (huǒ shí fèi, with an extra 伙) instead of this word's own two-character reading — corrected to `shífèi`. Pronunciation fields (sigfai/식빼/ㄙㄧㄎㄈㄚㄧ) already matched constituents exactly — **added entirely missing `kwin: false`**. Fixed comma-joined native-synonym contamination in `korean` (식비, 밥값 → 식비 alone). Filled blank `vietnamese: thực phí` — confirmed real, attested term. Both character pages already cited 食費 correctly. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 食酢.

### 2026-09-08, iteration 3610 — [[words/食酢|食酢]]
Legitimizing note added (酢's own `stand_in` is [[食酢]] itself; 食's own `stand_in` is 食 itself, so transitivity fails — no `#cranberry`). Pronunciation fields (sigjag/식작/ㄙㄧㄎㄐㄚㄎ) and `kwin: false` already matched constituents exactly — no bug. Confirmed a genuine reading-split on 酢: classical "toast" sense (zuò, matching its own Dan'a'yo derivation) vs. modern "vinegar" sense (merged with 醋's own cù/cou3 in Mandarin/Cantonese) — `mandarin: shí cù` was already correct for the vinegar sense (reformatted spacing); **filled blank `cantonese: sik6 cou3`** using the correct vinegar-sense reading, not 酢's own stored zok6. Confirmed `japanese: しょくす` (the official JAS 1979 term) and `korean: 식초` are both correct, using 酢's own real reading rather than the vault's Dan'a'yo derivation. Filled blank `vietnamese: thực thố` — compositionally straightforward but not independently attested (native giấm/giấm ăn are the actual terms). Both character pages already cited 食酢 correctly. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 飢餓.

### 2026-09-08, iteration 3611 — [[words/飢餓|飢餓]]
Confirmed existing `#cranberry` tag is correct: both 飢's own `stand_in` and 餓's own `stand_in` point here to 飢餓 itself (A=B=AB, full transitivity). Pronunciation fields (giǝ'a/긔아/ㄍㄧㄜ·ㄚ) already matched constituents exactly. **Found and fixed a real bug**: `cantonese` had `ei1 ngo6`, missing 飢's own initial `g` — corrected to `gei1 ngo6`. Added entirely missing `kwin: false`. Fixed comma-joined native-synonym contamination in `korean` (기아, 굶주림 → 기아 alone). Fixed `vietnamese` from the native đói to the compositionally-attested Sino form cơ ngạ, documenting đói as the everyday native word. **In passing**, removed a duplicate `品詞` field and fixed the heading level (`# Notes`→`## Notes`) on `characters/餓.md`. Both character pages already cited 飢餓 correctly. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 飯店.

### 2026-09-08, iteration 3612 — [[words/飯店|飯店]]
No cranberry (飯's own `stand_in` is [[米飯]], 店's is [[商店]] — neither points here). Pronunciation fields (bondem/본덤/ㄅㄛㄋㄉㄝㄇ) already matched constituents exactly — **added entirely missing `kwin: false`**. Filled blank `korean: 반점` and `vietnamese: phạn điếm` — confirmed both real; documented that Japanese はんてん and Korean 반점 have narrowed specifically to "Chinese restaurant," while Sino-Vietnamese phạn điếm keeps the fuller original "restaurant/hotel" range matching Mandarin. Both character pages already cited 飯店 correctly. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 飲.

### 2026-09-08, iteration 3613 — [[words/飲|飲]]
Legitimizing note added (this bare-character word is 飲's own legitimizer, `stand_in` points here). Pronunciation fields ('um/움/ㄨㄇ) already matched the character's own stored values exactly. **Found and fixed a real bug**: `kwin` was `true`, contradicting the character's own stored `kwin: false` — corrected to match. Added entirely missing `pos: 事詞`, `japanese: いん`, `korean: 음`, and `vietnamese: ẩm` (as in ẩm thực, "food and drink"). **Added missing self-citation** ("(stand-in for 飲)") to the character's own Words list. Fixed heading level (`# Notes`→`## Notes`). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found a shared syllable with [[音]] (also 'um/움/ㄨㄇ), but 音's own `stand_in` is [[音楽]], not itself — no genuine word-level collision.

Next: 飲食.

### 2026-09-08, iteration 3614 — [[words/飲食|飲食]]
No cranberry (both 飲's and 食's own `stand_in` are themselves). Pronunciation fields ('umsig/움식/ㄨㄇㄙㄧㄎ) and `kwin: false` already matched constituents exactly — no bug. Both character pages already cited 飲食 correctly. A clean case — all real-language fields (yǐnshí/jam2sik6/いんしょく/음식/ẩm thực) already correct standard everyday words. Fixed `characters:`/`aliases:` flow-style formatting. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found only an expected substring hit within [[飲食物]]'s own longer compound — no genuine collision.

Next: 飲食物.

### 2026-09-08, iteration 3615 — [[words/飲食物|飲食物]]
No cranberry (no constituent's own `stand_in` points here). Pronunciation fields ('umsigmud/움식묻/ㄨㄇㄙㄧㄎㄇㄨㄊ) and `kwin: false` already matched constituents exactly — no bug. All three character pages already cited 飲食物 correctly. Filled blank `cantonese: jam2 sik6 mat6` (compositional) and `vietnamese: ẩm thực vật` — compositionally exact but flagged as a real ambiguity risk, since it shares its last two syllables with 植物 (thực vật, "plant") and could be misparsed as "plant-based cuisine"; modern Vietnamese instead uses native phrases like đồ ăn thức uống. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 飽.

### 2026-09-08, iteration 3616 — [[words/飽|飽]]
Legitimizing note added (this bare-character word is 飽's own legitimizer, `stand_in` points here). Pronunciation fields (byau/뱟/ㄅ⼘ㄨ) already matched the character's own stored values exactly. **Found and fixed the literal-"null"-string bug** in `vietnamese` — replaced with `bão` (the character's own stored reading). Added entirely missing `pos: 性詞` and `japanese: ほう`. **Added missing self-citation** ("(stand-in for 飽)") to the character's own Words list. Fixed heading level (`# Notes`→`## Notes`). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found several syllable-mates (砲/包/表/俵/豹/胞/跑) but none is itself a legitimized single-character word — no genuine collision.

Next: 飽足.

### 2026-09-08, iteration 3617 — [[words/飽足|飽足]]
No cranberry (both 飽's and 足's own `stand_in` are themselves). Pronunciation fields (byaujog/뱟족/ㄅ⼘ㄨㄐㄛㄎ) already matched constituents exactly — **added entirely missing `kwin: false`**. Filled entirely blank `japanese: ほうそく`, `korean: 포족`, and `vietnamese: bão túc` (japanese/korean confirmed real and attested; vietnamese compositional but not independently attested, native no đủ/thỏa mãn are the actual terms). Fixed `characters:` disambiguation-suffix mismatch (飽→飽 (char), 足→足 (char)). Both character pages already cited 飽足 correctly. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 養成.

### 2026-09-08, iteration 3618 — [[words/養成|養成]]
No cranberry (養's own `stand_in` is [[養育]], 成's is 成 itself — neither points here). Pronunciation fields ('yangsing/양싱/⼘ㄫㄙㄧㄫ) and `kwin: false` already matched constituents exactly — no bug. Both character pages already cited 養成 correctly. Confirmed the existing [[陽性]] homophone callout remains correctly reciprocal on both pages. Filled blank `vietnamese: dưỡng thành` — confirmed real, attested term. A clean case otherwise. Stamped `date-last-perfect: 2026-09-08`.

Next: 養殖.

### 2026-09-08, iteration 3619 — [[words/養殖|養殖]]
No cranberry (養's own `stand_in` is [[養育]], 殖's is [[繁殖]] — neither points here). Pronunciation fields ('yangsig/양식/⼘ㄫㄙㄧㄎ) and `kwin: true` (AND-rule: both constituents' own kwin true) already matched constituents exactly — no bug. **Fixed non-standard homophone callout format** (was a bare "[!tip]" line) to the standard `>[!warning] Homophones` block on both this file and its reciprocal partner [[様式]] — confirmed the collision itself is genuine, matching pronunciation fields on both sides. Filled blank `vietnamese: dưỡng thực` — compositionally straightforward but not independently attested (native nuôi trồng is the actual term). Both character pages already cited 養殖 correctly. Stamped `date-last-perfect: 2026-09-08`.

Next: 養母.

### 2026-09-08, iteration 3620 — [[words/養母|養母]]
No cranberry (養's own `stand_in` is [[養育]], 母's is [[母親]] — neither points here). Pronunciation fields ('yangmou/양못/⼘ㄫㄇㄛㄨ) and `kwin: false` already matched constituents exactly — no bug. Both character pages already cited 養母 correctly. Filled blank `vietnamese: dưỡng mẫu` — confirmed real, standard, synonymous with the more everyday native mẹ nuôi. A clean case otherwise. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 養父.

### 2026-09-08, iteration 3621 — [[words/養父|養父]]
No cranberry (養's own `stand_in` is [[養育]], 父's is [[父親]] — neither points here). Pronunciation fields ('yangbu/양부/⼘ㄫㄅㄨ) and `kwin: true` (AND-rule: both constituents' own kwin true) already matched constituents exactly — no bug. Both character pages already cited 養父 correctly. Filled blank `vietnamese: dưỡng phụ` — confirmed real, standard formal/literary term (vs. everyday native cha nuôi). A clean case otherwise. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 養生.

### 2026-09-08, iteration 3622 — [[words/養生|養生]]
No cranberry (養's own `stand_in` is [[養育]], 生's is [[生活]] — neither points here). Pronunciation fields ('yangsang/양상/⼘ㄫㄙㄚㄫ) and `kwin: false` already matched constituents exactly — no bug. Both character pages already cited 養生 correctly. Filled blank `vietnamese: dưỡng sinh` — confirmed real, very common traditional-wellness term across all five languages (also used for concrete curing in Korean construction contexts). A clean case otherwise. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 養育.

### 2026-09-08, iteration 3623 — [[words/養育|養育]]
Legitimizing note added (養's own `stand_in` is [[養育]] itself, already annotated in its own citation; 育's own `stand_in` is 育 itself, so transitivity fails — no `#cranberry`). Pronunciation fields ('yang'yug/양육/⼘ㄫ⼜ㄎ) and `kwin: true` (AND-rule: both constituents' own kwin true) already matched constituents exactly — no bug. Both character pages already cited 養育 correctly. `vietnamese: dưỡng dục` was already correctly filled. A clean case otherwise — all real-language fields already correct standard words. Fixed `characters:`/`aliases:` flow-style formatting. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 餐.

### 2026-09-08, iteration 3624 — [[words/餐|餐]]
Legitimizing note added (this bare-character word is 餐's own legitimizer, `stand_in` points here). Pronunciation fields (can/찬/ㄑㄚㄋ) already matched the character's own stored values exactly. Added entirely missing `japanese: さん` (documenting native たべる as the everyday verb). Flattened `vietnamese` from a 3-item list (xan/san/xun) to the single representative `xan`, matching word-page convention (character pages document all attested forms; word pages pick one). **Fixed a malformed self-citation** on the character's own Words list (bare "[餐](words/餐.md)..." lacking ruby/bopomofo and the standard "(stand-in for 餐)" annotation format). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found syllable-mates 燦/竄 but neither is itself a legitimized single-character word — no genuine collision.

Next: 餓鬼.

### 2026-09-08, iteration 3625 — [[words/餓鬼|餓鬼]]
No cranberry (餓's own `stand_in` is [[飢餓]], 鬼's is [[鬼神]] — neither points here). Pronunciation fields ('agui/아귀/ㄚㄍㄨㄧ) and `kwin: true` (AND-rule: both constituents' own kwin true) already matched constituents exactly — no bug. A clean case — all real-language fields (èguǐ/ngo6gwai2/がき/아귀/ngạ quỷ) already correct standard Buddhist terms. **In passing, added an entirely missing `## Words` section** to `characters/餓.md`, which had none at all (citing both [[飢餓]] with its "(stand-in for 餓)" annotation and 餓鬼). Fixed `characters:` flow-style formatting. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 饅頭.

### 2026-09-08, iteration 3626 — [[words/饅頭|饅頭]]
Legitimizing note added (饅's own `stand_in` is [[饅頭]] itself, already annotated in its own citation; 頭's own `stand_in` is 頭 itself, so transitivity fails — no `#cranberry`). Pronunciation fields (mantou/만톳/ㄇㄚㄋㄊㄛㄨ) and `kwin: false` already matched constituents exactly — no bug. **Found and fixed a real bug**: `japanese` had まんぢゆう, mixing the historical kana ぢ with an outright typo (big ゆ instead of small ゅ) — corrected to modern standard まんじゅう. Documented a genuine semantic divergence: Japanese まんじゅう usually means a filled sweet bun, Korean 만두 has diverged further to mean dumplings generally, while Mandarin/Cantonese/Vietnamese keep the plain-bun sense. **In passing, fixed a wrong "wonton" gloss** on `characters/頭 (char).md`'s citation of this exact word (should say "steamed bun"). Quoted `hsk_level`, removed blank `swadesh`/empty `aliases`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 首尾.

### 2026-09-08, iteration 3627 — [[words/首尾|首尾]]
No cranberry (首's own `stand_in` is [[首長]], 尾's is 尾 itself — neither points here). Pronunciation fields (syumui/슈뮈/ㄙ⼜ㄇㄨㄧ) and `kwin: false` (AND-rule: both constituents' own kwin false) already matched constituents exactly — no bug. Verified `characters: [首, "尾 (char)"]` disambiguation was actually already correct (no `words/首.md` exists, so bare 首 is right; `words/尾.md` does exist, hence 尾's disambiguated citation). Both character pages already cited 首尾 correctly. Filled blank `vietnamese: thủ vĩ` — confirmed real literary/technical term (thủ vĩ tương ứng). Removed blank `hsk_level`/`swadesh`/empty `aliases`, consolidated Etymology into a proper `## Notes` section. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 首都.

### 2026-09-08, iteration 3628 — [[words/首都|首都]]
Re-perfected from an older stamp (`date-last-perfect: 2026-06-28`, pre-dating current conventions). Legitimizing note added (都's own `stand_in` is [[首都]] itself, already annotated in its own citation; 首's own `stand_in` is [[首長]], so transitivity fails — no `#cranberry`) — this was entirely missing from the existing Notes despite otherwise being a rich, well-written page. Pronunciation fields (syudo/슈도/ㄙ⼜ㄉㄛ) and `kwin: false` (AND-rule: 首 false, 都 true) already matched constituents exactly — no bug. `characters: [首, 都]` already correct (no `words/都.md` exists, so bare 都 is right). Both character pages already cited 首都 correctly. `vietnamese: thủ đô` already correctly filled. Left the page's existing detailed kwin-divergence paragraph intact (substantively correct, just an older stylistic convention). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found a substring false-positive (受動's 注音 ㄙ⼜ㄉㄛㄫ merely starts with ㄙ⼜ㄉㄛ) — not a genuine collision.

Next: 首長.

### 2026-09-08, iteration 3629 — [[words/首長|首長]]
Already well-perfected (stamped 2026-08-30): legitimizing note for 首 (首's own `stand_in` is [[首長]] itself; 長's own `stand_in` is 長 itself, so transitivity fails — no `#cranberry`) already correctly documented in Notes. Pronunciation fields (syujang/슈장/ㄙ⼜ㄐㄚㄫ) and `kwin: false` (AND-rule: 首 false, 長 true) already matched constituents exactly — no bug. `characters: [首, "長 (char)"]` disambiguation already correct (`words/長.md` does exist, confirming 長's disambiguated citation is required). Existing homophone warning with [[手掌]] (both ㄙ⼜ㄐㄚㄫ) already correctly documented as a genuine coincidence between two unrelated real words. **Found and fixed a real gap**: `characters/長 (char).md`'s own `## Words` list was entirely missing a citation of 首長 despite 首長 being one of its two-character compounds — added. No changes needed to the word file itself; left `date-last-perfect` as-is since the word page itself required no edits (only the character page's citation gap was fixed).

Next: 首領.

### 2026-09-08, iteration 3630 — [[words/首領|首領]]
Re-perfected from an old stamp (`date-last-perfect: 2026-05-26`). No cranberry (首's own `stand_in` is [[首長]], 領's is [[領土]] — neither points here). Pronunciation fields (syuling/슈링/ㄙ⼜ㄌㄧㄫ) and `kwin: false` (AND-rule: both constituents' own kwin false) already matched constituents exactly — no bug. Both character pages already cited 首領 correctly. All real-language fields (shǒulǐng/sau2 ling5/しゅりょう/수령/thủ lĩnh) and the rich Notes on 수령's historical use as Kim Il-sung's title were already correct and well-written — left as-is. **Fixed minor formatting**: quoted `mandarin`/`cantonese`/`korean` for consistency with current convention (were bare unquoted scalars). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found only an incidental mention in `lookup/Korean/Korea.md` (not a word/character page) — no genuine collision.

Next: 香気.

### 2026-09-08, iteration 3631 — [[words/香気|香気]]
Legitimizing note added (香's own `stand_in` is [[香気]] itself, already annotated in its own citation; 気's own `stand_in` is 気 itself, so transitivity fails — no `#cranberry`). Pronunciation fields (hyangkiǝ/향킈/ㄏ⼘ㄫㄎㄧㄜ) and `kwin: false` (AND-rule: 香 true, 気 false) already matched constituents exactly — no bug. `characters: [香, "気 (char)"]` disambiguation already correct (no `words/香.md` exists; `words/気.md` does). Both character pages already cited 香気 correctly. Filled blank `vietnamese: hương khí` — a real, if more literary/classical, Sino-Vietnamese term (everyday speech prefers native mùi hương/hương thơm). Removed blank `hsk_level`/`swadesh`, cleaned up a stray orphaned "positive connotation" fragment sitting outside any heading by writing it into a proper Notes sentence contrasting 香気 with neutral/negative smell-words. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 香港.

### 2026-09-08, iteration 3632 — [[words/香港|香港]]
No cranberry (香's own `stand_in` is [[香気]], 港's is [[港湾]] — neither points here). Pronunciation fields (hyanghong/향홍/ㄏ⼘ㄫㄏㄛㄫ) and `kwin: false` (AND-rule: 香 true, 港 false) already matched constituents exactly — no bug. Both character pages already cited 香港 correctly. **Investigated a suspected bug that turned out correct**: `korean: 향항` looked wrong at first (modern colloquial Korean says 홍콩) until cross-checking sibling toponym words [[北京]] (북경), [[東京]] (동경), [[上海]] (상해) confirmed this vault consistently records the classical/literary Sino-Korean hanja reading for CJK place names rather than the modern transliteration — documented this convention explicitly in Notes. `vietnamese: Hương Cảng` and `japanese: ホンコン` were already correctly filled. Removed blank `hsk_level`/`swadesh`/empty `aliases`, consolidated Etymology into a proper `## Notes` section. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 香芝.

### 2026-09-08, iteration 3633 — [[words/香芝|香芝]]
No cranberry (香's own `stand_in` is [[香気]], 芝's is the special `名専字` "name-only character" marker — neither points here). Pronunciation fields (hyangji/향지/ㄏ⼘ㄫㄐㄧ) and `kwin: true` (AND-rule: both constituents' own kwin true) already matched constituents exactly — no bug. Both character pages already cited 香芝 correctly. **Found and fixed a real bug**: `pos: 名詞` should be `固有名詞` (this is a proper-noun place name; cross-checked against sibling toponyms [[北京]], [[東京]], [[台湾]], [[上海]], [[香港]], all of which correctly use 固有名詞). Filled entirely missing `vietnamese: Hương Chi` (compositional Hán Việt, following the same always-fill convention already established for obscure toponyms like [[奈良]]'s Nại Lương). **Also fixed a wording slip** in the existing Notes ("The character 香芝 was added to the Jōyō kanji list" — should read "The character 芝", since 芝 alone is the late addition, not the two-character compound). Quoted `mandarin`/`cantonese`/`korean`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 香蒲.

### 2026-09-08, iteration 3634 — [[words/香蒲|香蒲]]
Legitimizing note added (蒲's own `stand_in` is [[香蒲]] itself, already annotated in its own citation; 香's own `stand_in` is [[香気]], so transitivity fails — no `#cranberry`) — the existing Notes already said this substantively, just reworded to match current convention phrasing. Pronunciation fields (hyangbo/향보/ㄏ⼘ㄫㄅㄛ) and `kwin: false` (AND-rule: 香 true, 蒲 false) already matched constituents exactly — no bug. Both character pages already cited 香蒲 correctly. Filled entirely missing `vietnamese: hương bồ` — confirmed real, attested Sino-Vietnamese name for cattail/Typha. **Fixed formatting**: `mandarin: xiāng pú` had a stray space (should be a single joined pinyin string `xiāngpú` per convention); quoted `mandarin`/`cantonese`/`korean`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 香蕉.

### 2026-09-08, iteration 3635 — [[words/香蕉|香蕉]]
No cranberry (香's own `stand_in` is [[香気]], 蕉's is [[甘蕉]] — neither points here). Pronunciation fields (hyangjou/향좃/ㄏ⼘ㄫㄐㄛㄨ) and `kwin: false` (AND-rule: 香 true, 蕉 false) already matched constituents exactly — no bug. `japanese: バナナ`/`korean: 바나나` (English loanwords) already correctly reflect real-world usage rather than compositional readings — bananas being a later-introduced fruit in Japan/Korea with no felt need for the Sino compound, while Mandarin/Cantonese 香蕉/hoeng1ziu1 are the genuine native terms. **Found and fixed a real gap**: `characters/蕉.md`'s own `## Words` list was missing a citation of 香蕉 (had only [[甘蕉]], its actual `stand_in`) — added. Filled entirely missing `vietnamese: hương tiêu` (compositional Hán Việt; documented that everyday Vietnamese instead uses the native word chuối, paralleling the JA/KO divergence). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 馬.

### 2026-09-09, iteration 3636 — [[words/馬|馬]]
Already well-perfected (stamped 2026-09-04): stand-in note, pronunciation fields (ma/마/ㄇㄚ), `kwin: true` (matches character's own kwin), and the existing 3-way homophone warning with [[碼]]/[[磨]] were all already correct — verified both are themselves legitimized words (own `stand_in` = themselves) with exact-matching ma/마/ㄇㄚ, confirming the collision is genuine. **Found and fixed a real bug** on `characters/馬 (char).md`: its `aliases` field wrongly included 瑪 ("agate", unrelated meaning) and 碼 ("yard", already separately and correctly listed in Derived Characters) — aliases should only hold true orthographic variants of 馬 itself (kept 马, the genuine simplified form; removed the other two, which are phonetic derivatives, not variants). Checked 魔/麻/罵/媽 (all same ㄇㄚ syllable) for a broader collision — none are themselves legitimized words (`stand_in` points elsewhere for all four), so no additional homophone. No changes needed to the word page itself.

Next: 馬上.

### 2026-09-09, iteration 3637 — [[words/馬上|馬上]]
No cranberry (both 馬's and 上's own `stand_in` point to themselves — neither points here). Pronunciation fields (masyang/마샹/ㄇㄚㄙ⼘ㄫ) and `kwin: false` (AND-rule: 馬 true, 上 false) already matched constituents exactly — no bug. **Decoded a stray design note**: an orphaned "not "immediately"" fragment sitting outside any heading turned out to be a real, important scope note — 馬上 very commonly means "immediately, right away" in colloquial modern Mandarin, but this Dan'a'yo word deliberately excludes that idiomatic extension and keeps only the literal "horseback" sense; wrote this up properly in Notes. Filled entirely missing `vietnamese: mã thượng` (compositional; noted everyday Vietnamese prefers the native phrase trên lưng ngựa). **Found and fixed two real bugs on `characters/上 (char).md`**: (1) its own `## Words` list was missing a citation of 馬上 entirely — added; (2) its Classical-Chinese-frequency line was malformed, with the initial/final wikilinks (聲 禪, 韻 陽開) dangling bare outside any sentence instead of the standard "Nth most used character..." template — reconstructed using its own `mc_id: 29`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 馬厩.

### 2026-09-09, iteration 3638 — [[words/馬厩|馬厩]]
Legitimizing note added (厩's own `stand_in` is [[馬厩]] itself; 馬's own `stand_in` is 馬 itself, so transitivity fails — no `#cranberry`). Pronunciation fields (magyu/마규/ㄇㄚㄍ⼜) and `kwin: false` (AND-rule: 馬 true, 厩 false) already matched constituents exactly — no bug. **Investigated and explained a real divergence**: `korean: 마구간` doesn't match compositional 마구 — cross-referenced `characters/厩.md`'s own `korean_native: 마구간` field and the alias `馬廏間`, confirming the actual real Korean word for "stable" is structurally the longer compound 馬廏間, not bare 馬厩; documented this in Notes rather than treating it as a bug. Filled blank `cantonese: maa5 gau3` and entirely missing `vietnamese: mã cứu` (compositional; noted everyday Vietnamese prefers native chuồng ngựa). Fixed a stray space in `mandarin: mǎ jiù`→`mǎjiù`. **In passing, fixed `characters/厩.md`'s own citation** of 馬厩, which was missing its "(stand-in for 厩)" annotation despite 厩's own `stand_in` pointing there. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 馬来西亜.

### 2026-09-09, iteration 3639 — [[words/馬来西亜|馬来西亜]]
No cranberry (none of the four constituents' own `stand_in` points here). Pronunciation fields (malaisei'a/마래세아/ㄇㄚㄌㄚㄧㄙㄝㄧ·ㄚ) and `kwin: false` (AND-rule: 馬 true, 来 true, 西 false, 亜 true) already matched constituents exactly — no bug. `characters: ["馬 (char)", "来 (char)", 西, 亜]` disambiguation already correct (`words/来.md` exists; `words/西.md`/`words/亜.md` don't). All four character pages already cited 馬来西亜 correctly. All real-language fields (Mandarin's dual-tone variant, Cantonese, Japanese/Korean English-loanword transliterations, Vietnamese's dual phonetic/Sino-Vietnamese forms) were already correctly filled — a clean case. Removed blank `hsk_level`/`swadesh`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found only an incidental mention in `lexipedia/Geography.md` (not a word/character page) — no genuine collision.

Next: 馬脚.

### 2026-09-09, iteration 3640 — [[words/馬脚|馬脚]]
No cranberry (both 馬's and 脚's own `stand_in` point to themselves — neither points here). Pronunciation fields (magyag/마갹/ㄇㄚㄍ⼘ㄎ) and `kwin: false` (AND-rule: both constituents' own kwin false/true → false) already matched constituents exactly — no bug. **Found and fixed a real disambiguation bug**: `characters: [馬, 脚]` used bare names despite `words/馬.md` and `words/脚.md` both existing (confirmed by the Etymology section already correctly linking to the disambiguated "馬 (char)"/"脚 (char)" pages) — fixed to match. Both character pages already cited 馬脚 correctly. All real-language fields (mǎjiǎo/maa5goek3/ばきゃく/마각/mã cước) were already correct standard readings. Removed blank `hsk_level`/`swadesh`, consolidated Etymology into a proper `## Notes` section. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 馬蹄.

### 2026-09-09, iteration 3641 — [[words/馬蹄|馬蹄]]
No cranberry (both 馬's and 蹄's own `stand_in` point to themselves — neither points here). Pronunciation fields (madei/마데/ㄇㄚㄉㄝㄧ) and `kwin: false` (AND-rule: 馬 true, 蹄 false) already matched constituents exactly — no bug. **Fixed the same disambiguation bug pattern as the previous two words**: `characters: [馬, 蹄]` used bare names despite both `words/馬.md`/`words/蹄.md` existing. **Explained a real divergence**: `korean: 말굽` is a native Korean compound (말 "horse" + 굽 "hoof"), not the Sino-Korean reading 마제 (confirmed via 蹄's own `korean`/`korean_native` fields) — 말굽 is genuinely the everyday term, 마제 being confined to technical compounds like 마제형. Filled entirely missing `vietnamese: mã đề`, documenting a real semantic narrowing: it names the plantain herb (leaf shaped like a hoofprint), not "horse hoof" literally. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 馬𡿺.

### 2026-09-09, iteration 3642 — [[words/馬𡿺|馬𡿺]]
Legitimizing note added (𡿺's own `stand_in` is [[馬𡿺]] itself, already annotated in its own citation; 馬's own `stand_in` is 馬 itself, so transitivity fails — no `#cranberry`). **Found and fixed a significant real bug spanning multiple files**: `characters/𡿺.md`'s own `羅馬字`/`諺文`/`注音` (nuo/눗/ㄋㄨㄛ) were an outlier inconsistent with every other `middle_chinese_final: ɑu` character in the entire vault, all of which map to Dan'a'yo "-au" — including its own semantic siblings [[脳 (char)|脳]]/[[悩 (char)|悩]] ("brain"/"angered"), both nau/낫/ㄋㄚㄨ. Corrected to nau/낫/ㄋㄚㄨ, which cascaded into: this word's own `羅馬字`/`諺文`/`注音` (mano/마노/ㄇㄚㄋㄛ → manau/마낫/ㄇㄚㄋㄚㄨ); `characters/馬 (char).md`'s citation of this word; a stray reference on `syllables/ㄍㄚ.md`'s entry for [[珂]] (another pageless "agate" name-only character that also points here); moved 𡿺 itself from the now-empty syllable page `ㄋㄨㄛ` (rewritten to size 0) into `ㄋㄚㄨ` (now size 3). Removed a duplicate `品詞: 名詞` field (redundant with `pos: 名詞`). All five real-language fields (mǎnǎo/maa5nou5/마노/めのう/mã não) were already correctly filled with the real "agate" word's readings, distinct from the constructed Dan'a'yo pronunciation — the vault represents this word with the rare/hapax placeholder 𡿺 rather than the common 瑪瑙 orthography, whose many spelling variants are recorded as aliases. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check on the corrected reading found no collision (all hits were this word's own touched files).

Next: 馳.

### 2026-09-09, iteration 3643 — [[words/馳|馳]]
Self-standing bare-character word (own `stand_in` is 馳 itself). Pronunciation fields (cǝ/츠/ㄑㄜ) and `kwin: false` already matched the character's own stored values exactly — no bug. Existing homophone warning with [[此]] confirmed genuine (its own `stand_in` is 此 itself, exact-matching cǝ/츠/ㄑㄜ). **Found and fixed a real gap**: `japanese` was entirely missing from the word's frontmatter — added `ち` (on'yomi, matching the vault's default convention for bare-character words, e.g. [[気]] き, [[長]] ちょう). **Fixed a malformed self-citation** on `characters/馳 (char).md`'s Words list (bare, non-ruby "[馳](words/馳.md)..." format instead of the standard `<ruby>...(stand-in for 馳)` template). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check confirmed no additional collision beyond the already-documented 此.

Next: 馿.

### 2026-09-09, iteration 3644 — [[words/馿|馿]]
Self-standing bare-character word (own `stand_in` is 馿 itself). **Found and fixed a cluster of real bugs**: `korean: "null"` was a literal string bug (corrected to 려, the character's own stored value); `vietnamese: null` was likewise a literal-null bug (filled with lừa, the real everyday word for "donkey," documenting the character's other stored variant lư as the more literal/literary alternative); `characters: "馿 (char)"` was a bare string instead of a proper list; heading was `# Notes` (level 1) instead of `## Notes`; `pos`/`kwin`/`date-last-perfect` were all entirely missing. Added missing `japanese: ろ` (bare on'yomi, per default convention), documenting that real standalone Japanese instead uses the compound ロバ (roba, itself built from this character's own on'yomi + 馬). Checked the ㄌ⼄ syllable for a homophone: 慮/旅/呂/侶 all share this reading but none is itself a legitimized bare word — no collision.

Next: 駄.

### 2026-09-09, iteration 3645 — [[words/駄|駄]]
Self-standing bare-character word (own `stand_in` is 駄 itself). Existing homophone warning with [[舵]] confirmed genuine (its own `stand_in` is 舵 itself, exact-matching da/다/ㄉㄚ) — checked the full ㄉㄚ syllable set (朶/打/爹/駝/陀) for any other collision, none are themselves legitimized bare words. **Fixed the same bug cluster as the previous two words**: bare-string `characters:` instead of a list, `# Notes` heading level, missing `pos`/`kwin`/`date-last-perfect`. Added missing `japanese: だ` — **deliberately chose the second-listed on'yomi over the first** (TA, DA, TAI, DAI on the character page), since だ is the practically-attested reading (無駄, 駄目, 駄菓子) while た is essentially unused in real vocabulary, matching the precedent set by [[食]] (which similarly picked its third-listed reading じき over first-listed しょく for the correct standalone sense). Self-caught and fixed a subject/object reversal I introduced while rewriting the homophone warning line. Stamped `date-last-perfect: 2026-09-09`.

Next: 駅.

### 2026-09-09, iteration 3646 — [[words/駅|駅]]
Already well-perfected (stamped 2026-07-26): self-standing bare-character word, rich existing Notes on the 驛→駅 Japan-coined shinjitai narrowing and the cross-language "post station" vs. "modern station" divergence, and the existing homophone warning with [[䋇]] all confirmed correct — checked the full ⼶ㄎ syllable set (役/易/疫/液/訳), none are themselves legitimized bare words, so no additional collision. **Found and fixed a real bug**: duplicate `pos`/`品詞` fields (same recurring bug type as 馬𡿺 and 食). Re-stamped `date-last-perfect: 2026-09-09`.

Next: 駆.

### 2026-09-09, iteration 3647 — [[words/駆|駆]]
Self-standing bare-character word (own `stand_in` is 駆 itself). All real-language fields (qū/keoi1/く/구/xúi) already matched the character's own stored values exactly — no bug. Checked ㄎㄨ syllable-mate [[区]] for a homophone collision — not itself a legitimized bare word (`stand_in` points to [[区域]]), so none exists. **Fixed the recurring bug cluster**: duplicate `pos`/`品詞` fields (4th instance this session) and bare-string `characters:` instead of a list. Stamped `date-last-perfect: 2026-09-09`.

Next: 駆逐.

### 2026-09-09, iteration 3648 — [[words/駆逐|駆逐]]
No cranberry (駆's own `stand_in` is 駆 itself, 逐's is [[追逐]] — neither points here). Pronunciation fields (kudug/쿠둑/ㄎㄨㄉㄨㄎ) and `kwin: false` (AND-rule: both constituents' own kwin false) already matched constituents exactly — no bug. **Fixed the recurring `characters:` disambiguation bug**: bare "駆" despite `words/駆.md` existing (confirmed `words/逐.md` doesn't, so bare 逐 was already correct). Both character pages already cited 駆逐 correctly. All real-language fields (qūzhú/keoi1zuk6/くちく/구축/khu trục) already correct standard readings. Quoted `hsk_level`, removed blank `swadesh`/empty `aliases`, consolidated Etymology into a proper `## Notes` section. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found only a substring false-positive on 駆逐艦 — no genuine collision.

Next: 駆逐艦.

### 2026-09-09, iteration 3649 — [[words/駆逐艦|駆逐艦]]
No cranberry (none of the three constituents' own `stand_in` points here). Pronunciation fields (kudugham/쿠둑함/ㄎㄨㄉㄨㄎㄏㄚㄇ) and `kwin: false` (AND-rule: 駆 false, 逐 false, 艦 true → false) already matched constituents exactly — no bug. **Fixed the same recurring `characters:` disambiguation bug**: bare "駆" despite `words/駆.md` existing (confirmed `words/逐.md`/`words/艦.md` don't exist, so bare 逐/艦 were already correct). All three character pages already cited 駆逐艦 correctly. All real-language fields already correct standard readings. Removed blank `hsk_level`/`swadesh`, consolidated Etymology into a proper `## Notes` section. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 駐屯.

### 2026-09-09, iteration 3650 — [[words/駐屯|駐屯]]
Legitimizing note reworded to convention (駐's own `stand_in` is [[駐屯]] itself; 屯's own `stand_in` is 屯 itself, so transitivity fails — no `#cranberry`) — the existing Notes already said this substantively. Pronunciation fields (dudun/두둔/ㄉㄨㄉㄨㄋ) and `kwin: false` (AND-rule: 駐 false, 屯 true) already matched constituents exactly — no bug. `characters: [駐, "屯 (char)"]` disambiguation already correct (`words/駐.md` doesn't exist; `words/屯.md` does). Filled entirely missing `vietnamese: đồn trú` — a real, very common military/administrative term that reverses the Sino word order (屯-then-駐), joining the vault's small set of documented Vietnamese word-order-reversal cases ([[限定詞]], [[除外]]). **In passing, added a missing `đồn` reading** to `characters/屯 (char).md`'s own `vietnamese` list (previously only had `truân`). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 駝背.

### 2026-09-09, iteration 3651 — [[words/駝背|駝背]]
Already fully perfected (stamped 2026-07-27): legitimizing note for 駝 (its own `stand_in` is [[駝背]] itself; 背's is 背 itself, so no `#cranberry`), pronunciation fields (daboi/다뵈/ㄉㄚㄅㄛㄧ), `kwin: false` (AND-rule: both false), `characters:` disambiguation, both character-page citations, and an unusually thorough Notes section (already distinguishing 背's multiple Vietnamese reading candidates by sense, and noting Vietnamese đà bối as literary vs. everyday native gù) were all already correct. Background exact-match homophone check found no collision. No changes needed — left `date-last-perfect` untouched.

Next: 駱駝.

### 2026-09-09, iteration 3652 — [[words/駱駝|駱駝]]
Legitimizing note added (駱's own `stand_in` is [[駱駝]] itself; 駝's own `stand_in` is [[駝背]], so transitivity fails — no `#cranberry`). Pronunciation fields (lagda/락다/ㄌㄚㄎㄉㄚ), `kwin: false` (AND-rule: 駱 true, 駝 false), and `vietnamese`/`japanese` (lạc đà; らくだ, a rendaku-voiced compound) already matched constituents exactly — no bug there. **Found and fixed a real bug**: `korean: 낙타` used the South Korean 두음법칙-softened form instead of the North Korean compositional form 락타 (violating the vault's standing Korean-reading rule) — corrected, while documenting that 낙타 is what both character pages' `korean_native` fields cite as the universal real-world word. **Found and fixed two real citation gaps**: `characters/駝.md`'s own `## Words` list was entirely missing a citation of 駱駝 (added); `characters/駱.md`'s existing citation was missing its "(stand-in for 駱)" annotation despite 駱's own `stand_in` pointing there (added). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 騎乗.

### 2026-09-09, iteration 3653 — [[words/騎乗|騎乗]]
No cranberry (騎's own `stand_in` is [[騎馬]], 乗's is 乗 itself — neither points here). Pronunciation fields (guisung/귀숭/ㄍㄨㄧㄙㄨㄫ) and `kwin: false` (AND-rule: both constituents' own kwin false) already matched constituents exactly — no bug. Both character pages already cited 騎乗 correctly. **Found and investigated a systemic bug**: `pos: 動詞` — cross-checked the vault's own grammar documentation (`文法 - 05形態.md`), which defines a canonical four-way word-class system (名詞/性詞/事詞/固有名詞) and uses 動詞 only as a general linguistic term ("verb phrase," "verb morphology"), never as a frontmatter category; corrected to `事詞`, matching both constituent characters. **This same non-canonical `動詞` value appears on 181 other word files** — likely an older-era term never migrated to `事詞`; flagged as a bulk-cleanup candidate rather than something to keep hand-fixing one at a time. Fixed a stray space in `mandarin: qí chéng`→`qíchéng`. Filled entirely missing `vietnamese: kỵ thừa` (compositional; noted the everyday term is native cưỡi ngựa). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 騎馬.

### 2026-09-09, iteration 3654 — [[words/騎馬|騎馬]]
Legitimizing note reworded to convention (騎's own `stand_in` is [[騎馬]] itself; 馬's own `stand_in` is 馬 itself, so transitivity fails — no `#cranberry`) — the existing Notes already said this substantively. Pronunciation fields (guima/귀마/ㄍㄨㄧㄇㄚ) and `kwin: false` (AND-rule: 騎 false, 馬 true) already matched constituents exactly — no bug. Both character pages already cited 騎馬 correctly. **Fixed the same `pos: 動詞` bug as the previous word** — corrected to `事詞`, matching 騎's own `pos`. Flattened `vietnamese` from a single-item list to scalar `kị mã`, matching word-page convention. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 騒.

### 2026-09-09, iteration 3655 — [[words/騒|騒]]
Already well-perfected (stamped 2026-08-30): self-standing bare-character word, pronunciation fields (sau/삿/ㄙㄚㄨ), `kwin: false`, and the existing homophone warning with [[掻]] were all already correct — verified 掻's own `stand_in` points to itself, confirming the collision genuine. **Closed a gap the word's own Notes had explicitly flagged for later**: `characters/騒 (char).md`'s own `vietnamese` field was blank despite the word's Notes already documenting tao as the well-attested real Vietnamese reading — filled it in now rather than deferring further, since the answer was already established right here. Re-stamped `date-last-perfect: 2026-09-09`.

Next: 験.

### 2026-09-09, iteration 3656 — [[words/験|験]]
Self-standing bare-character word (own `stand_in` is 験 itself). Pronunciation fields ('em/엄/ㄝㄇ) and `kwin: false` already matched the character's own stored values exactly — no bug. Checked the ㄝㄇ syllable set (俺/炎) for a homophone — neither is itself a legitimized bare word, so none exists. **Found and fixed three real bugs on `characters/験 (char).md`**: (1) `japanese_native` was malformed YAML — a bare scalar あかし immediately followed by a misindented `- いさお` list item, rather than a proper two-item list; (2) its self-citation read "(stand-in for 験 (char))," wrongly including the filename-disambiguation suffix in the prose parenthetical, instead of the standard bare "(stand-in for 験)"; (3) the Classical-Chinese-frequency line was malformed exactly like the earlier `上 (char).md` case — dangling bare initial/final wikilinks instead of the standard "Nth most used character..." sentence — reconstructed using `mc_id: 1136`. Stamped `date-last-perfect: 2026-09-09`.

Next: 騙.

### 2026-09-09, iteration 3657 — [[words/騙|騙]]
Already fully perfected (stamped 2026-09-05): self-standing bare-character word, pronunciation fields (pyen/편/ㄆ⼶ㄋ), `kwin: true`, and the documented genuine 3-way homophone group with [[篇]]/[[偏]] were all already correct — verified both are themselves legitimized bare words with exact-matching readings. Character page citation format also already correct. No changes needed — a clean pass.

Next: 騰貴.

### 2026-09-09, iteration 3658 — [[words/騰貴|騰貴]]
Legitimizing note added (騰's own `stand_in` is [[騰貴]] itself; 貴's own `stand_in` is [[貴重]], so transitivity fails — no `#cranberry`). Pronunciation fields (dǝnggui/등귀/ㄉㄜㄫㄍㄨㄧ) and `kwin: true` (AND-rule: both constituents' own kwin true) already matched constituents exactly — no bug. Initially misread both constituent character pages' `vietnamese` fields as blank from a truncated grep, but a full re-read showed both already correctly filled (騰: dằng/đằng; 貴: quí) — filled the word's own entirely missing `vietnamese: đằng quí` accordingly, noting the everyday native alternative vật giá leo thang. **Fixed the recurring `pos: 動詞` bug on both this word and `characters/騰.md` itself** — the first character-page instance of this bug found so far, suggesting the bulk-cleanup scope extends beyond word files. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 驟雨.

### 2026-09-09, iteration 3659 — [[words/驟雨|驟雨]]
Legitimizing note reworded to convention (驟's own `stand_in` is [[驟雨]] itself; 雨's own `stand_in` is 雨 itself, so transitivity fails — no `#cranberry`) — the existing Notes already said this substantively. Pronunciation fields (sau'u/삿우/ㄙㄚㄨ·ㄨ) and `kwin: false` (AND-rule: 驟 false, 雨 true) already matched constituents exactly — no bug. `characters: [驟, "雨 (char)"]` disambiguation already correct. **Fixed the recurring duplicate `pos`/`品詞` bug.** **Found and fixed a real citation gap**: `characters/驟.md`'s own citation of 驟雨 was missing its "(stand-in for 驟)" annotation despite 驟's own `stand_in` pointing there. Filled entirely missing `vietnamese: sậu vũ` (compositional; noted the everyday native term mưa rào). Kept the existing rich Notes distinguishing 驟雨 from its near-synonym [[俄雨]] by intensity vs. brevity. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 骨.

### 2026-09-09, iteration 3660 — [[words/骨|骨]]
Already fully perfected (stamped 2026-08-03): self-standing bare-character word with an unusually thorough Notes section already documenting a real `kwin` bug fix (곧/GOD vs 골/GOL, the same MC-checked-coda-vs-Korean-liquid pattern as 月/越/舌) and the character's large anatomical compound family. Verified pronunciation fields, `kwin: false`, and the character page's self-citation format all still correct — no new issues found. No changes needed — a clean pass.

Next: 骨格.

### 2026-09-09, iteration 3661 — [[words/骨格|骨格]]
No cranberry (both 骨's and 格's own `stand_in` point to themselves — neither points here). Pronunciation fields (godgag/곧각/ㄍㄛㄊㄍㄚㄎ) already matched constituents exactly — no bug. `characters: ["骨 (char)", "格 (char)"]` disambiguation already correct (both `words/骨.md`/`words/格.md` exist). Both character pages already cited 骨格 correctly. **Fixed a real contamination bug**: `korean: "골격, 뼈대"` comma-joined the correct Sino compositional reading (골격) with an unrelated native synonym (뼈대, "bone-frame") — corrected to just 골격, matching the AND-rule concatenation. Filled entirely missing `vietnamese: cốt cách`, documenting a genuine figurative drift in everyday Vietnamese (now means "bearing, character" rather than literal skeleton). Removed blank `hsk_level`/`swadesh`/empty `aliases`. Added entirely missing `kwin: false`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found only an incidental mention in `lexipedia/Body.md` — no genuine collision.

Next: 骨盤.

### 2026-09-09, iteration 3662 — [[words/骨盤|骨盤]]
No cranberry (both 骨's and 盤's own `stand_in` point to themselves — neither points here). Pronunciation fields (godban/곧반/ㄍㄛㄊㄅㄚㄋ) already matched constituents exactly — no bug. `characters:` disambiguation already correct. Both character pages already cited 骨盤 correctly. **Found and fixed a real `kwin` bug**: was `true`, but the AND-rule requires both constituents' own kwin true — 骨's is false, giving the correct value `false`. Filled entirely missing `vietnamese: cốt bàn` (compositional; noted the everyday native term xương chậu). Removed blank `hsk_level`/`swadesh`/empty `aliases`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 骨肉.

### 2026-09-09, iteration 3663 — [[words/骨肉|骨肉]]
No cranberry (both 骨's and 肉's own `stand_in` point to themselves — neither points here). Pronunciation fields (godnug/곧눅/ㄍㄛㄊㄋㄨㄎ) and `kwin: false` (AND-rule: both constituents' own kwin false) already matched constituents exactly — no bug. Both character pages already cited 骨肉 correctly. All real-language fields (gǔròu/gwat1juk6/こつにく/골육/cốt nhục) already correct standard readings, paralleling the Biblical idiom already noted on [[骨]]. Quoted `hsk_level`, removed blank `swadesh`/empty `aliases`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found only substring hits on the longer chengyu 骨肉相連 — no genuine collision.

Next: 骨髄.

### 2026-09-09, iteration 3664 — [[words/骨髄|骨髄]]
Legitimizing note reworded to convention (髄's own `stand_in` is [[骨髄]] itself; 骨's own `stand_in` is 骨 itself, so transitivity fails — no `#cranberry`) — the existing Notes already said this substantively. Pronunciation fields (godsui/곧쉬/ㄍㄛㄊㄙㄨㄧ) and `kwin: false` (AND-rule: both false) already matched constituents exactly — no bug. `characters:` disambiguation already correct. **Found and fixed a real gap**: `characters/髄.md`'s existing citation of 骨髄 was missing its "(stand-in for 髄)" annotation despite 髄's own `stand_in` pointing there. All real-language fields already correct standard readings. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 骸骨.

### 2026-09-09, iteration 3665 — [[words/骸骨|骸骨]]
No cranberry (骸's own `stand_in` is [[死骸]], 骨's is 骨 itself — neither points here). Pronunciation fields (hyegod/혀곧/ㄏ⼶ㄍㄛㄊ) and `kwin: false` (AND-rule: both false) already matched constituents exactly — no bug. **Fixed the recurring `characters:` disambiguation bug**: bare "骨" despite `words/骨.md` existing (confirmed `words/骸.md` doesn't, so bare 骸 was already correct). Both character pages already cited 骸骨 correctly. Filled entirely missing `vietnamese: hài cốt` — confirmed the standard, everyday Vietnamese term for "remains/skeleton," already referenced in passing on [[骨]]'s own Notes. Removed blank `hsk_level`/`swadesh`/empty `aliases`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 高.

### 2026-09-09, iteration 3666 — [[words/高|高]]
Already fully perfected (stamped 2026-08-03): self-standing bare-character word with an unusually thorough Notes section — periodic-table prefix role for gallium (高素), a documented genuine phonetic-family homophone with [[稿]] (already cross-checked against all other ㄍㄚㄨ-reading characters), and the `japanese_native: ø`-despite-common-たかい gap already flagged as a known pattern (cf. 手/玉/飛). Verified pronunciation fields and `kwin: false` still match the character page exactly. No changes needed — a clean pass.

Next: 高人.

### 2026-09-09, iteration 3667 — [[words/高人|高人]]
No cranberry (both 高's and 人's own `stand_in` point to themselves — neither points here). Pronunciation fields (gaunin/갓닌/ㄍㄚㄨㄋㄧㄋ) and `kwin: false` (AND-rule: both false) already matched constituents exactly — no bug. `characters:` disambiguation already correct. **Found and fixed a real gap**: `japanese` was entirely blank — added こうじん (favoring the more common じん reading for 人-compounds like 個人/老人 over the Dan'a'yo-internal にん derivation). Filled entirely missing `vietnamese: cao nhân`. **Noted a large-scale formatting backlog**: `characters/人 (char).md`'s own `## Words` list has a ~35-item numbered stub sub-list (citations like "29. [[高人]]" lacking ruby/gloss) below its properly-formatted entries — fixed only the one entry relevant here (#29, 高人); the rest remains a bulk-cleanup candidate, not something to fix piecemeal. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 高句麗.

### 2026-09-09, iteration 3668 — [[words/高句麗|高句麗]]
Already fully perfected (stamped 2026-06-19): rich historical Notes on the Goguryeo–Baekje–Silla Three Kingdoms period and an explicit callout of the irregular Mandarin gōu-vs-jù reading exception (correctly noting Dan'a'yo doesn't follow it). Verified pronunciation fields (gaugule/갓구러/ㄍㄚㄨㄍㄨㄌㄝ), `kwin: false` (AND-rule: 高 false, 句 true, 麗 false), `characters:` disambiguation, and all three character-page citations — all already correct. No changes needed — a clean pass.

Next: 高山.

### 2026-09-09, iteration 3669 — [[words/高山|高山]]
No cranberry (both 高's and 山's own `stand_in` point to themselves — neither points here). Pronunciation fields (gausan/갓산/ㄍㄚㄨㄙㄚㄋ) and `kwin: false` (AND-rule: 高 false, 山 true) already matched constituents exactly — no bug. Both character pages already cited 高山 correctly. Filled entirely missing `vietnamese: cao sơn` — confirmed real, attested in the classical idiom cao sơn lưu thủy (高山流水, a metaphor for deep friendship). Kept the existing note distinguishing this from the unrelated Takayama place-name reading of the same two characters. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 高峰.

### 2026-09-09, iteration 3670 — [[words/高峰|高峰]]
Already fully perfected (stamped 2026-05-26): legitimizing note for 峰 (own `stand_in` is [[高峰]] itself, already annotated), an unusually thorough Notes section covering figurative/diplomatic extensions (高峰期, 高峰會議) and per-language native-vs-Sino register contrasts across all five languages. Verified pronunciation fields (gaufong/갓뽕/ㄍㄚㄨㄈㄛㄫ), `kwin: false` (AND-rule: both false), and both character-page citations all still correct. No changes needed — a clean pass.

Next: 高校.

### 2026-09-09, iteration 3671 — [[words/高校|高校]]
No cranberry (校's own `stand_in` is [[学校]], 高's is 高 itself — neither points here). Pronunciation fields (gauhyau/갓햣/ㄍㄚㄨㄏ⼘ㄨ) and `kwin: false` (AND-rule: both false) already matched constituents exactly — no bug (double-checked the ⼶/⼘-glide bopomofo notation against [[香気]]'s ㄏ⼘ㄫ pattern before concluding no mismatch). Both character pages already cited 高校 correctly. Filled entirely missing `vietnamese: cao hiệu` (compositional; noted the everyday native term trường trung học). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 高盧.

### 2026-09-09, iteration 3672 — [[words/高盧|高盧]]
Already fully perfected (stamped 2026-05-26): no cranberry (盧's own `stand_in` is the special `名専字` marker, 高's is 高 itself), rich historical Notes on Caesar's Gallic Wars already noting that modern Japanese/Korean prefer phonetic ガリア/갈리아 over the Sino-readings used here. Verified pronunciation fields (gaulo/갓로/ㄍㄚㄨㄌㄛ), `kwin: false` (AND-rule: 高 false, 盧 true), and both character-page citations all still correct. No changes needed — a clean pass.

Next: 高等.

### 2026-09-09, iteration 3673 — [[words/高等|高等]]
Already fully perfected (stamped 2026-07-11): no cranberry (both 高's and 等's own `stand_in` point to themselves), rich Notes already documenting a genuine Vietnamese semantic narrowing (cao đẳng → a specific junior-college tier, not the general "advanced" sense retained in Chinese/Japanese/Korean). Verified pronunciation fields (gaudung/갓둥/ㄍㄚㄨㄉㄨㄫ), `kwin: false` (AND-rule: both false), `characters:` disambiguation, and both character-page citations all still correct. No changes needed — a clean pass.

Next: 高素.

### 2026-09-09, iteration 3674 — [[words/高素|高素]]
Periodic-table neologism series (gallium): already correctly following the special convention — `mandarin`/`cantonese` (jiā/gaa1) give the avoided real element character 鎵/镓's own readings, not a compositional reading; `korean`/`japanese`/`vietnamese` (갈륨/ガリウム/gali) are the loanword element names; `kwin: false` correctly compares Dan'a'yo 갓소 against Korean 갈륨 (clearly different) rather than an AND-rule. Dan'a'yo pronunciation fields (gauso/갓소/ㄍㄚㄨㄙㄛ) still correctly follow normal compositional concatenation of 高+素. Both character pages already cited 高素 correctly. **Fixed a stale cross-reference**: the homophone note claimed [[告訴]] was "still unperfected," but it was stamped 2026-08-28, after this word's prior 2026-07-27 stamp — updated the wording and re-verified the collision is still genuine (exact-matching gauso/갓소/ㄍㄚㄨㄙㄛ). Stamped `date-last-perfect: 2026-09-09`.

Next: 高綿.

### 2026-09-09, iteration 3675 — [[words/高綿|高綿]]
No cranberry (both 高's and 綿's own `stand_in` point elsewhere — neither points here). Pronunciation fields (gaumyen/갓면/ㄍㄚㄨㄇ⼶ㄋ) already matched constituents exactly — no bug. Both character pages already cited 高綿 correctly. **Fixed the recurring duplicate `pos`/`品詞` bug**, added entirely missing `kwin: false` (AND-rule: 高 false, 綿 true). Filled entirely blank `korean`/`japanese` fields with the modern phonetic loanwords 캄보디아/カンボジア rather than a compositional Sino-reading — following the same real-name-over-compositional-reading pattern established on [[馬来西亜]]. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found only an incidental mention in `lexipedia/Geography.md` — no genuine collision.

Next: 高考.

### 2026-09-09, iteration 3676 — [[words/高考|高考]]
No cranberry (高's own `stand_in` is 高 itself, 考's is [[考慮]] — neither points here). Pronunciation fields (gaukau/갓캇/ㄍㄚㄨㄎㄚㄨ) already matched constituents exactly — no bug. Both character pages already cited 高考 correctly. **Fixed the recurring duplicate `pos`/`品詞` bug**, added missing `kwin: false` (AND-rule: 高 false, 考 false). Filled entirely blank `korean`/`japanese` with phonetic transliterations of Mandarin (가오카오/ガオカオ) rather than compositional Sino-readings — reasoned that Japanese likely avoids compositional こうこう specifically to prevent collision with [[高校]]'s own reading. Removed blank `swadesh`, consolidated Etymology into a proper `## Notes` section. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 高興.

### 2026-09-09, iteration 3677 — [[words/高興|高興]]
No cranberry (both 高's and 興's own `stand_in` point to themselves — neither points here). **Fixed a real romanization typo**: `羅馬字: gauhing` should be `gauhǝng` (興's own stored 羅馬字 uses the schwa ǝ, not "i") — the 諺文/注音 fields were already correct concatenations, only 羅馬字 had drifted. **Decoded a stray design note** ("platonic version of 興奮. Only J lacks this term!") into a proper Notes section: 高興 is a calm "glad, pleased" sense contrasting with the more intense [[興奮]] ("excited, aroused"), and Japanese genuinely lacks this compound as an attested word despite 興 having viable on'yomi — confirmed the character page's own blank `japanese` field is consistent with this, so left it blank rather than guessing a reading. Both character pages already cited 高興 correctly. Quoted `hsk_level`, removed blank `swadesh`/empty `aliases`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 高麗.

### 2026-09-09, iteration 3678 — [[words/高麗|高麗]]
Already fully perfected (stamped 2026-06-19): no cranberry (both 高's and 麗's own `stand_in` point elsewhere), exceptionally rich historical Notes on the Goryeo dynasty and its role as the direct source of the English exonym "Korea" (via Persian/Arab/Marco Polo transliterations). Verified pronunciation fields (gaule/갓러/ㄍㄚㄨㄌㄝ), `kwin: false` (AND-rule: both false), and both character-page citations all still correct. No changes needed — a clean pass.

Next: 鬚髯.

### 2026-09-09, iteration 3679 — [[words/鬚髯|鬚髯]]
**Found and fixed a real missed-cranberry bug**: both 鬚's and 髯's own `stand_in` point to [[鬚髯]] itself, and both characters' own meanings ("beard") are identical to each other and to the compound — full transitivity, a genuine `#cranberry` case that had gone untagged. Added `#cranberry`, added the missing "(stand-in for 鬚)" annotation on 鬚's own citation, and added this word to [[lookup/List of 連綿詞]] (native alliterative binome category), incrementing its `size` to 47. Pronunciation fields (sunom/수놈/ㄙㄨㄋㄛㄇ) and `kwin: false` (AND-rule: 鬚 true, 髯 false) already matched constituents exactly — no bug. Filled entirely missing `japanese: しゅぜん`/`vietnamese: tu nhiêm`. Noted 수염 (Korean) is both the compositional Sino-Korean reading and 鬚's own attested native gloss — a case where the Sino compound became the everyday word. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no genuine collision.

Next: 鬣.

### 2026-09-09, iteration 3680 — [[words/鬣|鬣]]
Already well-perfected (stamped 2026-09-03): self-standing bare-character word, pronunciation fields (lob/롭/ㄌㄛㄆ), `kwin: false`, and the existing homophone warning with [[獵]] all confirmed correct — verified 獵's own `stand_in` points to itself, exact-matching reading. Only fix was quoting `hsk_level: 無` for consistency. Stamped `date-last-perfect: 2026-09-09`.

Next: 鬼婆.

### 2026-09-09, iteration 3681 — [[words/鬼婆|鬼婆]]
No cranberry (鬼's own `stand_in` is [[鬼神]], 婆's is [[婆婆]] — neither points here). Pronunciation fields (guiba/귀바/ㄍㄨㄧㄅㄚ) already matched constituents exactly — no bug. Both character pages already cited 鬼婆 correctly. `japanese: おにばば` already correctly identified as a native kun'yomi folklore compound (Onibaba/Yamamba), not a Sino reading. Filled entirely missing `korean: 귀파`/`vietnamese: quỷ bà` (compositional) and added missing `kwin: false` (AND-rule: 鬼 true, 婆 false). Removed blank `hsk_level`/`swadesh`/empty `aliases`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found only a substring false-positive on 閨房 — no genuine collision.

Next: 鬼火.

### 2026-09-09, iteration 3682 — [[words/鬼火|鬼火]]
No cranberry (鬼's own `stand_in` is [[鬼神]], 火's is 火 itself — neither points here). Pronunciation fields (guihwa/귀화/ㄍㄨㄧㄏ⺢) already matched constituents exactly — no bug. Both character pages already cited 鬼火 correctly. `japanese: おにび` already correctly a native folklore compound, not Sino. Filled entirely missing `korean: 귀화`/`vietnamese: quỷ hỏa` (compositional; noted native alternative ma trơi) and missing `kwin: true` (AND-rule: both constituents' own kwin true). Removed blank `hsk_level`/`swadesh`/empty `aliases`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found only a substring false-positive on 帰還 — no genuine collision.

Next: 鬼神.

### 2026-09-09, iteration 3683 — [[words/鬼神|鬼神]]
Legitimizing note added (鬼's own `stand_in` is [[鬼神]] itself, already annotated in its own citation; 神's own `stand_in` is 神 itself, so transitivity fails — no `#cranberry`). Pronunciation fields (guisin/귀신/ㄍㄨㄧㄙㄧㄋ) and `kwin: true` (AND-rule: both constituents' own kwin true) already matched constituents exactly — no bug. Both character pages already cited 鬼神 correctly. **Fixed a real contamination bug**: `japanese: きじん, おにがみ` comma-joined two genuinely distinct real readings (on'yomi vs. native kun'yomi) in one field — picked きじん as the representative form, documenting おにがみ as the folkloric alternate in Notes rather than dropping it entirely. Filled entirely missing `vietnamese: quỷ thần` — confirmed real, common phrase ("ghosts and spirits"). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found only incidental prose/gloss mentions (神霊's Notes, Korean mnemonic lists) — no genuine collision.

Next: 鬼老.

### 2026-09-09, iteration 3684 — [[words/鬼老|鬼老]]
No cranberry (鬼's own `stand_in` is [[鬼神]], 老's is 老 itself — neither points here). Pronunciation fields (guilau/귀랏/ㄍㄨㄧㄌㄚㄨ) already matched constituents exactly — no bug. **Fixed the recurring `characters:` disambiguation bug**: bare "老" despite `words/老.md` existing. Both character pages already cited 鬼老 correctly. **Enriched the `english` gloss**: the alias 鬼佬 (gwai2lou2) is a well-known, extremely common Cantonese colloquial term for a Western foreigner, far more prevalent in real usage than the literal "male demon" sense — added "foreigner (Cantonese slang)" alongside the literal gloss and documented this in Notes. Filled entirely blank `japanese`/`korean`/`vietnamese` with compositional readings and missing `kwin: false`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 鬼金.

### 2026-09-09, iteration 3685 — [[words/鬼金|鬼金]]
Periodic-table neologism series (cobalt): already correctly following convention — `mandarin`/`cantonese` (gǔ/gu2) give the avoided real element character 钴's own readings; `korean`/`japanese`/`vietnamese` (코발트/コバルト/coban) are the loanword element names; `kwin: false` correctly compares Dan'a'yo 귀김 against Korean 코발트 (clearly different). Dan'a'yo pronunciation fields (guigim/귀김/ㄍㄨㄧㄍㄧㄇ) still correctly follow normal compositional concatenation of 鬼+金. 鬼's own character page already cites 鬼金 correctly (with a special note on its neologism role); `characters/金 (char).md` doesn't cite it, consistent with that character's already-documented, deliberately out-of-scope ~55+ file citation gap. Fixed the recurring duplicate `pos`/`品詞` bug and a stray trailing space in the `japanese` list item; flattened single-item `japanese`/`vietnamese` lists to scalars. Kept the unusually extensive, well-researched Notes on the Kobold/cobalt etymology intact. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found only an incidental mention in `lexipedia/Periodic Table.md` — no genuine collision.

Next: 魂.

### 2026-09-09, iteration 3686 — [[words/魂|魂]]
Self-standing bare-character word (own `stand_in` is 魂 itself). Pronunciation fields (hon/혼/ㄏㄛㄋ) and `kwin: true` already matched the character's own stored values exactly — no bug. Checked the full ㄏㄛㄋ syllable set (喧/昏/棍/婚/混) for a homophone — none are themselves legitimized bare words, so no collision. Flattened `vietnamese` from a 2-item list to scalar `hồn` (the standard modern form), matching word-page convention. Stamped `date-last-perfect: 2026-09-09`.

Next: 魂魄.

### 2026-09-09, iteration 3687 — [[words/魂魄|魂魄]]
Legitimizing note added (魄's own `stand_in` is [[魂魄]] itself, already annotated in its own citation; 魂's own `stand_in` is 魂 itself, so transitivity fails — no `#cranberry`) — this was the only real gap in an otherwise exceptionally rich, already-thorough Notes section covering classical hun/po cosmology, the *Suwen*'s three-hun-seven-po count, and per-language register contrasts (JA konpaku formal vs. tamashii vernacular; native Vietnamese hồn alone vs. the Sino calque). Pronunciation fields (honbag/혼박/ㄏㄛㄋㄅㄚㄎ) and `kwin: false` (AND-rule: 魂 true, 魄 false) already matched constituents exactly — no bug. Quoted `mandarin`/`cantonese`/`korean`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 魅惑.

### 2026-09-09, iteration 3688 — [[words/魅惑|魅惑]]
Legitimizing note reworded to convention (魅's own `stand_in` is [[魅惑]] itself; 惑's own `stand_in` is 惑 itself, so transitivity fails — no `#cranberry`) — the existing Notes already said this substantively. Pronunciation fields (miǝhog/믜혹/ㄇㄧㄜㄏㄛㄎ) and `kwin: false` (AND-rule: 魅 false, 惑 true) already matched constituents exactly — no bug. `characters:` disambiguation already correct. Both character pages already cited 魅惑 correctly. Filled entirely missing `vietnamese: mị hoặc` — confirmed real, standard Sino-Vietnamese term for "to charm, bewitch." Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 魏国.

### 2026-09-09, iteration 3689 — [[words/魏国|魏国]]
Legitimizing note added (魏's own `stand_in` is [[魏国]] itself, already annotated in its own citation; 国's own `stand_in` is [[国家]], so transitivity fails — no `#cranberry`). Pronunciation fields ('egog/어곡/ㄝㄍㄛㄎ) and `kwin: false` (AND-rule: both false) already matched constituents exactly — no bug. **Investigated and explained a real, deliberate divergence**: `japanese`/`korean`/`vietnamese` (ぎ/위/Ngụy) give only 魏's own bare reading, not a compositional reading of the full compound — confirmed this is because Chinese historical Three-Kingdoms-era states are conventionally referred to by their bare name alone (unlike modern nations, which take "-国"), documented in Notes. **In passing, fixed 魏's own citation**, which was missing its "(stand-in for 魏)" annotation. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 魏峨.

### 2026-09-09, iteration 3690 — [[words/魏峨|魏峨]]
No cranberry (魏's own `stand_in` is [[魏国]], 峨's is [[峨峨]] — neither points here). Pronunciation fields ('e'a/어아/ㄝㄚ) and `kwin: false` (AND-rule: 魏 false, 峨 true) already matched constituents exactly — no bug. Both character pages already cited 魏峨 correctly. Exceptionally rich existing Notes already explained a "Component + Translation" substitution for the out-of-character-set 巍 (from the *Analects*), and the Dan'a'yo-identity-vs-compound-reading divergence paralleling [[六楽]]/[[楽]] — left entirely intact. Only fixes were the recurring duplicate `pos`/`品詞` bug and quoting `mandarin`/`cantonese`/`korean`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 魏晋.

### 2026-09-09, iteration 3691 — [[words/魏晋|魏晋]]
No cranberry (魏's own `stand_in` is [[魏国]], 晋's is [[晋升]] — neither points here). Pronunciation fields ('ejin/어진/ㄝㄐㄧㄋ) already matched constituents exactly — no bug. **Found and fixed three real bugs on `characters/晋.md`**: (1) malformed `japanese` YAML with a zero-indent list item; (2) a literal empty-string `korean_native: ''`; (3) its own `## Words` list was entirely missing a citation of 魏晋 — added all three fixes. Filled entirely missing `japanese: ぎしん`/`korean: 위진`/`vietnamese: Ngụy Tấn` and `kwin: false` (AND-rule: 魏 false, 晋 true) — contrasted with [[魏国]]'s bare-reading convention, since this compound period-name (cf. 魏晋南北朝) is read compositionally rather than by bare state name. Fixed duplicate `pos`/`品詞` and a bare-string `aliases`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no genuine collision.

Next: 魑魅.

### 2026-09-09, iteration 3692 — [[words/魑魅|魑魅]]
Legitimizing note added (魑's own `stand_in` is [[魑魅]] itself; 魅's own `stand_in` is [[魅惑]], so transitivity fails — no `#cranberry`). Pronunciation fields (cimiǝ/치믜/ㄑㄧㄇㄧㄜ) and `kwin: false` (AND-rule: 魑 true, 魅 false) already matched constituents exactly — no bug. **Investigated and explained a real irregular reading**: `korean: 이매` doesn't match naive compositional 치매 — confirmed 이매 is the genuine, attested reading (surviving in the classical idiom 이매망량/魑魅魍魎), and noted 치매 would collide with modern Korean "dementia." **Found and fixed a real bug**: `hsk_level: "1"` was clearly wrong for this obscure literary term (neither constituent has hsk_level "1"; 魑's own is 無) — corrected to `"無"`. **Found and fixed a structural mislabeling**: `characters/魑.md` had no `## Words` section at all — its citation of the actual word 魑魅 was miscategorized under `## Chengyu` (alongside the genuine 4-character idiom 魑魅罔両) — split into a proper `## Words` section, and added the missing "(stand-in for 魑)" annotation. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found only substring hits on the longer chengyu — no genuine collision.

Next: 魔力.

### 2026-09-09, iteration 3693 — [[words/魔力|魔力]]
No cranberry (魔's own `stand_in` is [[魔鬼]], 力's is 力 itself — neither points here). Pronunciation fields (malig/마릭/ㄇㄚㄌㄧㄎ) and `kwin: false` (AND-rule: 魔 true, 力 false) already matched constituents exactly — no bug. Both character pages already cited 魔力 correctly. **Fixed a real contamination bug**: `japanese: まりょく, まりま` comma-joined the standard, correct compositional reading with a bogus second form that doesn't correspond to any of 魔's or 力's own listed readings — dropped まりま entirely. Filled entirely missing `vietnamese: ma lực` — confirmed real, common term. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 魔女.

### 2026-09-09, iteration 3694 — [[words/魔女|魔女]]
Already fully perfected (stamped 2026-05-20): no cranberry (both 魔's and 女's own `stand_in` point elsewhere), exceptionally rich Notes tracing the concept from classical Chinese 妖女/女巫 through Buddhist 魔羅 demonology to Japan's dual folkloric/魔法少女 traditions (Kiki's Delivery Service, Madoka Magica). Verified pronunciation fields (manǝ/마느/ㄇㄚㄋㄜ), `kwin: false` (AND-rule: 魔 true, 女 false), and both character-page citations all still correct. No changes needed — a clean pass.

Next: 魔羅.

### 2026-09-09, iteration 3695 — [[words/魔羅|魔羅]]
Already fully perfected (stamped 2026-05-20): no cranberry (both 魔's and 羅's own `stand_in` point elsewhere), exceptionally rich Notes on Māra's assault on the Buddha under the Bodhi tree, the earth-touching gesture, and the Japanese Heian-era semantic shift to anatomical slang (independently preserved across Ryukyuan dialects). Verified pronunciation fields (malo/마로/ㄇㄚㄌㄛ), `kwin: false` (AND-rule: 魔 true, 羅 false), and both character-page citations all still correct. No changes needed — a clean pass.

Next: 魔銅.

### 2026-09-09, iteration 3696 — [[words/魔銅|魔銅]]
Periodic-table neologism series (nickel): `mandarin`/`cantonese` (niè/nip6) give the avoided real element character 鎳/镍's own readings; `korean`/`japanese`/`vietnamese` (니켈/ニッケル/nikel) are the loanword element names; `kwin: false` correctly compares Dan'a'yo 마동 against Korean 니켈 (clearly different). Dan'a'yo pronunciation fields (madong/마동/ㄇㄚㄉㄛㄫ) still correctly follow normal compositional concatenation of 魔+銅. Both character pages already cited 魔銅 correctly. Fixed the recurring duplicate `pos`/`品詞` bug; flattened single-item `japanese`/`vietnamese` lists to scalars. Kept the well-researched Notes on the Kupfernickel/"nick" folklore etymology intact. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found only an incidental mention in `lexipedia/Periodic Table.md` — no genuine collision.

Next: 魔鬼.

### 2026-09-09, iteration 3697 — [[words/魔鬼|魔鬼]]
Legitimizing note added (魔's own `stand_in` is [[魔鬼]] itself, already annotated in its own citation; 鬼's own `stand_in` is [[鬼神]], so transitivity fails — no `#cranberry`). Pronunciation fields (magui/마귀/ㄇㄚㄍㄨㄧ) and `kwin: true` (AND-rule: both constituents' own kwin true) already matched constituents exactly — no bug. Both character pages already cited 魔鬼 correctly. All real-language fields (móguǐ/mo1gwai2/まき/마귀/ma quỉ) already correct standard readings. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found only incidental prose mentions (e.g. 烏鳥's Korean gloss 까마귀 containing "마귀" as a substring) — no genuine collision.

Next: 魚.

### 2026-09-09, iteration 3698 — [[words/魚|魚]]
Self-standing bare-character word, already richly perfected (stamped 2026-06-29) with a detailed kwin explanation (Dan'a'yo 요 vs Korean 어, the MC 魚韻→-o correspondence also seen in [[且]]). **Found and fixed a real gap — a previously undocumented 3-way homophone cluster**: checked the full ⼄ syllable set and found [[与]] ("and, with") and [[輿]] ("palanquin") are BOTH themselves legitimized self-standing bare words with the exact same reading 'yo/요/⼄, yet none of the three pages had ever documented this collision. Added full reciprocal `>[!warning] Homophones` callouts to all three. Checked the remaining ⼄-reading characters (余/予/漁/圄/御/語/誉/馭) — none is itself a self-standing word, confirming the cluster is exactly these three. **In passing**, fixed a duplicate `pos`/`品詞` bug and flow-style `characters:` on 与.md, and fixed 輿.md's `# Notes` heading level and bare-string `characters:` field (its other gaps — missing `kwin`/`date-last-perfect` — left for when the sweep naturally reaches it). Fixed the duplicate `pos`/`品詞` bug on 魚.md itself. Re-stamped `date-last-perfect: 2026-09-09`.

Next: 魚叉.

### 2026-09-09, iteration 3699 — [[words/魚叉|魚叉]]
No cranberry (need not check — neither 魚's nor 叉's own `stand_in` points here). Pronunciation fields ('yocai/요채/⼄ㄑㄚㄧ) and `kwin: false` (AND-rule: both false) already matched constituents exactly — no bug. Rich existing Notes on harpoon history (Paleolithic origins, Svend Foyn's 1864 cannon) and the 漁叉/魚叉 written-form variance kept intact. **Fixed a malformed citation** on `characters/叉 (char).md` (bare asterisk-bullet "* [[魚叉]] harpoon" instead of the standard ruby template). Filled entirely missing `japanese: ぎょさ`/`vietnamese: ngư xoa`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 魚翅.

### 2026-09-09, iteration 3700 — [[words/魚翅|魚翅]]
Legitimizing note reworded to convention (翅's own `stand_in` is [[魚翅]] itself; 魚's own `stand_in` is 魚 itself, so transitivity fails — no `#cranberry`) — the existing Notes already said this substantively. Pronunciation fields ('yosi/요시/⼄ㄙㄧ) already matched constituents exactly — no bug. Both character pages already cited 魚翅 correctly. Added missing `kwin: false` (AND-rule: 魚 false, 翅 true) and filled entirely missing `vietnamese: ngư sí`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found only substring false-positives (標識/灰色/鼠色, all longer readings) — no genuine collision.

Next: 魚雷.

### 2026-09-09, iteration 3701 — [[words/魚雷|魚雷]]
No cranberry (both 魚's and 雷's own `stand_in` point to themselves — neither points here). Pronunciation fields ('yoloi/요뢰/⼄ㄌㄛㄧ) and `kwin: false` (AND-rule: 魚 false, 雷 true) already matched constituents exactly — no bug. Both character pages already cited 魚雷 correctly. All real-language fields already correct standard readings — a clean case. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 魚類.

### 2026-09-09, iteration 3702 — [[words/魚類|魚類]]
No cranberry (魚's own `stand_in` is 魚 itself, 類's is [[種類]] — neither points here). Pronunciation fields ('yolui/요뤼/⼄ㄌㄨㄧ) and `kwin: false` (AND-rule: both false) already matched constituents exactly — no bug. **Fixed a real contamination bug**: `mandarin: "yúlèi ; hû-luī"` had a Southern Min/Taiwanese Hokkien romanization (POJ-style "hû-luī") jammed into the Mandarin field entirely — removed, keeping just yúlèi. Filled blank `cantonese: jyu4 leoi6` and missing `vietnamese: ngư loại`. **In passing, fixed a real citation gap**: `characters/魚 (char).md`'s own Words list was missing 魚類 entirely — added. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found only a substring false-positive on 鼠類 — no genuine collision.

Next: 魚鰭.

### 2026-09-09, iteration 3703 — [[words/魚鰭|魚鰭]]
Legitimizing note reworded to convention (鰭's own `stand_in` is [[魚鰭]] itself; 魚's own `stand_in` is 魚 itself, so transitivity fails — no `#cranberry`) — the existing Notes already said this substantively. Pronunciation fields ('yogiǝ/요긔/⼄ㄍㄧㄜ) and `kwin: false` (AND-rule: both false) already matched constituents exactly — no bug. Both character pages already cited 魚鰭 correctly. Filled entirely missing `vietnamese: ngư kì`. Quoted `mandarin`/`cantonese`/`korean`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 魶.

### 2026-09-09, iteration 3704 — [[words/魶|魶]]
Self-standing bare-character word (own `stand_in` is 魶 itself). **Found and fixed a real bug**: `mandarin: dàní` was a two-syllable reading belonging to 大鯢 (the actual modern Mandarin word for "giant salamander") rather than 魶's own single-character reading — corrected to `nà` per the character page, documenting in Notes that 魶 itself is obsolete in Standard Chinese and modern usage universally prefers 大鯢. Filled blank `cantonese: naap6`; left `vietnamese` blank since the character page's own field is explicitly marked `ø` (no attested reading), not merely absent. Fixed the recurring duplicate `pos`/`品詞` bug and bare-string `characters:`. Checked the ㄋㄨㄆ syllable for a homophone — 魶 is the sole occupant, none found. Stamped `date-last-perfect: 2026-09-09`.

Next: 鮎.

### 2026-09-09, iteration 3705 — [[words/鮎|鮎]]
Already well-perfected (stamped 2026-09-05): self-standing bare-character word, pronunciation fields (nem/넘/ㄋㄝㄇ), `kwin: false`, and the existing homophone warning with [[粘]] all confirmed correct — verified 粘's own `stand_in` points to itself, exact-matching reading. Notes already correctly document Japanese's unique semantic divergence to あゆ ("sweetfish") vs. the original Chinese catfish/sheatfish sense. No changes needed.

Next: 鮑.

### 2026-09-09, iteration 3706 — [[words/鮑|鮑]]
Self-standing bare-character word. Pronunciation fields (bau/밧/ㄅㄚㄨ) and `kwin: false` already matched the character's own stored values exactly — no bug. **Found a real homophone already anticipated by its counterpart**: `words/報.md` already carried a homophone warning for 鮑 (added when 報 was perfected earlier this sweep, correctly flagging 鮑 as "still unperfected") — added the reciprocal warning here now that 鮑 is done, and fixed the now-stale "still unperfected" phrasing on 報.md. Checked the remaining ㄅㄚㄨ-reading characters (抱/堡/保/宝) — none is itself a legitimized bare word, confirming the cluster is exactly 鮑/報. Fixed duplicate `pos`/`品詞`, bare-string `characters:`, and flattened a 3-item `vietnamese` list to scalar `bào`. Stamped `date-last-perfect: 2026-09-09`.

Next: 鮫魚.

### 2026-09-09, iteration 3707 — [[words/鮫魚|鮫魚]]
Legitimizing note added (鮫's own `stand_in` is [[鮫魚]] itself, already annotated in its own citation; 魚's own `stand_in` is 魚 itself, so transitivity fails — no `#cranberry`). **Fixed a real romanization typo**: `羅馬字: gyau'yo` should be `gyou'yo` (鮫's own stored 羅馬字 uses "gyou," not "gyau") — the 諺文/注音 fields were already correct. **Fixed the recurring `characters:` disambiguation bug**: bare "魚" despite `words/魚.md` existing. Fixed a stray space in `mandarin: jiāo yú`→`jiāoyú`. Filled blank `cantonese: gaau1 jyu4`/`vietnamese: giao ngư` (compositional; `japanese: さめ` already correctly the native everyday word). **Investigated and removed an unverifiable stray claim** ("homophone of *make*") — checked exact-match candidates including [[交]] (shares 鮫's own partial reading, not the full compound's) and found nothing that confirms it. Self-caught and fixed a stray "英語:" field I accidentally introduced while rewriting. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no genuine collision.

Next: 鮮少.

### 2026-09-09, iteration 3708 — [[words/鮮少|鮮少]]
No cranberry (鮮's own `stand_in` is [[新鮮]], 少's is 少 itself — neither points here). Pronunciation fields (syensou/션솟/ㄙ⼶ㄇㄙㄛㄨ) already matched constituents exactly — no bug. **Clarified `pos: 実詞` is NOT a bug** — cross-checked the vault's own grammar docs (`文法 - 04句法.md`, `文法 - 97品詞.md`), which establish 実詞 as the legitimate umbrella "content word" category (encompassing 名詞/事詞/性詞/系詞), distinct from the earlier-confirmed non-canonical `動詞`; verified via a 310-file scope check that 実詞 is a well-established, intentional frontmatter value, not an artifact — left unchanged. `characters:` disambiguation already correct. Both character pages already cited 鮮少 correctly. Added missing `kwin: false` (AND-rule: both false) and filled blank `korean: 선소`/`vietnamese: tiên thiểu`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no genuine collision.

Next: 鮮美.

### 2026-09-09, iteration 3709 — [[words/鮮美|鮮美]]
No cranberry (鮮's own `stand_in` is [[新鮮]], 美's is 美 itself — neither points here). **Found and fixed a real bug**: `羅馬字`/`諺文` were syenmi/션미, an unexplained -n substitution for 鮮's own -m coda, inconsistent with the word's own `注音` field (ㄙ⼶ㄇㄇㄧ, already correctly showing -m) — corrected to syemmi/셤미 to match straightforward concatenation. `kwin: false` (AND-rule: 鮮 false, 美 true) already correct. Both character pages already cited 鮮美 correctly. Filled entirely missing `vietnamese: tiên mĩ`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check on the corrected reading found no collision.

Next: 鮮花.

### 2026-09-09, iteration 3710 — [[words/鮮花|鮮花]]
No cranberry (鮮's own `stand_in` is [[新鮮]], 花's is [[草花]] — neither points here). **Fixed the same systematic bug found on this word's siblings**: `羅馬字`/`諺文` had the same -n-for-鮮's-own-m substitution as [[鮮少]] and [[鮮美]] — corrected to syemhwa/셤화, matching `注音`. **Went back and fixed [[鮮少]] too**: caught only now that all three 鮮-prefixed words were checked side by side, its own syensou/션솟 (from iteration 3708, logged as already-correct at the time) actually had the identical bug — self-corrected. Confirmed via a vault-wide check that no other word uses 鮮 as its first constituent, so the bug is now fully resolved across all three affected files. **Fixed a malformed citation** on `characters/花.md` (bare "- [[鮮花]]" with no ruby/gloss). Filled entirely missing `vietnamese: tiên hoa`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 鯖魚.

### 2026-09-09, iteration 3711 — [[words/鯖魚|鯖魚]]
Legitimizing note added (鯖's own `stand_in` is [[鯖魚]] itself, already annotated in its own citation; 魚's own `stand_in` is 魚 itself, so transitivity fails — no `#cranberry`). Pronunciation fields (ceng'yo/청요/ㄑㄝㄫ⼄) and `kwin: false` (AND-rule: 鯖 true, 魚 false) already matched constituents exactly — no bug. Fixed the recurring `characters:` disambiguation bug (bare "魚" despite `words/魚.md` existing) and a typo in `english` (mackrel→mackerel). `japanese`/`korean`/`vietnamese` (さば/고등어/cá thu) already correctly the real native everyday words rather than Sino readings. Both character pages already cited 鯖魚 correctly. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 鯤魚.

### 2026-09-09, iteration 3712 — [[words/鯤魚|鯤魚]]
Already well-perfected (stamped 2026-06-06): legitimizing note for 鯤 (own `stand_in` is [[鯤魚]] itself, already annotated), rich Notes on the Zhuangzi's 鯤-鵬 transformation parable. Verified pronunciation fields (gon'yo/곤요/ㄍㄛㄋ⼄), `kwin: false` (AND-rule: 鯤 true, 魚 false), and both character-page citations all still correct. Only fix was quoting `mandarin`/`cantonese`/`korean`. Re-stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no genuine collision.

Next: 鯨魚.

### 2026-09-09, iteration 3713 — [[words/鯨魚|鯨魚]]
Already fully perfected (stamped 2026-08-30): legitimizing note for 鯨, `japanese: くじら` already correctly the native word, and the homophone warning with [[敬語]] already confirmed genuine (verified again: exact-matching gyeng'yo/경요/ㄍ⼶ㄫ⼄). Verified pronunciation fields and `kwin: false` (AND-rule: 鯨 true, 魚 false) still correct. No changes needed — a clean pass.

Next: 鰌魚.

### 2026-09-09, iteration 3714 — [[words/鰌魚|鰌魚]]
Legitimizing note already substantively documented (鰌's own `stand_in` is [[鰌魚]] itself). **Found and fixed a real gap**: `characters/鰌.md`'s own citation of 鰌魚 was missing its "(stand-in for 鰌)" annotation despite 鰌's own `stand_in` pointing there. Pronunciation fields (cuyo/추요/ㄑㄨ⼄) and `kwin: false` (AND-rule: 鰌 true, 魚 false) already matched constituents exactly — no bug. Exceptionally rich existing Notes on the loach's barometric-sensitivity folklore, Edo-period 柳川鍋/どじょう-ya culture, and Korean 추어탕/Jeolla regional cuisine kept fully intact. Quoted `mandarin`/`cantonese`/`korean`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 鰐梨.

### 2026-09-09, iteration 3715 — [[words/鰐梨|鰐梨]]
No cranberry (鰐's own `stand_in` is [[鰐魚]], 梨's is 梨 itself — neither points here). Pronunciation fields ('agliǝ/악릐/ㄚㄎㄌㄧㄜ) and `kwin: false` (AND-rule: 鰐 true, 梨 false) already matched constituents exactly — no bug. `characters:` disambiguation already correct. Both character pages already cited 鰐梨 correctly. **Fixed a likely-wrong real-language field**: `japanese: ワニナシ` (a literal "alligator-pear" calque) was swapped for アボカド, the overwhelmingly dominant real modern Japanese word — matching Korean's already-correct loanword 아보카도. Filled entirely missing `vietnamese: bơ` (native, from French *beurre*, "butter"). Removed blank `hsk_level`/`swadesh`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 鰐魚.

### 2026-09-09, iteration 3716 — [[words/鰐魚|鰐魚]]
Legitimizing note added (鰐's own `stand_in` is [[鰐魚]] itself, already annotated in its own citation; 魚's own `stand_in` is 魚 itself, so transitivity fails — no `#cranberry`). Pronunciation fields ('ag'yo/악요/ㄚㄎ·⼄) and `kwin: false` (AND-rule: 鰐 true, 魚 false) already matched constituents exactly — no bug. **In passing, fixed 鰐's own citation**, which was missing its "(stand-in for 鰐)" annotation. Filled entirely missing `vietnamese: ngạc ngư` (compositional; noted native cá sấu). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 鱏.

### 2026-09-09, iteration 3717 — [[words/鱏|鱏]]
Self-standing bare-character word (own `stand_in` is 鱏 itself). Pronunciation fields (him/힘/ㄏㄧㄇ) and `kwin: false` already matched the character's own stored values exactly — no homophone. **Fixed a real bug**: `pos`/`品詞` were both entirely blank (duplicate empty fields) — consolidated to a single `pos: 名詞`, matching the character page. Filled entirely missing `vietnamese: tầm`. Stamped `date-last-perfect: 2026-09-09`.

Next: 鱗.

### 2026-09-09, iteration 3718 — [[words/鱗|鱗]]
Self-standing bare-character word. **Found and fixed a real gap — a previously undocumented homophone**: checked the full ㄌㄧㄋ syllable set and found [[隣]] ("neighbor") is itself a legitimized self-standing bare word with the exact same reading lin/린/ㄌㄧㄋ, yet neither page had ever documented this collision (checked 吝/燐/麟 too — none is self-standing, confirming the cluster is exactly these two). Added reciprocal `>[!warning] Homophones` callouts to both. Fixed duplicate `pos`/`品詞` and a bare-string `characters:` field. Stamped `date-last-perfect: 2026-09-09`.

Next: 鳥.

### 2026-09-09, iteration 3719 — [[words/鳥|鳥]]
Self-standing bare-character word, already richly perfected with a detailed kwin explanation (Dan'a'yo 촛 vs Korean 조, the shared MC 端母+蕭韻 palatalization with different aspiration/diphthong outcomes). Checked the full ㄑㄛㄨ syllable set (招/湊/彫/釣/取) for a homophone — none is itself a legitimized bare word, so none exists. Only fix was the recurring duplicate `pos`/`品詞` bug. Re-stamped `date-last-perfect: 2026-09-09`.

Next: 鳥嘴.

### 2026-09-09, iteration 3720 — [[words/鳥嘴|鳥嘴]]
Legitimizing note added (嘴's own `stand_in` is [[鳥嘴]] itself, already annotated in its own citation; 鳥's own `stand_in` is 鳥 itself, so transitivity fails — no `#cranberry`). Pronunciation fields (coucui/촛취/ㄑㄛㄨㄑㄨㄧ) and `kwin: false` (AND-rule: 鳥 false, 嘴 true) already matched constituents exactly — no bug. `japanese: くちばし`/`korean: 부리` already correctly the real native everyday words, matching 嘴's own `japanese_native`/`korean_native` fields exactly. **In passing, fixed a real gap**: `characters/嘴.md`'s own citation of 鳥嘴 was missing its "(stand-in for 嘴)" annotation. Filled entirely missing `vietnamese: điểu chuỷ` (compositional; noted native mỏ). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found only an incidental mention in `lexipedia/Body.md` — no genuine collision.

Next: 鳥巣.

### 2026-09-09, iteration 3721 — [[words/鳥巣|鳥巣]]
Legitimizing note added (巣's own `stand_in` is [[鳥巣]] itself, already annotated in its own citation; 鳥's own `stand_in` is 鳥 itself, so transitivity fails — no `#cranberry`). Pronunciation fields (coujau/촛잣/ㄑㄛㄨㄐㄚㄨ) already matched constituents exactly — no bug. **Fixed a real contamination bug**: `korean: 둥지, 새집` comma-joined two native synonyms — kept 둥지 (standard), moved 새집 to prose. **Fixed a real semantic-mismatch bug**: `vietnamese: làm tổ` was a verb phrase ("to build a nest") rather than the noun this word actually is — corrected to tổ chim. Filled blank `cantonese: niu5 caau4` and added missing `kwin: false` (AND-rule: both false). Removed blank `hsk_level`/`swadesh`/empty `aliases`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 鳥籠.

### 2026-09-09, iteration 3722 — [[words/鳥籠|鳥籠]]
No cranberry (both 鳥's and 籠's own `stand_in` point to themselves — neither points here). Pronunciation fields (coulong/촛롱/ㄑㄛㄨㄌㄛㄫ) and `kwin: false` (AND-rule: 鳥 false, 籠 true) already matched constituents exactly — no bug. `characters:` disambiguation already correct. Both character pages already cited 鳥籠 correctly. `japanese: とりかご`/`korean: 새장` already correctly native compounds. Filled entirely missing `vietnamese: lồng chim` — a real, reversed-word-order term, a 4th confirmed instance of the Vietnamese reversal pattern. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 鳥類.

### 2026-09-09, iteration 3723 — [[words/鳥類|鳥類]]
No cranberry (鳥's own `stand_in` is 鳥 itself, 類's is [[種類]] — neither points here). Pronunciation fields (coului/촛뤼/ㄑㄛㄨㄌㄨㄧ) and `kwin: false` (AND-rule: both false) already matched constituents exactly — no bug. Both character pages already cited 鳥類 correctly. Filled entirely missing `vietnamese: điểu loại`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no genuine collision.

Next: 鳩鳥.

### 2026-09-09, iteration 3724 — [[words/鳩鳥|鳩鳥]]
Legitimizing note added (鳩's own `stand_in` is [[鳩鳥]] itself; 鳥's own `stand_in` is 鳥 itself, so transitivity fails — no `#cranberry`). Pronunciation fields (kyucou/큐촛/ㄎ⼜ㄑㄛㄨ) and `kwin: false` (AND-rule: both false) already matched constituents exactly — no bug. **Found and fixed a cluster of real bugs**: `mandarin: jiū` was missing 鳥's own reading entirely (corrected to jiūniǎo); `cantonese` comma-joined an unexplained extra "kau1" and was missing 鳥's own niu5 (corrected to gau1 niu5); `japanese` comma-joined the correct はと with an unrecognizable "きう" matching neither of 鳩's own on'yomi (dropped); `vietnamese` was over-specified "domestic pigeon" relative to this word's plain sense (simplified to bồ câu). **Also fixed `characters/鳩.md` itself**: its own `## Words` list was missing a citation of 鳩鳥 entirely, the [[狙鳩]] entry had no ruby/gloss, [[斑鳩]] used an inconsistent asterisk bullet, and its Classical-Chinese-frequency line was the same dangling-bare-wikilinks bug seen before — all reformatted/reconstructed. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 鳳凰.

### 2026-09-09, iteration 3725 — [[words/鳳凰|鳳凰]]
Already fully perfected (stamped 2026-06-27) and correctly tagged `#cranberry` — verified both 鳳's and 凰's own `stand_in` point to [[鳳凰]] itself, confirming genuine transitivity for this "dead paired-gender" compound, matching its own listed category on `lookup/List of 連綿詞`. Rich existing Notes on the Shangshu/Zuozhuan omen tradition and the 龍鳳 imperial pairing kept intact. **Found and fixed a real gap**: `characters/凰.md`'s own citation of 鳳凰 was missing its "(stand-in for 凰)" annotation despite 凰's own `stand_in` pointing there (鳳's citation already had it). Quoted `mandarin`/`cantonese`/`korean`. Stamped `date-last-perfect: 2026-09-09`.

Next: 鳳梨.

### 2026-09-09, iteration 3726 — [[words/鳳梨|鳳梨]]
No cranberry (鳳's own `stand_in` is [[鳳凰]], 梨's is 梨 itself — neither points here). Pronunciation fields (pungliǝ/풍릐/ㄆㄨㄫㄌㄧㄜ) and `kwin: false` (AND-rule: both false) already matched constituents exactly — no bug. **Fixed a real bug**: `japanese: ほうり` was a compositional Sino reading, but real Japanese universally uses the loanword パイナップル (matching Korean's already-correct 파인애플) — swapped. Fixed a malformed citation on `characters/鳳.md` (bare "[[鳳梨]] "pineapple"" with no ruby/注音). Filled entirely missing `vietnamese: dứa` — the real native word. Removed blank `hsk_level`/`swadesh`/empty `aliases`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 鳳笙.

### 2026-09-09, iteration 3727 — [[words/鳳笙|鳳笙]]
Legitimizing note added (笙's own `stand_in` is [[鳳笙]] itself, already annotated in its own citation; 鳳's own `stand_in` is [[鳳凰]], so transitivity fails — no `#cranberry`). Pronunciation fields (pungsang/풍상/ㄆㄨㄫㄙㄚㄫ) and `kwin: false` (AND-rule: both false) already matched constituents exactly — no bug. Both character pages already cited 鳳笙 correctly. Rich existing Notes on the gagaku ほうしょう's technical vs. Chinese poetic register kept intact. Filled entirely missing `vietnamese: phượng sinh`. Quoted `mandarin`/`cantonese`/`korean`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 鳴.

### 2026-09-09, iteration 3728 — [[words/鳴|鳴]]
Already fully perfected (stamped 2026-08-30): self-standing bare-character word, pronunciation fields (myeng/명/ㄇ⼶ㄫ), `kwin: true`, and the documented genuine 3-way homophone group with [[皿]]/[[明]] all confirmed correct — verified both are themselves legitimized bare words with exact-matching readings. No changes needed — a clean pass.

Next: 鳶.

### 2026-09-09, iteration 3729 — [[words/鳶|鳶]]
Already fully perfected (stamped 2026-09-03) with an unusually thorough Notes section documenting its own prior romanization-typo fix and a genuine 3-way homophone discovery (演/鉛), already cross-checked against the full ⼶ㄋ syllable set. Verified pronunciation fields ('yen/연/⼶ㄋ) and `kwin: true` still match the character page exactly. No changes needed — a clean pass.

Next: 鴎.

### 2026-09-09, iteration 3730 — [[words/鴎|鴎]]
Self-standing bare-character word (own `stand_in` is 鴎 itself). Pronunciation fields ('ou/옷/ㄛㄨ) already matched the character's own stored values exactly — no homophone (checked full ㄛㄨ syllable set: 偶/殴/𧦅/呕/欧, none self-standing). **Found and fixed a real bug**: `pos` was `固有名詞` (proper noun) despite "seagull" plainly being a common noun — corrected to `名詞`, matching the character's own `pos`. Fixed the recurring duplicate `pos`/`品詞` bug and bare-string `characters:` field. Stamped `date-last-perfect: 2026-09-09`.

Next: 鴛鴦.

### 2026-09-09, iteration 3731 — [[words/鴛鴦|鴛鴦]]
Already correctly `#cranberry`-tagged — verified both 鴛's and 鴦's own `stand_in` point to [[鴛鴦]] itself with genuine transitivity (both independently mean "mandarin duck"), matching its listed entry on `lookup/List of 連綿詞`. Pronunciation fields ('on'ang/온앙/ㄛㄋ·ㄚㄫ), `kwin: false` (AND-rule: 鴛 false, 鴦 true), and all real-language fields already correct. **Found and fixed a real structural gap**: both `characters/鴛.md` and `characters/鴦.md` had no `## Words` section at all despite each documenting the cranberry relationship extensively in prose — added proper citation entries with stand-in annotations to both. Removed blank `hsk_level`/`swadesh`/empty `aliases`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no genuine collision.

Next: 鴨.

### 2026-09-09, iteration 3732 — [[words/鴨|鴨]]
Already fully perfected (stamped 2026-08-30): self-standing bare-character word with a detailed explanation of the Cantonese/Japanese sub-syllable distinction Dan'a'yo's coarser 注音 merges (aap3 vs. 押's aat3; corrected on-reading おう vs. garbled あふ). Verified pronunciation fields ('ab/압/ㄚㄆ), `kwin: true`, and the homophone warning with [[押]] all still correct — 押's own `stand_in` points to itself, exact-matching reading. No changes needed — a clean pass.

Next: 鴻鵠.

### 2026-09-09, iteration 3733 — [[words/鴻鵠|鴻鵠]]
Legitimizing note already substantively documented (鵠's own `stand_in` is [[鴻鵠]] itself). Pronunciation fields (honghog/홍혹/ㄏㄛㄫㄏㄛㄎ) and `kwin: false` (AND-rule: 鴻 true, 鵠 false) already matched constituents exactly — no bug. Both character pages already cited 鴻鵠 correctly. **Found and fixed a real bug**: `pos: 事詞` was wrong for a noun ("swan") — corrected to `名詞`, matching both constituent characters' own `pos`. Rich existing Notes on the Shiji's 燕雀安知鴻鵠之志哉 saying and 鴻's 名専字 status kept intact. Fixed duplicate `pos`/`品詞`, quoted real-language fields. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 鵉鳳.

### 2026-09-09, iteration 3734 — [[words/鵉鳳|鵉鳳]]
Legitimizing note reworded to convention (鵉's own `stand_in` is [[鵉鳳]] itself; 鳳's own `stand_in` is [[鳳凰]], so transitivity fails — no `#cranberry`) — the existing Notes already said this substantively. Pronunciation fields (lanpung/란풍/ㄌㄚㄋㄆㄨㄫ) and `kwin: false` (AND-rule: 鵉 true, 鳳 false) already matched constituents exactly — no bug. Both character pages already cited 鵉鳳 correctly. Filled entirely missing `japanese: らんほう`/`vietnamese: loan phượng`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 鵖鴔.

### 2026-09-09, iteration 3735 — [[words/鵖鴔|鵖鴔]]
Already correctly `#cranberry`-tagged — verified both 鵖's and 鴔's own `stand_in` point to [[鵖鴔]] itself, matching its listed entry on `lookup/List of 連綿詞`. Pronunciation fields (bubbib/붑빕/ㄅㄨㄆㄅㄧㄆ) already matched constituents exactly — no bug. **Found and fixed a real bug**: `pos: 固有名詞` was wrong for a bird species name (a common noun) — corrected to `名詞`, matching both constituent characters. **Decoded a terse stray note** ("Different from a 戴勝") into proper Notes: 鵖鴔 is a classical/archaic hoopoe name distinct from the modern standard 戴勝; filled `japanese: ヤツガシラ`/`korean: 핍핍` (compositional) and flattened `vietnamese` from a list to scalar `đầu rìu`. Flagged, without resolving, an apparent discrepancy on 鵖's own character page (its native gloss points to goldcrest, not hoopoe). In passing fixed a missing stand-in annotation on 鵖's citation and the recurring duplicate `pos`/`品詞` bug. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no genuine collision.

Next: 鵝鳥.

### 2026-09-09, iteration 3736 — [[words/鵝鳥|鵝鳥]]
Legitimizing note added (鵝's own `stand_in` is [[鵝鳥]] itself, already annotated in its own citation; 鳥's own `stand_in` is 鳥 itself, so transitivity fails — no `#cranberry`). Pronunciation fields ('acou/아촛/ㄚㄑㄛㄨ) and `kwin: false` (AND-rule: 鵝 true, 鳥 false) already matched constituents exactly — no bug. **Fixed a real bug**: `mandarin: è` was missing 鳥's own reading entirely — corrected to compositional éniǎo. Filled blank `cantonese: ngo4 niu5`/`vietnamese: nga điểu` (compositional; noted the everyday native word ngỗng). `japanese: がちょう`/`korean: 거위` already correctly native. In passing, fixed 鵝's own citation, which was missing its "(stand-in for 鵝)" annotation. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found only a substring false-positive on 詐取 — no genuine collision.

Next: 鵰.

### 2026-09-09, iteration 3737 — [[words/鵰|鵰]]
Self-standing bare-character word. Pronunciation fields (cuo/춧/ㄑㄨㄛ) already matched the character's own stored values exactly — the existing homophone warning with [[秋]] confirmed genuine (own `stand_in` points to itself). **Found and fixed the same recurring `pos: 固有名詞`→`名詞` bug** seen on 鴎/鴻鵠 — "eagle" is a common noun, not a proper noun, matching the character's own `pos`. Fixed duplicate `pos`/`品詞`, a bare-string `characters:` field, and a stray trailing space on `vietnamese`. Stamped `date-last-perfect: 2026-09-09`.

Next: 鶏.

### 2026-09-09, iteration 3738 — [[words/鶏|鶏]]
Self-standing bare-character word. `pos: 名詞` already correct this time (unlike the recent 鴎/鴻鵠/鵰 mistagging pattern). Pronunciation fields (gei/게/ㄍㄝㄧ) already matched the character's own stored values exactly — checked the full ㄍㄝㄧ syllable set (係/稽/計/継), none self-standing, so no homophone. Fixed duplicate `pos`/`品詞`, a bare-string `characters:` field, and flattened single-item `japanese`/`vietnamese` lists to scalars. Stamped `date-last-perfect: 2026-09-09`.

Next: 鶏卵.

### 2026-09-09, iteration 3739 — [[words/鶏卵|鶏卵]]
No cranberry (鶏's own `stand_in` is 鶏 itself, 卵's is [[卵子]] — neither points here). Pronunciation fields (geilan/게란/ㄍㄝㄧㄌㄚㄋ) and `kwin: false` (AND-rule: 鶏 false, 卵 true) already matched constituents exactly — no bug. Both character pages already cited 鶏卵 correctly. **Fixed a real bug**: `cantonese: ji1 dan4` matched neither constituent's own reading (dan4/蛋 being a different, unrelated Cantonese word for "egg") — corrected to gai1 leon2. **Fixed a malformed `vietnamese` field**: had an odd embedded parenthetical "trứng (thức ăn)" — replaced with the cleaner real term trứng gà, a native word-order reversal joining the vault's documented set of such cases. Removed blank `hsk_level`/`swadesh`, consolidated Etymology into `## Notes`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 鶏肉.

### 2026-09-09, iteration 3740 — [[words/鶏肉|鶏肉]]
No cranberry (both 鶏's and 肉's own `stand_in` point to themselves — neither points here). Pronunciation fields (geinug/게눅/ㄍㄝㄧㄋㄨㄎ) and `kwin: false` (AND-rule: both false) already matched constituents exactly — no bug. Both character pages already cited 鶏肉 correctly. Rich existing Notes on the JA on'yomi/native-hybrid readings and cross-language native-vs-Sino divergence kept intact. Filled entirely missing `vietnamese: kê nhục` (compositional; already correctly described in prose as losing out to native thịt gà, now named explicitly). Quoted `mandarin`/`cantonese`/`korean`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 鶏鳴.

### 2026-09-09, iteration 3741 — [[words/鶏鳴|鶏鳴]]
No cranberry (both 鶏's and 鳴's own `stand_in` point to themselves — neither points here). **Fixed the recurring `characters:` disambiguation bug on BOTH constituents**: bare "鶏"/"鳴" despite `words/鶏.md` and `words/鳴.md` both existing. Pronunciation fields (geimyeng/게명/ㄍㄝㄧㄇ⼶ㄫ) already matched constituents exactly — no bug. Both character pages already cited 鶏鳴 correctly. Filled blank `cantonese: gai1 ming4`/`korean: 계명`/`vietnamese: ke minh` and added missing `kwin: false` (AND-rule: 鶏 false, 鳴 true). Removed blank `hsk_level`/`swadesh`, consolidated Etymology into `## Notes`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found only substring hits on the longer chengyu 鶏鳴狗盗 — no genuine collision.

Next: 鶴.

### 2026-09-09, iteration 3742 — [[words/鶴|鶴]]
Already fully perfected (stamped 2026-08-31): self-standing bare-character word, pronunciation fields (hag/학/ㄏㄚㄎ), `kwin: true`, and the documented genuine 3-way homophone group with [[核]]/[[嚇]] all confirmed correct — verified both are themselves legitimized bare words. No changes needed — a clean pass.

Next: 鷹.

### 2026-09-09, iteration 3743 — [[words/鷹|鷹]]
Already fully perfected (stamped 2026-08-29): self-standing bare-character word, pronunciation fields ('ing/잉/ㄧㄫ), `kwin: false`, and the homophone warning with [[応]] all confirmed correct — 応's own `stand_in` points to itself, exact-matching reading. No changes needed — a clean pass.

Next: 鸚哥.

### 2026-09-09, iteration 3744 — [[words/鸚哥|鸚哥]]
No cranberry (鸚's own `stand_in` is [[鸚鵡]], 哥's is [[哥哥]] — neither points here). Pronunciation fields ('anggǝ/앙그/ㄚㄫㄍㄜ) already matched constituents exactly — no bug. Both character pages already cited 鸚哥 correctly. Filled entirely blank `japanese: おうか`/`vietnamese: anh ca` (compositional; noted everyday Vietnamese prefers native vẹt) and added missing `kwin: false` (AND-rule: both false). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 鸚鵡.

### 2026-09-09, iteration 3745 — [[words/鸚鵡|鸚鵡]]
Already correctly `#cranberry`-tagged — verified both 鸚's and 鵡's own `stand_in` point to [[鸚鵡]] itself, matching its listed entry on `lookup/List of 連綿詞`. Pronunciation fields ('angmu/앙무/ㄚㄫㄇㄨ), `kwin: false` (AND-rule: 鸚 false, 鵡 true), and all real-language fields already correct — `vietnamese: vẹt` confirmed as the real everyday native word (vs. the less common compositional anh vũ), documented in Notes. **Found and fixed the same structural gap as 鴛/鴦**: `characters/鵡.md` had no `## Words` section at all despite documenting the cranberry relationship extensively in prose — added a proper citation with stand-in annotation. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check (precise 注音-only match, ruling out earlier broad substring hits) found no genuine collision.

Next: 鸛鶴.

### 2026-09-09, iteration 3746 — [[words/鸛鶴|鸛鶴]]
Legitimizing note already substantively documented (鸛's own `stand_in` is [[鸛鶴]] itself). Pronunciation fields (gwanhag/관학/ㄍ⺢ㄋㄏㄚㄎ) and `kwin: true` (AND-rule: both true) already matched constituents exactly — no bug. Both character pages already cited 鸛鶴 correctly. Filled entirely missing `vietnamese: quán hạc`. Quoted `mandarin`/`cantonese`/`korean`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 鹸.

### 2026-09-09, iteration 3747 — [[words/鹸|鹸]]
Self-standing bare-character word. Pronunciation fields (cem/첨/ㄑㄝㄇ) and `kwin: true` already matched the character's own stored values exactly — the existing homophone warning with [[諂]] confirmed genuine (own `stand_in` points to itself, per that page's own prior perfecting notes referencing a `homophone_check.py` script). Reformatted the Notes from an unconventional numbered list into proper prose, keeping the useful content: 鹸 serves as the periodic-table abbreviation prefix for sodium via [[鹸素]]. Fixed a bare-string `characters:` field.

Next: 鹸素.

### 2026-09-09, iteration 3748 — [[words/鹸素|鹸素]]
Periodic-table neologism series (sodium): already correctly following convention — `mandarin`/`cantonese` give the avoided real element character 鈉/钠's readings; `korean`/`japanese`/`vietnamese` (나트륨/ナトリウム/natri) are loanwords from "Natrium"; `kwin: false` correctly compares Dan'a'yo against Korean. Dan'a'yo pronunciation fields (cemso/첨소/ㄑㄝㄇㄙㄛ) correctly follow normal compositional concatenation of 鹸+素. `characters:` disambiguation already correct (`words/鹸.md` exists, `words/素.md` doesn't). Both character pages already cited 鹸素 correctly. Rich existing Notes already comparing this semantic (not phonetic) coinage to [[巨金]]/[[惰素]] kept intact. No changes needed — a clean pass.

Next: 鹿.

### 2026-09-09, iteration 3749 — [[words/鹿|鹿]]
Already fully perfected (stamped 2026-08-03): self-standing bare-character word with a detailed record of a prior real `korean` bug fix (녹→록, the same North-Korean-form pattern as [[老]]), and the genuine homophone with [[緑]] confirmed correct — verified 緑's own `stand_in` points to itself, exact-matching reading. `characters/鹿 (char).md`'s own remaining rough state was already flagged as out-of-scope for a future character-perfection sweep, not this word. No changes needed — a clean pass.

Next: 鹿砦.

### 2026-09-09, iteration 3750 — [[words/鹿砦|鹿砦]]
Legitimizing note added (砦's own `stand_in` is [[鹿砦]] itself, already annotated in its own citation; 鹿's own `stand_in` is 鹿 itself, so transitivity fails — no `#cranberry`). Pronunciation fields (logjai/록재/ㄌㄛㄎㄐㄚㄧ) already matched constituents exactly — no bug. **In passing, fixed a real gap**: `characters/砦.md`'s own citation of 鹿砦 was missing its "(stand-in for 砦)" annotation. Filled blank `korean: 록채`/`vietnamese: lộc trại` and added missing `kwin: false` (AND-rule: 鹿 true, 砦 false). Removed blank `hsk_level`/`swadesh`/empty `aliases`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 麒麟.

### 2026-09-09, iteration 3751 — [[words/麒麟|麒麟]]
Already correctly `#cranberry`-tagged — verified both 麒's and 麟's own `stand_in` point to [[麒麟]] itself, matching its listed entry on `lookup/List of 連綿詞`. Pronunciation fields (gilin/기린/ㄍㄧㄌㄧㄋ), `kwin: true` (AND-rule: both true), and all real-language fields already correct. **Unlike 鴛/鴦 and 鵡, both character pages already had proper `## Words` sections** — but both were missing the "(stand-in for X)" annotation despite their own `stand_in` pointing here; fixed both. Removed blank `hsk_level`/`swadesh`/empty `aliases`, quoted real-language fields. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 麒麟羚羊.

### 2026-09-09, iteration 3752 — [[words/麒麟羚羊|麒麟羚羊]]
No cranberry (none of the four constituents' own `stand_in` points here). Pronunciation fields (gilinleng'yang/기린렁양/ㄍㄧㄌㄧㄋㄌㄝㄫ⼘ㄫ) and `kwin: false` (AND-rule: 麒 true, 麟 true, 羚 false, 羊 true → false) already matched constituents exactly — no bug. **Found and fixed the most severe real-language field bug this sweep**: `mandarin: zhōnggúo` was literally "中国" ("China," entirely unrelated) and `cantonese: yǔwén1` was likewise unrelated garbage ("語文"-ish, "language and literature") — both corrected to the compositional qílínlíngyáng/kei4leon4ling4joeng4. Filled entirely missing `vietnamese: kỳ lân linh dương`. **In passing, fixed a real citation gap** on `characters/羊.md`, whose own Words list was missing 麒麟羚羊 entirely. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 麟史.

### 2026-09-09, iteration 3753 — [[words/麟史|麟史]]
No cranberry (麟's own `stand_in` is [[麒麟]], 史's is [[歴史]] — neither points here). Pronunciation fields (linsi/린시/ㄌㄧㄋㄙㄧ) and `kwin: false` (AND-rule: 麟 true, 史 false) already matched constituents exactly — no bug. Both character pages already cited 麟史 correctly. `pos: 固有名詞` already correctly a proper noun (a specific historical text's alternate name, unlike the recent bird-species mistagging cases). **Investigated `korean: 인사`, which deviates from 麟's own stored 린 (the North-Korean-consistent compositional form would be 린사)** — cross-checked the sibling word [[麟経]], which documents the identical 두음법칙 pattern (인경, also deviating from 린) with a specific real-world-attestation rationale; treated as a deliberate, already-reasoned exception rather than a bug, and left unchanged. Only fix was the recurring duplicate `pos`/`品詞` bug. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 麟経.

### 2026-09-09, iteration 3754 — [[words/麟経|麟経]]
No cranberry (麟's own `stand_in` is [[麒麟]], 経's is 経 itself — neither points here). Pronunciation fields (lingeng/린겅/ㄌㄧㄋㄍㄝㄫ) and `kwin: false` (AND-rule: 麟 true, 経 false) already matched constituents exactly — no bug. `characters:` disambiguation already correct. Both character pages already cited 麟経 correctly. `korean: 인경` already correctly the documented deliberate exception (matching 麟史's identical pattern, confirmed last iteration). Only fix was the recurring duplicate `pos`/`品詞` bug and quoting real-language fields. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 麦芽.

### 2026-09-09, iteration 3755 — [[words/麦芽|麦芽]]
No cranberry (麦's own `stand_in` is [[大麦]], 芽's is [[新芽]] — neither points here). Pronunciation fields (mag'a/막아/ㄇㄚㄎㄚ) and `kwin: false` (AND-rule: 麦 false, 芽 true) already matched constituents exactly — no bug (noted the 注音 lacks a syllable-boundary dot before the vowel-initial 芽, unlike some other vowel-initial-second-syllable words this sweep — but 麦's own character page uses the identical undotted form consistently across its own citations, so left as an established pattern rather than guessed at). Both character pages already cited 麦芽 correctly. All real-language fields already correct standard readings. Removed blank `hsk_level`/`swadesh`, consolidated Etymology into `## Notes`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 麦芽糖.

### 2026-09-09, iteration 3756 — [[words/麦芽糖|麦芽糖]]
No cranberry (none of the three constituents' own `stand_in` points here). Pronunciation fields (mag'adwang/막아돵/ㄇㄚㄎㄚㄉ⺢ㄫ) already matched constituents exactly — no bug (same consistently-undotted pattern as [[麦芽]], left alone). **Fixed the recurring `characters:` disambiguation bug**: bare "糖" despite `words/糖.md` existing (Etymology already correctly cited "糖 (char)"). Both character pages already cited 麦芽糖 correctly. Filled entirely missing `vietnamese: mạch nha đường`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 麦茶.

### 2026-09-09, iteration 3757 — [[words/麦茶|麦茶]]
No cranberry (both 麦's and 茶's own `stand_in` point elsewhere — neither points here). Pronunciation fields (magca/막차/ㄇㄚㄎㄑㄚ) already matched constituents exactly — no bug. `characters:` disambiguation already correct. Both character pages already cited 麦茶 correctly. Left `korean` deliberately blank per the existing well-reasoned note (real Korean has no attested Sino form at all, using only native 보리차). Added missing `kwin: false` (AND-rule: both false) and filled entirely missing `vietnamese: mạch trà` (compositional). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 麦酒.

### 2026-09-09, iteration 3758 — [[words/麦酒|麦酒]]
No cranberry (麦's own `stand_in` is [[大麦]], 酒's is [[酒精]] — neither points here). Pronunciation fields (magjuo/막줏/ㄇㄚㄎㄐㄨㄛ) and `kwin: false` (AND-rule: both false) already matched constituents exactly — no bug. Both character pages already cited 麦酒 correctly. **Investigated and explained a real divergence, previously undocumented**: `mandarin`/`cantonese` (píjiǔ/be1zau2) don't match compositional màijiǔ/mak6zau2 — confirmed this is deliberate, giving the real modern standard word 啤酒 (already listed as this word's alias) instead, since 麦酒 itself is the historical Japanese-coined term now largely displaced by ビール — the same real-name-over-compositional convention seen elsewhere; documented in Notes. Removed blank `hsk_level`/`swadesh`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 麺.

### 2026-09-09, iteration 3759 — [[words/麺|麺]]
Self-standing bare-character word. Pronunciation fields (men/먼/ㄇㄝㄋ) already matched the character's own stored values exactly — no homophone. Kept the existing explanation of the flour→noodle metonymy and cross-reference to [[拉麺]] intact. Fixed duplicate `pos`/`品詞` and flattened single-item `japanese`/`vietnamese` lists to scalars. Stamped `date-last-perfect: 2026-09-09`.

Next: 麺包.

### 2026-09-09, iteration 3760 — [[words/麺包|麺包]]
No cranberry (麺's own `stand_in` is 麺 itself, 包's is [[包装]] — neither points here). Pronunciation fields (menbyau/먼뱟/ㄇㄝㄋㄅ⼘ㄨ) and `kwin: false` (AND-rule: both false) already matched constituents exactly — no bug. Both character pages already cited 麺包 correctly. `japanese: パン`/`korean: 빵` already correctly loanwords from Portuguese *pão*. Decoded a stray note ("for pastries and sweet bread, use 餅") into a proper Notes sentence. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found only an incidental Bible-translation mention — no genuine collision.

Next: 麻布.

### 2026-09-09, iteration 3761 — [[words/麻布|麻布]]
No cranberry (麻's own `stand_in` is [[大麻]], 布's is [[亜麻布]] — neither points here). Pronunciation fields (mabo/마보/ㄇㄚㄅㄛ) and `kwin: false` (AND-rule: 麻 true, 布 false) already matched constituents exactly — no bug. **Fixed a real contamination bug**: `japanese: あさふ,あさぬの` comma-joined two forms — kept あさぬの (the more naturally-attested compound). **Fixed a malformed citation** on `characters/麻.md` (markdown-link syntax mixed with orphaned ruby tags instead of the standard wikilink template). Filled entirely missing `vietnamese: ma bố`. Removed blank `hsk_level`/`swadesh`/empty `aliases`, consolidated Etymology into `## Notes`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 麻痺.

### 2026-09-09, iteration 3762 — [[words/麻痺|麻痺]]
Legitimizing note added (痺's own `stand_in` is [[麻痺]] itself, already annotated in its own citation; 麻's own `stand_in` is [[大麻]], so transitivity fails — no `#cranberry`). Pronunciation fields (mabi/마비/ㄇㄚㄅㄧ) and `kwin: true` (AND-rule: both true) already matched constituents exactly — no bug. **Fixed the same malformed-citation pattern found on 麻布, and swept the rest of `characters/麻.md`'s Words list while there**: 麻痺's own citation plus 麻雀/淡麻/胡麻 all used markdown-link syntax instead of wikilinks, and 亜麻 had no ruby/注音 at all — reformatted all five to the standard template (亜麻's 注音 verified against its own word file rather than guessed). **In passing, fixed a real gap**: `characters/痺.md`'s citation was missing its "(stand-in for 痺)" annotation. Filled entirely missing `vietnamese: ma tê`, extending the existing rich Notes on the shared hemp-metaphor etymology. Rich existing content on medical/figurative senses (脳性麻痺, 都市機能が麻痺する) kept intact. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 麻雀.

### 2026-09-09, iteration 3763 — [[words/麻雀|麻雀]]
No cranberry (麻's own `stand_in` is [[大麻]], 雀's is [[麻雀鳥]] — neither points here). Pronunciation fields (majag/마작/ㄇㄚㄐㄚㄎ) and `kwin: true` (AND-rule: both true) already matched constituents exactly — no bug. **Decoded the design behind this word**: 麻雀 is deliberately reserved for "mahjong" while the literal "sparrow" sense uses the extended [[麻雀鳥]] (雀's own actual legitimizer) — documented this disambiguation explicitly in Notes. **In passing, fixed a real citation gap**: `characters/雀.md`'s own Words list was missing 麻雀 entirely (had only its own stand-in 麻雀鳥) — added, and added the missing "(stand-in for 雀)" annotation to the existing 麻雀鳥 citation. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 麻雀鳥.

### 2026-09-09, iteration 3764 — [[words/麻雀鳥|麻雀鳥]]
Legitimizing note added (雀's own `stand_in` is [[麻雀鳥]] itself, already annotated in its own citation; neither 麻's nor 鳥's own `stand_in` points here — no `#cranberry`). Pronunciation fields (majagcou/마작촛/ㄇㄚㄐㄚㄎㄑㄛㄨ) and `kwin: false` (AND-rule: 麻 true, 雀 true, 鳥 false → false) already matched constituents exactly — no bug. All three character pages already cited 麻雀鳥 correctly. `japanese: すずめ`/`korean: 참새` already correctly native. Filled entirely missing `vietnamese: ma tước điểu`. Self-caught and fixed a tone-typo (maa5→maa4) I introduced while drafting the Notes prose. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 黄.

### 2026-09-09, iteration 3765 — [[words/黄|黄]]
Self-standing bare-character word. Pronunciation fields (hwang/황/ㄏ⺢ㄫ) and `kwin: true` already matched the character's own stored values exactly — checked the full ㄏ⺢ㄫ syllable set (徨/横/凰/皇/幌/煌/況/慌/晃/荒), none self-standing, so no homophone. **Found and fixed a real bug**: `cantonese: huang2` was a Mandarin-pinyin-style romanization, not valid Jyutping — corrected to wong4, matching the character's own stored field. Fixed duplicate `pos`/`品詞` and a bare-string `characters:` field. Stamped `date-last-perfect: 2026-09-09`.

Next: 黄昏.

### 2026-09-09, iteration 3766 — [[words/黄昏|黄昏]]
Legitimizing note added (昏's own `stand_in` is [[黄昏]] itself, already annotated in its own citation; 黄's own `stand_in` is 黄 itself, so transitivity fails — no `#cranberry`). Pronunciation fields (hwanghon/황혼/ㄏ⺢ㄫㄏㄛㄋ) and `kwin: true` (AND-rule: both true) already matched constituents exactly — no bug. **Fixed the recurring `characters:` disambiguation bug**: bare "黄" despite `words/黄.md` existing (Etymology already correctly cited "黄 (char)"). Both character pages already cited 黄昏 correctly. All real-language fields already correct standard readings. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 黄檗.

### 2026-09-09, iteration 3767 — [[words/黄檗|黄檗]]
Legitimizing note added (檗's own `stand_in` is [[黄檗]] itself, already annotated in its own citation; 黄's own `stand_in` is 黄 itself, so transitivity fails — no `#cranberry`). Pronunciation fields (hwangbag/황박/ㄏ⺢ㄫㄅㄚㄎ) already matched constituents exactly — no bug. **Found and fixed two real bugs**: `cantonese` had two slash-separated candidates ("wong4 baak3 / wong4 paak3") — kept only paak3, matching 檗's own stored field exactly; `kwin: true` contradicted the AND-rule (檗's own kwin is false) — corrected to `false`. **In passing, fixed a missing stand-in annotation** on 檗's own citation. Filled entirely missing `vietnamese: hoàng bách`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 黄沙.

### 2026-09-09, iteration 3768 — [[words/黄沙|黄沙]]
No cranberry (both 黄's and 沙's own `stand_in` point to themselves — neither points here). Pronunciation fields (hwangsa/황사/ㄏ⺢ㄫㄙㄚ) and `kwin: true` (AND-rule: both true) already matched constituents exactly — no bug. Both character pages already cited 黄沙 correctly. Filled entirely missing `japanese: こうさ`, using 黄's first-listed KOU reading (over OU, the reading its own bare word page uses) — こうさ matches the real, standard Japanese term for this weather phenomenon exactly (though modern Japanese conventionally spells it 黄砂). Filled entirely missing `vietnamese: hoàng sa`, flagging its coincidental overlap with the Paracel Islands' Vietnamese name. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 黄泉.

### 2026-09-09, iteration 3769 — [[words/黄泉|黄泉]]
No cranberry (黄's own `stand_in` is 黄 itself, 泉's is [[源泉]] — neither points here). Pronunciation fields (hwangjwen/황줜/ㄏ⺢ㄫㄐ⼔ㄋ) and `kwin: false` (AND-rule: 黄 true, 泉 false) already matched constituents exactly — no bug. Both character pages already cited 黄泉 correctly. **Fixed a real contamination bug**: `japanese: よみ,こうせん` comma-joined two forms — kept よみ, the real, culturally significant term for the Japanese mythological underworld. `korean: 황천` already correctly compositional. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 黄海.

### 2026-09-09, iteration 3770 — [[words/黄海|黄海]]
No cranberry (both 黄's and 海's own `stand_in` point elsewhere — neither points here). Pronunciation fields (hwanghai/황해/ㄏ⺢ㄫㄏㄚㄧ) and `kwin: true` (AND-rule: both true) already matched constituents exactly — no bug. Both character pages already cited 黄海 correctly. Decoded a stray note ("Koreans call it 西海") into a proper Notes sentence, explaining the Korean colloquial 西海/서해 preference alongside the formal 황해 already used in this word's own `korean` field (kept, since both are genuinely real Korean usage). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 黄金.

### 2026-09-09, iteration 3771 — [[words/黄金|黄金]]
Already fully perfected (stamped 2026-07-27): a real, established compound for gold (unlike the invented-calque periodictable neologisms elsewhere this sweep), correctly tagged `periodictable` without `neologism`, with `kwin: true` correctly following the normal AND-rule rather than the special neologism convention. Verified pronunciation fields (hwanggim/황김/ㄏ⺢ㄫㄍㄧㄇ) and both character-page citations still correct. No changes needed — a clean pass.

Next: 黄銅.

### 2026-09-09, iteration 3772 — [[words/黄銅|黄銅]]
No cranberry (both 黄's and 銅's own `stand_in` point to themselves — neither points here). Pronunciation fields (hwangdong/황동/ㄏ⺢ㄫㄉㄛㄫ) already matched constituents exactly — no bug. Both character pages already cited 黄銅 correctly. **Fixed a likely typo**: `japanese: わうどう` used the archaic historical kana spelling — corrected to おうどう, matching the modern form already established on the sibling word [[黄金]]. Filled blank `korean: 황동`/`vietnamese: hoàng đồng` (compositional; noted native đồng thau) and added missing `kwin: true` (AND-rule: both true). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 黎明.

### 2026-09-09, iteration 3773 — [[words/黎明|黎明]]
Legitimizing note added (黎's own `stand_in` is [[黎明]] itself, already annotated in its own citation; 明's own `stand_in` is 明 itself, so transitivity fails — no `#cranberry`). Pronunciation fields (leimyeng/레명/ㄌㄝㄧㄇ⼶ㄫ) and `kwin: false` (AND-rule: 黎 false, 明 true) already matched constituents exactly — no bug. **Fixed the recurring `characters:` disambiguation bug**: bare "明" despite `words/明.md` existing (Etymology already correctly cited "明 (char)"). **Fixed a real content bug**: the Etymology gloss for 黎 was literally its own romanization "Liǝ" rather than a meaning — corrected to "black" (黎's own stored English gloss), explaining the "black-bright" transition-to-dawn logic. Filled entirely missing `vietnamese: lê minh`. In passing fixed curly quotes and a missing stand-in annotation on 黎's own citation. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 黒.

### 2026-09-09, iteration 3774 — [[words/黒|黒]]
Already fully perfected (stamped 2026-08-03): self-standing bare-character word with a rich Notes section on the soot/smoke-blackened 象形 origin (paralleling [[青]]'s pigment-based etymology), the periodic-table hassium prefix role via [[黒金]], and a detailed kwin explanation. Verified pronunciation fields (hug/훅/ㄏㄨㄎ) and `kwin: false` still match the character page exactly. No changes needed — a clean pass.

Next: 黒暗.

### 2026-09-09, iteration 3775 — [[words/黒暗|黒暗]]
No cranberry (both 黒's and 暗's own `stand_in` point to themselves — neither points here), added to the extensive existing philosophical/cosmological essay covering Daoist 玄, yin, Buddhist 無明, and the moral light/darkness polarity. Pronunciation fields (hug'am/훅암/ㄏㄨㄎ·ㄚㄇ) and `kwin: false` (AND-rule: 黒 false, 暗 true) already matched constituents exactly — no bug. **Found and fixed two real bugs where the frontmatter directly contradicted the essay's own prose**: `korean: 암흑` had the syllables reversed (the prose itself already correctly says 흑암) — corrected; `vietnamese: bóng tối` was a native phrase entirely different from the compositional form the prose explicitly names (hắc ám) — corrected. Also fixed a duplicated "hắc ám or hắc ám" typo in the prose itself, and a real citation gap on `characters/黒 (char).md`, whose Words list was missing 黒暗 entirely. Added missing `date-last-perfect: 2026-09-09`. Background exact-match homophone check found only an incidental Bible-translation mention — no genuine collision.

Next: 黒板.

### 2026-09-09, iteration 3776 — [[words/黒板|黒板]]
No cranberry (黒's own `stand_in` is 黒 itself, 板's is [[木板]] — neither points here). Pronunciation fields (hugpan/훅판/ㄏㄨㄎㄆㄚㄋ) and `kwin: false` (AND-rule: 黒 false, 板 true) already matched constituents exactly — no bug. **Fixed the recurring `characters:` disambiguation bug**: bare "黒" despite `words/黒.md` existing. Both character pages already cited 黒板 correctly. Filled entirely missing `vietnamese: hắc bản`, quoted `hsk_level`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 黒洞.

### 2026-09-09, iteration 3777 — [[words/黒洞|黒洞]]
No cranberry (黒's own `stand_in` is 黒 itself, 洞's is [[洞窟]] — neither points here). Pronunciation fields (hugdong/훅동/ㄏㄨㄎㄉㄛㄫ) and `kwin: false` (AND-rule: 黒 false, 洞 true) already matched constituents exactly — no bug. Both character pages already cited 黒洞 correctly. `japanese: ブラックホール`/`korean: 블랙홀` already correctly English loanwords. Filled entirely missing `vietnamese: hố đen`, a real native word-order-reversed term. Fixed a stray blank Etymology gloss for 黒. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 黒猩.

### 2026-09-09, iteration 3778 — [[words/黒猩|黒猩]]
No cranberry (黒's own `stand_in` is 黒 itself, 猩's is [[猩猩]] — neither points here). Pronunciation fields (hugseng/훅성/ㄏㄨㄎㄙㄝㄫ) and `kwin: false` (AND-rule: 黒 false, 猩 true) already matched constituents exactly — no bug. Both character pages already cited 黒猩 correctly. Rich existing Notes on the 黒猩猩 abbreviation pattern (paralleling 大猩/倭猩) and Jane Goodall's Gombe research kept intact. Only fix was quoting `mandarin`/`cantonese`/`korean`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 黒色.

### 2026-09-09, iteration 3779 — [[words/黒色|黒色]]
No cranberry (黒's own `stand_in` is 黒 itself, 色's is [[色彩]] — neither points here). Pronunciation fields (hugsig/훅식/ㄏㄨㄎㄙㄧㄎ) and `kwin: false` (AND-rule: both false) already matched constituents exactly — no bug. **Fixed the recurring `characters:` disambiguation bug** and **a real comma-joined `vietnamese` contamination bug** (kept đen, the real native word; hắc mentioned as the compositional alternate in Notes). Documented `japanese: くろ`/`korean: 검정` as legitimate real-native-word choices over the compositional こくしょく/흑색, previously unexplained. Removed blank `hsk_level`/`swadesh`/empty `aliases`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 黒貂.

### 2026-09-09, iteration 3780 — [[words/黒貂|黒貂]]
Legitimizing note added (貂's own `stand_in` is [[黒貂]] itself, already annotated in its own citation; 黒's own `stand_in` is 黒 itself, so transitivity fails — no `#cranberry`). Pronunciation fields (hugco/훅초/ㄏㄨㄎㄑㄛ) and `kwin: false` (AND-rule: 黒 false, 貂 true) already matched constituents exactly — no bug. Fixed the recurring `characters:` disambiguation bug. `japanese: くろてん`/`korean: 검은담비` already correctly native compounds. In passing, fixed a missing stand-in annotation on 貂's own citation. Filled entirely missing `vietnamese: hắc điêu`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 黒金.

### 2026-09-09, iteration 3781 — [[words/黒金|黒金]]
Periodic-table neologism series (hassium): already correctly following convention and richly documented — the toponymic coincidence between 黒 ("black") and 黑森州 (Hesse, where hassium was discovered) explained alongside parallels to [[海金]]/[[冥金]]. `mandarin`/`cantonese` give the avoided real element character 𨭆's own reading; `korean`/`japanese`/`vietnamese` are IUPAC-name loanwords; `kwin: false` correctly compares Dan'a'yo against Korean. `characters/金 (char).md` doesn't cite 黒金, consistent with that character's already-documented, deliberately out-of-scope citation gap. No changes needed — a clean pass.

Next: 黙想.

### 2026-09-09, iteration 3782 — [[words/黙想|黙想]]
No cranberry (黙's own `stand_in` is [[沈黙]], 想's is [[思想]] — neither points here). Pronunciation fields (mugsang/묵상/ㄇㄨㄎㄙㄚㄫ) and `kwin: true` (AND-rule: both true) already matched constituents exactly — no bug. Both character pages already cited 黙想 correctly. Filled blank `cantonese: mak6 soeng2`/`vietnamese: mặc tưởng`. Removed blank `hsk_level`/`swadesh`/empty `aliases`, consolidated Etymology into `## Notes`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 黙黙.

### 2026-09-09, iteration 3783 — [[words/黙黙|黙黙]]
Self-reduplication of [[黙]] (own `stand_in` is [[沈黙]], no cranberry logic needed for a same-character pair). Pronunciation fields (mugmug/묵묵/ㄇㄨㄎㄇㄨㄎ) already matched constituents exactly — no bug. Character page already cited 黙黙 correctly. Added missing `kwin: true` (AND-rule: both instances true) and filled entirely missing `vietnamese: mặc mặc`. Quoted `korean`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 黼黻.

### 2026-09-09, iteration 3784 — [[words/黼黻|黼黻]]
Already correctly `#cranberry`-tagged, matching its listed entry on `lookup/List of 連綿詞`. **Investigated a suspected romanization mismatch and resolved it as legitimate**: 黼's own `羅馬字` "fu" appeared to conflict with its own `諺文` "뿌" (a tense ㅃ), but cross-checking `middle_chinese_initial` confirmed both 黼 and 黻 share the same MC f- initial, and the tense-ㅃ 諺文 spelling is a consistent vault convention for approximating this class (Korean lacking a native /f/) — the word's own concatenation (뿌뿓/ㄈㄨㄈㄨㄊ) already correctly follows this pattern; left `黼 (char).md`'s own possibly-inconsistent `羅馬字` alone rather than guess-fix it. Filled entirely missing `vietnamese: phủ phất`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 鼈.

### 2026-09-09, iteration 3785 — [[words/鼈|鼈]]
Self-standing bare-character word. **Found a real homophone already anticipated by its counterpart**: `words/別.md` already carried a homophone warning for 鼈 (correctly flagging it as "awaiting its own turn") — added the reciprocal warning here and fixed the now-stale wording on 別.md. Pronunciation fields (bed/벋/ㄅㄝㄊ) already matched the character's own stored values exactly — checked the full ㄅㄝㄊ syllable set (閥/罰), neither self-standing, confirming the cluster is exactly 鼈/別. Filled entirely missing `japanese: すっぽん`, the real native word (a well-known culinary delicacy) rather than a Sino on'yomi. Fixed `# Notes` heading level, bare-string `characters:`, and added missing `pos`/`kwin`/`date-last-perfect`.

Next: 鼎.

### 2026-09-09, iteration 3786 — [[words/鼎|鼎]]
Already fully perfected (stamped 2026-08-03): self-standing bare-character word with the anticipated reciprocal homophone callout to [[呈]] completed, and the character page's own rough state already flagged out-of-scope (a tenth instance of that pattern this sweep). Verified pronunciation fields (ding/딩/ㄉㄧㄫ) and `kwin: false` still match the character page exactly. No changes needed — a clean pass.

Next: 鼓.

### 2026-09-09, iteration 3787 — [[words/鼓|鼓]]
Self-standing bare-character word, already largely perfected: pronunciation fields (go/고/ㄍㄛ), `pos: 名詞`, `kwin: true`, and all real-language fields already matched `characters/鼓 (char).md` exactly, and the real three-way homophone group with [[股]]/[[錮]] was already fully cross-linked from a previous pass. **Fixed a stale-note bug**: the word's own Notes claimed `characters/鼓 (char).md` was "genuinely unperfected" (blank `pos`, dangling CC wikilinks, no `date-last-perfect`) — but the character page is actually already fully perfected (stamped 2026-08-05, proper `## Words` list, complete `mc_id`/`stand_in`), evidently completed by a separate later pass after this word's own note was written. Corrected the Notes accordingly and aligned the etymology description with the character page's own documented components (壴 + 攴, not "支"). Stamped `date-last-perfect: 2026-09-09`.

Next: 鼓舞.

### 2026-09-09, iteration 3788 — [[words/鼓舞|鼓舞]]
No cranberry (鼓's own `stand_in` is 鼓 itself, 舞's is [[跳舞]] — neither points here). Fixed the recurring `characters:` disambiguation bug (bare "鼓" despite `words/鼓.md` existing; "舞" correctly left bare, no `words/舞.md`). Pronunciation fields (gomu/고무/ㄍㄛㄇㄨ) and `kwin: true` (AND-rule: both true) already matched constituents exactly. **Found a genuine hidden-character bug**: the `japanese` field's displayed text "こぶ" silently contained a zero-width space (U+200B) between the two kana — invisible on render but a corrupted field value; removed it. Converted lone `## Etymology` heading to standard `## Notes` template with cranberry-status line and explanatory prose (Japanese こぶ real attested on'yomi compound, Vietnamese cổ vũ real everyday verb). Removed blank `hsk_level`/`swadesh`/`aliases`. Added missing `date-last-perfect: 2026-09-09`. Both character pages' `## Words` citations already correct. Background exact-match homophone check found no collision.

Next: 鼠色.

### 2026-09-09, iteration 3789 — [[words/鼠色|鼠色]]
No cranberry (鼠's own `stand_in` is [[熊鼠]], 色's is [[色彩]] — neither points here). Pronunciation fields (syosig/쇼식/ㄙ⼄ㄙㄧㄎ) and `kwin: false` (AND-rule: both false) already matched constituents exactly. `characters:` already correctly bare (neither `words/鼠.md` nor `words/色.md` exists). **Fixed a real citation gap**: `characters/鼠.md`'s `## Words` list was missing 鼠色 entirely (色's own list already had it). **Removed a redundant self-referential `aliases: [鼠色]` entry** — same bug variant previously fixed on [[熊鼠]] (the field is for genuine variant written forms, not a copy of the filename). Confirmed `mandarin`/`cantonese` (huīsè/fui1 sik1, "grey" proper rather than a literal mouse-color calque) and filled entirely missing `vietnamese: xám chuột` (real native "mouse grey" color term) — both following the real-attested-usage-over-compositional convention; Japanese ねずみいろ/Korean 쥐색 already correctly real mouse-color compounds. Stamped `date-last-perfect: 2026-09-09` (previously stale at 2026-03-27). Background exact-match homophone check found no collision.

Next: 鼠類.

### 2026-09-09, iteration 3790 — [[words/鼠類|鼠類]]
No cranberry (鼠's own `stand_in` is [[熊鼠]], 類's is [[種類]] — neither points here). Both character pages already cited 鼠類 correctly. Pronunciation fields (syolui/쇼뤼/ㄙ⼄ㄌㄨㄧ) and `kwin: false` (AND-rule: both false) already matched. **Fixed two real bugs**: `mandarin` was truncated to bare "shǔ" (missing 類's own "lèi"); `cantonese` held "su3," an unrelated garbage value matching neither constituent's own stored reading — both corrected to compositional shǔlèi/syu2 leoi6. **Fixed a contaminated `aliases` entry**: "即鼠總科" had a stray leading "即" ("namely") — explanatory prose accidentally left inside the alias value — trimmed to the real alternate title 鼠總科. Filled entirely missing `vietnamese: thử loại`, matching the plain-compositional convention already used on sibling words [[鳥類]]/[[魚類]]; Japanese ネズミ上科/Korean 쥐상과 already correctly real taxonomic compounds. Converted `## Etymology` to `## Notes`. Removed blank `hsk_level`/`swadesh`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 鼻.

### 2026-09-09, iteration 3791 — [[words/鼻|鼻]]
Self-standing bare-character word, already fully perfected: pronunciation fields (bi/비/ㄅㄧ), `pos: 名詞`, `kwin: true`, and `vietnamese: tị` all matched `characters/鼻 (char).md` exactly, and the character page's own `## Words`/`## Chengyu` citations for 鼻/鼻水/阿鼻/阿鼻叫喚 were already correct. No-homophone conclusion (checked 碑/痺/脾/琵/婢/皮, none self-standing) reconfirmed via background exact-match grep. Only fix was the stale `date-last-perfect` (2026-08-03 → 2026-09-09) — a clean pass otherwise.

Next: 鼻水.

### 2026-09-09, iteration 3792 — [[words/鼻水|鼻水]]
No cranberry (both 鼻's and 水's own `stand_in` point to themselves — neither points here). Both character pages already cited 鼻水 correctly. Fixed the recurring `characters:` disambiguation bug (bare "鼻"/"水" despite both `words/鼻.md` and `words/水.md` existing). Added missing `kwin: true` (AND-rule: both constituents individually true). **Fixed a comma-joined `korean` contamination bug**: `"비수, 콧물"` — kept 콧물, the real native "nose-water" compound (the everyday word for snot), documented 비수 (the literal compositional form) as the rejected alternate in prose, noting 비수 is additionally a real unrelated Korean word for "dagger" (匕首). Filled entirely missing `vietnamese: nước mũi`, a native word-order-reversed compound ("water of nose") matching the established pattern. `japanese: はなみず` already correctly the real native compound. Removed blank `hsk_level`/`swadesh`/`aliases`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 龍.

### 2026-09-09, iteration 3793 — [[words/龍|龍]]
Self-standing bare-character word. Pronunciation fields (lyong/룡/ㄌ⼄ㄫ), `pos: 名詞`, `kwin: true`, and `vietnamese: long` all matched `characters/龍 (char).md` exactly. **Fixed the duplicate `品詞`/`pos` field bug** (part of the known 590-file scope, fixed for free here since the sweep reached it directly). **Fixed a real citation gap**: the character page's `## Words` list was missing 龍's own self-citation entirely (`stand_in: 龍`, self-pointing) — added it. The character page otherwise remains in a rough, largely-unperfected state (bare unformatted `[[link]] - gloss` bullets throughout, nonstandard `### Related Characters` heading, two dangling CC-initial/final wikilinks after `## Chengyu`) — flagged for the character-perfection sweep, not rebuilt here. Background exact-match homophone check found no collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 龍巻.

### 2026-09-09, iteration 3794 — [[words/龍巻|龍巻]]
`characters:` already correctly disambiguated (both `words/龍.md` and `words/巻.md` exist). Both character pages already cited 龍巻 correctly. Pronunciation fields (lyonggwen/룡권/ㄌ⼄ㄫㄍ⼔ㄋ) already matched; mandarin's lóngjuǎn correctly reflects 巻's minority "to roll" verb-sense reading (juǎn) rather than its stored default noun-sense (juàn) — same reading-split pattern as [[拓]]/[[間]], not a bug. **Fixed a real `kwin` bug**: was `false`, contradicting the AND-rule (both 龍 and 巻 individually true) — corrected to `true`. **Filled the deliberately-left-blank `vietnamese` field**: prose had already researched and explained vòi rồng ("dragon's spout") as the real independently-coined Vietnamese term, but per the established real-attested-usage convention the field itself should hold it rather than stay blank — added `vietnamese: vòi rồng`. Korean's already-corrected `용오름` (from a prior pass) and Japanese たつまき were already correct. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 龍断.

### 2026-09-09, iteration 3795 — [[words/龍断|龍断]]
No cranberry (龍's own `stand_in` is 龍 itself, 断's is [[割断]] — neither points here). `characters:` already correctly disambiguated/bare as appropriate. Both character pages already cited 龍断 correctly. Fixed the duplicate `品詞`/`pos` field bug (590-file scope, fixed opportunistically). **Investigated and explained, rather than "fixed," an elaborate real-language-field divergence**: mandarin `lǒngduàn` (not `lóngduàn`), cantonese `lung5` (not `lung4`), korean `롱단` (not `룡단`), and vietnamese `lũng đoạn` (not matching 龍's own "long") all deliberately follow the real attested word 壟斷, not a naive compositional reading of 龍's own stored fields — traced directly to the word's own quoted Mencius passage, where 龍 was originally a phonetic loan for 壟 ("mound"); Dan'a'yo's own headword spelling/reading preserves the loan-form 龍 while every real-language field correctly tracks the actual pronunciation of 壟斷 (Korean's `롱단`/`농단` being the word behind the well-known 2016 "국정농단" scandal name). Japanese ろうだん already correctly uses 龍's own alternate on'yomi ROU. Fixed a stray "=" (should be "+") in the Notes citation line. Added missing `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 龍王.

### 2026-09-09, iteration 3796 — [[words/龍王|龍王]]
No cranberry (both 龍's and 王's own `stand_in` point to themselves — neither points here). `characters:` already correctly disambiguated (both `words/龍.md` and `words/王.md` exist). Both character pages already cited 龍王 correctly. Pronunciation fields (lyong'wang/룡왕/ㄌ⼄ㄫ·⺢ㄫ) and `kwin: true` (AND-rule: both true) already matched. **Fixed a real orthography bug**: `japanese` was written in obsolete historical kana spelling ("りゆうわう") instead of modern hiragana — corrected to りゅうおう, matching every sibling 王-compound's already-consistent "-おう" spelling ([[帝王]], [[冥王]], [[国王]], [[天王星]], [[海王星]]). Added an entirely missing `## Notes` section. Removed blank `hsk_level`/`swadesh`/empty `aliases: []`. Added missing `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 龍眼.

### 2026-09-09, iteration 3797 — [[words/龍眼|龍眼]]
No cranberry (龍's own `stand_in` is 龍 itself, 眼's is [[眼球]] — neither points here). `characters:` already correctly disambiguated/bare as appropriate; both character pages already cited 龍眼 correctly. Pronunciation fields (lyong'an/룡안/ㄌ⼄ㄫ·ㄚㄋ) and `kwin: true` (AND-rule: both true) already matched, including a previously-fixed `korean: 롱안→룡안` phonetic-borrowing bug already documented in the word's own rich existing prose. Fixed the duplicate `品詞`/`pos` field bug (590-file scope, fixed opportunistically). Quoted `mandarin`/`cantonese` for consistency. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 龍蝦.

### 2026-09-09, iteration 3798 — [[words/龍蝦|龍蝦]]
No cranberry (龍's own `stand_in` is 龍 itself, 蝦's is [[毛蝦]] — neither points here). `characters:` already correctly disambiguated/bare as appropriate; both character pages already cited 龍蝦 correctly. Pronunciation fields (lyongha/룡하/ㄌ⼄ㄫㄏㄚ) already matched. **Fixed a real `kwin` bug**: was `false`, contradicting the AND-rule (龍 true, 蝦 true) — corrected to `true`. **Fixed a real garbage-adjacent bug**: `korean` was `가재` ("crayfish/crawfish," a related but distinct freshwater crustacean) rather than lobster — corrected to `바닷가재` ("sea crayfish"), the real standard Korean word for lobster. Japanese イセエビ/Vietnamese tôm hùm already correctly real, everyday words. Converted informal `## Word` heading with a stray joke-bullet ("lobster's are the dragons of the shrimp world!") into a standard `## Notes` template with proper citation and explanatory prose. Removed blank `hsk_level`/`swadesh`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 龕.

### 2026-09-09, iteration 3799 — [[words/龕|龕]]
Self-standing bare-character word ("shrine, alcove"), found in a very incomplete state: bare frontmatter (`vietnamese: ''`, unlisted `characters: "龕 (char)"`, no `pos`, no `date-last-perfect`, no `japanese`) and only an empty `# Notes` heading with no content. **Found a real anticipated homophone**: both `words/勘.md` and `words/堪.md` already carried a reciprocal Homophones callout for 龕, flagged "still unperfected"/"awaiting its own turn" — added the reciprocal callout here (completing a genuine three-way Dan'a'yo homophone group, all reading kam/캄/ㄎㄚㄇ) and fixed the now-stale wording on both siblings. Filled `japanese: こん` (on'yomi, matching the character's own stored KON, with native ずし noted in prose as the narrower everyday term) and `vietnamese: khám` (Hán Việt, attested in khám thờ "shrine niche" — coincidentally the same spelling already used by [[勘]] for an unrelated sense, a genuine cross-language homophone collision, not a bug). Added missing `pos: 名詞`, converted `characters:` to proper list format with disambiguation, rebuilt `## Notes` with full etymology/pronunciation prose and `kwin` explanation (false: MC aspirated 溪母 kʰ → Dan'a'yo aspirated ㅋ vs Korean's plain ㄱ). Stamped `date-last-perfect: 2026-09-09`.

Next: 𧦅歌.

### 2026-09-09, iteration 3800 — [[words/𧦅歌|𧦅歌]]
Legitimizing note (𧦅's own `stand_in` is this exact compound; 歌's own is [[歌曲]] — transitivity fails, no `#cranberry`), already essentially present in prose though not labeled as such — labeled explicitly. `characters:` already correctly bare (no `words/𧦅.md`/`words/歌.md`). Both character pages already cited 𧦅歌 correctly. Pronunciation fields (`'ougǝ`/옷그/ㄛㄨㄍㄜ) and `kwin: false` (AND-rule: both false) already matched. **Fixed the non-canonical `pos: 動詞`** → `事詞` (matching 𧦅's own stored `pos`). Filled entirely missing `japanese: おうか` and `vietnamese: âu ca`, both real attested compounds corresponding to 謳歌 (𧦅 being a listed graphic-variant alias of 謳); `korean: 구가` already correct and additionally a real attested Sino-Korean word. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

**MILESTONE — FULL PASS COMPLETE**: 𧦅歌 was the alphabetically-last file in `words/*.md` under `LC_ALL=C` sort. The sweep now wraps around to the alphabetically-first word, [[㪘]], resuming iteration count without reset (per standing convention — iteration numbers track total words processed, not position within a single pass).

Next: 㪘.

### 2026-09-09, iteration 3801 — [[words/㪘|㪘]]
First iteration of the sweep's second pass. Self-standing bare-character word ("to gather, collect, restrain"), reciprocal Homophones callout with [[廉]] already correctly in place on both pages. `characters:` already correctly disambiguated. Pronunciation fields (lyem/렴/ㄌ⼶ㄇ) and `kwin: true` already matched. **Fixed the non-canonical `pos: 動詞`** on both this word page and `characters/㪘 (char).md` → `事詞`. **Fixed an empty-string `hsk_level: ""` bug** on the character page → `無` (not ranked). Quoted `mandarin`/`cantonese`/`korean` for consistency. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found only itself and 廉, both already cross-linked.

Next: 䋇.

### 2026-09-09, iteration 3802 — [[words/䋇|䋇]]
Self-standing bare-character word ("unravel, explain"). Reciprocal Homophones callout with [[駅]] (coincidental phonetic-series collision, already explained in prose) already correctly in place on both pages. All pronunciation and real-language fields (`'yeg`/역/⼶ㄎ, mandarin yì, cantonese jik6, korean 역, japanese やく, vietnamese dịch) already matched `characters/䋇 (char).md` exactly; `kwin: true` and `pos: 事詞` both correct. A fully clean pass — only quoted `mandarin`/`cantonese`/`korean` for consistency and refreshed the date stamp.

Next: 䔥国.

### 2026-09-09, iteration 3803 — [[words/䔥国|䔥国]]
Legitimizing note (䔥's own `stand_in` is this exact compound; 国's own is [[国家]] — transitivity fails, no `#cranberry`), already essentially present in prose, labeled explicitly. `characters:` already correctly bare (no `words/䔥.md`/`words/国.md`). Both character pages already cited 䔥国 correctly. Pronunciation fields (syaugog/샷곡/ㄙ⼘ㄨㄍㄛㄎ) and `kwin: false` (AND-rule: both false) already matched. Normalized `mandarin` from spaced lowercase "xiāo guó" to capitalized-proper-noun "Xiāoguó," matching sibling ancient-state words ([[蜀国]], [[鄂国]], [[斉国]]). Filled entirely missing `vietnamese: Tiêu quốc`, same capitalization convention. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 䦧.

### 2026-09-09, iteration 3804 — [[words/䦧|䦧]]
Self-standing bare-character word ("quarrel"). `characters:` already correctly disambiguated. Character page already cited 䦧 correctly. Pronunciation fields (heg/헉/ㄏㄝㄎ), `kwin: false`, and `pos: 事詞` all matched the character page exactly; japanese せめぐ already correctly the real native kun-reading over rarer on'yomi. **Fixed a comma-joined `vietnamese` contamination bug**: `"huých, huỵch"` — kept huých (the character's own stored reading), removed huỵch (an unrelated onomatopoeia for a thudding sound). Quoted `mandarin`/`cantonese`/`korean` for consistency. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 䦧神星.

### 2026-09-09, iteration 3805 — [[words/䦧神星|䦧神星]]
Celestial-body proper noun ("Eris, dwarf planet"), no stand-in relationship (all three constituents are their own stand-ins). All three character pages already cited 䦧神星 correctly. Pronunciation fields (hegsinseng/헉신성/ㄏㄝㄎㄙㄧㄋㄙㄝㄫ) and japanese けきしんせい already matched compositionally. **Added missing `kwin: false`** (AND-rule: 䦧 false, 神 true, 星 true — this word follows the plain AND-rule, not the periodic-table-neologism exception, consistent with sibling celestial words 冥王星/天王星). **Fixed `vietnamese` capitalization**: lowercase "huých thần tinh" → "Huých Thần Tinh," matching the proper-noun capitalization convention already used on 冥王星's "Diêm Vương Tinh" and 天王星's "Thiên Vương Tinh". Quoted `mandarin`/`cantonese`/`korean`. Added missing `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 一.

### 2026-09-09, iteration 3806 — [[words/一|一]]
Self-standing bare-character word ("one"), reciprocal three-way Homophones callout with [[壱]]/[[逸]] already correctly cross-linked on all three pages. Pronunciation fields (`'id`/읻/ㄧㄊ), `pos: 数詞`, `hsk_level`, `swadesh: 22`, and `vietnamese: nhất` all already matched `characters/一 (char).md` exactly. **Found and fixed a real frontmatter/prose self-contradiction bug**: frontmatter had `kwin: true`, but the word's own extensive prose paragraph explicitly explains and derives `kwin` as false (Dan'a'yo 읻 preserving the MC -t coda vs. Korean 일's historical -t→-l lenition) — matching the character page's own stored `kwin: false`. Corrected the frontmatter to `false`. Fixed the duplicate `品詞`/`pos` field bug (590-file scope, fixed opportunistically). Quoted `mandarin`/`cantonese`/`korean`. Stamped `date-last-perfect: 2026-09-09`.

Next: 一万.

### 2026-09-09, iteration 3807 — [[words/一万|一万]]
Legitimizing note (万's own `stand_in` is this exact compound — 万's reading 몬 is phonologically "overfull" and must always be spoken as 一万; 一's own `stand_in` is 一 itself — transitivity fails, no `#cranberry`). **Fixed a real bug on `characters/万.md`**: its own stored `cantonese` was `mak6`, phonologically implausible for this non-entering-tone MC final — corrected to `maan6`, matching what this word's own field already correctly used (the word itself was right; the character page was wrong). **Fixed a real citation gap**: `characters/一 (char).md`'s `## Words` list was missing 一万 entirely. Fixed a comma-joined `vietnamese` contamination bug (`"mười nghìn, vạn"` — kept vạn, the character's own stored and everyday-attested reading; mười nghìn noted in prose as the native numeral-phrase alternative). Removed the duplicate `品詞` field and restructured a stray "Stand-in for [[万]]" fragment into a proper `## Notes` template. Kept `hsk_level`/`swadesh`/`aliases: []` blank, matching the established convention for numeral-compound words (cf. [[十一]]). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 一体.

### 2026-09-09, iteration 3808 — [[words/一体|一体]]
No cranberry (体's own `stand_in` is [[体系]], 一's is 一 itself — neither points here). Both character pages already cited 一体 correctly. Pronunciation fields (`'idtei`/읻테/ㄧㄊㄊㄝㄧ) and `kwin: false` already matched, with the divergence already correctly explained in existing prose. **Fixed a real factual-accuracy bug in the prose itself** (not a frontmatter/field bug, a new variant): the Notes claimed 一's own `nhất` and 体's own `thể` were "blank on their individual character pages" and that this word's vietnamese field was independently researched rather than inherited — false on both counts; both character pages already stored these exact values, and had done so even before this word's own prior perfecting date. Corrected the claim. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 一億.

### 2026-09-09, iteration 3809 — [[words/一億|一億]]
Legitimizing note (億's own `stand_in` is this exact compound; 一's own is 一 itself — transitivity fails, no `#cranberry`). **Fixed a real citation gap**: `characters/一 (char).md`'s `## Words` list was missing 一億 entirely (億's own list already had it). Pronunciation fields (`'id'ig`/읻익/ㄧㄊ·ㄧㄎ) and `kwin: false` (AND-rule: both false) already matched. **Fixed a real bug**: `japanese` was `いち かた` — a stray space plus かた matching neither of 億's own stored on'yomi — corrected to いちおく (ICHI+OKU), the real standard word. Vietnamese `ức` confirmed correct (used alone, without a "one" prefix, matching [[一万]]'s established precedent for Vietnamese numeral compounds). Fixed the duplicate `品詞`/`pos` field bug and restructured a stray `>[!warn]` tip fragment into a proper template. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 一兆.

### 2026-09-09, iteration 3810 — [[words/一兆|一兆]]
No `#cranberry` (兆's own `stand_in` is [[前兆]], 一's is 一 itself — neither points here). **Fixed the exact structural bug already flagged reciprocally from [[一朝]]'s own page**: a plain-text "Stand-in for [[兆]]" line before the meta-bind-embed block — converted to a proper `>[!warning] Homophones` callout. **Fixed real "one"-prefix-dropped bugs**: `mandarin` was bare `zhào` (missing 一's yī) and `cantonese` was bare `siu6` (missing jat1) — both corrected, restoring the prefix pattern already established on [[一万]]/[[一億]]. **Fixed `japanese`**: was bare ちょう, missing the いち prefix and its expected sokuon assimilation (documented precedent: [[一体]]'s いったい) — corrected to いっちょう. Vietnamese `một triệu triệu` confirmed correct as the real Vietnamese circumlocution for "trillion" (kept, not reduced to a misleading bare "triệu" = "million"). Fixed a real citation gap on `characters/一 (char).md`. `kwin: false` already correct, matching the now-familiar 一-root-cause pattern (documented on 一定/一斉/一旦/一朝). Stamped `date-last-perfect: 2026-09-09`.

Next: 一処.

### 2026-09-09, iteration 3811 — [[words/一処|一処]]
`characters:` already correctly disambiguated (処's own `stand_in` is 処 itself — self-standing, no legitimizing note needed). Character page already cited 一処 correctly. Pronunciation fields (`'idco`/읻초/ㄧㄊㄑㄛ) and `kwin: false` already matched, with the divergence already explained in prose. **Fixed a real field-contamination bug**: `korean` jammed two candidates together with a period instead of proper separation, `"한데. 한곳"` — resolved to a single value, `한곳` (using 処's own stored native reading 곳), with 한데 kept as a documented near-synonym alternate in prose rather than in the field. Fixed the duplicate `品詞`/`pos` field bug. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 一切.

### 2026-09-09, iteration 3812 — [[words/一切|一切]]
`characters:` already correctly disambiguated. Character page already cited 一切 correctly. Pronunciation fields (`'idced`/읻첟/ㄧㄊㄑㄝㄊ) already matched. **Fixed a real garbage-adjacent bug**: `cantonese` was `jat1chai3` — missing the word-space and, worse, a second syllable (`chai3`) matching neither 切's own stored cantonese (`cit3`) nor any plausible reading — corrected to `jat1 cit3`. **Added a missing `kwin: false`** (AND-rule: both constituents individually false). Fixed the duplicate `品詞`/`pos` field bug. Korean's already-documented 일체/일절 doublet-reading fork and Vietnamese's already-documented semantic drift (nhất thiết, "necessarily," far from the Buddhist "all dharmas" source) were both already correct and richly explained. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 一千.

### 2026-09-09, iteration 3813 — [[words/一千|一千]]
Legitimizing note (千's own `stand_in` is this exact compound; 一's own is 一 itself — transitivity fails, no `#cranberry`). Character page already cited 一千 correctly. Pronunciation fields (`'idcen`/읻천/ㄧㄊㄑㄝㄋ) already matched. **Fixed a real `kwin` bug**: was `true`, contradicting the AND-rule (一 false, 千 true) — corrected to `false`. **Fixed `japanese`**: was bare せん, missing the いち prefix and its expected sokuon assimilation (same pattern as [[一体]]/[[一兆]]) — corrected to いっせん. Vietnamese một nghìn confirmed correct (real native numeral phrase, matching [[一万]]'s established preference over Sino-Vietnamese). Fixed the duplicate `品詞` field and restructured a stray "Stand-in for : [[千]]" fragment into a proper `## Notes` template. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 一半.

### 2026-09-09, iteration 3814 — [[words/一半|一半]]
Legitimizing note (半's own `stand_in` is this exact compound; 一's own is 一 itself — transitivity fails, no `#cranberry`). Character page already cited 一半 correctly, reciprocal Homophones callout with [[一般]] already correctly cross-linked on both pages. **Fixed a real comma-joined `mandarin` contamination bug**: `"yībànr,yībàn"` — kept the standard yībàn, moved the Beijing-dialect erhua variant to prose (already separately recorded among `aliases`). **Fixed a real `kwin` bug**: was `true`, contradicting the AND-rule (一 false, 半 true) — corrected to `false`. **New pattern noted**: `japanese: いっぱん` is not a bug despite superficially resembling 一般's own reading — it's the phonologically regular sokuon-assimilated form of いち+はん (半's own on'yomi HAN), and coincidentally matches 一般's real pronunciation exactly, a genuine cross-language homophone paralleling the already-documented Dan'a'yo-level one. Fixed the duplicate `品詞`/`pos` field. Kept `hsk_level`/`swadesh`/`aliases` per the numeral-word convention. Stamped `date-last-perfect: 2026-09-09`.

Next: 一定.

### 2026-09-09, iteration 3815 — [[words/一定|一定]]
No `#cranberry` (定's own `stand_in` is [[決定]], 一's is 一 itself — neither points here). Character page already cited 一定 correctly. All pronunciation and real-language fields (`'idjeng`/읻정/ㄧㄊㄐㄝㄫ, mandarin, cantonese, japanese いってい, korean, vietnamese nhất định) already matched `characters/定.md` exactly, `kwin: false` already correct — this word is the source of the earlier-documented 一(char) root-cause `kwin` fix. A fully clean pass — only refreshed the date stamp. Background exact-match homophone check found no collision.

Next: 一斉.

### 2026-09-09, iteration 3816 — [[words/一斉|一斉]]
Legitimizing note (斉's own `stand_in` is this exact compound) already correctly documented. Both character pages already cited 一斉 correctly. Confirmed `pos: 副詞` (adverb) is a legitimate category, widely used across 32 other files — not part of the confirmed `動詞`-only bug pattern. All pronunciation/real-language fields and `kwin: false` already correct from a prior thorough pass (which itself documented the same 一-root-cause kwin fix found on [[一定]]). A fully clean pass — only refreshed the date stamp. Background exact-match homophone check found no collision.

Next: 一日.

### 2026-09-09, iteration 3817 — [[words/一日|一日]]
No `#cranberry` (both 一's and 日's own `stand_in` point to themselves — neither points here). `characters:` already correctly disambiguated. Both character pages already cited 一日 correctly. Pronunciation fields and `kwin: false` already matched. Fixed a stray trailing "l" typo in `mandarin` (`yīrìl`→`yīrì`). **Fixed a comma-joined `japanese` contamination bug**: `"ついたち, いちにち"` — this compound genuinely covers two senses that Japanese splits into two distinct real words (ついたち for "1st of the month," いちにち for "one day" duration); kept ついたち as the field value (matching the word's first-listed calendrical sense) with いちにち documented in prose as the sense-specific alternate for the duration meaning. Restructured a stray `## Etymology` heading below a numbered `## Notes` list into a single standard `## Notes` template. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 一旦.

### 2026-09-09, iteration 3818 — [[words/一旦|一旦]]
Character page already cited 一旦 correctly. Confirmed `pos: 副用名詞` is a legitimate, widely-used category (38 files). All pronunciation/real-language fields and `kwin: false` already correct from a prior thorough pass (structural + korean contamination bugs already fixed there). A fully clean pass — only refreshed the date stamp. Background exact-match homophone check found no collision.

Next: 一月.

### 2026-09-09, iteration 3819 — [[words/一月|一月]]
No `#cranberry` (both 一's and 月's own `stand_in` point to themselves). Both character pages already cited 一月, though with a typo. **Fixed a real `kwin` bug**: was `true`, contradicting the AND-rule (一 false, 月 false) — corrected to `false`, the same recurring 一-root-cause pattern. **Fixed a real cantonese bug**: `jat1jut6` — missing both the word-space and the glide in 月's own stored `jyut6` — corrected to `jat1 jyut6`. **Fixed a real 注音 typo**: `ㄧㄊ·⼔ㄋ` (wrong final consonant) → `ㄧㄊ·⼔ㄊ`, fixed both in this word's own frontmatter and in its citation on `characters/月 (char).md`'s `## Words` list. **Flagged, not fixed**: the identical typo appears to also affect [[三月]]/[[十一月]]'s own citations on the same character page — left for when the sweep reaches those words directly. Vietnamese `tháng giêng` confirmed correct (a real native idiom specific to January, distinct from every other numbered month). Fixed the duplicate `品詞`/`pos` field. Stamped `date-last-perfect: 2026-09-09`.

Next: 一朝.

### 2026-09-09, iteration 3820 — [[words/一朝|一朝]]
No `#cranberry` (both 一's and 朝's own `stand_in` point to themselves). `characters:` already correctly disambiguated, character page already cited 一朝 correctly. Pronunciation fields and `kwin: false` already correct from a prior thorough pass. **Extended the already-documented reading-split observation**: confirmed the same by-sense split already noted for Vietnamese (triêu "morning" vs triều "dynasty") also holds for Mandarin (zhāo vs the character page's stored default cháo) and Cantonese (ziu1 vs stored ciu4) — all three now correctly using the morning-sense reading, not a bug. Fixed a stale cross-reference: the prose noted the reciprocal structural bug on [[一兆]] as "not yet fixed since perfecting it is a separate task" — 一兆 has since been perfected earlier in this sweep, so updated the wording. Stamped `date-last-perfect: 2026-09-09`.

Next: 一溝.

### 2026-09-09, iteration 3821 — [[words/一溝|一溝]]
`characters:` already correctly disambiguated. Pronunciation/real-language fields and `kwin: false` already correct from a prior thorough pass (including a deliberate, correctly-justified blank `vietnamese`). Japanese いっこう confirmed correct (regular sokuon assimilation of いち+こう). **Fixed a real citation gap**: `characters/一 (char).md`'s `## Words` list was missing 一溝 entirely (溝's own list already had it). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 一点.

### 2026-09-09, iteration 3822 — [[words/一点|一点]]
No `#cranberry` (both 一 and 点 are bare self-standing characters, own `stand_in` pointing to themselves). `characters:` already correctly disambiguated, both character pages already cited 一点 correctly. Pronunciation fields and `kwin: false` already correct from a prior thorough pass (including a real content bug already fixed there: gloss corrected from the literal "dot, speck" to the primary everyday "a little, a bit" quantifier sense). A fully clean pass — only refreshed the date stamp. Background exact-match homophone check found no collision.

Next: 一百.

### 2026-09-09, iteration 3823 — [[words/一百|一百]]
No `#cranberry` (both 一's and 百's own `stand_in` point to themselves). Character page already cited 一百 correctly. **Fixed the recurring `characters:` disambiguation bug**: bare "百" despite `words/百.md` existing (a genuine miss, unlike the many already-correct 一-cluster words checked so far). **Fixed a real japanese bug**: `いち ひゃく` (bare space-joined, no assimilation) → `いっぴゃく` (regular sokuon + h→p devoicing, same pattern as 一半/一体/一千). Vietnamese một trăm confirmed correct (real native numeral, matching 一万/一千's established preference). Fixed the duplicate `品詞` field and added an entirely missing `## Notes` section. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 一瞥.

### 2026-09-09, iteration 3824 — [[words/一瞥|一瞥]]
Legitimizing note (瞥's own `stand_in` is this exact compound; 一's own is 一 itself — transitivity fails, no `#cranberry`), already essentially present in prose, labeled explicitly. Character page already cited 一瞥 correctly. All pronunciation and real-language fields already matched `characters/瞥.md` exactly, `kwin: false` correct. A fully clean pass — added a brief explanatory pronunciation paragraph and refreshed the date stamp. Background exact-match homophone check found no collision.

Next: 一瞬.

### 2026-09-09, iteration 3825 — [[words/一瞬|一瞬]]
Legitimizing note (瞬's own `stand_in` is this exact compound; 一's own is 一 itself — transitivity fails, no `#cranberry`). Character page already cited 一瞬 correctly. Filled entirely missing `pos`, `korean: 일순`, `vietnamese: nhất thuấn`, and `kwin: false` (AND-rule: both false). **Fixed a real spelling-consistency bug**: `cantonese` was `jat1 seon3` — corrected to `jat1 seun3`, matching both 瞬's own stored cantonese and the already-perfected sibling [[瞬間]]'s own field. Japanese いっしゅん already correctly assimilated. Added an entirely missing `## Notes` section. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 一端.

### 2026-09-09, iteration 3826 — [[words/一端|一端]]
No `#cranberry` (端's own `stand_in` is [[末端]], 一's is 一 itself — neither points here). Character page already cited 一端 correctly. All pronunciation and real-language fields, `kwin: false`, already correct from a prior thorough pass (including a nicely-documented coincidental cross-language homophone with [[一旦]] in Japanese specifically, いったん, despite the two being semantically unrelated). A fully clean pass — only refreshed the date stamp. Background exact-match homophone check found no Dan'a'yo-level collision.

Next: 一致.

### 2026-09-09, iteration 3827 — [[words/一致|一致]]
No `#cranberry` (both 一's and 致's own `stand_in` point to themselves). `characters:` already correctly disambiguated, character page already cited 一致 correctly. All pronunciation and real-language fields already matched, `kwin: false` correct. Fixed the duplicate `品詞`/`pos` field, quoted `hsk_level`, and added an entirely missing `## Notes` section. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 一般.

### 2026-09-09, iteration 3828 — [[words/一般|一般]]
No `#cranberry` (both 一's and 般's own `stand_in` point to themselves). `characters:` already correctly disambiguated, character page already cited 一般 correctly, reciprocal Homophones callout with [[一半]] already correctly cross-linked (fixed a few iterations ago). `mandarin: yìbān` already correctly reflects regular tone-sandhi (一's yī→yì before a 1st-tone syllable) — clarified in prose, not a bug. **Fixed a real `kwin` bug**: was `true`, contradicting the AND-rule (一 false, 般 true) — corrected to `false`, the same recurring 一-root-cause pattern found repeatedly this stretch. Stamped `date-last-perfect: 2026-09-09`.

Next: 一角獣.

### 2026-09-09, iteration 3829 — [[words/一角獣|一角獣]]
`characters:` already correctly disambiguated (角's own word file exists, 獣's doesn't). All pronunciation and real-language fields, `kwin: false` (AND-rule: all three constituents false), already correct from a prior exceptionally thorough pass — including well-documented real divergences: cantonese/mandarin using the actually-attested 獨角獸/独角兽 alias form rather than a literal calque, and Vietnamese's genuine terminological conflation with the unrelated native 麒麟/qilin creature (kỳ lân), both correctly left as real cross-linguistic facts rather than "fixed." **Found a real citation gap**: `characters/角 (char).md`'s `## Words` list was missing 一角獣 entirely (獣's own list already had it). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 丁.

### 2026-09-09, iteration 3830 — [[words/丁|丁]]
Self-standing bare-character word ("fourth on a list of four"), reciprocal three-way Homophones callout with [[艇]]/[[釘]] already correctly cross-linked on all three pages. All pronunciation and real-language fields already matched `characters/丁 (char).md` exactly, `kwin: false` correct. Confirmed `pos: 修飾語` (a widely-used category, 52 files) is a legitimate divergence from the character's own stored `名詞` — the word's specific ordinal-modifier sense differs grammatically from the character's general noun sense. A fully clean pass — only refreshed the date stamp.

Next: 丁丁.

### 2026-09-09, iteration 3831 — [[words/丁丁|丁丁]]
Self-reduplication of [[丁]] (no cranberry logic needed). Character page already cited 丁丁 correctly. Confirmed `pos: 擬詞` (onomatopoeia) is a legitimate category (13 files). Pronunciation fields and `kwin: false` already correct, with a nicely-flagged classical-commentary detail (a historical zhēngzhēng reading distinct from the vault's modern dīng-based convention, left as a documented note rather than overhauled). Fixed a missing word-space in `cantonese` (`ding1ding1`→`ding1 ding1`). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 丁香.

### 2026-09-09, iteration 3832 — [[words/丁香|丁香]]
Both character pages already cited 丁香 correctly. All pronunciation and real-language fields, `kwin: false` (AND-rule: 丁 false, 香 true → false), already correct from a prior thorough pass — including a nicely-documented note on Japanese's more common but differently-written 丁子/丁字 (ちょうじ) form versus this word's own literal-spelling ちょうこう reading. A fully clean pass — only refreshed the date stamp. Background exact-match homophone check found no collision.

Next: 七.

### 2026-09-09, iteration 3833 — [[words/七|七]]
Self-standing bare-character word ("seven"), reciprocal Homophones callout with [[漆]] already correctly cross-linked. All pronunciation and real-language fields, `kwin: false`, already correct from a prior thorough pass. Fixed the duplicate `品詞`/`pos` field bug. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision beyond the already-documented 漆.

Next: 七万.

### 2026-09-09, iteration 3834 — [[words/七万|七万]]
All pronunciation and real-language fields, `kwin: false`, already correct from a prior thorough pass (which had already caught and fixed a serious prior bug: the whole page had once been a mistaken copy of [[七千]]'s content). **Fixed a real citation gap**: `characters/万.md`'s `## Words` list was missing 七万 entirely (七's own list already had it). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 七事.

### 2026-09-09, iteration 3835 — [[words/七事|七事]]
No `#cranberry` (both 七's and 事's own `stand_in` point to themselves). `characters:` already correctly disambiguated, both character pages already cited 七事 correctly. Pronunciation/kwin already correct. Filled entirely missing `vietnamese: thất sự` (plain compositional, classical/historical term). Quoted `mandarin`/`cantonese`/`korean`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 七十.

---
**LOOP MODE CHANGE**: user said "stop the loop and switch to continuous word perfecting" — cron job 070ee753 cancelled via CronDelete; processing now continues back-to-back within this single turn per [[feedback_continuous_loop_trigger]], no more waiting for 5-minute cron fires.

### 2026-09-09, iteration 3836 — [[words/七十|七十]]
No `#cranberry` (both 七's and 十's own `stand_in` point to themselves). Both character pages already cited 七十 correctly. **Fixed the recurring `characters:` disambiguation bug**: bare "十" despite `words/十.md` existing. **Fixed a real `kwin` bug**: was `true`, contradicting the AND-rule (七 false, 十 true) — corrected to `false`. Fixed two empty-string bugs (`vietnamese: ""`, `swadesh: ""`) and filled `vietnamese: bảy mươi`, the real native tens-numeral for "seventy." Japanese ななじゅう already correctly using native なな over しち. Fixed the duplicate `品詞` field. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 七千.

### 2026-09-09, iteration 3837 — [[words/七千|七千]]
Both character pages already cited 七千 correctly. All fields and `kwin: false` already correct from a prior thorough pass (this word was itself the source of the 七(char) kwin root-cause fix and the discovery of 七万's duplicated-content bug). A fully clean pass — only refreshed the date stamp.

Next: 七夕.

### 2026-09-09, iteration 3838 — [[words/七夕|七夕]]
No `#cranberry` (夕's own `stand_in` is [[夕陽]], 七's is 七 itself — neither points here). Character page already cited 七夕 correctly. **Fixed a real `kwin` bug**: was `true`, contradicting the AND-rule (七 false, 夕 true) — corrected to `false`. Fixed a missing word-space in `cantonese` (`cat1zik6`→`cat1 zik6`) and the duplicate `品詞` field. Japanese たなばた confirmed correct (a real native jukujikun reading for the whole compound, not built from individual on'yomi). Added an entirely missing `## Notes` section. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 七宝.

### 2026-09-09, iteration 3839 — [[words/七宝|七宝]]
No `#cranberry` (宝's own `stand_in` is [[宝物]], 七's is 七 itself — neither points here). Character page already cited 七宝 correctly. Pronunciation fields and `kwin: false` already matched. **Fixed a real bug**: `japanese` was しちほう, a bare unassimilated concatenation — corrected to しっぽう (real word, sokuon+devoicing, same pattern as 一半/一百). Quoted `mandarin`/`cantonese`/`korean`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 七対子.

### 2026-09-09, iteration 3840 — [[words/七対子|七対子]]
No `#cranberry` (none of the three constituents' own `stand_in` points here). Both remaining character pages already cited 七対子 correctly. Pronunciation fields, `kwin: false`, and Japanese ちいといつ (previously fixed malformed hiragana) already correct. Documented the deliberately-blank `vietnamese` field (no attested Vietnamese mahjong term found). Quoted `mandarin`/`cantonese`/`korean`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 七情.

### 2026-09-09, iteration 3841 — [[words/七情|七情]]
Both character pages already cited 七情 correctly (fixed a trivial `[[words/七情]]`→`[[七情]]` wikilink-path formatting slip on `七 (char).md` while there). All pronunciation and real-language fields, `kwin: false`, already correct from an exceptionally thorough prior pass (three-tradition emotion-enumeration comparison, Vietnamese idiom cross-check). A fully clean pass content-wise — only refreshed the date stamp.

Next: 七日.

### 2026-09-09, iteration 3842 — [[words/七日|七日]]
Both character pages already cited 七日 correctly. All pronunciation and real-language fields, `kwin: false`, already correct from a prior thorough pass, including a well-documented irregular native Japanese calendar reading (なのか, part of the same fossilized day-counting family as 一日/八日). A fully clean pass — only refreshed the date stamp.

Next: 七星.

### 2026-09-09, iteration 3843 — [[words/七星|七星]]
No `#cranberry` (both 七's and 星's own `stand_in` point to themselves). Both character pages already cited 七星 correctly. Pronunciation fields and `kwin: false` already matched. Filled entirely missing `vietnamese: thất tinh` and quoted the other real-language fields. Korean 칠성 confirmed as a real, well-known term (the Big Dipper deity in Korean folk religion/Buddhism). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 七曜.

### 2026-09-09, iteration 3844 — [[words/七曜|七曜]]
No `#cranberry` (曜's own `stand_in` is [[曜日]], 七's is 七 itself — neither points here). Character page already cited 七曜 correctly. Pronunciation fields and `kwin: false` already matched. Filled entirely missing `vietnamese: thất diệu` (a real Vietnamese astrological term). In passing, fixed an empty-string `hsk_level: ""` bug on `characters/曜.md` itself → `無`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 七月.

### 2026-09-09, iteration 3845 — [[words/七月|七月]]
No `#cranberry` (both 七's and 月's own `stand_in` point to themselves). Both character pages already cited 七月 correctly (no typo this time, unlike 一月's earlier ⼔ㄋ bug). **Fixed a real `kwin` bug**: was `true`, contradicting the AND-rule (七 false, 月 false) — corrected to `false`. **Fixed a real cantonese bug**: `cat1jut6` — missing both the word-space and the glide in 月's own stored `jyut6` — corrected to `cat1 jyut6`, the identical bug pattern already found on [[一月]]. Fixed the duplicate `品詞` field. Vietnamese tháng bảy confirmed correct (real native month-name). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 七百.

### 2026-09-09, iteration 3846 — [[words/七百|七百]]
Both character pages already cited 七百 correctly. All fields and `kwin: false` already correct from a prior thorough pass. A fully clean pass — only refreshed the date stamp.

Next: 七色.

### 2026-09-09, iteration 3847 — [[words/七色|七色]]
No `#cranberry` (色's own `stand_in` is [[色彩]], 七's is 七 itself — neither points here). Both character pages already cited 七色 correctly. Pronunciation and real-language fields, `kwin: false`, already correct. Japanese なないろ confirmed correct (real everyday word, not compositional しちしょく). Added missing `date-last-perfect: 2026-09-09` and quoted fields.

Next: 七角形.

### 2026-09-09, iteration 3848 — [[words/七角形|七角形]]
No `#cranberry` (none of the three constituents' own `stand_in` points here). All three character pages already cited 七角形 correctly. Pronunciation fields, `kwin: false` (AND-rule: all three false), already matched. Filled entirely missing `vietnamese: hình bảy góc`, matching the native "hình + number + góc" polygon-naming pattern already established on sibling [[三角形]]'s "hình ba góc" (not a Sino-Vietnamese thất giác form). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 七面鳥.

### 2026-09-09, iteration 3849 — [[words/七面鳥|七面鳥]]
No `#cranberry` (面's own `stand_in` is [[表面]], 七's and 鳥's are themselves — none points here). All three character pages already cited 七面鳥 correctly. Pronunciation fields, `kwin: false`, already matched. Filled entirely missing `vietnamese: gà tây` ("western chicken," the real everyday Vietnamese word, no compositional connection to the "seven faces" imagery — matching the real-attested-usage convention). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 万乗.

### 2026-09-09, iteration 3850 — [[words/万乗|万乗]]
No `#cranberry` (both 万's and 乗's own `stand_in` point to themselves). **Fixed a real citation gap**: `characters/万.md`'s `## Words` list was missing 万乗 entirely. **Fixed two real bugs**: `mandarin` had a stray internal space (`wàn chéng`), and `cantonese` carried the same `mak6` typo for 万 already found and fixed on the character page — corrected to `maan6 sing4`. Filled entirely missing `vietnamese: vạn thừa`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 万年.

### 2026-09-09, iteration 3851 — [[words/万年|万年]]
Both character pages already cited 万年 correctly. Pronunciation and real-language fields already correct — cantonese already correctly `maan6` (no propagated `mak6` typo here, unlike [[万乗]]). Only fix was the duplicate `品詞`/`pos` field. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 万歳.

### 2026-09-09, iteration 3852 — [[words/万歳|万歳]]
Both character pages already cited 万歳 correctly. Confirmed `pos: 感詞` (interjection) is a legitimate category (19 files). All pronunciation/real-language fields, `kwin: false`, already correct from an exceptionally thorough prior pass (Japanese ばんざい/まんざい dual-reading split, Korean 3.1 Movement history, Chinese imperial-taboo history all well documented). Only fix was the duplicate `品詞`/`pos` field. Stamped `date-last-perfect: 2026-09-09`.

Next: 万物.

### 2026-09-09, iteration 3853 — [[words/万物|万物]]
No `#cranberry` (万's own `stand_in` is [[一万]], 物's is 物 itself — neither points here). **Fixed a real citation gap**: `characters/万.md`'s `## Words` list was missing 万物 entirely (物's own list already had it). Confirmed the 萬物/万物 大字 (anti-falsification) pairing already correctly documented on 萬物's own page — mirrored that documentation onto this page, keeping `aliases: []` empty per the established 萬/万 non-cross-listing precedent. Fixed the duplicate `品詞` field and normalized `vietnamese` from a single-item list to a bare string. Stamped `date-last-perfect: 2026-09-09`.

Next: 万象.

### 2026-09-09, iteration 3854 — [[words/万象|万象]]
No `#cranberry` (万's own `stand_in` is [[一万]], 象's is [[大象]] — neither points here). Both character pages already cited 万象 correctly. Pronunciation fields, `kwin: false`, already matched. **Fixed a real semantic-mismatch bug**: `vietnamese` was capitalized `Vạn Tượng` — the real Vietnamese name for Vientiane (capital of Laos), a coincidentally-homographic but completely unrelated proper noun — corrected to lowercase `vạn tượng`, matching 象's own stored reading and the word's actual meaning. Fixed the duplicate `品詞` field. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 万邦.

### 2026-09-09, iteration 3855 — [[words/万邦|万邦]]
No `#cranberry` (万's own `stand_in` is [[一万]], 邦's is [[連邦]] — neither points here). Both character pages already cited 万邦 correctly. Filled an entirely missing `cantonese: maan6 bong1`. Fixed the duplicate `品詞` field. `kwin: false` already correct. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision. This closes out the 万-prefixed word cluster.

Next: 丈.

### 2026-09-09, iteration 3856 — [[words/丈|丈]]
Self-standing bare-character word ("zhang," unit of length). Pronunciation fields and `kwin: false` already matched `characters/丈 (char).md` exactly. Fixed the duplicate `品詞`/`pos` field and normalized single-item `japanese`/`vietnamese` lists to bare strings. **Fixed a real citation gap**: the character page had no `## Words` section at all (only a nonstandard `## Definition` heading) — added a minimal `## Words` section with the missing self-citation, leaving the rest of the rough character page for the character-perfection sweep. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 丈人.

### 2026-09-09, iteration 3857 — [[words/丈人|丈人]]
`characters:` already correctly disambiguated. **Fixed a real internal-consistency bug**: `羅馬字`/`注音` had been stored using the wrong unaspirated onset (`jangnin`/`ㄐㄚㄫㄋㄧㄋ`) — inconsistent with this word's own already-correct `諺文: 창닌` and with 丈's own stored triple (cang/창/ㄑㄚㄫ) — corrected to `cangnin`/`ㄑㄚㄫㄋㄧㄋ`. The identical typo had also propagated into this word's own citation on `characters/丈 (char).md`'s Words list, fixed there too. Fixed a real citation gap on `characters/人 (char).md`'s Words list (missing 丈人 entirely). `kwin: false` already correct regardless. Stamped `date-last-perfect: 2026-09-09`.

Next: 丈夫.

### 2026-09-09, iteration 3858 — [[words/丈夫|丈夫]]
No `#cranberry` (both 丈's and 夫's own `stand_in` point to themselves). **Found and fixed a significant real bug**: `羅馬字`/`諺文`/`注音` had been built from the SINO-KOREAN compositional reading (jangbu/장부/ㄐㄚㄫㄅㄨ, i.e. 丈's own Korean 장 + 夫's own Korean 부) rather than Dan'a'yo's own derivation — corrected to the proper mechanical concatenation of each constituent's own stored Dan'a'yo triple (cangfǝ/창쁘/ㄑㄚㄫㄈㄜ). The identical error had propagated into this word's own citations on both `丈 (char).md` and `夫 (char).md`'s Words lists, fixed there too. Documented Japanese じょうぶ as a genuine false-friend divergence (means "robust/healthy" in Japanese, not "husband," despite being the real reading of this exact written compound) and Korean 장부's own real meaning ("a great man," not "husband" — reinforcing why the native 남편 is correctly used instead). Fixed the duplicate `品詞` field. Stamped `date-last-perfect: 2026-09-09`.

Next: 丈母.

### 2026-09-09, iteration 3859 — [[words/丈母|丈母]]
No `#cranberry` (丈's own `stand_in` is 丈 itself, 母's is [[母親]] — neither points here). **Fixed the same Sino-Korean-vs-Dan'a'yo mix-up already found on [[丈夫]]**: `羅馬字`/`諺文`/`注音` had been built from 丈's Korean 장 rather than Dan'a'yo's own 창 — corrected to `cangmou`/`창못`/`ㄑㄚㄫㄇㄛㄨ`. Same propagated typo fixed on both character-page citations. Filled entirely missing `vietnamese: mẹ vợ` (real native compound, matching [[丈人]]'s "bố vợ"). Normalized single-item `japanese` list to a bare string. Stamped `date-last-perfect: 2026-09-09`. This closes out the 丈-prefixed word cluster.

Next: 三.

### 2026-09-09, iteration 3860 — [[words/三|三]]
Self-standing bare-character word ("three"). Pronunciation fields and `kwin: true` already matched `characters/三 (char).md` exactly (self-standing). **Found and corrected a real over-claim in the prose**: the Notes asserted 三 "has a dedicated anti-forgery/financial variant... [[参]]," matching the completed [[一]]/[[壱]] and [[七]]/[[漆]] pairs — but `characters/参.md`'s own `stand_in` actually points to [[参加]], not to itself, and no `words/参.md` exists; corrected the claim to flag this as NOT yet implemented rather than asserting it as done. Fixed the duplicate `品詞`/`pos` field and removed a stray misplaced `hanmun_edu_level` field (a character-page-only field that had leaked into this word file). Normalized the non-standard opening tip line to the standard `>[!tip]` callout format. Stamped `date-last-perfect: 2026-09-09`.

Next: 三位一体.

### 2026-09-09, iteration 3861 — [[words/三位一体|三位一体]]
No `#cranberry` (none of the four constituents' own `stand_in` points here). All four character pages already cited 三位一体 correctly. All pronunciation and real-language fields, `kwin: false`, already correct. Japanese さんみいったい confirmed correct (a real special classical/Buddhist alternate on'yomi for 位, み instead of い — not a bug). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 三十.

### 2026-09-09, iteration 3862 — [[words/三十|三十]]
Both character pages already cited 三十 correctly. Pronunciation fields and `kwin: true` (AND-rule: both true) already matched. **Fixed the recurring `characters:` disambiguation bug**: bare "十" despite `words/十.md` existing. Vietnamese ba mươi and Japanese みそじ/さんじゅう split already correctly documented. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 三十一日.

### 2026-09-09, iteration 3863 — [[words/三十一日|三十一日]]
No stand-in relationship (all four constituents independent). **Fixed several real bugs**: `mandarin`/`cantonese` had been entirely blank; `japanese` held a stray middle-dot separator instead of plain concatenation; `vietnamese` held the cardinal-number phrase "ba mươi mốt" ("thirty-one") rather than the compositional day-of-month form matching sibling words [[十一日]]/[[七日]]. Fixed the recurring `characters:` disambiguation bug and the duplicate `品詞` field. Confirmed (matching precedent on [[十一日]]) that day-numbered compounds like this one are not systematically cross-cited on every constituent character's own Words list, only on 日's — not a bug, left as-is. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 三十日.

### 2026-09-09, iteration 3864 — [[words/三十日|三十日]]
No stand-in relationship. Character page already cited 三十日 correctly. Japanese みそか confirmed correct (real special native reading, not the expected compositional さんじゅうにち — same "last day of month" irregular-reading family as [[一日]]'s ついたち). Filled entirely missing `vietnamese: tam thập nhật`. Fixed the recurring `characters:` disambiguation bug and the duplicate `品詞` field. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 三叉.

### 2026-09-09, iteration 3865 — [[words/三叉|三叉]]
`characters:` already correctly disambiguated. Both character pages already cited 三叉 correctly. All pronunciation and real-language fields, `kwin: false`, already correct from a prior thorough pass (trigeminal-nerve medical-vocabulary cross-check, Vietnamese native-phrase divergence both already documented). A fully clean pass — only refreshed the date stamp.

Next: 三国.

### 2026-09-09, iteration 3866 — [[words/三国|三国]]
Both character pages already cited 三国 correctly. Pronunciation fields, `kwin: false`, already matched. **Fixed a structural formatting bug**: the reciprocal homophone with [[三角]] was expressed as a non-standard `>[!tip]` line before the meta-bind-embed block instead of a proper `>[!warning] Homophones` callout — converted (the identical issue exists on 三角's own reciprocal side, flagged for when that word is reached). Quoted `mandarin`/`cantonese`/`korean`. Stamped `date-last-perfect: 2026-09-09`.

Next: 三日.

### 2026-09-09, iteration 3867 — [[words/三日|三日]]
No stand-in relationship. Character page already cited 三日 correctly. Japanese みっか confirmed correct (real special native reading, same irregular-day-reading family as 一日/三十日). Filled entirely missing `mandarin`/`cantonese`/`vietnamese`. Fixed the duplicate `品詞` field. `kwin: false` correct. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 三月.

### 2026-09-09, iteration 3868 — [[words/三月|三月]]
No stand-in relationship. **Fixed three real bugs, the same family already found on [[一月]]/[[七月]]**: `cantonese` missing 月's glide (jut6→jyut6); `注音` carrying the ⼔ㄋ-for-⼔ㄊ typo (fixed here and in this word's own citation on `月 (char).md`); `kwin: true` contradicting the AND-rule (三 true, 月 false) — corrected to `false`. Fixed the duplicate `品詞` field. Stamped `date-last-perfect: 2026-09-09`.

Next: 三焦.

### 2026-09-09, iteration 3869 — [[words/三焦|三焦]]
No stand-in relationship. Both character pages already cited 三焦 correctly. **Fixed a real orthography bug**: `japanese` was obsolete historical kana (さんせう) instead of modern さんしょう, the same bug family as [[龍王]]. Filled entirely missing `vietnamese: tam tiêu` (real standard TCM term). Fixed the duplicate `品詞` field. **Found a genuine new Dan'a'yo homophone**: shares its exact reading with [[参照]] ("refer to, cross-reference") — added reciprocal `>[!warning] Homophones` callouts on both pages; in passing on 参照 also fixed its non-canonical `pos: 動詞`→`事詞` and quoted its real-language fields. Stamped `date-last-perfect: 2026-09-09` on both files.

Next: 三猿.

### 2026-09-09, iteration 3870 — [[words/三猿|三猿]]
`characters:` fine (猿 bound but usable in other compounds beyond its own stand_in legitimizer [[猿猩]]). Character citation present (bare-format, on the already-flagged rough 三(char) page). **Fixed a comma-joined `japanese` contamination bug**: さんざる (the real, famous popular reading for this cultural icon, Nikkō Tōshō-gū's "see/hear/speak no evil" monkeys) kept, さんえん removed as a less-common alternate. **Fixed a real garbage-value bug**: `vietnamese` was `phiên âm` ("phonetic transcription," totally unrelated) → `tam viên` (compositional, matching 猿's own stored `viên`). Fixed the duplicate `品詞` field. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 三稜鏡.

### 2026-09-09, iteration 3871 — [[words/三稜鏡|三稜鏡]]
All three character pages already cited 三稜鏡 correctly. All pronunciation and real-language fields, `kwin: false`, already correct from an exceptionally thorough prior pass (Korean loanword divergence, Vietnamese etymology cross-check both already documented). Added an explicit legitimizing-note label (稜's own `stand_in` is this exact compound). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 三綱.

### 2026-09-09, iteration 3872 — [[words/三綱|三綱]]
Character page already cited 三綱 correctly. All pronunciation and real-language fields, `kwin: true` (AND-rule: both true), already correct from a prior thorough pass (Dong Zhongshu/Chunqiu Fanlu history, Vietnamese scholarship cross-check already documented). A fully clean pass — only refreshed the date stamp.

Next: 三菱.

### 2026-09-09, iteration 3873 — [[words/三菱|三菱]]
Fixed a real citation gap on `characters/菱 (char).md`'s Words list. Added missing `kwin: true` (AND-rule: both true) and filled missing `vietnamese: Mitsubishi` (loanword, matching Korean's own phonetic-loan approach). Fixed the duplicate `品詞` field. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 三角.

### 2026-09-09, iteration 3874 — [[words/三角|三角]]
Both character pages already cited 三角 correctly. Pronunciation fields, `kwin: false`, already matched. **Fixed the reciprocal structural bug already flagged from [[三国]]'s own page**: non-standard `>[!tip]` homophone line before the meta-bind-embed block — converted to a proper `>[!warning] Homophones` callout. Fixed the duplicate `品詞` field and quoted real-language fields. Stamped `date-last-perfect: 2026-09-09`.

Next: 三角形.

### 2026-09-09, iteration 3875 — [[words/三角形|三角形]]
No `#cranberry` (none of the three constituents' own `stand_in` points here). Fixed a real citation gap on `characters/角 (char).md`'s Words list. Fixed the duplicate `品詞` field, added an entirely missing `## Notes` section. All other fields already correct — this is the source precedent for the vietnamese hình-N-góc polygon-naming pattern later applied to 七角形. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 三角法.

### 2026-09-09, iteration 3876 — [[words/三角法|三角法]]
No `#cranberry`. Fixed real citation gaps on both `characters/三 (char).md` and `characters/角 (char).md`'s Words lists (法's own list already had it). Fixed the duplicate `品詞` field, added an entirely missing `## Notes` section. Vietnamese lượng giác học confirmed correct (real standard term, not a calque). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision. This closes out the 三-prefixed word cluster.

Next: 上.

### 2026-09-09, iteration 3877 — [[words/上|上]]
Self-standing bare-character word ("above"), reciprocal three-way Homophones callout with [[尚]]/[[賞]] already correctly cross-linked on all three pages. Pronunciation fields and `kwin: false` already matched. **Fixed a real YAML-structure bug**: `characters: 上 (char)` was a bare scalar instead of a proper list. Fixed the duplicate `品詞`/`pos` field and normalized single-item `japanese`/`vietnamese` lists to bare strings. Stamped `date-last-perfect: 2026-09-09`.

Next: 上位.

### 2026-09-09, iteration 3878 — [[words/上位|上位]]
Both character pages already cited 上位 correctly. All fields and `kwin: false` already correct from a prior thorough pass. A fully clean pass — only quoted fields and refreshed the date stamp.

Next: 上半期.

### 2026-09-09, iteration 3879 — [[words/上半期|上半期]]
No `#cranberry`. All three character pages already cited 上半期 correctly. Pronunciation fields, `kwin: false`, already matched. Filled entirely missing `vietnamese: thượng bán kì`. Quoted real-language fields. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 上帝.

### 2026-09-09, iteration 3880 — [[words/上帝|上帝]]
No `#cranberry` (帝's own `stand_in` is [[帝王]], 上's is 上 itself — neither points here). Fixed a real citation gap on `characters/上 (char).md`'s Words list. **Fixed a cantonese spelling-consistency bug**: `soeng6 dai3` → `seong6 dai3`, matching 上's own stored cantonese; noted a genuine seong6/soeng6 split exists across the vault's 上-word family (roughly half each way) worth a fuller audit later. `kwin: false` already correct. Stamped `date-last-perfect: 2026-09-09`.

Next: 上弦.

### 2026-09-09, iteration 3881 — [[words/上弦|上弦]]
No `#cranberry`. Fixed a real citation gap on `characters/上 (char).md`'s Words list (弦's own list already had it). Filled entirely missing `vietnamese: thượng huyền`. Quoted real-language fields. `kwin: false` correct. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 上旬.

### 2026-09-09, iteration 3882 — [[words/上旬|上旬]]
No `#cranberry` (旬's own `stand_in` is [[旬日]], 上's is 上 itself). **Fixed a real garbage-value bug**: `cantonese` was `sang4 xun2` — neither syllable real Jyutping; `xun2` appears to be leftover Mandarin pinyin (旬's own mandarin is xún) misplaced into the cantonese field — corrected to `seong6 ceon4`. Fixed a missing citation on `characters/上 (char).md`'s Words list and the duplicate `品詞` field. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 上昇.

### 2026-09-09, iteration 3883 — [[words/上昇|上昇]]
Legitimizing note already present (昇's own `stand_in` is this exact compound). All content already correct from a prior thorough pass. Fixed the recurring cantonese `soeng6`→`seong6` spelling bug and a missing citation on `characters/上 (char).md`'s Words list. Stamped `date-last-perfect: 2026-09-09`.

Next: 上海.

### 2026-09-09, iteration 3884 — [[words/上海|上海]]
No `#cranberry`. Reciprocal homophone with [[傷害]] already correctly cross-linked. **Fixed a structural bug**: the Homophones callout sat before the meta-bind-embed block, violating the required order — moved. Fixed the recurring cantonese `soeng6`→`seong6` spelling bug and a missing citation on `characters/上 (char).md`'s Words list. Japanese しゃんはい confirmed correct (real proper-noun reading). Stamped `date-last-perfect: 2026-09-09`. This finishes the run of 上(char) citation-gap fixes found this stretch (上帝/上弦/上旬/上/上半期/上昇/上海 — seven gaps in a row).

Next: 上知.

### 2026-09-09, iteration 3885 — [[words/上知|上知]]
Both character pages already cited 上知 correctly. All content already correct from a prior thorough pass (Analects/Joseon-scholar historical detail already well documented). Fixed the recurring cantonese `soeng6`→`seong6` spelling bug and quoted fields. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 上述.

### 2026-09-09, iteration 3886 — [[words/上述|上述]]
Both character pages already cited 上述 correctly (上's own citation in the already-flagged rough bare-link format). All content already correct from a prior thorough pass. Fixed the recurring cantonese `soeng6`→`seong6` spelling bug. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 上面.

### 2026-09-09, iteration 3887 — [[words/上面|上面]]
Both character pages already cited 上面 correctly. All content already correct from a prior thorough pass (register-comparison across five languages already well documented). Fixed the recurring cantonese `soeng6`→`seong6` spelling bug. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision. This closes out the 上-prefixed word cluster.

Next: 下.

### 2026-09-09, iteration 3888 — [[words/下|下]]
Self-standing bare-character word ("down, under"), reciprocal Homophones callout with [[何]] already correctly cross-linked. Pronunciation fields and `kwin: true` already matched. Fixed the duplicate `品詞`/`pos` field and normalized single-item `japanese`/`vietnamese` lists to bare strings. Stamped `date-last-perfect: 2026-09-09`.

Next: 下位.

### 2026-09-09, iteration 3889 — [[words/下位|下位]]
Both character pages already cited 下位 correctly. All content already correct, including japanese かい (correctly compositional KA+I). A fully clean pass — only quoted fields and refreshed the date stamp.

Next: 下半期.

### 2026-09-09, iteration 3890 — [[words/下半期|下半期]]
No `#cranberry`. All three character pages already cited 下半期 correctly. Filled entirely missing `vietnamese: hạ bán kì` (matching sibling 上半期's own pattern). Quoted real-language fields. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 下弦.

### 2026-09-09, iteration 3891 — [[words/下弦|下弦]]
Both character pages already cited 下弦 correctly. Filled entirely missing `vietnamese: hạ huyền` (matching sibling 上弦's own thượng huyền). Quoted real-language fields. `kwin: false` correct. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 下愚.

### 2026-09-09, iteration 3892 — [[words/下愚|下愚]]
Both character pages already cited 下愚 correctly. `kwin: true` (AND-rule: both true) already correct; the注音 dot-disambiguation from [[好]]/[[毫]] (both genuinely ㄏㄚㄨ without a dot) already correctly explained in prose — confirmed not a real collision, just a documented near-miss. Quoted fields. Stamped `date-last-perfect: 2026-09-09`.

Next: 下旬.

### 2026-09-09, iteration 3893 — [[words/下旬|下旬]]
No `#cranberry`. Both character pages already cited 下旬 correctly. **Fixed a real garbage-value bug identical to the one found on [[上旬]]**: `cantonese` was `xia4 xun2` — leftover Mandarin pinyin syllables mistakenly placed in the cantonese field — corrected to `haa6 ceon4`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 下痢.

### 2026-09-09, iteration 3894 — [[words/下痢|下痢]]
Legitimizing note (痢's own `stand_in` is this exact compound) already essentially present, labeled explicitly. Character page already cited 下痢 correctly. All content already correct from an exceptionally thorough prior pass (Korean 설사-vs-하리 divergence, Japanese げり coincidental-match, Vietnamese classical-vs-modern register all well documented). Stamped `date-last-perfect: 2026-09-09`.

Next: 下降.

### 2026-09-09, iteration 3895 — [[words/下降|下降]]
Legitimizing note (降's own `stand_in` is this exact compound). Both character pages already cited 下降 correctly. Filled entirely missing `vietnamese: hạ giáng` and added an entirely missing `## Notes` section. `kwin: true` (AND-rule: both true) correct. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 下顎.

### 2026-09-09, iteration 3896 — [[words/下顎|下顎]]
Legitimizing note (顎's own `stand_in` is this exact compound). **Fixed a real 注音 typo**: missing middle-dot before 顎's vowel-initial reading (ㄏㄚㄚㄎ→ㄏㄚ·ㄚㄎ), matching the already-correct citation on `characters/下 (char).md` but fixing the same wrong typo propagated onto `characters/顎.md`'s own citation. **Fixed a real `kwin` bug**: was `false`, contradicting the AND-rule (both 下 and 顎 individually true) — corrected to `true`. Japanese あご/Korean 턱/Vietnamese xương hàm all confirmed correct (real native words). Removed blank `hsk_level`/`swadesh`/`aliases`. Stamped `date-last-perfect: 2026-09-09`. This closes out the 下-prefixed word cluster.

Next: 不.

### 2026-09-09, iteration 3897 — [[words/不|不]]
Self-standing bare-character word ("not"), the core negation particle. Pronunciation fields and `kwin: false` already matched. Confirmed `pos: 修飾語` legitimate. Fixed the duplicate `品詞`/`pos` field and quoted real-language fields. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 不丹.

### 2026-09-09, iteration 3898 — [[words/不丹|不丹]]
Both character pages already cited 不丹 correctly, reciprocal homophone with [[不但]] already correctly cross-linked. All content already correct from an exceptionally thorough prior pass (Bhutan etymology, Dzongkha name, UN history all well documented). Only quoted fields and refreshed the date stamp.

Next: 不亦V乎.

### 2026-09-09, iteration 3899 — [[words/不亦V乎|不亦V乎]]
Special discontinuous-circumfix entry (Classical Chinese rhetorical-question frame, 不亦……乎), already thoroughly perfected with well-reasoned deliberate-blank-field justification for the daughter-language fields (no independent life outside Classical Chinese literary grammar). Fixed a real citation gap: `characters/不 (char).md`'s Words list was missing this entry (亦/乎's own lists already had it). Stamped `date-last-perfect: 2026-09-09`.

Next: 不但.

### 2026-09-09, iteration 3900 — [[words/不但|不但]]
Reciprocal homophone with [[不丹]] already correctly cross-linked. Deliberate blank japanese/korean/vietnamese fields already correctly justified (a genuinely Mandarin-specific grammatical particle with no cross-linguistic parallel at all). **Fixed the recurring `characters:` disambiguation bug**: bare "但" despite `words/但.md` existing — corrected to "但 (char)", and fixed the prose's stale claim to match. Stamped `date-last-perfect: 2026-09-09`.

Next: 不信.

### 2026-09-09, iteration 3901 — [[words/不信|不信]]
Both character pages already cited 不信 correctly. Pronunciation fields and `kwin: false` already correct. Documented Korean 불신 (not 부신) as a real regular Sino-Korean assimilation rule (matching 불가능/불편), not a bug. Fixed the duplicate `品詞` field. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 不及.

### 2026-09-09, iteration 3902 — [[words/不及|不及]]
Both character pages already cited 不及 correctly. **Fixed a real bug**: `korean` was `부급` (naive concatenation) — the real attested reading (confirmed via the famous idiom 과유불급) is `불급`, following the same 不→불 assimilation rule just documented on [[不信]]. Quoted real-language fields. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 不可.

### 2026-09-09, iteration 3903 — [[words/不可|不可]]
Fixed a real citation gap on `characters/不 (char).md`'s Words list (可's own list already had it). Korean 불가 already correctly following the 不→불 assimilation rule. Added an entirely missing `## Notes` section and `date-last-perfect: 2026-09-09`.

Next: 不可不.

### 2026-09-09, iteration 3904 — [[words/不可不|不可不]]
No `#cranberry`. Both character pages already cited 不可不 correctly. Filled entirely missing `cantonese: bat1 ho2 bat1`. Added missing `date-last-perfect: 2026-09-09`. Completes the modal square with [[可]]/[[不可]]/[[可不]] already cross-linked in prose.

Next: 不可以.

### 2026-09-09, iteration 3905 — [[words/不可以|不可以]]
All three character pages already cited 不可以 correctly. All content already correct from an exceptionally thorough prior pass (deliberate blank japanese/korean already justified, Vietnamese attestation caveat already documented). A fully clean pass — only refreshed the date stamp.

Next: 不同.

### 2026-09-09, iteration 3906 — [[words/不同|不同]]
Both character pages already cited 不同 correctly. Korean 부동 confirmed correct (no 불 assimilation here; the famous 不同/不動 homophone-collision already well documented). Fixed a missing word-space in `cantonese`. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 不均.

### 2026-09-09, iteration 3907 — [[words/不均|不均]]
Both character pages already cited 不均 correctly. Filled entirely missing `japanese: ふきん` and `korean: 불균` — the real attested reading (confirmed via 불균형 "imbalance"), following the 不→불 assimilation rule (3rd confirmed instance: 不信/不及/不均). Quoted fields. Stamped `date-last-perfect: 2026-09-09`.

Next: 不安.

### 2026-09-09, iteration 3908 — [[words/不安|不安]]
Both character pages already cited 不安 correctly. All content already correct from an exceptionally thorough prior pass (Heidegger/Kierkegaard translation history, 不穏 contrast all well documented). Korean 불안 already correctly following the assimilation rule. Only quoted fields and refreshed the date stamp.

Next: 不定.

### 2026-09-09, iteration 3909 — [[words/不定|不定]]
Both character pages already cited 不定 correctly. All content already correct from an exceptionally thorough prior pass (grammatical/mathematical/general-usage tricategorization all well documented). Fixed a stray internal space in `mandarin` (bù dìng→bùdìng). Quoted fields. Stamped `date-last-perfect: 2026-09-09`.

Next: 不平.

### 2026-09-09, iteration 3910 — [[words/不平|不平]]
Both character pages already cited 不平 correctly. Fixed a missing word-space in `cantonese` and quoted `hsk_level`. Korean 불평 already correctly following the assimilation rule (4th confirmed instance), additionally the everyday word for "complaint." Added an entirely missing `## Notes` section and removed blank `swadesh`/`aliases`. Stamped `date-last-perfect: 2026-09-09`.

Next: 不幸.

### 2026-09-09, iteration 3911 — [[words/不幸|不幸]]
Both character pages already cited 不幸 correctly. Fixed a missing word-space in `cantonese` and quoted `hsk_level`. Korean 불행 already correctly following the assimilation rule. Added an entirely missing `## Notes` section and removed blank `swadesh`/`aliases`. Stamped `date-last-perfect: 2026-09-09`.

Next: 不当.

### 2026-09-09, iteration 3912 — [[words/不当|不当]]
Both character pages already cited 不当 correctly. Korean 부당 confirmed correct (不→불 assimilation does not apply before this consonant, a genuine non-application). Added an entirely missing `## Notes` section and removed blank `hsk_level`/`swadesh`. Stamped `date-last-perfect: 2026-09-09`.

Next: 不断.

### 2026-09-09, iteration 3913 — [[words/不断|不断]]
Both character pages already cited 不断 correctly. All content already correct from an exceptionally thorough prior pass (行/朝-style Vietnamese reading-split, ふだん/普段 true-homophone documentation both well done). **Fixed a comma-joined `cantonese` contamination bug**: `"bat1 dyun6, bat1 tyun5"` — kept bat1 dyun6, matching 断's own stored reading. Stamped `date-last-perfect: 2026-09-09`.

Next: 不満.

### 2026-09-09, iteration 3914 — [[words/不満|不満]]
Both character pages already cited 不満 correctly. Pronunciation fields, `kwin: false`, already correct. Korean 불만 confirmed correct. Added an entirely missing Notes prose paragraph. Stamped `date-last-perfect: 2026-09-09`.

Next: 不用.

### 2026-09-09, iteration 3915 — [[words/不用|不用]]
Both character pages already cited 不用 correctly. This word's own prose independently CONFIRMS the exact 不→불/부 rule already deduced this stretch ("不 reads 부 mainly before ㄷ/ㅈ-initial syllables and 불 otherwise") — nice corroboration. Also documents a genuine Japanese 不用/不要 near-homophone collision and a real Vietnamese gap (no calque exists, honestly left blank). Fixed a missing word-space in `cantonese`. Stamped `date-last-perfect: 2026-09-09`.

Next: 不穏.

### 2026-09-09, iteration 3916 — [[words/不穏|不穏]]
Both character pages already cited 不穏 correctly. All content already correct from an exceptionally thorough prior pass (Chinese-concrete/Japanese-ominous/Korean-politically-charged register comparison already well documented). Fixed a stray internal space in `mandarin`. Quoted fields. Stamped `date-last-perfect: 2026-09-09`.

Next: 不穏素.

### 2026-09-09, iteration 3917 — [[words/不穏素|不穏素]]
Periodic-table neologism series (astatine): already correctly following convention (mandarin/cantonese give the avoided real element character 砹's own reading; korean/japanese/vietnamese are IUPAC-name loanwords; `kwin: false` correctly compares Dan'a'yo against Korean). Fixed a real citation gap: `characters/不 (char).md`'s Words list was missing this entry. Fixed the duplicate `品詞` field. Stamped `date-last-perfect: 2026-09-09`.

Next: 不要.

### 2026-09-09, iteration 3918 — [[words/不要|不要]]
Both character pages already cited 不要 correctly. All content already correct from a thorough prior pass (Mandarin-prohibitive vs Japanese/Korean-descriptive-only false-friend split already well documented). Fixed a missing word-space in `cantonese`. Quoted fields. Stamped `date-last-perfect: 2026-09-09`.

Next: 不許.

### 2026-09-09, iteration 3919 — [[words/不許|不許]]
Both character pages already cited 不許 correctly. All content already correct from a prior thorough pass. A fully clean pass — only refreshed the date stamp.

Next: 不過.

### 2026-09-09, iteration 3920 — [[words/不過|不過]]
Both character pages already cited 不過 correctly. All content already correct from a prior thorough pass (dual limiting-adverb/conjunction sense, deliberate blank japanese, Vietnamese exact-match all well documented). A fully clean pass — only refreshed the date stamp. This closes out the 不-prefixed word cluster.

Next: 与.

### 2026-09-09, iteration 3921 — [[words/与|与]]
Self-standing bare-character word ("and, with"), reciprocal three-way Homophones callout with [[魚]]/[[輿]] already correctly cross-linked on all three pages. All content already correct from an exceptionally thorough prior pass (full CJKV conjunction-vocabulary comparison, MC-vowel-correspondence explanation already well documented). A fully clean pass — only refreshed the date stamp.

Next: 与格.

### 2026-09-09, iteration 3922 — [[words/与格|与格]]
Both character pages already cited 与格 correctly. All content already correct from a prior thorough pass (case-name suffix pattern cross-linking to 8 sibling case-terms already documented). Fixed the duplicate `品詞` field, quoted fields, tidied trailing blank lines. Stamped `date-last-perfect: 2026-09-09`. This closes out the 与-prefixed word cluster.

Next: 丑月.

### 2026-09-09, iteration 3923 — [[words/丑月|丑月]]
No `#cranberry`. `kwin: false` (AND-rule: 丑 true, 月 false) correct. Fixed a real citation gap: `characters/丑.md` had no `## Words` section at all — added minimal section with the self-relevant citation, leaving the page's other rough spots (duplicate `## Notes` heading, dangling CC wikilinks) flagged out-of-scope. Fixed the duplicate `品詞` field and normalized single-item `japanese`/`vietnamese` lists to bare strings. Stamped `date-last-perfect: 2026-09-09`.

Next: 且.

### 2026-09-09, iteration 3924 — [[words/且|且]]
Self-standing bare-character word ("also, too"). **Fixed a real self-reference bug in the reciprocal homophone callout**: both this page and [[処]]'s own page had their callouts pointing to themselves instead of the other party ("[[且]] is a homophone of [[処]]" written ON 且's own page, and the mirror-image error on 処's) — corrected both to the standard format naming only the OTHER word. Fixed the duplicate `品詞` field. Stamped `date-last-perfect: 2026-09-09`.

Next: 且爵.

### 2026-09-09, iteration 3925 — [[words/且爵|且爵]]
Both character pages already cited 且爵 correctly. **Fixed the non-canonical `pos: 動詞`** → `事詞`. Clarified an imprecise prose claim: 爵's "stand-in for 嚼" role here is a special ad-hoc graphemic reuse specific to this one compound only, distinct from 爵's own official `stand_in` ([[男爵]], "baron," unrelated in meaning) — corrected the character-page citation format label too ("stand-in for 嚼"→"stand-in for 咀嚼", matching 爵's own page). Deliberately-blank vietnamese already correctly justified. Stamped `date-last-perfect: 2026-09-09`.

Next: 世仇.

### 2026-09-09, iteration 3926 — [[words/世仇|世仇]]
`characters:` already correctly bare (no words/世.md or words/仇.md). Both character pages already cited 世仇 correctly. Filled entirely missing `vietnamese: thế cừu` and added missing `date-last-perfect: 2026-09-09`. Quoted fields. `kwin: false` correct.

Next: 世代.

### 2026-09-09, iteration 3927 — [[words/世代|世代]]
Legitimizing note (代's own `stand_in` is this exact compound). Both character pages already cited 世代 correctly. Fixed a missing word-space in `cantonese`. Added an entirely missing `## Notes` section. Stamped `date-last-perfect: 2026-09-09`.

Next: 世宗.

### 2026-09-09, iteration 3928 — [[words/世宗|世宗]]
Both character pages already cited 世宗 correctly. Added missing `kwin: false` (AND-rule: 世 false, 宗 true). Quoted `korean`. Stamped `date-last-perfect: 2026-09-09`.

Next: 世界.

### 2026-09-09, iteration 3929 — [[words/世界|世界]]
Legitimizing note (世's own `stand_in` is this exact compound; 界's own is [[境界]] — transitivity fails, no `#cranberry`). **Fixed a real 注音 typo** propagated onto `characters/世.md`'s own citation (ㄙㄝㄐ⼶→ㄙㄝㄍ⼶, wrong onset). Added an entirely missing `## Notes` section and `date-last-perfect: 2026-09-09`.

Next: 世界観.

### 2026-09-09, iteration 3930 — [[words/世界観|世界観]]
No `#cranberry`. All three character pages already cited 世界観 correctly. Added an entirely missing `## Notes` section and `date-last-perfect: 2026-09-09`.

Next: 世界語.

### 2026-09-09, iteration 3931 — [[words/世界語|世界語]]
No `#cranberry`. All three character pages already cited 世界語 correctly (界's own citation clarifies "Esperanto" specifically). Added an entirely missing `## Notes` section clarifying the specific Esperanto referent and `date-last-perfect: 2026-09-09`.

Next: 世紀.

### 2026-09-09, iteration 3932 — [[words/世紀|世紀]]
Legitimizing note (紀's own `stand_in` is this exact compound) already present. Both character pages already cited 世紀 correctly, along with a large family of sibling 世紀-compounds. A fully clean pass — only refreshed the date stamp.

Next: 世紀中.

### 2026-09-09, iteration 3933 — [[words/世紀中|世紀中]]
No `#cranberry`. Fixed a real citation gap on `characters/中 (char).md`'s Words list (世/紀's own lists already had it). Filled entirely missing `vietnamese: giữa thế kỷ` (native word-order-reversed, real natural phrase). Quoted fields. Stamped `date-last-perfect: 2026-09-09`.

Next: 世紀初.

### 2026-09-09, iteration 3934 — [[words/世紀初|世紀初]]
No `#cranberry`. All three character pages already cited 世紀初 correctly. Filled entirely missing `vietnamese: đầu thế kỷ` (native word-order-reversed, matching sibling 世紀中's pattern). Quoted fields. Stamped `date-last-perfect: 2026-09-09`.

Next: 世紀末.

### 2026-09-09, iteration 3935 — [[words/世紀末|世紀末]]
No `#cranberry`. All three character pages already cited 世紀末 correctly. Filled entirely missing `vietnamese: cuối thế kỷ` (matching sibling 世紀中/世紀初 pattern). Quoted fields. Stamped `date-last-perfect: 2026-09-09`.

Next: 世間.

### 2026-09-09, iteration 3936 — [[words/世間|世間]]
Both character pages already cited 世間 correctly. All content already correct from an exceptionally thorough prior pass (Ruth Benedict/Chie Nakane cultural-concept documentation, 間's own reading-split correctly using the "between" default sense, not "interval"). Only quoted fields and refreshed the date stamp. This closes out the 世-prefixed word cluster.

Next: 丘.

### 2026-09-09, iteration 3937 — [[words/丘|丘]]
Self-standing bare-character word ("hill"), reciprocal Homophones callout with [[九]] already correctly cross-linked. All content already correct from a prior thorough pass (Confucius naming-taboo, khâu/khưu Vietnamese variant, native おか/언덕 alternates all well documented). A fully clean pass — only refreshed the date stamp.

Next: 丘引.

### 2026-09-09, iteration 3938 — [[words/丘引|丘引]]
`characters:` already correctly disambiguated. Both character pages already cited 丘引 correctly. Filled entirely missing `vietnamese: giun đất` (real native word, matching the established real-attested-usage convention) and added a missing `## Notes` section. Japanese みみず confirmed correct (real native word, not compositional きゅういん). `kwin` false correct (AND-rule: 丘 false alone determines the result). Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 丙.

### 2026-09-09, iteration 3939 — [[words/丙|丙]]
Self-standing bare-character word ("third class, tertiary"). **Fixed stale wording**: the three-way homophone group with [[坪]]/[[柄]] was described as "still awaiting their own turn" — both are now already perfected, so corrected to reflect the completed mutual cross-link (matching the established 鮑/報-style stale-wording fix pattern). Filled a previously-missing `japanese: へい` field. In passing, fixed a stray blank line inside [[柄]]'s own Homophones callout. Stamped `date-last-perfect: 2026-09-09`.

Next: 両.

### 2026-09-09, iteration 3940 — [[words/両|両]]
Self-standing bare-character word ("both"), reciprocal three-way Homophones callout with [[梁]]/[[糧]] already correctly cross-linked. All content already correct from a prior thorough pass (兩/両/輛 shinjitai-collapse history, tael/vehicle-classifier senses, Korean North-Korean-form note all well documented). Normalized single-item `japanese`/`vietnamese` lists to bare strings. In passing, fixed the same stray-blank-line glitch (already seen on 柄) in both [[梁]]'s and [[糧]]'s own Homophones callouts. Stamped `date-last-perfect: 2026-09-09`.

Next: 両親.

### 2026-09-09, iteration 3941 — [[words/両親|両親]]
Both character pages already cited 両親 correctly. All content already correct from an exceptionally thorough prior pass (父母 register comparison, 双親/song thân Vietnamese near-synonym caveat, Korean 두음법칙-adjacent divergence all well documented). Cantonese loeng5 (vs 両's own stored loeng2) confirmed as a real, standard Cantonese tone divergence for this specific compound, not a bug — left as-is. A fully clean pass — only refreshed the date stamp.

Next: 並.

### 2026-09-09, iteration 3942 — [[words/並|並]]
Self-standing bare-character word ("side by side"). **Fixed stale wording**: [[瓶]] was described as "still awaiting its own turn" — it's already perfected and already reciprocally cross-linked, so corrected the phrasing. Filled a previously-missing `japanese: へい` field. Stamped `date-last-perfect: 2026-09-09`.

Next: 並列.

### 2026-09-09, iteration 3943 — [[words/並列|並列]]
No `#cranberry`. `characters:` already correctly disambiguated/bare as appropriate, both character pages already cited 並列 correctly. Filled entirely missing `vietnamese: tịnh liệt`. **Fixed a redundant self-referential `aliases: [並列]` entry** — same bug variant previously fixed on [[熊鼠]]/[[鼠色]]. Quoted fields. Stamped `date-last-perfect: 2026-09-09`.

Next: 並立.

### 2026-09-09, iteration 3944 — [[words/並立|並立]]
Both character pages already cited 並立 correctly. All content already correct from a prior thorough pass (five-way cross-linguistic attestation, including Vietnamese tịnh lập confirmed via web search, all well documented). A fully clean pass — only refreshed the date stamp. This closes out the 並-prefixed word cluster.

Next: 中.

### 2026-09-09, iteration 3945 — [[words/中|中]]
Self-standing bare-character word (the progressive aspect marker "-ing"). Pronunciation fields and `kwin: true` already matched. All content already correct from a prior thorough pass (full CJKV progressive-aspect comparison chart, [[公]] phonological parallel already documented). Fixed the duplicate `品詞`/`pos` field and quoted real-language fields. Stamped `date-last-perfect: 2026-09-09`. Background exact-match homophone check found no collision.

Next: 中世.

### 2026-09-09, iteration 3946 — [[words/中世|中世]]
Both character pages already cited 中世 correctly. All content already correct from a prior thorough pass (Vietnamese trung thế's narrower Japanese-periodization-specific scope vs. broader trung đại/trung cổ already well documented). A fully clean pass — only refreshed the date stamp.

Next: 中亜.

### 2026-09-09, iteration 3947 — [[words/中亜|中亜]]
Both character pages already cited 中亜 correctly. Added missing `kwin: true` (AND-rule: both 中 and 亜 individually true). Quoted `korean`. Stamped `date-last-perfect: 2026-09-09`.

Next: 中原.

### 2026-09-09, iteration 3948 — [[words/中原|中原]]
**Fixed a real bug the word's own prose had already diagnosed but never corrected**: `japanese` was なかはら, a coincidental Japanese surname/placename unrelated in meaning — the prose itself said so, but the wrong value stayed in the field — corrected to ちゅうげん, the real on'yomi compositional reading used in Japanese sinological writing. Filled an entirely missing `注音` field. Fixed real citation gaps on both `characters/中 (char).md` (was a bare unformatted wikilink) and `characters/原.md`'s (missing entirely) Words lists. Fixed the duplicate `品詞` field.

Next: 中古.

### 2026-09-09, iteration 3949 — [[words/中古|中古]]
**Fixed a real garbled-value bug**: `vietnamese` was `đồ đả dùng qua` (wrong word "đả" for "đã," non-standard word order) — corrected to trung cổ, the real, standard Sino-Vietnamese word for "medieval," matching the word's own senses 2/3; noted the real native phrase (đồ đã qua sử dụng) for the distinct "secondhand goods" sense in prose. Fixed a missing citation on `characters/中 (char).md`'s Words list. Normalized `english` from a bare string to a proper list. Quoted real-language fields. Stamped `date-last-perfect: 2026-09-09`.

Next: 中国.

### 2026-09-09, iteration 3950 — [[words/中国|中国]]
**Fixed a real citation gap my own earlier full-scan false-negatived**: `characters/中 (char).md` had no proper `## Words` citation for 中国, only a bare "short for [[中国]]" mention under a separate `## Definitions` list — the earlier scan's substring match wrongly counted that as satisfying the check. Added the proper ruby-formatted citation. Fixed the duplicate `品詞` field. `国`'s own citation and the systematic 곡/국 divergence explanation (already generalized to [[中国人]]/[[中国語]]/[[中華民国]]) were already correct. Stamped `date-last-perfect: 2026-09-09`.

Next: 中国人.

### 2026-09-09, iteration 3951 — [[words/中国人|中国人]]
**Fixed a real missing-field bug**: `注音` was entirely absent from the frontmatter — added `ㄐㄨㄫㄍㄛㄎㄋㄧㄋ`, matching 国's own citation. Fixed real citation gaps on both `characters/中 (char).md` (was a bare unformatted wikilink) and `characters/人 (char).md` (missing entirely). Fixed the duplicate `品詞` field and lowercased an over-capitalized `vietnamese` ("Người Trung Quốc"→"người Trung Quốc," only the country name warrants capitals).

Next: 中国語.

### 2026-09-09, iteration 3952 — [[words/中国語|中国語]]
**Fixed a real missing-field bug**: `注音` was entirely absent — added `ㄐㄨㄫㄍㄛㄎ⼄`, matching 語's/国's own citations. Fixed a real citation gap on `characters/中 (char).md` (bare unformatted wikilink). Fixed the duplicate `品詞` field and an over-capitalized `vietnamese` ("Tiếng Trung Quốc"→"tiếng Trung Quốc," matching [[中国人]]'s fix).

Next: 中央.

### 2026-09-09, iteration 3953 — [[words/中央|中央]]
Legitimizing note (央's own `stand_in` is this exact compound). **Fixed a real `kwin` bug**: was `true`, contradicting the AND-rule (中 true, 央 false) — corrected to `false`. Fixed a citation gap on `characters/中 (char).md` (bare "short for" mention upgraded to proper ruby citation). Quoted `hsk_level`, removed blank `swadesh`/`aliases`. Added an entirely missing `## Notes` section. Stamped `date-last-perfect: 2026-09-09`.

Next: 中央情報局.

### 2026-09-09, iteration 3954 — [[words/中央情報局|中央情報局]]
`characters:` already correctly bare/disambiguated. All five constituent character pages already cited 中央情報局 correctly. All content already correct from a prior thorough pass (CIA/1947 National Security Act history, KCIA borrowing history both well documented). `kwin: false` correct. A fully clean pass — only refreshed the date stamp.

Next: 中子.

### 2026-09-09, iteration 3955 — [[words/中子|中子]]
All content already exceptionally thoroughly documented from a prior pass (the "middle son" vs. "neutron" homograph carefully disambiguated, Vietnamese deliberately left blank with full justification). **Fixed a real duplicate-citation bug**: `characters/中 (char).md`'s Words list had cited 中子 twice — once correctly and once erroneously glossed "neutron" with a garbled non-matching 注音 — removed the erroneous duplicate (this vault has no separate neutron word file). Stamped `date-last-perfect: 2026-09-09`.

Next: 中学校.

### 2026-09-09, iteration 3956 — [[words/中学校|中学校]]
**Fixed a real missing-field bug**: `注音` was entirely absent — added `ㄐㄨㄫㄏㄚㄎㄏ⼘ㄨ`, matching 学's own citation. Fixed a real citation gap on `characters/校.md` (missing entirely) and upgraded a bare unformatted citation on `characters/中 (char).md`. Fixed the duplicate `品詞` field.

Next: 中庭.

### 2026-09-09, iteration 3957 — [[words/中庭|中庭]]
Legitimizing note (庭's own `stand_in` is this exact compound). **Fixed several real bugs**: `注音` was entirely missing — added `ㄐㄨㄫㄉㄝㄫ`, matching 庭's own citation; upgraded a bare unformatted citation on `characters/中 (char).md`; removed the duplicate `品詞` field.

Next: 中庸.

### 2026-09-09, iteration 3958 — [[words/中庸|中庸]]
No `#cranberry`. Both character pages already cited 中庸 correctly. **Fixed the recurring `characters:` disambiguation bug**: both "中" and "庸" needed the "(char)" suffix (both `words/中.md` and `words/庸.md` exist) — a double instance in one word. `kwin: true` (AND-rule: both true) correct. Removed blank `hsk_level`/`swadesh`/`aliases`. Added an entirely missing `## Notes` section.

Next: 中心.

### 2026-09-09, iteration 3959 — [[words/中心|中心]]
Both character pages already cited 中心 correctly (中's own upgraded from bare to proper ruby format). All other content already correct from a prior thorough pass. Fixed the duplicate `品詞` field. Stamped `date-last-perfect: 2026-09-09`.

Next: 中性子.

### 2026-09-09, iteration 3960 — [[words/中性子|中性子]]
Confirms [[中子]]'s own claim: this IS the vault's separate "neutron" word (中 "neutral" + 性 "charge/nature" + 子 "particle"), distinct from 中子's "middle son" sense — no conflict. All content already exceptionally thoroughly documented (Chadwick 1932 discovery, Japanese Meiji-Taishō scientific-coinage system, Vietnamese phonetic-borrowing choice all well documented). Upgraded two bare unformatted citations on `characters/子.md` and `characters/中 (char).md` to proper ruby format. Stamped `date-last-perfect: 2026-09-09`.

Next: 中指.

### 2026-09-09, iteration 3961 — [[words/中指|中指]]
No `#cranberry`. Both character pages already cited 中指 correctly. **Fixed a real cantonese bug**: `zong1 zi3` → `zung1 zi2`, the proper compositional concatenation. **Removed a false, already-disproven homophone claim**: the page asserted "same sound as [[曽子]]," but [[曽子]]'s own page had already investigated and rejected this exact claim (注音 ㄐㄜㄫㄐㄜ vs this word's ㄐㄨㄫㄐㄧㄜ, no match) — the reciprocal stale claim on this side was simply never cleaned up. Restructured into standard `## Notes` template. Stamped `date-last-perfect: 2026-09-09`.

Next: 中文.

### 2026-09-09, iteration 3962 — [[words/中文|中文]]
Both character pages already cited 中文 correctly (中's own upgraded from bare to proper ruby format). All other content already correct from a prior thorough pass. Fixed the duplicate `品詞` field. Stamped `date-last-perfect: 2026-09-09`.

Next: 中日韓越.

### 2026-09-09, iteration 3963 — [[words/中日韓越|中日韓越]]
`characters:` already correctly disambiguated/bare as appropriate. **Fixed several real bugs**: `cantonese` used non-breaking spaces (U+00A0) instead of regular spaces AND was missing 越's own syllable entirely — required a Python-based fix since the invisible NBSP characters didn't match ordinary Edit tool string matching; `mandarin` had a tone-mark placement typo (Yùe→Yuè, matching 越's own stored yuè). Fixed a missing citation on `characters/韓.md`'s Words list and the duplicate `品詞` field. Added an entirely missing `## Notes` section.

Next: 中旬.

### 2026-09-09, iteration 3964 — [[words/中旬|中旬]]
Both character pages already cited 中旬 correctly (中's own upgraded from bare to proper ruby format). Cantonese zung1 ceon4 already correctly matches the fix pattern established on sibling 上旬/下旬. All other content already correct from a prior thorough pass. Fixed the duplicate `品詞` field. Stamped `date-last-perfect: 2026-09-09`.

Next: 中止.

### 2026-09-09, iteration 3965 — [[words/中止|中止]]
Legitimizing note (止's own `stand_in` is this exact compound) already essentially present, labeled explicitly. Both character pages already cited 中止 correctly. Filled entirely missing `vietnamese: trung chỉ`. Stamped `date-last-perfect: 2026-09-09`.

Next: 中秋節.

### 2026-09-09, iteration 3966 — [[words/中秋節|中秋節]]
All three character pages already cited 中秋節 correctly. All content already correct from a prior thorough pass (嫦娥/后羿 mythology, Korean 추석/Chuseok structural contrast, cross-referenced 仲秋/桂月/秋分 all well documented). Fixed the duplicate `品詞` field and quoted fields. Stamped `date-last-perfect: 2026-09-09`.

Next: 中等.

### 2026-09-09, iteration 3967 — [[words/中等|中等]]
Found and fixed a duplicate-citation bug on `characters/等 (char).md`: an old bare-format `## Words` list (中等/初等/同等/優等/劣等, plus still-unique 平等/恒等式/等分/等待) sat alongside a newer properly ruby-formatted list further down that had re-added 高等/中等/初等/同等/優等/劣等 with correct 注音. Removed the 5 confirmed-duplicated old bare entries, keeping 平等/恒等式/等分/等待 (not yet migrated) untouched. `kwin: false` on 中等 itself confirmed correct via AND-rule (中's kwin true + 等's own kwin false = false). Content (三-tier 初等/中等/高等 hierarchy, 等's bamboo-tablet etymology) already thorough from a prior pass. Quoted mandarin/cantonese/korean fields, no homophone collision on ㄐㄨㄫㄉㄨㄫ. Stamped `date-last-perfect: 2026-09-09`.

Next: 中耳.

### 2026-09-09, iteration 3968 — [[words/中耳|中耳]]
Citation on `中(char)` was still bare-format (`[[中耳]]`); upgraded to proper ruby-formatted entry matching `耳(char)`'s already-correct citation. Fixed duplicate `pos`/`品詞` field, quoted mandarin/cantonese. `kwin: false` confirmed correct via AND-rule (中 true + 耳's own kwin false = false). No homophone collision on ㄐㄨㄫㄋㄧ. Content already thorough (anatomy, MC 日-initial n-/∅ split cross-referenced with 中国人's 人). Stamped `date-last-perfect: 2026-09-09`.

Next: 中華.

### 2026-09-09, iteration 3969 — [[words/中華|中華]]
Substantially incomplete before this pass: `characters:` used undisambiguated `中` despite `words/中.md` existing, `date-last-perfect` was entirely absent, `hsk_level`/`swadesh` sat as dangling empty fields, `pos` was 性詞 (adjective-like) rather than 固有名詞 to match sibling proper-noun culture/place terms (中国/中亜/中日韓越), and the whole Notes section was a single stray fragment ("syn . 台湾") instead of real content. Disambiguated 中→中 (char), removed empty fields, fixed pos, normalized aliases to block-list form, wrote full Notes (civilizational-vs-political contrast with 中国, 中華民国/中華人民共和国, 中華料理 in Japanese, Vietnamese Trung Hoa vs Trung Quốc). `kwin: true` confirmed correct via AND-rule (中/華 both true). Citations already present and correctly ruby-formatted on both `中(char)` and `華.md`. No homophone collision on ㄐㄨㄫㄏ⺢. Stamped `date-last-perfect: 2026-09-09`.

Next: 中華民国.

### 2026-09-09, iteration 3970 — [[words/中華民国|中華民国]]
Citation on `中(char)` was still bare-format (`[[中華民国]]`); upgraded to proper ruby entry matching the already-correct citations on 華/民/国. Fixed duplicate `pos`/`品詞` field, quoted mandarin/cantonese, caught my own mistyped korean old_string on the first Edit attempt (typed hanja 中華民国 instead of the actually-stored Hangul 중화민국 — same recurring self-transcription error) and corrected on retry. `kwin: false` confirmed via 4-way AND-rule (中/華/民 true, 国 false). Content already thorough (ROC vs PRC distinction, 곡/국 divergence cross-referenced with 中国人/中国語). No homophone collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 中間.

### 2026-09-09, iteration 3971 — [[words/中間|中間]]
Found the systemic missing-注音 bug: frontmatter had no `注音` field at all. Derived and added ㄐㄨㄫㄍㄚㄋ (中's ㄐㄨㄫ + 間's own ㄍㄚㄋ), matching 間.md's own citation. Also upgraded 中(char)'s still-bare citation (`[[中間]]`) to proper ruby format, fixed duplicate `pos`/`品詞`, quoted mandarin/cantonese. `kwin: true` confirmed via AND-rule (中/間 both true). Content already thorough (間's "interval/gap" contrast with 中心's "core/hub" sense). No homophone collision. Stamped `date-last-perfect: 2026-09-09`. This closes out the 中-prefixed word cluster; next word begins a new initial (串).

Next: 串.

### 2026-09-09, iteration 3972 — [[words/串|串]]
Found a missing `japanese` field entirely absent from frontmatter despite Notes discussing both Japanese readings (セン/カン on'yomi, くし kun'yomi). Established (via cross-checking 上/丁/丙, all of which pick their character page's first-listed on'yomi for the stand-in word) that the vault convention is: first-listed on'yomi wins. 串(char)'s own `japanese: [SEN, KAN]` → added せん. Documented the convention explicitly in the word's own Notes. `kwin: false` trivially confirmed (single constituent, character's own kwin false). No homophone collision on ㄐ⺢ㄇ. Stamped `date-last-perfect: 2026-09-09`.

Next: 丹砂.

### 2026-09-09, iteration 3973 — [[words/丹砂|丹砂]]
Already fully correct from a prior pass: `characters:` bare 丹 confirmed right (no `words/丹.md` exists), `沙 (char)` disambiguation correct, `kwin: true` confirmed via AND-rule, legitimizing note (丹's own `stand_in: 丹砂`) confirmed, citations correctly ruby-formatted on both character pages, and the reciprocal Homophones callout with [[単詞]] (real, anchored-grep-confirmed collision on 注音 ㄉㄚㄋㄙㄚ) already in standard format on both pages. Just refreshed `date-last-perfect: 2026-09-09`.

Next: 丹金.

### 2026-09-09, iteration 3974 — [[words/丹金|丹金]]
Periodic-table-neologism word (hafnium, via Copenhagen→Denmark→丹 two-step toponymic reduction) — `kwin` correctly uses the neologism exception (compares word's own 諺文 vs its own korean field directly, not constituent AND-rule), already thoroughly explained in Notes. Found and fixed a missing citation on `金 (char).md` (丹金 wasn't listed at all); added it with the periodic-table-neologism annotation matching its siblings (蛍金/隠金/難金/雷金). No homophone collision on ㄉㄚㄋㄍㄧㄇ. Stamped `date-last-perfect: 2026-09-09`.

Next: 丹麦.

### 2026-09-09, iteration 3975 — [[words/丹麦|丹麦]]
Fixed an unspaced cantonese field ("daan1mak6"→"daan1 mak6") to match the vault's overwhelming space-separated-syllable convention. `characters:` bare 丹/麦 both confirmed correct (neither has a `words/*.md` conflict). `kwin: false` confirmed via AND-rule (丹 true, 麦 false). Citations correct on both character pages. No homophone collision. Cross-checked the terse "Purely phonetic" Notes style against [[瑞典]] (same pattern) — confirmed this is the accepted vault convention for transliterated country names, not a content gap; noted 瑞典's own separate bugs (duplicate 品詞, malformed vietnamese field) for when its turn comes up alphabetically. Stamped `date-last-perfect: 2026-09-09`.

Next: 主人.

### 2026-09-09, iteration 3976 — [[words/主人|主人]]
Substantially incomplete: `date-last-perfect` entirely absent, dangling empty `swadesh`/`aliases` fields, vietnamese wrongly capitalized ("Chủ nhân"→"chủ nhân", common noun not proper noun), and no `## Notes` section at all. Wrote full Notes covering the legitimizing note (主's own `stand_in: 主人`), cross-CJKV usage (主人公/女主人/男主人, Japanese しゅじん's "one's own husband" sense, 주인공/주인의식, chủ nhân của), and the kwin explanation (人's MC 日-initial n-/∅ split, same as [[中国人]]/[[中耳]]). Found and fixed a missing citation on `人(char).md`. `kwin: false` confirmed via AND-rule (主 true, 人 false). No homophone collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 主婦.

### 2026-09-09, iteration 3977 — [[words/主婦|主婦]]
Already fully correct from a prior pass: `characters:` disambiguation confirmed right on both sides (bare 主, disambiguated `婦 (char)`), `kwin: false` confirmed via AND-rule, citations correctly ruby-formatted on both character pages, no homophone collision confirmed via anchored grep. Just refreshed `date-last-perfect: 2026-09-09`.

Next: 主宰.

### 2026-09-09, iteration 3978 — [[words/主宰|主宰]]
Found a missing legitimizing note: 宰's own page carries `stand_in: "主宰"`, but this word's own Notes never documented the reciprocal relationship. Added it. `characters:` confirmed correct (bare 主/宰, neither has a conflicting `words/*.md`), `kwin: true` confirmed via AND-rule, citations correctly ruby-formatted on both character pages (including the sibling compound 主宰万物), no homophone collision. Content otherwise already thorough (cosmic/philosophical vs mundane administrative sense, Vietnamese chủ tể's matching dual weight). Stamped `date-last-perfect: 2026-09-09`.

Next: 主導.

### 2026-09-09, iteration 3979 — [[words/主導|主導]]
Same missing-legitimizing-note pattern as the previous iteration: 導's own page carries `stand_in: "主導"`, not documented reciprocally here — added it. `characters:` confirmed correct (bare 主/導), `kwin: false` confirmed via AND-rule, citations correctly ruby-formatted on both character pages, no homophone collision. Content otherwise already thorough (主導 vs 主宰 register contrast, the yet-uncreated 指導/引導/領導 family noted). Stamped `date-last-perfect: 2026-09-09`.

Next: 主席.

### 2026-09-09, iteration 3980 — [[words/主席|主席]]
Substantially incomplete: `date-last-perfect` entirely absent, dangling empty `swadesh`/`aliases` fields, and no real `## Notes` — just a stray non-standard homophone line. `characters:` confirmed correct (bare 主/席, no conflicting words/*.md; 席's own `stand_in` is a different word, 坐席, so no legitimizing note applies here). `kwin: true` confirmed via AND-rule. Reformatted the homophone claim into the standard `>[!warning] Homophones` callout and verified it's real via anchored grep (both 主席 and [[朱錫]] share 注音 ㄐㄨㄙㄝㄎ). Wrote full Notes (国家主席 head-of-state usage, North Korean 주석 as a historical head-of-state title, Vietnamese Chủ tịch nước parallel). **Flagged for later**: 朱錫.md's own side of this homophone still uses a non-standard callout format and carries a stray gibberish line ("This very K word is necessary because 'seg' is so full") — awaiting its alphabetical turn. Stamped `date-last-perfect: 2026-09-09`.

Next: 主幹.

### 2026-09-09, iteration 3981 — [[words/主幹|主幹]]
Already fully correct from a prior pass: legitimizing note present (幹's `stand_in: 主幹` correctly documented), `characters:` confirmed correct, `kwin: true` confirmed via AND-rule, citations correctly ruby-formatted on both character pages, no homophone collision. Just refreshed `date-last-perfect: 2026-09-09`.

Next: 主従.

### 2026-09-09, iteration 3982 — [[words/主従|主従]]
Found: `date-last-perfect` entirely absent, `vietnamese` field entirely missing, mandarin/cantonese/korean unquoted, and caught my own recurring korean-hanja-instead-of-Hangul transcription slip on the first Edit attempt (corrected on retry). Filled vietnamese with chủ tớ — the real, everyday native+SV idiom for "master and servant" (quan hệ chủ tớ), preferred over the compositional-but-unattested chủ tùng. `characters:` confirmed correct (従's own `stand_in` is itself, not this compound — so no legitimizing note needed here despite the 主-compound cluster pattern). `kwin: true` confirmed via AND-rule. Citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 主意.

### 2026-09-09, iteration 3983 — [[words/主意|主意]]
Found two real bugs: `kwin` field entirely missing from frontmatter (added `false`, via AND-rule: 主 true + 意 false = false), and a citation inconsistency on `主.md` — its 主意 entry used rt `ㄐㄨ·ㄧ` while the word's own stored `注音` and `意.md`'s own citation both correctly use `ㄐㄨ·ㄜ`; fixed `主.md`'s citation to match. `characters:` confirmed correct (both bare, no conflicting words/*.md). Content already excellent (the 主意/注意 homophone pair thoroughly cross-explained, cross-strait Mandarin tone split, Korean's identical collision). No other homophone collisions beyond the already-documented 注意. Stamped `date-last-perfect: 2026-09-09`.

Next: 主掌.

### 2026-09-09, iteration 3984 — [[words/主掌|主掌]]
Fixed duplicate `pos`/`品詞` field and quoted mandarin/cantonese/korean (self-caught a transcription slip mid-edit: the korean field was already correct Hangul 주장, not hanja as I first mistyped in old_string). `characters:` confirmed correct (bare 主/掌, no conflicting words/*.md). `kwin: true` confirmed via AND-rule. Citations correct on both character pages. Verified no Dan'a'yo-level homophone collision (注音 ㄐㄨㄐㄚㄫ unique) — the Korean-only 主張/主掌 collision already well-documented in prose is real but Korean-specific, not a Dan'a'yo pair (主張 doesn't even exist as a word file yet). Content otherwise already excellent (周禮 citation). Stamped `date-last-perfect: 2026-09-09`.

Next: 主教.

### 2026-09-09, iteration 3985 — [[words/主教|主教]]
Substantially incomplete: `date-last-perfect` and `vietnamese` both entirely missing, mandarin/cantonese/korean unquoted, and Notes were two bare bullets with no cross-language usage or kwin explanation. Filled vietnamese with giám mục (the real, standard Vietnamese Catholic term for "bishop," preferred over compositional-but-unattested chủ giáo, since Vietnamese ecclesiastical vocabulary developed largely independently of Sino-Vietnamese roots — cf. linh mục, hồng y). Wrote the kwin explanation (教's own 굣/교 Dan'a'yo-vs-Sino-Korean divergence). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule, citations correct on both character pages (including sibling 大主教/総主教), no homophone collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 主日.

### 2026-09-09, iteration 3986 — [[words/主日|主日]]
Quoted mandarin/cantonese/korean fields. Expanded thin Notes: added the Japanese しゅじつ usage note (rare, mainly liturgical/translated texts; everyday Japanese uses 主の日 or 日曜日) and the kwin explanation (日's MC 日-initial n-/∅ split, same pattern as [[中国人]]/[[中耳]]/[[主人]]). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule, citations correct on both character pages (including sibling 棕枝主日). No homophone collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 主旨.

### 2026-09-09, iteration 3987 — [[words/主旨|主旨]]
Already fully correct from a prior pass: legitimizing note present (旨's `stand_in: "主旨"` correctly documented), `characters:` confirmed correct, `kwin: false` confirmed via AND-rule, citations correct on both character pages, no homophone collision. Just refreshed `date-last-perfect: 2026-09-09`.

Next: 主格.

### 2026-09-09, iteration 3988 — [[words/主格|主格]]
Fixed duplicate `pos`/`品詞` field and quoted mandarin/cantonese/korean. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule, citations correct on both character pages, no homophone collision. Content already excellent (grammatical-metalanguage cross-reference to 主語/主題, full etymological breakdown of both 主 and 格, cross-link to [[与格]]). Stamped `date-last-perfect: 2026-09-09`.

Next: 主権.

### 2026-09-09, iteration 3989 — [[words/主権|主権]]
Quoted mandarin/cantonese/korean fields. Expanded a one-line Notes into full cross-language coverage (主権国家/主権在民/領土主権 collocations, Vietnamese chủ quyền's everyday political usage, kwin explanation). `characters:` confirmed correct, `kwin: true` confirmed via AND-rule, citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 主義.

### 2026-09-09, iteration 3990 — [[words/主義|主義]]
Content already thoroughly perfected in a very recent prior pass (2026-09-04, the ju'wi/읫-confusion cleanup shared with 官僚主義/定義/定義域/正義). Investigated the kwin:false vs AND-heuristic (主 true, 義 true → expected true) discrepancy: 主義's own kwin:false is directly justified by its own field comparison (諺文 주읫 vs korean 주의 diverge in the final coda) — correct as stored. **Flagged an unresolved open question** rather than acting unilaterally: 義(char)'s own page has the identical 읫/의 divergence yet marks its own `kwin: true`, which doesn't obviously reconcile with the AND-heuristic; documented in this word's Notes for future investigation rather than touched here. `characters:` confirmed correct, citations correct on both character pages (including 官僚主義/社会主義/禁欲主義 siblings), no homophone collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 主要.

### 2026-09-09, iteration 3991 — [[words/主要|主要]]
Already fully correct from a prior pass: `characters:` confirmed correct, `kwin: false` confirmed via AND-rule, citations correct on both character pages, no homophone collision confirmed. Just refreshed `date-last-perfect: 2026-09-09`.

Next: 主頁.

### 2026-09-09, iteration 3992 — [[words/主頁|主頁]]
Substantially incomplete: `characters:` had bare undisambiguated `頁` despite `words/頁.md` existing (fixed to `頁 (char)`), `date-last-perfect` entirely absent, dangling empty `hsk_level`/`swadesh`, inline-flow `aliases`, no Notes at all, and a missing citation on `頁 (char).md`'s own Words section (added). Found and fixed three fabricated/non-standard readings: japanese しゅページ (a half-Sino/half-loanword hybrid that isn't real Japanese) → ホームページ, korean 메인페이지 (literal "main page" transliteration, less standard) → 홈페이지 ("homepage," the actually universal term), vietnamese Trang Chính (the specific proper-noun title of, e.g., Wikipedia's own main page) → trang chủ (the real generic everyday term for a website's homepage) — all three replaced with genuinely attested real-world usage per the vault's real-usage-over-compositional convention, since Chinese/Cantonese build this IT term compositionally from Sino roots but Japanese/Korean/Vietnamese don't. `kwin: false` confirmed via AND-rule (主 true, 頁(char) false). No homophone collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 主題.

### 2026-09-09, iteration 3993 — [[words/主題|主題]]
Missing `date-last-perfect`, dangling empty fields, and no Notes at all. Wrote full Notes (contrast with 主旨/主格/主語, cross-language compositional readings, 主題曲/主題公園 collocations, kwin explanation via 題's own 테/제 divergence). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule, citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-09`. This closes out the long 主-prefixed word cluster; next word begins a new initial (乃).

Next: 乃.

### 2026-09-09, iteration 3994 — [[words/乃|乃]]
Found the systemic missing-`japanese` field bug again: absent from frontmatter despite Notes discussing all three on'yomi. Applied the established first-listed-on'yomi convention (乃(char)'s `[DAI, AI, NAI]` → だい), documented explicitly in the word's own Notes. `kwin: true` trivially confirmed (single constituent, character's own kwin true). Citation correct, and the reciprocal real homophone with [[耐]] already correctly documented on both pages. Stamped `date-last-perfect: 2026-09-09`.

Next: 久.

### 2026-09-09, iteration 3995 — [[words/久|久]]
Already fully correct from a very recent prior pass: legitimizing note present, `kwin: false` confirmed (single constituent), citation correct, and the reciprocal real homophone with [[球]] already correctly documented on both pages. Just refreshed `date-last-perfect: 2026-09-09`.

Next: 久闊.

### 2026-09-09, iteration 3996 — [[words/久闊|久闊]]
Substantially incomplete: `korean`, `vietnamese`, and `kwin` fields all entirely missing, and Notes were a single bare constituent-breakdown bullet. Added korean 구활 (compositional concatenation) and vietnamese cửu khoát (compositional, flagged as not independently attested — 久闊 appears to be primarily a Sino-Japanese/Mandarin literary expression), `kwin: false` via AND-rule (both constituents independently false). Also fixed a citation-format inconsistency on `闊 (char).md` (was using a raw markdown link instead of a wikilink). Wrote full Notes on the formal-greeting-after-long-absence register. No homophone collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 之.

### 2026-09-09, iteration 3997 — [[words/之|之]]
Found a missing self-legitimizing citation: 之 (char)'s own `stand_in: 之` (i.e. itself) wasn't cited in its own Words section at all — added it. Also fixed a raw-markdown-link-instead-of-wikilink citation for the sibling 之間 on the same page (added its missing gloss too) while there. Fixed duplicate `pos`/`品詞` and quoted cantonese. `kwin: false` trivially confirmed (single constituent). Content otherwise already excellent (attested classical usage across all five languages, MC palatal-onset mapping explanation). Stamped `date-last-perfect: 2026-09-09`.

Next: 之間.

### 2026-09-09, iteration 3998 — [[words/之間|之間]]
Fixed duplicate `pos`/`品詞` field. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (之(char) false, 間 true), citations correct on both character pages (之(char)'s own citation now correct after last iteration's fix), no homophone collision. Content already excellent (legitimizing note for 間, the frontmatter-vs-everyday-equivalent distinction for particle words, full kwin mismatch explanation). Stamped `date-last-perfect: 2026-09-09`.

Next: 乎.

### 2026-09-09, iteration 3999 — [[words/乎|乎]]
Already fully correct from a prior pass: `kwin: true` confirmed (single constituent), citation correct on the character page, and the 3-way homophone claim with [[呼]]/[[虎]] confirmed real via anchored grep (both still awaiting their own turn, consistent with the Notes' own claim). Just refreshed `date-last-perfect: 2026-09-09`.

Next: 乖巧.

### 2026-09-09, iteration 4000 — [[words/乖巧|乖巧]]
**4000th iteration of this sweep.** Already fully correct from a prior pass: legitimizing note present (乖's `stand_in: "乖巧"` correctly documented, distinct from 巧's own `stand_in: "巧妙"`), `characters:` confirmed correct (neither has a conflicting words/*.md), `kwin: false` confirmed via AND-rule, citations correct on both character pages, no homophone collision. Just refreshed `date-last-perfect: 2026-09-09`.

Next: 乗.

### 2026-09-09, iteration 4001 — [[words/乗|乗]]
Found the missing-`japanese`-field bug again (4th time this sweep: 串, 中間, 乃, now 乗). Applied the established first-listed-on'yomi convention (乗(char)'s `[JOU, SHOU]` → じょう), documented in Notes. `kwin: false` trivially confirmed (single constituent). Citation correct, and the real homophone with [[升]] confirmed (still awaiting its own turn). Stamped `date-last-perfect: 2026-09-09`.

Next: 乗務.

### 2026-09-09, iteration 4002 — [[words/乗務|乗務]]
Missing `vietnamese` entirely and thin Notes (one bare bullet). Filled vietnamese with thừa vụ (compositional; flagged as not independently attested) and, while researching it, **found a separate bug**: 務's own character page stores vietnamese as mùa/múa, which are unrelated native Vietnamese words (not readings of 務 at all — the real Sino-Vietnamese reading is vụ, extremely productive elsewhere) — flagged for 務's own alphabetical turn rather than fixed here. Quoted mandarin/cantonese/korean. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (乗(char) false, 務 true), citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 乗員.

### 2026-09-09, iteration 4003 — [[words/乗員|乗員]]
Quoted mandarin/cantonese/korean and expanded thin Notes (contrast with [[乗務]], 乗務員 as the combined common form, kwin explanation). Initially suspected a duplicate-citation bug (乗員 appearing to be cited twice) but verified it was two separate, correct single-citations on two different character pages (乗(char) and 員), not a duplicate — false alarm caught before acting. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (員's own korean 운/kwin:true independently verified, not assumed), no homophone collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 乗客.

### 2026-09-09, iteration 4004 — [[words/乗客|乗客]]
Missing `vietnamese` entirely; filled with hành khách (行客, the real everyday Vietnamese term for "passenger") rather than a compositional-but-unattested "thừa khách." Quoted mandarin/cantonese/korean, wrote full Notes. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 乗数.

### 2026-09-09, iteration 4005 — [[words/乗数|乗数]]
Missing `vietnamese` entirely; filled with thừa số, the real Vietnamese math term (乗's thừa + 数's số) — used generically for "factor" without Vietnamese distinguishing multiplier from multiplicand. Quoted mandarin/cantonese/korean, expanded Notes (被乗数 contrast, kwin explanation). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (乗(char) false, 数 true), citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 乗算.

### 2026-09-09, iteration 4006 — [[words/乗算|乗算]]
Missing `vietnamese` entirely; filled with phép nhân, the real everyday Vietnamese term for the multiplication operation (built on native/SV verb nhân), rather than compositional-but-unattested "thừa toán." Quoted mandarin/cantonese/korean, wrote full Notes (sibling operations 加算/減算/除算). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 乗船.

### 2026-09-09, iteration 4007 — [[words/乗船|乗船]]
Quoted mandarin/cantonese/korean, wrote full Notes (乗車/乗馬 sibling pattern). **Vietnamese kept as-is but flagged**: thừa thuyền is a sound compositional derivation but not independently confirmed as a real fixed term (everyday Vietnamese favors native lên thuyền/lên tàu) — couldn't verify further this iteration (web search budget exhausted for this session), documented the uncertainty honestly rather than asserting either way. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 乗車.

### 2026-09-09, iteration 4008 — [[words/乗車|乗車]]
Quoted mandarin/cantonese/korean, wrote full Notes (乗船/乗馬 sibling pattern, 乗車券/乗車率 collocations). Vietnamese thừa xa kept as-is with the same honest uncertainty caveat as [[乗船]]'s thừa thuyền (compositionally sound, not independently confirmed, everyday Vietnamese favors native lên xe). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 乗降.

### 2026-09-09, iteration 4009 — [[words/乗降|乗降]]
Missing `vietnamese` entirely; filled with lên xuống, the real everyday native Vietnamese term (native lên+xuống, as in cửa lên xuống "boarding door") rather than a forced compositional Sino-Vietnamese calque. Quoted mandarin/cantonese/korean, wrote full Notes (乗降口/乗降客数/승강장 collocations, kwin explanation). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (乗(char) false, 降 true), citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 乗馬.

### 2026-09-09, iteration 4010 — [[words/乗馬|乗馬]]
Quoted mandarin/cantonese/korean, wrote full Notes (乗馬クラブ/乗馬服 collocations). Vietnamese thừa mã kept with the same honest uncertainty caveat as its 乗船/乗車 siblings (compositionally sound classical form, modern Vietnamese favors native cưỡi ngựa). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (乗(char) false, 馬(char) true), citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-09`. This closes out the long 乗-prefixed word cluster; next word moves to the 乘 variant character.

Next: 乘法.

### 2026-09-09, iteration 4011 — [[words/乘法|乘法]]
Vietnamese thừa pháp replaced with phép nhân, the same real term already established on [[乗算]] (same underlying concept, 乘/乗 variant characters sharing the same char page, Vietnamese doesn't distinguish the 法-vs-算 register split). Quoted mandarin/cantonese/korean, expanded Notes. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 乙.

### 2026-09-09, iteration 4012 — [[words/乙|乙]]
Fixed a duplicate `pos`/`品詞` field pair that also disagreed with each other (副用名詞 vs 副詞名詞) — kept `pos`, removed `品詞`. `kwin: true` confirmed (single constituent), citation correct, no homophone collision. Content already excellent (十干 stem sequence, Vietnamese sexagenary-cycle cross-reference to [[丙]]'s own bính). Stamped `date-last-perfect: 2026-09-09`.

Next: 九.

### 2026-09-09, iteration 4013 — [[words/九|九]]
Fixed duplicate `pos`/`品詞` field. `kwin: false` confirmed (single constituent), citation correct, and the real coincidental homophone with [[丘]] confirmed reciprocally documented on both pages. Content already excellent (玖 anti-forgery variant cross-referenced with 一/壱 and 七/漆, Japanese く-avoidance superstition). Stamped `date-last-perfect: 2026-09-09`.

Next: 九九.

### 2026-09-09, iteration 4014 — [[words/九九|九九]]
Substantially incomplete: `characters:` was a malformed scalar string instead of a YAML list, `羅馬字` was un-doubled (kyu, inconsistent with the doubled 諺文 큐큐/注音 ㄎ⼜ㄎ⼜) — fixed to kyukyu, `date-last-perfect` and `vietnamese` both entirely missing, duplicate `pos`/`品詞`, and no Notes at all. Filled vietnamese with bảng cửu chương (the real, universally-known Vietnamese term for the multiplication table) rather than a literal cửu-cửu reduplication. Also upgraded a bare-format citation on `九(char).md` to proper ruby format. Wrote full Notes on the reduplication naming pattern (九九八十一 chant, 구구단). `kwin: false` confirmed (inherits 九's own mismatch in both syllables). No homophone collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 九十.

### 2026-09-09, iteration 4015 — [[words/九十|九十]]
Found a missing disambiguation: `characters:` had bare `十` despite `十 (char)` (and a conflicting `words/十.md`) existing — fixed. Also found and fixed empty-string `vietnamese`/`swadesh` fields (vietnamese filled with cửu thập, the classical Sino-Vietnamese numeral, distinct from everyday native chín mươi), duplicate `pos`/`品詞`, missing `date-last-perfect`, and no Notes at all. Upgraded bare-format citations on BOTH character pages (九(char) and 十(char)) to proper ruby format. `kwin: false` confirmed via AND-rule (九(char) false, 十(char) true). No homophone collision. Stamped `date-last-perfect: 2026-09-09`.

Next: 九卿.

### 2026-09-10, iteration 4016 — [[words/九卿|九卿]]
Missing `vietnamese` entirely; filled with cửu khanh, a real attested classical Sino-Vietnamese term (Vietnam's own Nguyễn-dynasty imperial bureaucracy borrowed the same "Nine Ministers" concept directly from the Chinese model). Quoted mandarin/cantonese/korean. Upgraded a bare-format citation on `九(char).md` to proper ruby format. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already excellent (Zhou/Han/later-dynasty compositional variation). Stamped `date-last-perfect: 2026-09-10`.

Next: 九天.

### 2026-09-10, iteration 4017 — [[words/九天|九天]]
Content already excellent from a prior pass (Daoist Nine Heavens cosmology, Vietnamese Cửu Thiên compositional parallel, kwin explanation). Found and fixed one gap: `九(char).md`'s own citation was still bare-format — upgraded to proper ruby. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 九官鳥.

### 2026-09-10, iteration 4018 — [[words/九官鳥|九官鳥]]
Missing `vietnamese` entirely; filled with yểng, the real standard native Vietnamese name for the hill myna, rather than a forced Sino-Vietnamese compositional calque (cửu quan điểu, unattested) — concrete animal names typically carry native terms across the sphere. Quoted mandarin/cantonese/korean. Upgraded a bare-format citation on `九(char).md` to proper ruby format. `characters:` confirmed correct, `kwin: false` confirmed via 3-way AND-rule (官 true, 九/鳥 both false), no homophone collision. Content already excellent (九品 official-rank etymology theory). Stamped `date-last-perfect: 2026-09-10`.

Next: 九尾狐.

### 2026-09-10, iteration 4019 — [[words/九尾狐|九尾狐]]
Verified japanese きゅうびこ is correct (compositional on'yomi concatenation of 九/尾/狐's own KYUU/BI/KO), not a bug, despite everyday Japanese always using the mixed on-kun 九尾の狐 (documented in Notes already, now explicitly cross-referenced to explain the frontmatter/prose divergence). Quoted mandarin/cantonese/korean. Upgraded a bare-format citation on `九(char).md`. `characters:` confirmed correct, `kwin: false` confirmed via 3-way AND-rule (狐 true, 九/尾 both false), no homophone collision. Content already excellent (山海経 origin, Korean malevolent-shapeshifter tradition, Tamamo-no-Mae/殺生石 legend). Stamped `date-last-perfect: 2026-09-10`.

Next: 九州.

### 2026-09-10, iteration 4020 — [[words/九州|九州]]
Found and fixed a duplicate-citation bug on `九(char).md`: two separate bare-format entries for 九州 ("biggest Japanese island" and "Kyushu") — merged into one proper ruby-formatted entry. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already excellent (genuine two-referent word: Yu the Great's legendary nine provinces vs Japan's Kyushu, Korean 구주/규슈 register split). **Noted for later** (not fixed, out of alphabetical scope): `九(char).md` still has several other bare/raw-link citations (九日, 九経 via raw markdown link, 十九 with trailing space, 九族) awaiting their own turns. Stamped `date-last-perfect: 2026-09-10`.

Next: 九数.

### 2026-09-10, iteration 4021 — [[words/九数|九数]]
Fixed duplicate `pos`/`品詞`, quoted mandarin/cantonese/korean. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (九(char) false, 数 true), citations correct on both character pages, no homophone collision. Content already excellent (周禮 Six Arts curriculum, full Zheng Xuan/Zheng Zhong Nine Numbers enumeration, 九章算術 lineage). Stamped `date-last-perfect: 2026-09-10`.

Next: 九族.

### 2026-09-10, iteration 4022 — [[words/九族|九族]]
Quoted mandarin/cantonese/korean. Upgraded a bare-format citation on `九(char).md` to proper ruby format (one of the previously-flagged pending gaps, now cleared). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (九(char) false, 族 true), no homophone collision. Content already excellent (full nine-degree kinship enumeration, 尚書 origin, 誅九族 imperial-law collective punishment doctrine). Stamped `date-last-perfect: 2026-09-10`.

Next: 九日.

### 2026-09-10, iteration 4023 — [[words/九日|九日]]
Substantially incomplete: `date-last-perfect` entirely absent, duplicate `pos`/`品詞`, vietnamese was a lazy placeholder ("ngày 9" mixing digit with word) rather than proper Vietnamese — fixed to mùng chín, the standard everyday way to name a date in this range. Verified japanese ここのか is correct (the real native day-counting reading, not a compositional bug — same convention as ついたち/ふつか/みっか through とおか). Expanded the bare 3-item list into full Notes (multi-sense word: calendar date / duration / Hou Yi nine-suns myth, cross-referenced with [[中秋節]]). Also upgraded an odd bare citation (`[[words/九日]]`, unusual path-prefixed link syntax) on `九(char).md` to proper ruby format — clearing another previously-flagged gap. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 九月.

### 2026-09-10, iteration 4024 — [[words/九月|九月]]
Fixed an unspaced cantonese field (gau2jut6→gau2 jut6). Verified japanese くがつ is correct (real Japanese month-name irregularity, retaining the older on'yomi く rather than きゅう — same pattern as 四月/七月). Upgraded a bare-format citation on `九(char).md` to proper ruby format, clearing another flagged gap. Expanded thin Notes. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 九泉.

### 2026-09-10, iteration 4025 — [[words/九泉|九泉]]
Missing `vietnamese` entirely; filled with cửu tuyền, the real classical literary term (alongside native chín suối). Quoted mandarin/cantonese/korean. Noted korean 구천's coincidental identity with [[九天]]'s own korean field (both 泉/天 read 천 in Sino-Korean) is Korean-specific only, not a Dan'a'yo homophone (Dan'a'yo readings 큐줜 vs 큐턴 remain distinct) — verified via direct field comparison rather than assumed. Upgraded a bare-format citation on `九(char).md`, clearing another flagged gap. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule, no Dan'a'yo-level homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 九経.

### 2026-09-10, iteration 4026 — [[words/九経|九経]]
Missing `vietnamese` entirely; filled with cửu kinh, a real attested term (Vietnam's own imperial exam system used the same Confucian canon). Quoted mandarin/cantonese/korean, noted korean 구경's coincidental identity with [[九卿]]'s own korean field is Korean-specific only (Dan'a'yo readings 큐겅 vs 큐켱 remain distinct) — verified directly. Fixed `九(char).md`'s raw-markdown-link citation (`[九經](../words/九経.md)`) by upgrading to a proper wikilink+ruby entry. One bare-format citation remains on that page — `[[十九]] - nineteen` — deferred to 十九's own alphabetical turn (later, since 十-prefixed words sort after all 九-prefixed ones). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule, no Dan'a'yo-level homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 九龍.

### 2026-09-10, iteration 4027 — [[words/九龍|九龍]]
Missing `date-last-perfect` entirely, dangling empty `hsk_level`/`swadesh`/`aliases`, no Notes at all. Wrote full Notes on the genuine multi-referent nature: Kowloon (Hong Kong district) vs Vietnamese Cửu Long (the Mekong Delta's nine tributary mouths) — the same "nine dragons" naming logic applied to two unrelated geographic features. Upgraded bare-format citations on BOTH `九(char).md` and `龍(char).md`. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (九(char) false, 龍(char) true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 九-prefixed word cluster; next word begins a new initial (乞).

Next: 乞.

### 2026-09-10, iteration 4028 — [[words/乞|乞]]
Found the missing-`japanese`-field bug again (5th time this sweep: 串, 中間, 乃, 乗, now 乞). Applied first-listed-on'yomi convention (乞(char)'s `[KOTSU, KI]` → こつ), documented in Notes. `kwin: false` trivially confirmed (single constituent). Citation correct, no homophone collision. Content already excellent (乞丐/乞食/Buddhist alms-begging cross-references, Vietnamese khất disambiguated from unrelated gật/khắt candidates). Stamped `date-last-perfect: 2026-09-10`.

Next: 乞丐.

### 2026-09-10, iteration 4029 — [[words/乞丐|乞丐]]
Found a real bug: `japanese` stored かたい, an unrelated real Japanese word ("hard, solid, strict") that doesn't match either constituent's own on'yomi at all — corrected to こつかい (compositional first-listed-on'yomi concatenation, 乞's KOTSU + 丐's KAI). Also fixed an unspaced cantonese field and added a missing legitimizing note (丐's own `stand_in: 乞丐`, not previously documented reciprocally). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (乞(char) false, 丐 true), citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 也.

### 2026-09-10, iteration 4030 — [[words/也|也]]
Found the missing-`japanese`-field bug again (6th time this sweep). Added や (也's only on'yomi, YA). Quoted mandarin/cantonese/korean. `kwin: true` trivially confirmed (single constituent), citation correct, and the real homophone with [[夜]] confirmed (still awaiting its own turn). Content already excellent (disputed pictographic origin, Sino-Tibetan grammaticalization, なり functional parallel). Stamped `date-last-perfect: 2026-09-10`.

Next: 乱漫.

### 2026-09-10, iteration 4031 — [[words/乱漫|乱漫]]
Substantially incomplete: `date-last-perfect` and `vietnamese` both entirely missing, and the file used a non-standard `## Etymology` heading instead of the vault's standard `## Notes`. Fixed the heading, wrote full Notes (floral-profusion sense + 天真乱漫 personality extension), filled vietnamese with hồn nhiên (real native term for "innocent, artless" — no fixed Sino-Vietnamese compound attested from 乱/漫's own stored readings). `characters:` confirmed correct (both bare, no conflicting words/*.md), `kwin: true` confirmed via AND-rule (both constituents independently true), citations correct on both character pages (including sibling 天真乱漫), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 乱離.

### 2026-09-10, iteration 4032 — [[words/乱離|乱離]]
Found and fixed a missing citation: 乱離 was entirely absent from `乱.md`'s own Words section — added. `characters:` confirmed correct (both bare, no conflicting words/*.md), `kwin: false` confirmed via AND-rule (乱 true, 離 false), no homophone collision. Content already excellent (Vietnamese loạn ly's literary attestation, Korean 난리's lexicalized "commotion" extension). Stamped `date-last-perfect: 2026-09-10`.

Next: 乳房.

### 2026-09-10, iteration 4033 — [[words/乳房|乳房]]
Substantially incomplete: `date-last-perfect` missing, dangling empty `hsk_level`/`swadesh`/`aliases`, no Notes. Wrote full Notes. Vietnamese "nhũ phòng" (compositional but unattested) replaced with vú, the real everyday native word for "breast" — concrete body-part words typically favor native Vietnamese vocabulary over Sino-Vietnamese compounds. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (乳 false, 房(char) true), citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 乳押.

### 2026-09-10, iteration 4034 — [[words/乳押|乳押]]
Found and fixed a false stale claim: the page asserted it was the `stand_in` legitimizer for [[押]], but 押's own `stand_in` actually points to itself (押 is independently viable as its own word, "mortgage") — 乳押 just uses 押 as an ordinary bound morpheme in this coinage, no legitimizing relationship applies. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (乳 false, 押(char) true), citations correct on both character pages, no homophone collision. Content otherwise already excellent (genuine Dan'a'yo-internal neologism vs each real language's own independently-formed term — 乳罩/胸罩, ちちおさえ, 브래지어, áo ngực). Stamped `date-last-perfect: 2026-09-10`.

Next: 乳液.

### 2026-09-10, iteration 4035 — [[words/乳液|乳液]]
Quoted korean field. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), citations correct on both character pages, no homophone collision. Content already excellent, including an honest self-documented note about a prior "no Vietnamese attestation" finding being revisited with domain knowledge under an exhausted search quota (nhũ dịch, real chemistry/cosmetics term) — same honesty pattern I've been applying this session. Stamped `date-last-perfect: 2026-09-10`.

Next: 乳色.

### 2026-09-10, iteration 4036 — [[words/乳色|乳色]]
Quoted mandarin/cantonese/korean, expanded Notes (cross-language compositional confirmation, kwin explanation). Flagged vietnamese nhũ sắc honestly as unverified (compositionally sound, but this session's search budget remains exhausted; native alternatives màu kem/trắng sữa noted as possibilities) rather than asserting or guessing. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 乳酪.

### 2026-09-10, iteration 4037 — [[words/乳酪|乳酪]]
Already fully correct from a prior pass: legitimizing note present (酪's `stand_in: "乳酪"` correctly documented), `characters:` confirmed correct, `kwin: false` confirmed via AND-rule, citations correct on both character pages, no homophone collision. Just refreshed `date-last-perfect: 2026-09-10`.

Next: 乳頭.

### 2026-09-10, iteration 4038 — [[words/乳頭|乳頭]]
Found a real bug: `japanese` stored a garbled mix "乳首,にゅうとう" (a comma-joined mash of the everyday word's kanji spelling and a compositional on'yomi reading) — corrected to just にゅうとう (compositional 乳's NYUU + 頭's TOU), moving 乳首's everyday-usage role into prose. Also fixed vietnamese capitalization (Núm vú→núm vú, common noun), removed dangling empty fields, added missing `date-last-perfect`, wrote full Notes. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-10`. This closes out the 乳-prefixed word cluster; next word begins a new initial (乾).

Next: 乾.

### 2026-09-10, iteration 4039 — [[words/乾|乾]]
Found the missing-`japanese`-field bug again (7th time this sweep). Applied first-listed-on'yomi convention (乾(char)'s `[KAN, KEN, GEN]` → かん). Also found and fixed a one-sided stale claim: Notes said [[鍵]] was "still awaiting its own turn," but 鍵 was perfected 2026-09-07 (after 乾's own last-perfect date) and its own page already confirms the 3-way cross-link with [[見]] is complete — updated the claim. `kwin: false` trivially confirmed (single constituent). Content otherwise excellent (qián/gān dual-sense unification, 干/幹 disambiguation, Vietnamese càn/kiền attested-vs-corpus-noise candidate sorting). Stamped `date-last-perfect: 2026-09-10`.

Next: 乾坤.

### 2026-09-10, iteration 4040 — [[words/乾坤|乾坤]]
Found and fixed: (1) a missing legitimizing note (坤's own `stand_in: "乾坤"` not documented reciprocally), (2) a missing citation on `乾(char).md` (乾坤 entirely absent from its Words section), and (3) an inconsistent vietnamese capitalization (frontmatter "Càn Khôn" vs the prose's own lowercase "càn khôn" example — càn khôn is a common expression, not a proper noun, so standardized to lowercase). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content otherwise excellent (八卦 trigram cosmology, xoay chuyển càn khôn idiom). Stamped `date-last-perfect: 2026-09-10`.

Next: 乾浄.

### 2026-09-10, iteration 4041 — [[words/乾浄|乾浄]]
Fixed duplicate `pos`/`品詞` (which also disagreed: 性詞 vs 形容詞), quoted mandarin/cantonese/korean, normalized `japanese` from a single-item list to a scalar. Missing `vietnamese` filled with càn tịnh — but found a real bug while researching it: `浄.md`'s own stored vietnamese candidates (tĩnh, tạnh) belong to entirely unrelated characters (靜 "quiet" and an unrelated weather term), not 浄 at all; the real Sino-Vietnamese reading of 浄 is tịnh (thanh tịnh, tịnh xá) — flagged for 浄's own alphabetical turn rather than fixed there. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (乾(char) false, 浄 true), citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 乾溜.

### 2026-09-10, iteration 4042 — [[words/乾溜|乾溜]]
Quoted korean field. Verified the vietnamese "can" (vs 乾's other stored candidates càn/càng used elsewhere for the "heavenly"/other senses) is a deliberate, correct sense-appropriate reading choice, not an inconsistency. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (乾(char) false, 溜 true), citations correct on both character pages, no homophone collision. Content already excellent, including an honest self-documented "search quota exhausted" caveat for the Vietnamese chemistry-term attestation (same pattern as this session's own). Stamped `date-last-perfect: 2026-09-10`.

Next: 乾燥.

### 2026-09-10, iteration 4043 — [[words/乾燥|乾燥]]
Already fully correct from a prior pass: legitimizing note present (燥's `stand_in: "乾燥"` correctly documented), `characters:` confirmed correct, `kwin: false` confirmed via AND-rule, citations correct on both character pages, no homophone collision, `swadesh: 195` confirmed a legitimate numbered field per vault convention. Just refreshed `date-last-perfect: 2026-09-10`.

Next: 乾芻.

### 2026-09-10, iteration 4044 — [[words/乾芻|乾芻]]
Found a real bug: `korean` field stored 간추, but 乾's own Sino-Korean reading is 건 (not 간) — corrected to 건추 (乾's 건 + 芻's own 추, both in frontmatter and prose). Quoted mandarin/cantonese. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (乾(char) false, 芻 true), citations correct on both character pages, no homophone collision. Content already exceptional (芻狗/芻言/芻議 classical compound family, 道德經 citation, military-logistics fodder-supply context). Stamped `date-last-perfect: 2026-09-10`.

Next: 乾達婆.

### 2026-09-10, iteration 4045 — [[words/乾達婆|乾達婆]]
Missing `date-last-perfect` entirely, dangling empty `hsk_level`/`swadesh`, no Notes at all. Wrote full Notes explaining this is a pure Sanskrit phonetic transliteration (gandharva → 乾達婆), not a compositional Chinese coinage — the three characters carry no combined semantic meaning. Confirmed vietnamese Càn Thát Bà's capitalization is correct (a genuine proper noun, naming a specific class of celestial being). `characters:` confirmed correct, `kwin: false` confirmed via 3-way AND-rule (all three constituents independently false), citations correct on all three character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 乾酪.

### 2026-09-10, iteration 4046 — [[words/乾酪|乾酪]]
Already fully correct from a prior pass: `characters:` confirmed correct, `kwin: false` confirmed via AND-rule, citations correct on both character pages, no homophone collision. Content already excellent (cross-referenced with [[乳酪]]'s own nhũ lạc, French loanword phô mai contrast). Just refreshed `date-last-perfect: 2026-09-10`. This closes out the 乾-prefixed word cluster; next word begins a new initial (亀).

Next: 亀.

### 2026-09-10, iteration 4047 — [[words/亀|亀]]
Found the missing-`japanese`-field bug again (8th time this sweep). Applied first-listed-on'yomi convention (亀(char)'s `[KI, KYUU, KIN]` → き). `kwin: false` trivially confirmed (single constituent), citation correct, no homophone collision. Content already excellent (shinjitai-over-simplified-Chinese rationale, 亀裂/龜裂 unrelated-sense disambiguation, Kim Quy golden-turtle legend). Stamped `date-last-perfect: 2026-09-10`.

Next: 亀頭.

### 2026-09-10, iteration 4048 — [[words/亀頭|亀頭]]
Missing `date-last-perfect` entirely, dangling empty `hsk_level`/`swadesh`, no Notes at all. Wrote full Notes. Found and fixed a missing citation on `亀(char).md`: 亀頭 was entirely absent from its own Words section — added. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Stamped `date-last-perfect: 2026-09-10`. **Noted for later** (not fixed, out of scope): 亀(char).md still has two other bare-format citations (海亀, 陸亀) awaiting their own turns. This closes out the 亀-prefixed word cluster; next word begins a new initial (了).

Next: 了.

### 2026-09-10, iteration 4049 — [[words/了|了]]
Found the missing-`japanese`-field bug again (9th time this sweep). Added りょう (了's only on'yomi, RYOU). `kwin: false` trivially confirmed (single constituent), citation correct, and the real homophone with [[聊]] confirmed (still awaiting its own turn). Content already excellent (free word vs. grammaticalized aspect-particle role, cross-reference to [[了解]]'s own corpus-noise vietnamese candidates). Stamped `date-last-perfect: 2026-09-10`.

Next: 了解.

### 2026-09-10, iteration 4050 — [[words/了解|了解]]
Already fully correct from a prior pass: `characters:` confirmed correct, `kwin: false` confirmed via AND-rule, citations correct on both character pages, no homophone collision. Content already excellent (瞭解 alias etymology, Japanese りょうかい's narrower "roger!" pragmatic function vs Chinese's general verb sense, Korean 요해/이해 register contrast, Vietnamese liễu giải/giải liễu doublet-order note). Just refreshed `date-last-perfect: 2026-09-10`. This closes out the 了-prefixed word cluster; next word begins a new initial (予).

Next: 予定.

### 2026-09-10, iteration 4051 — [[words/予定|予定]]
Missing `vietnamese` entirely; filled with dự định, the real everyday Vietnamese word for "plan, intend to," using 予's real Sino-Vietnamese reading dự — flagging `予.md`'s own stored vietnamese candidates (dư/dừ) as belonging to an unrelated character (餘/余, "surplus"), a bug for 予's own turn. Quoted mandarin/cantonese/korean, expanded thin Notes (careful note distinguishing this word's own 여정 reading from the unrelated, far more common 예정 which uses the separate character 豫). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (予 false, 定 true), citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 予州.

### 2026-09-10, iteration 4052 — [[words/予州|予州]]
Verified 豫 is genuinely registered as 予's own `aliases` entry (confirming this word's own 豫州 alias field is correct) and connected this to last iteration's 予定/예정 note — the same alias relationship explains why the everyday Korean word 예정 (written with 豫) shares a root with 予定's own compositional 여정 reading, retroactively clarifying rather than contradicting that earlier caution. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), citations correct on both character pages, no homophone collision. Content already excellent (《禹貢》 Tribute of Yu fertile-soil ranking, modern Henan continuity). Stamped `date-last-perfect: 2026-09-10`.

Next: 予様.

### 2026-09-10, iteration 4053 — [[words/予様|予様]]
Already fully correct from a prior pass: legitimizing note present (予's `stand_in: "予様"` correctly documented), `characters:` confirmed correct, `kwin: false` confirmed via AND-rule, citations correct on both character pages, no homophone collision. Content already excellent (Dan'a'yo-internal coinage vs each language's own real independent word for "beforehand," cross-referenced with [[乳押]]'s same coinage pattern). Just refreshed `date-last-perfect: 2026-09-10`.

Next: 予習.

### 2026-09-10, iteration 4054 — [[words/予習|予習]]
Already fully correct from a prior pass: `characters:` confirmed correct, `kwin: false` confirmed via AND-rule, citations correct on both character pages, no homophone collision. Content exceptional — this page definitively confirms the 予/豫/預 cognate-reading-borrowing pattern I'd been navigating cautiously across [[予定]]/[[予州]] (예/여 substitution in Korean, jyu6/jyu4 substitution in Cantonese), and the deliberately-left-blank Vietnamese field is well-justified (no fixed compound; descriptive phrase used instead), not an omission. Just refreshed `date-last-perfect: 2026-09-10`. This closes out the 予-prefixed word cluster; next word begins a new initial (争).

Next: 争端.

### 2026-09-10, iteration 4055 — [[words/争端|争端]]
Substantially incomplete: `date-last-perfect` and `vietnamese` both entirely missing, and Notes were absent (just the homophone callout with no explanation). Wrote full Notes. Filled vietnamese with tranh đoan, using 争's real Sino-Vietnamese reading tranh — not the chanh/danh currently stored on `争.md`'s own character page, which look like a separate bug flagged for later. `characters:` confirmed correct (both bare, no conflicting words/*.md), `kwin: false` confirmed via AND-rule (both constituents independently false), citations correct on both character pages, and the real homophone with [[長短]] confirmed reciprocally documented (already fixed on that page's own turn). Stamped `date-last-perfect: 2026-09-10`. This closes out the 争-prefixed word cluster; next word begins a new initial (事).

Next: 事.

### 2026-09-10, iteration 4056 — [[words/事|事]]
Quoted cantonese field. Polished the self-legitimizing note phrasing to match the standard convention (same pattern as [[之]]'s own fix earlier this sweep). `kwin: false` confirmed trivially, citation correct, and the real homophone with [[字]] confirmed reciprocally documented (already fixed on that page's own turn). Content already excellent (事/物 processual-vs-object contrast, correlative row generation, MC affricate-devoicing kwin explanation). Stamped `date-last-perfect: 2026-09-10`.

Next: 事件.

### 2026-09-10, iteration 4057 — [[words/事件|事件]]
Substantially incomplete: `date-last-perfect` missing, dangling empty `hsk_level`/`swadesh`/`aliases`, no Notes, wrong vietnamese capitalization (Sự kiện→sự kiện, common noun), and a minor `characters:` indentation inconsistency (normalized to match vault style). Wrote full Notes including a missing legitimizing note (件's own `stand_in: 事件`, not previously documented). Verified the unusual cantonese `si6 gin6-2` tone-sandhi notation is a legitimate, established vault convention (confirmed via other `-2`-suffixed cantonese fields elsewhere), not a bug. `characters:` otherwise confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 事典.

### 2026-09-10, iteration 4058 — [[words/事典|事典]]
Found and fixed a missing legitimizing note: 典's own `stand_in: "事典"` wasn't documented reciprocally on this page — added. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), citations correct on both character pages (including sibling 百科事典), and the real homophone with [[字典]] confirmed reciprocally documented (a genuine minimal pair distinguishing topic/fact-organized vs. character-organized reference works). Stamped `date-last-perfect: 2026-09-10`.

Next: 事務所.

### 2026-09-10, iteration 4059 — [[words/事務所|事務所]]
Already fully correct from a prior pass: `characters:` confirmed correct, `kwin: false` confirmed via 3-way AND-rule (務 true, 事(char)/所(char) both false), citations correct on all three character pages, no homophone collision. Content already excellent (弁護士事務所/会計事務所 professional-practice register vs. generic 会社/オフィス, Vietnamese sự vụ sở vs. văn phòng distinction). Just refreshed `date-last-perfect: 2026-09-10`.

Next: 事宜.

### 2026-09-10, iteration 4060 — [[words/事宜|事宜]]
Quoted mandarin/cantonese/korean. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), citations correct on both character pages, no homophone collision. Content already excellent (事's 会意 flag-and-hand etymology, 宜's cross-linked [[時宜]]/[[便宜]] family, bureaucratic-register "practical specifics vs. substance" distinction). Stamped `date-last-perfect: 2026-09-10`.

Next: 事実.

### 2026-09-10, iteration 4061 — [[words/事実|事実]]
Fixed a malformed `vietnamese` field (comma-joined, capitalized "Sự thật,Sự thực" string) into a proper lowercase two-item list. Missing `date-last-perfect` entirely, dangling empty `swadesh`, no Notes at all — wrote full content. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (事(char) false, 実 true), citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 事情.

### 2026-09-10, iteration 4062 — [[words/事情|事情]]
Already fully correct from a prior pass: `characters:` confirmed correct, `kwin: false` confirmed via AND-rule, citations correct on both character pages, no homophone collision. Content already excellent (事物 concrete-thing contrast, Japanese 事情がある polite-deflection idiom, Korean 사정이 있다 parallel idiom). Just refreshed `date-last-perfect: 2026-09-10`.

Next: 事故.

### 2026-09-10, iteration 4063 — [[words/事故|事故]]
Removed dangling empty `swadesh`/`aliases` fields. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (事(char) false, 故 true), citations correct on both character pages, and the real coincidental homophone with [[慈姑]] confirmed reciprocally documented. Content already excellent (no-stand-in-relationship clarification cross-referencing 故's own [[緣故]]). Stamped `date-last-perfect: 2026-09-10`.

Next: 事物.

### 2026-09-10, iteration 4064 — [[words/事物|事物]]
Fixed an unspaced cantonese field (si6mat6→si6 mat6), removed dangling empty `swadesh`/`aliases` fields, wrote full Notes (cross-referencing the 事/物 processual-vs-concrete pairing already noted on [[事]]'s own page). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (事(char) false, 物(char) true), citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 事詞.

### 2026-09-10, iteration 4065 — [[words/事詞|事詞]]
Substantially incomplete: `mandarin`/`cantonese`/`japanese`/`korean`/`vietnamese`/`kwin` were all entirely missing, and duplicate `pos`/`品詞` present. Filled all readings compositionally, matching the exact pattern established on sibling grammatical-category word [[性詞]] (careful to use 詞's real correct vietnamese reading từ, not its own first-listed-but-wrong candidate tờ — same lesson as 性詞's own precedent). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (事(char) false, 詞 true), citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-10`. This closes out the 事-prefixed word cluster; next word begins a new initial (二).

Next: 二.

### 2026-09-10, iteration 4066 — [[words/二|二]]
Fixed duplicate `pos`/`品詞`. Upgraded a bare-format citation on `二(char).md` to proper ruby format. `kwin: false` trivially confirmed (single constituent), and the real homophone with [[貳]] confirmed (still awaiting its own turn). Content already excellent (指事 stroke-duplication etymology, 貳 anti-forgery variant cross-referenced with 一/壱, 七/漆, 九/玖; Vietnamese nhị/nhì/hai three-way reading distinction). Stamped `date-last-perfect: 2026-09-10`.

Next: 二万.

### 2026-09-10, iteration 4067 — [[words/二万|二万]]
Missing `vietnamese` entirely; filled with nhị vạn, the real Sino-Vietnamese numeral compound for "twenty thousand." Quoted mandarin/cantonese/korean. Upgraded a bare-format citation on `二(char).md`. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already excellent (万-as-grouping-unit East Asian numeral system explanation, "万 overfull as bare syllable" rule cross-referenced with [[一万]]/[[七万]]/[[二百]]/[[二千]]). Stamped `date-last-perfect: 2026-09-10`.

Next: 二人.

### 2026-09-10, iteration 4068 — [[words/二人|二人]]
Quoted mandarin/cantonese/korean (self-caught the recurring korean-hanja-instead-of-Hangul transcription slip on the first Edit attempt and corrected on retry). Upgraded a bare-format citation on `二(char).md`. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already excellent (ふたり's fossilized-native-numeral status, Old Japanese ふた-/Korean 둘 cognate cross-reference). Stamped `date-last-perfect: 2026-09-10`.

Next: 二十.

### 2026-09-10, iteration 4069 — [[words/二十|二十]]
Found a missing disambiguation: `characters:` had bare `十` despite `十 (char)` (and a conflicting `words/十.md`) existing — fixed. Upgraded bare-format citations on BOTH `十(char).md` and `二(char).md` to proper ruby format. `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already exceptional (Korean 스물/스무 native layer, Japanese はたち/ふたそじ archaic -soji suffix system, Vietnamese hai mươi native-in-all-registers vs. classical-only nhị thập). Stamped `date-last-perfect: 2026-09-10`.

Next: 二十一日.

### 2026-09-10, iteration 4070 — [[words/二十一日|二十一日]]
Substantially incomplete: `characters:` had bare undisambiguated `十` despite `十(char)`/conflicting `words/十.md` existing (fixed to `十 (char)`), missing `vietnamese`/`date-last-perfect`, duplicate `pos`/`品詞`, `japanese` as a single-item list normalized to scalar, and Notes were a single bare constituent-link line (one via raw markdown link). Filled vietnamese with ngày hai mươi mốt (native calendar-date form, matching [[二十]]'s own convention). **Found and fixed a major citation gap**: this word was entirely missing from THREE of its four constituent character pages (一, 十, 二 — only 日 had it) — added to all three. `kwin: false` confirmed via 4-way AND-rule (all four constituents independently false). No homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 二十七日.

### 2026-09-10, iteration 4071 — [[words/二十七日|二十七日]]
Identical bug pattern to [[二十一日]] (same cluster of 二十N日 date words): bare undisambiguated `十`, missing vietnamese/date, duplicate pos/品詞, japanese single-item list, thin raw-markdown-link Notes, and citations missing from THREE of four constituent character pages (二/十/七 — only 日 had it). Fixed all of it identically: disambiguation, vietnamese ngày hai mươi bảy (native, matching [[二十一日]]/[[二十]] convention), full Notes, added missing citations to all three pages. `kwin: false` confirmed via 4-way AND-rule. No homophone collision. Stamped `date-last-perfect: 2026-09-10`. **Expect the same pattern on remaining 二十N日 siblings** (二十三日 next, etc.) — apply the same fix template each time rather than re-deriving from scratch.

Next: 二十三日.

### 2026-09-10, iteration 4072 — [[words/二十三日|二十三日]]
Same bug pattern as [[二十一日]]/[[二十七日]]: bare undisambiguated `十`, missing vietnamese/date, duplicate pos/品詞, japanese single-item list, thin Notes, citations missing from 二/十/三 (only 日 had it). Fixed identically: disambiguation, vietnamese ngày hai mươi ba, full Notes, added citations to all three character pages. `kwin: false` confirmed via 4-way AND-rule (三 true, 二/十/日 all false). No homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 二十九日.

### 2026-09-10, iteration 4073 — [[words/二十九日|二十九日]]
Same bug pattern (4th instance in this cluster): bare undisambiguated `十`, missing vietnamese/date, duplicate pos/品詞, japanese single-item list, thin Notes, citations missing from 二/十/九 (only 日 had it). Fixed identically: disambiguation, vietnamese ngày hai mươi chín, full Notes, added citations to all three character pages. `kwin: false` confirmed via 4-way AND-rule (all four independently false). No homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 二十二日.

### 2026-09-10, iteration 4074 — [[words/二十二日|二十二日]]
Same bug pattern (5th instance): bare undisambiguated `十`, missing vietnamese/date, duplicate pos/品詞, japanese single-item list, thin Notes, citations missing from 二/十 (only 日 had it). Fixed identically, plus a small variant: 二 appears twice in the reading (twenty + ones-digit) but was previously listed twice in `characters:` — condensed to a single entry, consistent with the established [[九九]] precedent (list each distinct constituent once regardless of repeat occurrences). `kwin: false` confirmed via AND-rule. No homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 二十五日.

### 2026-09-10, iteration 4075 — [[words/二十五日|二十五日]]
Same bug pattern (6th instance): bare undisambiguated `十`, missing vietnamese/date, duplicate pos/品詞, japanese single-item list, thin Notes, citations missing from 二/十/五 (only 日 had it). Fixed identically: vietnamese ngày hai mươi lăm (using the irregular lăm final-digit form Vietnamese requires for 5 from 15+ onward, not the plain năm), added citations to all three character pages. `kwin: false` confirmed via 4-way AND-rule (五 true, 二/十/日 all false). No homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 二十八日.

### 2026-09-10, iteration 4076 — [[words/二十八日|二十八日]]
Same bug pattern (7th instance): bare undisambiguated `十`, missing vietnamese/date, duplicate pos/品詞, japanese single-item list, thin Notes, citations missing from 二/十/八 (only 日 had it). Fixed identically, preserved the existing "last day of February in common years" content note. `kwin: false` confirmed via 4-way AND-rule (all four independently false). No homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 二十六日.

### 2026-09-10, iteration 4077 — [[words/二十六日|二十六日]]
Same bug pattern (8th instance), with a variant: `六(char).md` and `日(char).md` already had this word cited, but `二(char).md`/`十(char).md` did not — added to those two only. Fixed disambiguation, vietnamese ngày hai mươi sáu, date, duplicate pos/品詞, japanese-as-list, thin Notes — same template as the rest of the cluster. `kwin: false` confirmed via 4-way AND-rule (all four independently false). No homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 二十四日.

### 2026-09-10, iteration 4078 — [[words/二十四日|二十四日]]
Same bug pattern (9th instance): bare undisambiguated `十`, missing vietnamese/date, duplicate pos/品詞, thin Notes, citations missing from 二/十/四 (only 日 had it). Fixed identically; preserved and expanded the existing japanese-irregularity note (にじゅうよっか, using the native counter よっか rather than compositional にじゅうしにち, consistent with bare [[四日]]'s own irregularity). `kwin: false` confirmed via 4-way AND-rule (all four independently false). No homophone collision. Stamped `date-last-perfect: 2026-09-10`. Note: 二十日 (the bare 20th, no ones-digit) is still due next — the 二十N日 cluster isn't quite closed out yet.

Next: 二十日.

### 2026-09-10, iteration 4079 — [[words/二十日|二十日]]
Final instance (10th) of the 二十N日 bug pattern: bare undisambiguated `十`, missing vietnamese/date, duplicate pos/品詞, japanese-as-list, thin Notes, citations missing from 二/十 (only 日 had it). Fixed identically; preserved and expanded the existing japanese-irregularity note (はつか, one of Japanese's irregular native day-counting readings alongside ついたち...とおか/よっか). `kwin: false` confirmed via 3-way AND-rule (all three independently false). No homophone collision. Stamped `date-last-perfect: 2026-09-10`. **This genuinely closes out the entire 二十N日 date-word cluster** (二十日, 二十一日 through 二十九日 — 10 words total, all now fixed); next word (二千) moves to a different compound entirely.

Next: 二千.

### 2026-09-10, iteration 4080 — [[words/二千|二千]]
Found `cantonese` field was completely empty (blank value) — filled with ji6 cin1. Fixed a mis-capitalized vietnamese ("Hai ngàn"→"hai nghìn", using the northern-standard native numeral form; noted ngàn as the equally valid southern variant). Removed dangling empty `hsk_level`/`swadesh`/`aliases`, duplicate `pos`/`品詞`, added missing `date-last-perfect`, wrote full Notes. Upgraded a bare-format citation on `二(char).md`. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (二(char) false, 千 true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 二心.

### 2026-09-10, iteration 4081 — [[words/二心|二心]]
Missing `vietnamese` entirely; filled with nhị tâm, paralleling the well-established classical/literary Chinese register (not independently confirmed as a separately attested term, but defensible given the concept's own inherently classical nature). Quoted mandarin/cantonese/korean. Upgraded a bare-format citation on `二(char).md`. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (二(char) false, 心(char) true), no homophone collision. Content already excellent (classical political-loyalty 一心/二心 contrast, Japanese ふたごころ's more elegiac/romantic register vs Chinese's moral-political indictment, Buddhist divided-mind usage). Stamped `date-last-perfect: 2026-09-10`.

Next: 二日.

### 2026-09-10, iteration 4082 — [[words/二日|二日]]
Missing `vietnamese` entirely; filled with mùng hai (native calendar-date form, matching [[九日]]'s own mùng chín and the whole 二十N日 cluster convention). Upgraded a bare-format citation on `二(char).md`. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already thoroughly cleaned up from a prior pass (the date-vs-duration sense split consolidated into the `二天` alias, matching the [[三日]] precedent). Stamped `date-last-perfect: 2026-09-10`.

Next: 二月.

### 2026-09-10, iteration 4083 — [[words/二月|二月]]
Upgraded a bare-format citation on `二(char).md`, expanded thin Notes (cross-language compositional confirmation, kwin explanation). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 二次元.

### 2026-09-10, iteration 4084 — [[words/二次元|二次元]]
Missing `vietnamese` entirely; filled with nhị thứ nguyên, compositional from 次元's own standard Vietnamese math translation thứ nguyên — flagged as not independently confirmed for the otaku-slang sense, where Vietnamese fans more often just borrow the English loanword "2D" directly. Quoted mandarin/cantonese/korean. Upgraded a bare-format citation on `二(char).md`. `characters:` confirmed correct (both 次/元 bare, no conflicting words/*.md), `kwin: false` confirmed via 3-way AND-rule (元 true, 二/次 both false), no homophone collision. Content already excellent (math dimension sense vs. otaku 二次元/三次元 fiction-vs-reality slang split, 1990s-2000s Japanese origin, spread to Korean/Chinese fandom). Stamped `date-last-perfect: 2026-09-10`.

Next: 二百.

### 2026-09-10, iteration 4085 — [[words/二百|二百]]
Found a missing disambiguation: `characters:` had bare `百` despite `百 (char)` (and a conflicting `words/百.md`) existing — fixed. Quoted mandarin/cantonese/korean. Upgraded a bare-format citation on `二(char).md`. `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already excellent (standalone-hundred-unit East Asian numeral logic, 弍/佰 anti-counterfeiting variants, cross-referenced with [[二十]]/[[二千]]/[[二万]]). Stamped `date-last-perfect: 2026-09-10`.

Next: 二重.

### 2026-09-10, iteration 4086 — [[words/二重|二重]]
Missing `vietnamese` entirely; filled with nhị trùng, using 重's real Sino-Vietnamese reading trùng — found a real bug while researching it: `重(char)`'s own stored vietnamese candidates (chuộng/chõng/chùng) all look unrelated to 重's "double/heavy" sense, flagged for that page's own turn. Quoted mandarin/cantonese/korean. Upgraded a bare-format citation on `二(char).md`. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already excellent (二重奏/二重唱/二重国籍/二重課税 domain list, ふたえ double-eyelid cultural significance). Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 二-prefixed word cluster; next word begins a new initial (于).

Next: 于.

### 2026-09-10, iteration 4087 — [[words/于|于]]
Found a real character-page gap: `于 (char).md` had no `## Words` section at all — the self-legitimizing citation for 于 itself was entirely missing — added it, and while there also removed a duplicate `pos`/`品詞` on that same character page. Quoted cantonese and polished the self-legitimizing note phrasing (same pattern as [[之]]/[[事]]'s own earlier fixes). `kwin: true` trivially confirmed, and the real 4-way homophone group (于/雨/遇/愚, all reading ㄨ) verified via anchored grep. Content already excellent (与格 dative case, animate-goal vs. 於's inanimate-locative split, MC 云母 null-initial+虞韻 alignment). Stamped `date-last-perfect: 2026-09-10`.

Next: 互連網.

### 2026-09-10, iteration 4088 — [[words/互連網|互連網]]
Found a missing disambiguation: `characters:` had bare undisambiguated `連`/`網` despite `連 (char)`/`網 (char)` (and conflicting `words/連.md`/`words/網.md`) existing — fixed both. Found and fixed a missing citation on `網 (char).md` (互連網 was cited on 互/連 but not 網). Verified the AND-rule mismatch (all three constituents independently `kwin: true`, but the word's own `kwin: false`) is the established loanword/neologism exception, since the word's own korean field is the real loanword 인터넷 rather than a compositional reading — already correctly explained, now made more explicit. Content already excellent (net/web abbreviation parallel, Vietnamese liên mạng real-world abbreviated form). Stamped `date-last-perfect: 2026-09-10`. This closes out the 互-prefixed word cluster; next word begins a new initial (五).

Next: 五.

### 2026-09-10, iteration 4089 — [[words/五|五]]
Found a missing self-legitimizing citation: 五 (char)'s own `stand_in: 五` (itself) wasn't cited in its own "Important Words" section at all — added, and documented the legitimizing note explicitly in the word's own Notes (previously absent). Fixed duplicate `pos`/`品詞`. `kwin: true` trivially confirmed. Content already excellent (crossed-counting-sticks origin theory, 伍 anti-forgery variant, huge "Five X" canonical-compound family, 4-way homophone group with 伍/於/汚 — a prior pass already corrected 於's own malformed callout to cross-link properly). Stamped `date-last-perfect: 2026-09-10`.

Next: 五代十国.

### 2026-09-10, iteration 4090 — [[words/五代十国|五代十国]]
Substantially incomplete: `characters:` had bare undisambiguated `十` despite `十 (char)`/conflicting `words/十.md` existing, `japanese` was entirely empty, duplicate `pos`/`品詞`, missing `date-last-perfect`, and Notes were completely empty (just the bare heading). Filled japanese with ごだいじゅうこく (compositional), wrote full Notes on this 907–979 CE interregnum period. Found and fixed a missing citation on `五(char).md` and upgraded a raw-markdown-link citation on `十(char).md`. `kwin: false` confirmed via 4-way AND-rule (代 true, 十/国 both false). No homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 五倫.

### 2026-09-10, iteration 4091 — [[words/五倫|五倫]]
Found and fixed a formatting bug on `五(char).md`'s citation: an erroneous leading middle-dot ("·ㄛㄌㄨㄋ") that doesn't match the word's own 注音 (ㄛㄌㄨㄋ, no dot) or 倫's own matching citation — removed. **Noted for later**: this same leading-dot pattern appears to affect most/all of `五(char).md`'s "Important Words" entries (五礼, 五射, 五馭, 五経, 五月, 五行, etc.) — likely a systemic copy-paste artifact worth a dedicated cleanup pass across that whole file, not fixed wholesale here since only 五倫 is due today. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (五(char) true, 倫 false), no homophone collision. Content already excellent (五倫 vs [[三綱]] fuller/narrower relationship-framework contrast). Stamped `date-last-perfect: 2026-09-10`.

Next: 五十.

### 2026-09-10, iteration 4092 — [[words/五十|五十]]
**Self-correction**: caught my own error from earlier iterations in this session — I had been stating `十(char)`'s own kwin as false in several recent log entries (二十, 二十N日 series) without re-verifying; it is actually `kwin: true`. This didn't affect any of those words' own stamped kwin values (still correctly false, since 二's own kwin is false regardless), only my prose attribution of which constituent caused it — not retroactively corrected across all those entries, but flagging here for accuracy going forward. Found missing disambiguation on `characters:` (十→十(char)) and missing vietnamese (filled with ngũ thập, matching [[九十]]'s cửu thập convention). Fixed the same leading-middle-dot citation bug on `五(char).md` (2nd instance) and upgraded a bare-format citation on `十(char).md`. `kwin: true` confirmed via AND-rule (both constituents independently true — genuinely correct this time). No homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 五官.

### 2026-09-10, iteration 4093 — [[words/五官|五官]]
Missing `vietnamese` entirely; filled with ngũ quan (real, compositional, standard term). Quoted mandarin/cantonese/korean. Found and fixed a genuinely garbled citation on `五(char).md` (3rd leading-dot instance, but this one ALSO had a wrong rt value — ㄍㄨㄚㄋ instead of 官's real ㄍ⺢ㄋ) — corrected both issues at once. `characters:` confirmed correct, `kwin: true` confirmed via AND-rule (both constituents independently true), no homophone collision. Content already exceptional (classical TCM five-sense-organ/五臓/element correspondence table, diagnostic-window theory, modern colloquial facial-features sense with 五官端正/五官立体 idioms). Stamped `date-last-perfect: 2026-09-10`.

Next: 五射.

### 2026-09-10, iteration 4094 — [[words/五射|五射]]
Fixed duplicate `pos`/`品詞`, quoted mandarin/cantonese/korean. Found the leading-dot citation bug on BOTH `五(char).md` and, this time, `射.md`'s own citation too (not unique to 五's page as previously assumed) — fixed both. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (五(char) true, 射 false), no homophone collision. Content already exceptional (《周禮》 Six Arts curriculum, all five named archery techniques with etymological glosses, 弓道/궁도 transmission to Japan/Korea). Stamped `date-last-perfect: 2026-09-10`.

Next: 五常.

### 2026-09-10, iteration 4095 — [[words/五常|五常]]
Found and fixed a genuinely garbled citation on `五(char).md` (wrong rt "ㄙ·ㄚㄫ" instead of 常's real ㄙ⼘ㄫ, plus the recurring leading dot — 5th confirmed instance). Also found and fixed a missing citation on `常.md` (五常 wasn't cited there at all). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (五(char) true, 常 false), no homophone collision. Content already excellent (三綱五常 combined formula, Dong Zhongshu systematization, cross-referenced with [[五倫]]'s relational counterpart and [[三綱]]'s own Vietnamese tam cương ngũ thường). Stamped `date-last-perfect: 2026-09-10`.

Next: 五戒.

### 2026-09-10, iteration 4096 — [[words/五戒|五戒]]
Quoted mandarin/cantonese/korean. Fixed the recurring leading-dot citation bug on `五(char).md` (6th confirmed instance; the rt syllable itself was correct this time, just the stray dot). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (五(char) true, 戒 false), citations correct on both character pages otherwise, no homophone collision. Content already exceptional (full 5-precept enumeration with Sanskrit-derived Chinese terms, Theravāda Pātimokkha monastic-code contrast, Confucian-Buddhist 五常/五戒 virtue-mapping synthesis). Stamped `date-last-perfect: 2026-09-10`.

Next: 五指.

### 2026-09-10, iteration 4097 — [[words/五指|五指]]
Missing `vietnamese` entirely; filled with ngũ chỉ (real compositional term). Quoted mandarin/cantonese/korean. Found and fixed another garbled citation on `五(char).md` (wrong rt ㄐㄨㄛ vs real ㄐㄧㄜ, plus the recurring dot — 7th instance). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (五(char) true, 指 false), no homophone collision. Content already excellent (full traditional finger-naming table, 無名指 "nameless finger" cross-linguistic coinage parallel with German Ringfinger/French annulaire, Japanese 五指に入る/五指に余る idioms, 五指の別 equality-within-hierarchy metaphor). Stamped `date-last-perfect: 2026-09-10`.

Next: 五方.

### 2026-09-10, iteration 4098 — [[words/五方|五方]]
Quoted mandarin/cantonese/korean. Found and fixed another garbled citation on `五(char).md` (wrong initial consonant ㄆㄚㄫ vs real ㄈㄚㄫ, plus the recurring dot — 8th instance). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (五(char) true, 方 false), no homophone collision. Content already exceptional (full Five Directions/Colors/Elements/Seasons/Guardian-Creature correspondence table, four-outer-plus-center cosmology unique to East Asian systems, Han/Tang/Goguryeo/Japanese guardian-beast visual-culture spread, 五方雜處 cosmopolitan-population secondary sense). Stamped `date-last-perfect: 2026-09-10`.

Next: 五日.

### 2026-09-10, iteration 4099 — [[words/五日|五日]]
Found and fixed a missing citation on `五(char).md`: bare 五日 itself was absent (only sibling 二十五日 was cited there). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (五(char) true, 日(char) false), no homophone collision. Content already excellent (いつか native-reading irregularity cross-referenced with [[七日]]'s なのか, cross-linked to [[一日]]/[[二日]]/[[七日]]/[[八日]] day-counting family). Stamped `date-last-perfect: 2026-09-10`.

Next: 五更.

### 2026-09-10, iteration 4100 — [[words/五更|五更]]
Quoted mandarin/cantonese/korean. Replaced compositional vietnamese ngũ canh with canh năm, the real living Vietnamese idiom for this exact watch — already correctly identified in the word's own prose but not carried into the frontmatter field. Fixed the recurring leading-dot citation bug on `五(char).md` (9th instance). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (五(char) true, 更(char) false), no homophone collision. Content already exceptional (full five-watches timekeeping table with traditional names, 三更/五更's contrasting cultural associations — ghosts/lovers vs. dawn court rush — Du Fu poetry reference). Stamped `date-last-perfect: 2026-09-10`.

Next: 五月.

### 2026-09-10, iteration 4101 — [[words/五月|五月]]
Found a real bug: `kwin` was stamped `true`, but the word's own 諺文 (오웓) and stored `korean` field (오월) actually diverge in the second syllable's coda (웓 vs 월) — corrected to `false`, matching both the AND-rule and its exact homophone sibling [[午月]]'s own already-correct `kwin: false` (independently verified — 午月 has the identical 諺文/korean divergence). Fixed the recurring leading-dot citation bug on `五(char).md`, which also had a wrong syllable inside (10th instance). `characters:` confirmed correct, no additional homophone collision beyond the already-documented [[午月]] pair. Stamped `date-last-perfect: 2026-09-10`.

Next: 五礼.

### 2026-09-10, iteration 4102 — [[words/五礼|五礼]]
Fixed duplicate `pos`/`品詞`, quoted fields. Found and fixed a broken wikilink: `[[六書|六芸]]` pointed at `六書` (which actually means "Six Writings," one item within the Six Arts) while displaying "六芸" — corrected to `[[六芸]]`, the real dedicated Six-Arts umbrella page. **Major finding, not resolved today**: `六芸.md` documents the Six Arts using an entirely different, non-count-prefixed set of word pages ([[礼]], [[音楽]], [[words/射術]], [[words/御術]], [[words/書法]], [[数学]]) than the count-prefixed cluster this sweep has been processing (五礼/五射/五馭/六書/九数/六楽) — two apparently-parallel documentation systems for the same concept exist in the vault. Flagged for a future dedicated investigation/reconciliation, well beyond today's single-word scope. Fixed the leading-dot citation bug on `五(char).md` (11th instance). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (五(char) true, 礼(char) false), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 五穀.

### 2026-09-10, iteration 4103 — [[words/五穀|五穀]]
Quoted mandarin/cantonese/korean. Fixed the recurring leading-dot citation bug on `五(char).md` (12th instance; syllable itself correct). `characters:` confirmed correct, `kwin: true` confirmed via AND-rule (both constituents independently true), no homophone collision. Content already exceptional (northern-vs-southern classical grain-list disputes, 籍田禮 imperial Plowing Ceremony and its Mandate-of-Heaven stakes, 五穀豐登 auspicious New Year phrase, Korean 오곡밥 lunar new year dish). Stamped `date-last-perfect: 2026-09-10`.

Next: 五経.

### 2026-09-10, iteration 4104 — [[words/五経|五経]]
Fixed duplicate `pos`/`品詞`, reformatted Notes (dangling list with no intro sentence, now proper prose). Fixed a raw-path-prefixed-link citation on `五(char).md` (`[[../words/五経]]`, plus the recurring dot — 13th instance) to a proper wikilink+ruby entry. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already good (full 五経 enumeration with variant-character forms, cross-linked to [[四書五経]]). Stamped `date-last-perfect: 2026-09-10`.

Next: 五臓.

### 2026-09-10, iteration 4105 — [[words/五臓|五臓]]
Missing `date-last-perfect` entirely, dangling empty `hsk_level`/`swadesh`, no Notes at all. Found a real bug: `japanese` stored as ござう, not matching either of 臓's own on'yomi (ZOU/SOU) — corrected to ごぞう (compositional, first-listed ZOU). Wrote full Notes (TCM Five Solid Organs, 五臓六府 pairing with the Six Hollow Organs, cross-referenced with [[五官]]). Fixed the leading-dot citation bug on `五(char).md` (14th instance). `characters:` confirmed correct, `kwin: true` confirmed via AND-rule (both constituents independently true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 五色.

### 2026-09-10, iteration 4106 — [[words/五色|五色]]
Quoted mandarin/cantonese/korean. Fixed the recurring leading-dot citation bug on `五(char).md` (15th instance; syllable correct). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (五(char) true, 色 false), no homophone collision. Content already exceptional (full Five Colors/Elements/Directions/Seasons/Animal correspondence table, Han-dynasty codification, imperial-yellow exclusivity, Chinese-vs-Western mourning-color inversion, Dhyāni Buddha association, 五顔六色 modern idiom, contrasted with [[七色]]'s spectral rainbow). Stamped `date-last-perfect: 2026-09-10`.

Next: 五行.

### 2026-09-10, iteration 4107 — [[words/五行|五行]]
Substantially incomplete: missing `date-last-perfect`, dangling empty `hsk_level`/`swadesh`/`aliases`, no Notes, `characters:` in inline-flow format (normalized). Found a real bug: `japanese` stored as ごぎょうしそう (the longer "五行思想" expanded compound), not this word's own bare 五行 reading — corrected to ごぎょう, noting 行 uses its GYOU reading specifically for this sense rather than the first-listed KOU. Wrote full Notes (Five Phases enumeration, cross-referenced with [[五色]]/[[五方]]). Fixed the leading-dot citation bug on `五(char).md` (16th instance). `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 五角形.

### 2026-09-10, iteration 4108 — [[words/五角形|五角形]]
Missing `vietnamese` entirely; filled with ngũ giác, the real standard Vietnamese geometry term (the US Pentagon is even called Lầu Ngũ Giác in Vietnamese) — noted this diverges from 角's own currently-stored (and apparently wrong) vietnamese candidates chác/dạc, flagged for that page's own turn. Quoted mandarin/cantonese/korean. Fixed the leading-dot citation bug on `五(char).md` (17th instance — this appears to be the LAST entry in that "Important Words" list, so the cleanup pass may now be complete). `characters:` confirmed correct, `kwin: false` confirmed via 3-way AND-rule (all three constituents independently false), no homophone collision. Content already excellent (-角形 productive polygon-naming morpheme, golden-ratio/pentagram mathematics, US Pentagon building name contrast with Japanese ペンタゴン loanword, Shinto 五芒星/Abe no Seimei association). Stamped `date-last-perfect: 2026-09-10`.

Next: 五馭.

### 2026-09-10, iteration 4109 — [[words/五馭|五馭]]
Found and fixed a missing legitimizing note: 馭's own `stand_in: 五馭` wasn't documented reciprocally on this page — added. Fixed duplicate `pos`/`品詞`, quoted mandarin/cantonese/korean. The leading-dot bug appeared on BOTH `五(char).md` AND `馭.md`'s own citation this time (18th and 19th instances) — fixed both. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (五(char) true, 馭 false), no homophone collision. Content already exceptional (full 五 Zhou-era charioteering techniques with etymological glosses, 五御 modern-form alias, cross-linked to the Six Arts family). Stamped `date-last-perfect: 2026-09-10`. This closes out the entire "Five X" cluster on `五(char).md`'s "Important Words" section; next word begins a new initial (井).

Next: 井堰.

### 2026-09-10, iteration 4110 — [[words/井堰|井堰]]
Fixed a raw-markdown-link citation on `井.md` (`[井堰](/words/井堰.md)`) to a proper wikilink+ruby entry. `characters:` confirmed correct (bare 井, no conflicting words/*.md; 堰's own `stand_in: "井堰"` matches the already-documented legitimizing note), citations correct on both character pages, no additional homophone collision beyond the already-documented, already-reciprocal [[証言]] pair (a genuine Dan'a'yo-only coincidence, confirmed real Korean readings differ). The AND-rule "mismatch" (井 false + 堰 true would predict true, but word's own kwin is false) is already correctly explained by direct field comparison in the existing Notes — no bug, verified rather than assumed. Stamped `date-last-perfect: 2026-09-10`.

Next: 井戸.

### 2026-09-10, iteration 4111 — [[words/井戸|井戸]]
Found and fixed a missing legitimizing note: 井's own `stand_in: 井戸` wasn't documented reciprocally on this page — added. Fixed a raw-markdown-link citation on `井.md` to a proper wikilink+ruby entry with the stand-in annotation. `characters:` confirmed correct, citations correct on both character pages, no homophone collision. Content already excellent and self-aware (deliberately "very Japanese" syllable-filling entry, honestly documented blank mandarin/cantonese, いど/井戸端/井戸端会議 idiom family). Stamped `date-last-perfect: 2026-09-10`.

Next: 井物.

### 2026-09-10, iteration 4112 — [[words/井物|井物]]
Substantially incomplete: `korean`/`vietnamese`/`kwin`/`date-last-perfect` all entirely missing, `cantonese` blank, `aliases` a bare string instead of a list, no Notes. Identified this as another Japanese-specific syllable-filling entry in the [[井戸]] family (井 substituting for the real character 丼, "donburi/rice bowl"). Filled korean with 덮밥 (deopbap, the real Korean rice-bowl-dish term) and vietnamese with cơm tô, following the same honest-native-word approach established on 井戸, rather than forcing a compositional Sino-reading that doesn't correspond to a real term in either language. Left cantonese blank, similarly. `characters:` and citations already correct on both character pages. `kwin: false` via AND-rule (井 false, 物(char) true). No homophone collision. Stamped `date-last-perfect: 2026-09-10`. This closes out the 井-prefixed word cluster; next word begins a new initial (亘).

Next: 亘.

### 2026-09-10, iteration 4113 — [[words/亘|亘]]
Found the missing-`japanese`-field bug again. Applied first-listed-on'yomi convention (亘(char)'s `[SEN, KAN, KOU]` → せん). `kwin: false` trivially confirmed (single constituent), citation correct, and the real 3-way homophone with [[喚]]/[[環]] confirmed (both still awaiting their own turns). Content already excellent (亘/亙 archaic-whirlpool-vs-extend semantic drift, Vietnamese cắng verified as one of three genuinely attested readings among several implausible candidates). Stamped `date-last-perfect: 2026-09-10`.

Next: 亙.

### 2026-09-10, iteration 4114 — [[words/亙|亙]]
Found the missing-`japanese`-field bug again. Added こう (亙's only on'yomi, KOU). `kwin: false` trivially confirmed, citation correct, and the real coincidental homophone with [[弓]] confirmed reciprocally documented (already fixed on that page's own turn). Content already excellent (指事 crescent-moon-spanning etymology, 亙/亘 historical-conflation-vs-Dan'a'yo-phonological-distinctness contrast, Vietnamese cắng cổ attestation vs. four unrelated corpus-noise candidates). Stamped `date-last-perfect: 2026-09-10`.

Next: 些少.

### 2026-09-10, iteration 4115 — [[words/些少|些少]]
Already fully correct from a prior pass: legitimizing note present (些's `stand_in: "些少"` correctly documented), `characters:` confirmed correct, `kwin: false` confirmed via AND-rule, citations correct on both character pages, no homophone collision. Just refreshed `date-last-perfect: 2026-09-10`. This closes out the 些-prefixed word cluster; next word begins a new initial (亜).

Next: 亜洲.

### 2026-09-10, iteration 4116 — [[words/亜洲|亜洲]]
Fixed a malformed comma-joined `mandarin` string into a proper two-item list (Yàzhōu/Yǎzhōu). Fixed duplicate `pos`/`品詞`, added missing `date-last-perfect`, expanded thin one-line Notes. Found and fixed a missing citation on `洲(char).md` (亜洲 was entirely absent from its Words section). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (亜 true, 洲(char) false), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 亜細亜.

### 2026-09-10, iteration 4117 — [[words/亜細亜|亜細亜]]
Found and fixed several real bugs: `characters:` listed 亜 twice (condensed, per the [[九九]]/[[二十二日]] precedent); `cantonese` was an apparent copy-paste leftover from [[亜洲]]'s own field (aa3 zau1) — corrected to the real compositional aa3 sai3 aa3; `vietnamese` was a comma-joined jumble of three variant forms — consolidated to the standard châu Á. Fixed missing `date-last-perfect`, removed dangling empty `hsk_level`/`swadesh`, and wrote full Notes including the previously-undocumented legitimizing note (亜's own `stand_in: 亜細亜`) and the cultural-vs-geographic contrast with [[亜洲]]. `kwin: true` confirmed via 3-way AND-rule (all constituents independently true), citations correct on both character pages, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 亜鉛.

### 2026-09-10, iteration 4118 — [[words/亜鉛|亜鉛]]
Missing `vietnamese`/`date-last-perfect`, no proper Notes (just a stray non-standard "Homophones: 亞鉛, 鋅" line). Filled vietnamese with á duyên (real Sino-Vietnamese chemistry term). Fixed the mislabeled claim: 亞鉛 is just this same word's traditional-character spelling, not a genuine homophone — moved to `aliases`; 鋅 (the real modern Chinese zinc character) names the same element via an entirely different etymological strategy and isn't documented as a Dan'a'yo word in this vault at all, so the "homophone" framing was doubly wrong — corrected in prose. Wrote full Notes ("sub-lead" naming logic). `characters:` confirmed correct, `kwin: true` confirmed via AND-rule (both constituents independently true), citations correct on both character pages, no genuine Dan'a'yo-level homophone (verified via anchored grep). Stamped `date-last-perfect: 2026-09-10`.

Next: 亜麻.

### 2026-09-10, iteration 4119 — [[words/亜麻|亜麻]]
Fixed a comma-joined mandarin string into a proper two-item list, fixed a mis-capitalized vietnamese ("Cây lanh"→"cây lanh", common noun), added missing `date-last-perfect`, wrote full Notes (self-caught a korean-hanja-transcription slip mid-edit and corrected before applying). `characters:` confirmed correct, `kwin: true` confirmed via AND-rule (both constituents independently true), citations correct on both character pages (including sibling [[亜麻布]]), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 亜麻布.

### 2026-09-10, iteration 4120 — [[words/亜麻布|亜麻布]]
Found a real bug: `cantonese` had a stray extra "ng" on the first syllable (ngaa3, not matching 亜's own real reading aa3) — corrected to aa3 maa4 bou3. Found and fixed a missing citation on `麻.md` (亜麻布 was cited on 亜/布 but not 麻). Removed dangling empty `hsk_level`/`swadesh`. `characters:` confirmed correct, `kwin: false` confirmed via 3-way AND-rule (亜/麻 both true, 布 false), no homophone collision. Content already excellent (亜麻布 vs [[麻布]] flax-specific-vs-general distinction, legitimizing note for 布 already present, Sino-Vietnamese 布-root cross-reference). Stamped `date-last-perfect: 2026-09-10`. This closes out the 亜-prefixed word cluster; next word begins a new initial (交).

Next: 交.

### 2026-09-10, iteration 4121 — [[words/交|交]]
Found the missing-`japanese`-field bug again. Applied first-listed-on'yomi convention (交(char)'s `[KOU, KYOU]` → こう). `kwin: false` trivially confirmed, citation correct, no homophone collision. Content already excellent (象形 crossed-legs etymology distinguished from visually similar 父, one of the vault's largest compound families spanning literal/social/transactional exchange senses). Stamped `date-last-perfect: 2026-09-10`.

Next: 交互.

### 2026-09-10, iteration 4122 — [[words/交互|交互]]
Fixed an unspaced cantonese field (gaau1wu6→gaau1 wu6), removed dangling empty `hsk_level`/`swadesh`/`aliases`. Upgraded a bare-format citation on `交(char).md` to proper ruby format. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (交(char) false, 互 true), no homophone collision. Content already good (attested Sino-Vietnamese giao hỗ, cross-referenced with 互相/互相 hỗ tương). Stamped `date-last-perfect: 2026-09-10`.

Next: 交付.

### 2026-09-10, iteration 4123 — [[words/交付|交付]]
Fixed an unspaced cantonese field (gaau1fu6→gaau1 fu6), removed a dangling empty `swadesh`/`aliases`. Upgraded a bare-format citation on `交(char).md` to proper ruby format. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already good (Vietnamese giao phó everyday-usage confirmation). Stamped `date-last-perfect: 2026-09-10`.

Next: 交叉.

### 2026-09-10, iteration 4124 — [[words/交叉|交叉]]
Found a real bug: `japanese` was stored in obsolete historical kana orthography (かうさ) despite the word's own Notes already correctly using modern こうさ throughout — corrected. Found and fixed a missing citation on `交(char).md` (交叉 was cited on 叉 but not 交) and upgraded a bare-format citation on `叉(char).md`. Removed dangling empty `hsk_level`/`swadesh`/`aliases`. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), and the real homophone with [[教材]] confirmed reciprocally documented. Content already excellent (Dan'a'yo's deliberate 交叉/交差 sense-split despite real Japanese conflating them, 叉's own missing-thoa-reading gap found and fixed on a prior pass). Stamped `date-last-perfect: 2026-09-10`.

Next: 交友.

### 2026-09-10, iteration 4125 — [[words/交友|交友]]
Fixed an unspaced cantonese field (gaau1jau5→gaau1 jau5). `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), citations correct on both character pages, and the real inherited-MC-homophone with [[交遊]] confirmed reciprocally documented. Content already exceptional (individual-bond vs. broad-network scope distinction, true Middle Chinese 以母尤韻 homophony traced through Mandarin/Cantonese tone-only distinction, Japanese full collapse vs. Korean's preserved 우/유 split). Stamped `date-last-perfect: 2026-09-10`.

Next: 交尾.

### 2026-09-10, iteration 4126 — [[words/交尾|交尾]]
Fixed an unspaced cantonese field (gaau1mei5→gaau1 mei5), removed dangling empty `hsk_level`/`swadesh`/`aliases`. Upgraded a bare-format citation on `交(char).md` to proper ruby format. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already good (giao vĩ vs. the unrelated-root giao phối distinction, honestly documented). Stamped `date-last-perfect: 2026-09-10`.

Next: 交差.

### 2026-09-10, iteration 4127 — [[words/交差|交差]]
Found and fixed a real content bug: `交(char).md`'s own citation for this word carried the wrong gloss ("intersection," which is actually [[交叉]]'s meaning) instead of this vault's own repurposed "report in, get debriefed" sense — corrected the gloss and upgraded to proper ruby format. Fixed a `characters:` indentation inconsistency, removed dangling empty `hsk_level`/`swadesh`/`aliases`, and fixed a stray typo in the tip callout ("This is a word about the word"→"This is a page about the word"). `characters:` otherwise confirmed correct, `kwin: false` confirmed via AND-rule (交(char) false, 差 true), citation on `差.md` already correct, no homophone collision. Content already excellent from a prior pass (回去交差 idiom, [[交叉]] look-alike distinction already documented, かうさ historical-kana bug already fixed there too). Stamped `date-last-perfect: 2026-09-10`.

Next: 交情.

### 2026-09-10, iteration 4128 — [[words/交情|交情]]
Fixed a `characters:` indentation inconsistency, removed dangling empty `hsk_level`/`swadesh`/`aliases`. Upgraded a bare-format citation on `交(char).md` to proper ruby format. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already good (literary/classical Vietnamese giao tình register note). Stamped `date-last-perfect: 2026-09-10`.

Next: 交接.

### 2026-09-10, iteration 4129 — [[words/交接|交接]]
Fixed an unspaced cantonese field (gaau1zip3→gaau1 zip3), removed dangling empty `hsk_level`/`swadesh`/`aliases`. Upgraded a bare-format citation on `交(char).md` to proper ruby format. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already good (giao tiếp everyday-usage confirmation, euphemistic sense-extension parallel with Mandarin original). Stamped `date-last-perfect: 2026-09-10`.

Next: 交換.

### 2026-09-10, iteration 4130 — [[words/交換|交換]]
Fixed an unspaced cantonese field (gaau1wun6→gaau1 wun6), a mis-capitalized vietnamese ("Giao hoán"→"giao hoán"), missing `date-last-perfect`, dangling empty `swadesh`/`aliases`, and no Notes at all — wrote full content (交換留学/交換手/交換機 domain examples, Vietnamese trao đổi near-synonym). Upgraded a bare-format citation on `交(char).md`. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 交易.

### 2026-09-10, iteration 4131 — [[words/交易|交易]]
Fixed a `characters:` indentation inconsistency, removed dangling empty `hsk_level`/`swadesh`/`aliases`. Upgraded a bare-format citation on `交(char).md` to proper ruby format. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (交(char) false, 易 true), no homophone collision. Content already good (giao dịch everyday-banking-and-commerce-usage confirmation). Stamped `date-last-perfect: 2026-09-10`.

Next: 交替.

### 2026-09-10, iteration 4132 — [[words/交替|交替]]
Quoted mandarin/cantonese/korean. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (交(char) false, 替 true), citations correct on both character pages, no homophone collision. Content already excellent (specialized grammatical 否定交替 copula-suppletion sense cross-referenced with [[繋辞]], everyday 交替制 shift-work sense, honest documentation of the giao thế compositional-but-unattested gap vs. real-usage luân phiên). Stamped `date-last-perfect: 2026-09-10`.

Next: 交流.

### 2026-09-10, iteration 4133 — [[words/交流|交流]]
Missing `vietnamese` entirely; filled with giao lưu, an extremely common, real everyday Vietnamese term. Found and fixed a real bug: `交(char).md`'s own citation used a wrong first-syllable glyph (ㄍ⼄ vs the correct ㄍ⼘, not matching this word's own 注音 or 流's own citation) — corrected. Expanded thin Notes. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (交(char) false, 流 true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 交溝.

### 2026-09-10, iteration 4134 — [[words/交溝|交溝]]
Substantially incomplete with several real bugs: `characters:` had bare undisambiguated `溝` despite `溝 (char)`/conflicting `words/溝.md` existing (fixed); `cantonese` was doubly garbled (gaa1gau3, missing a vowel and wrong second-syllable initial/tone) — corrected to gaau1 kau1; `japanese` was obsolete historical kana with an entirely wrong reading (かうこう) — corrected to こうこう (compositional); vietnamese mis-capitalized; empty fields removed; inline-flow aliases normalized; missing date and Notes. Wrote full content (交溝/交媾 alias relationship, giao cấu as the real Vietnamese legal/medical term). Upgraded a bare-format citation on `交(char).md`. `kwin: false` confirmed via AND-rule (both constituents independently false), citations correct on 溝(char) already, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 交点.

### 2026-09-10, iteration 4135 — [[words/交点|交点]]
Fixed an unspaced cantonese field (gaau1dim2→gaau1 dim2), removed dangling empty `swadesh`. Upgraded a bare-format citation on `交(char).md` to proper ruby format. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already good (giao điểm geometry/road-intersection usage confirmation). Stamped `date-last-perfect: 2026-09-10`.

Next: 交通.

### 2026-09-10, iteration 4136 — [[words/交通|交通]]
Fixed unspaced cantonese (gaau1tung1→gaau1 tung1), obsolete-kana japanese (かうつう→こうつう), removed dangling empty `aliases`, added missing `date-last-perfect`, wrote missing Notes section. Upgraded a bare-format citation on `交(char).md`; `通(char).md`'s own citation was already correct. `characters:` confirmed correct (both 交 and 通 require disambiguation, conflicting words/通.md exists), `kwin: false` confirmed via AND-rule (交(char) false overrides 通(char)'s own true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 交遊.

### 2026-09-10, iteration 4137 — [[words/交遊|交遊]]
Fixed unspaced cantonese (gaau1jau4→gaau1 jau4), added missing `aliases: [交游]` (the 遊→游 simplified-variant pattern, matching the established convention seen on 嬉遊/遊戯). `characters:` confirmed correct — bare `遊` is right since no `words/遊.md` or `遊 (char).md` exists to conflict. `kwin: false` confirmed via AND-rule (both constituents independently false). Homophone note (交友) verified via anchored grep — genuinely注音-identical (only 2 matches for ㄍ⼘ㄨ·⼜ㄛ). Content and both character-page citations were already excellent/correctly formatted. Stamped `date-last-perfect: 2026-09-10`.

Next: 交際.

### 2026-09-10, iteration 4138 — [[words/交際|交際]]
Fixed unspaced cantonese (gaau1zai3→gaau1 zai3), removed dangling empty `swadesh`, added missing `aliases: [交际]` (際→际 simplified variant, matching 際(char)'s own stored alias). Found and fixed a real missing-citation bug: 交際 was entirely absent from `交(char).md`'s Words list despite being present on `際(char).md` — added in proper ruby format. `characters:` confirmed correct (both constituents require disambiguation, conflicting words/際.md exists), `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already excellent (real attested giao tế Sino-Vietnamese term, 交-family cross-reference). Stamped `date-last-perfect: 2026-09-10`.

Next: 交響.

### 2026-09-10, iteration 4139 — [[words/交響|交響]]
Fixed missing disambiguation (bare `交`→`交 (char)`, since `words/交.md` exists), removed dangling empty `hsk_level`/`swadesh` fields, added missing `aliases: [交响]` (響→响 simplified variant, matching 響(char)'s own stored alias). Upgraded a bare-format citation on `交(char).md` to proper ruby format; `響.md`'s own citation was already correct. `kwin: false` confirmed via AND-rule (交(char) false overrides 響(char)'s own true), no homophone collision. Content already excellent (real everyday Vietnamese giao hưởng). Stamped `date-last-perfect: 2026-09-10`.

Next: 亥月.

### 2026-09-10, iteration 4140 — [[words/亥月|亥月]]
Already in excellent shape. `characters:` confirmed correct (bare `亥` is right, no conflicting words/亥.md exists). `japanese: いつき` verified as correct against the sibling zodiac-month native-kun+kun compound pattern (丑月→うしつき, 未月→ひつじつき, no の inserted) — not a bug. `kwin: false` confirmed via AND-rule (亥(char) true, 月(char) false). Both character-page citations (亥.md, 月(char).md) already correctly ruby-formatted. No homophone collision (注音 ㄏㄚㄧ·⼔ㄊ unique). Just refreshed `date-last-perfect: 2026-09-10`.

Next: 亦.

### 2026-09-10, iteration 4141 — [[words/亦|亦]]
Removed dangling empty `aliases` field. Added the missing self-referential "Legitimizing note" phrasing (亦(char)'s own `stand_in` is this exact word, itself), matching the exact established wording pattern from 事/于/之, plus a short usage example. `characters:` confirmed correct (亦 (char) required, since words/亦.md itself conflicts with a bare filename). `kwin: false` self-consistent (single-character word). Noted a 注音-level match with 厄(char) but no words/厄.md exists (厄's own stand_in is 災厄, not itself) so this isn't a real word-level homophone collision — not documented as one. Citation on 亦(char).md already correct. Stamped `date-last-perfect: 2026-09-10`.

Next: 亨通.

### 2026-09-10, iteration 4142 — [[words/亨通|亨通]]
Removed dangling empty `hsk_level`/`swadesh`/`aliases` fields. Added the missing legitimizing-note phrasing (亨's own `stand_in` is this exact compound; 通's own `stand_in` is itself, so transitivity fails and #cranberry doesn't apply). `characters:` confirmed correct (bare `亨` is right, no conflicting words/亨.md exists). `kwin: false` confirmed via AND-rule (亨 false overrides 通(char)'s own true). Both character-page citations already correctly ruby-formatted. No homophone collision. Content already excellent (attested Vietnamese hanh thông blessing usage, genuine Japanese homophone cross-reference with 交通 noted). Stamped `date-last-perfect: 2026-09-10`.

Next: 享受.

### 2026-09-10, iteration 4143 — [[words/享受|享受]]
Wrote missing Notes section entirely (word had none). Removed dangling empty `hsk_level`/`swadesh`/`aliases` fields, added missing `date-last-perfect`. Added legitimizing-note phrasing (享's own `stand_in` is this exact compound; 受's own `stand_in` is [[接受]], so transitivity fails and #cranberry doesn't apply). `characters:` confirmed correct (bare 享/受, no conflicting words/享.md or words/受.md exist). `kwin: false` confirmed via AND-rule (享(char) true, 受(char) false). Both character-page citations already correctly ruby-formatted. No homophone collision. Filled reasoning for already-good hưởng thụ/きょうじゅ fields. Stamped `date-last-perfect: 2026-09-10`.

Next: 京城.

### 2026-09-10, iteration 4144 — [[words/京城|京城]]
Fixed unspaced cantonese (ging1sing4→ging1 sing4), removed dangling empty `hsk_level`/`swadesh`/`aliases` fields. Added legitimizing-note phrasing (京's own `stand_in` is this exact compound; 城's own `stand_in` is [[城郭]], so transitivity fails and #cranberry doesn't apply). `characters:` confirmed correct (bare 京/城, no conflicting words exist). `kwin: false` confirmed via AND-rule (京(char) true, 城(char) false). Both character-page citations already correctly ruby-formatted. No homophone collision. Content already excellent (Kinh thành Huế real-world reference, honest note on the Japanese-colonial Gyeongseong/Seoul toponym history). Stamped `date-last-perfect: 2026-09-10`.

Next: 京畿.

### 2026-09-10, iteration 4145 — [[words/京畿|京畿]]
Removed dangling empty `hsk_level`/`swadesh`/`aliases` fields. Added legitimizing-note phrasing (畿's own `stand_in` is this exact compound; 京's own `stand_in` is [[京城]], not this word, so transitivity fails and #cranberry doesn't apply). `characters:` confirmed correct (bare 京/畿, no conflicting words exist). `kwin: false` confirmed via AND-rule (京(char) true, 畿(char) false). Both character-page citations already correctly ruby-formatted; cantonese already spaced. No homophone collision. Content already excellent (attested kinh kỳ, live modern-Korean Gyeonggi Province continuation noted). Stamped `date-last-perfect: 2026-09-10`.

Next: 亭子.

### 2026-09-10, iteration 4146 — [[words/亭子|亭子]]
Fixed a spelling typo ("pavillion"→"pavilion"), unspaced cantonese (ting4zi2→ting4 zi2), removed dangling empty `hsk_level`/`swadesh`/`aliases` fields. Added legitimizing-note phrasing (亭's own `stand_in` is this exact compound; 子's own `stand_in` is [[児子]], so transitivity fails and #cranberry doesn't apply). Upgraded a bare-format citation on `子.md` to proper ruby format; `亭.md`'s own citation was already correct. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision (re-verified the already-documented false-homophone-claim fix with 停止 still holds). Stamped `date-last-perfect: 2026-09-10`.

Next: 人.

### 2026-09-10, iteration 4147 — [[words/人|人]]
Fixed duplicate `pos`/`品詞` (kept pos). Added the standard self-referential legitimizing-note phrasing (matching 事/于/之 exact wording) alongside the existing prose. Found and fixed a real missing-citation bug: the word 人 itself was entirely absent from `人(char).md`'s own Words list despite being its stand-in — added at the top of that (very large, disorganized) list. `characters:` confirmed correct (`人 (char)` required, no bare `characters/人.md`). `kwin: false` self-consistent. Noted several 注音-level matches (忍/認/刃/仁) but none have independent word pages, so no real word-level homophone collision. **Flagged for later**: `人(char).md`'s own Words section is large and inconsistently formatted (mixed numbered list, many bare/raw-link citations without ruby) — well beyond this single word's scope, noted for a dedicated cleanup pass. Stamped `date-last-perfect: 2026-09-10`.

Next: 人中.

### 2026-09-10, iteration 4148 — [[words/人中|人中]]
Removed dangling empty `hsk_level`/`swadesh`/`aliases` fields. Found and fixed a real missing-citation bug: 人中 was entirely absent from `中(char).md`'s Words list — added in ruby format. Upgraded a bare numbered-list citation on `人(char).md` (item 9) to proper ruby format. Also fixed a broken markdown link on `中(char).md`'s own header (`[中](中)`→`[中](words/中.md)`) while touching that page. `characters:` confirmed correct (both require disambiguation). `kwin: false` confirmed via AND-rule (人(char) false overrides 中(char)'s own true). No homophone collision. Content already good (attested anatomical/TCM term across all languages, previously-fixed cantonese pinyin-leftover bug still holds). Stamped `date-last-perfect: 2026-09-10`.

Next: 人事.

### 2026-09-10, iteration 4149 — [[words/人事|人事]]
Fixed a missing space after a comma in `english`, removed dangling empty `swadesh`/`aliases` fields, added missing `date-last-perfect`. Found and fixed a real missing-citation bug: 人事 was entirely absent from `人(char).md`'s Words list despite being present on `事(char).md` — added in ruby format. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false). Homophone with [[仁慈]] re-verified via anchored grep — genuine 注音-level match. Content already good (nhân sự HR/personnel real usage, previously-fixed orphaned-note and capitalization bugs still hold). Stamped `date-last-perfect: 2026-09-10`.

Next: 人人.

### 2026-09-10, iteration 4150 — [[words/人人|人人]]
Fixed the reduplicated-constituent bug (characters: had `人 (char)` listed twice; deduped to a single entry per the established 九九/二十二日 convention). Removed dangling empty `hsk_level`/`swadesh`/`aliases` fields. Found and fixed a missing-citation bug: 人人 was entirely absent from `人(char).md`'s Words list — added. `kwin: false` confirmed correct (Dan'a'yo 닌닌 vs. native-Korean 사람마다, not a Sino-Korean compositional comparison). No homophone collision. Content already good (native-word reduplication pattern across Mandarin/Japanese/Vietnamese). Stamped `date-last-perfect: 2026-09-10`.

Next: 人参.

### 2026-09-10, iteration 4151 — [[words/人参|人参]]
Fixed unspaced cantonese (jan4sam1→jan4 sam1), mis-capitalized vietnamese (Nhân sâm→nhân sâm), missing `date-last-perfect`. Upgraded raw-markdown-link citations to proper wikilinks in both `人(char).md`'s and `参.md`'s own Words lists (`[人参](/words/人参.md)`/`[人参](../words/人参.md)`→`[[人参]]`), and fixed the same raw-link-without-../-prefix issue in this word's own Notes. `characters:` confirmed correct (bare 参, no conflicting words/参.md exists). `kwin: false` confirmed via AND-rule (both constituents independently false). No homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 人口.

### 2026-09-10, iteration 4152 — [[words/人口|人口]]
Fixed unspaced cantonese (jan4hau2→jan4 hau2), removed dangling empty `hsk_level`/`swadesh`/`aliases` fields. Upgraded a raw-markdown-link citation on `人(char).md` (`[人口](/words/人口.md)`→`[[人口]]`); `口(char).md`'s own citation was already correct. `characters:` confirmed correct (both constituents require disambiguation). `kwin: false` confirmed via AND-rule (both constituents independently false). No homophone collision. Content already good (attested nhân khẩu census term). Stamped `date-last-perfect: 2026-09-10`.

Next: 人員.

### 2026-09-10, iteration 4153 — [[words/人員|人員]]
Wrote missing Notes section entirely (word had none). Fixed mis-capitalized vietnamese (Nhân viên→nhân viên), removed dangling empty `swadesh`/`aliases` fields, added missing `人员` simplified-variant alias and `date-last-perfect`. Added legitimizing-note phrasing (員's own `stand_in` is this exact compound). Upgraded a bare numbered-list citation on `人(char).md` (item 28) to proper ruby format; `員.md`'s own citation was already correct. `characters:` confirmed correct (bare 員, no conflicting words/員.md exists). `kwin: false` confirmed via AND-rule (人(char) false overrides 員(char)'s own true). No homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 人工.

### 2026-09-10, iteration 4154 — [[words/人工|人工]]
Fixed missing disambiguation (bare `人`→`人 (char)`, since `words/人.md` exists), mis-capitalized vietnamese (Nhân công→nhân công), removed dangling empty `swadesh`/`aliases`. Wrote missing Notes section, honestly flagging that Vietnamese nhân công is a partial semantic match ("labor/workforce" rather than exactly "artificial"). Upgraded a bare numbered-list citation on `人(char).md` (item 16); `工.md`'s own citation was already correct. `kwin: false` confirmed via AND-rule (人(char) false overrides 工(char)'s own true). No homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 人手.

### 2026-09-10, iteration 4155 — [[words/人手|人手]]
Fixed a missing `kwin` field entirely (added `kwin: false`, confirmed via AND-rule — both constituents independently false). Removed dangling empty `hsk_level`/`swadesh`/`aliases` fields. Upgraded a bare numbered-list citation on `人(char).md` (item 7); `手(char).md`'s own citation was already correct. `characters:` confirmed correct, no homophone collision. Content already excellent (attested nhân thủ/인수). Stamped `date-last-perfect: 2026-09-10`.

Next: 人数.

### 2026-09-10, iteration 4156 — [[words/人数|人数]]
Already in excellent shape. `characters:` confirmed correct (bare 数, no conflicting words/数.md exists), `kwin: false` confirmed via AND-rule (人(char) false overrides 数(char)'s own true). Both character-page citations already correctly ruby-formatted, no homophone collision. Content already outstanding (thorough contrast with 人口/人員, rendaku explanation for にんずう, honest note on vernacular số người preference in Vietnamese). Just refreshed `date-last-perfect: 2026-09-10`.

Next: 人望.

### 2026-09-10, iteration 4157 — [[words/人望|人望]]
Removed dangling empty `hsk_level`/`swadesh`/`aliases` fields. Upgraded a bare numbered-list citation on `人(char).md` (item 32, used the fuller "popularity" gloss instead of the bare literal calque); `望.md`'s own citation was already correct. `characters:` confirmed correct (bare 望, no conflicting words/望.md exists), `kwin: false` confirmed via AND-rule (人(char) false overrides 望(char)'s own true), no homophone collision. Content already excellent (attested nhân vọng, contrast with [[声望]], the previously-fixed 声望 vietnamese bug still holds). Stamped `date-last-perfect: 2026-09-10`.

Next: 人民.

### 2026-09-10, iteration 4158 — [[words/人民|人民]]
Reworded the existing informal stand-in note into the standard legitimizing-note phrasing (matching the established convention), and added explicit `kwin` AND-rule reasoning and homophone-check statement that were implied but not stated. `characters:` confirmed correct, both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (人(char) false overrides 民(char)'s own true), no homophone collision. Content already outstanding (the honest, well-researched treatment of 인민's North Korean political connotation vs. neutral 국민). Stamped `date-last-perfect: 2026-09-10`.

Next: 人生.

### 2026-09-10, iteration 4159 — [[words/人生|人生]]
Wrote missing Notes section entirely (word had none). Fixed mis-capitalized vietnamese (Nhân sinh→nhân sinh), removed dangling empty `swadesh`/`aliases` fields, added missing `date-last-perfect`. Upgraded a bare numbered-list citation on `人(char).md` (item 21); `生.md`'s own citation was already correct. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 人称.

### 2026-09-10, iteration 4160 — [[words/人称|人称]]
Fixed duplicate `pos`/`品詞` (kept pos). `characters:` confirmed correct (bare 称, no conflicting words/称.md exists), both character-page citations already correctly ruby-formatted, no homophone collision. Content already outstanding (thorough MC 日母-retention explanation cross-referencing the whole pronoun system, honest note on Vietnamese ngôi vs. formal nhân xưng). Stamped `date-last-perfect: 2026-09-10`.

Next: 人等.

### 2026-09-10, iteration 4161 — [[words/人等|人等]]
Found and fixed a real missing-citation bug: 人等 was entirely absent from `等(char).md`'s Words list — added. Upgraded a bare numbered-list citation on `人(char).md` (item 13). `characters:` confirmed correct (both require disambiguation, conflicting words/等.md exists), `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already excellent and admirably honest about attestation limits (classical/legal register distinct from colloquial 人們, readings given as formal cross-reference rather than claimed natural usage). Stamped `date-last-perfect: 2026-09-10`.

Next: 人証.

### 2026-09-10, iteration 4162 — [[words/人証|人証]]
Fixed a missing `korean` field entirely (filled 인증, compositional from each constituent's own field), mis-capitalized vietnamese, missing `kwin` field entirely (added false, confirmed via AND-rule), removed dangling empty `hsk_level`/`swadesh`. Standardized the non-standard `>[!warn]` callout to the established `>[!warning] Homophones` format. Fixed relative-link Notes paths (missing `../` prefix), properly incorporated the bare "Contrast with 物証" text as a wikilink within Notes, and honestly flagged that Vietnamese nhân chứng more commonly means "witness" than "personal evidence" itself. Found and fixed a missing-citation bug: 人証 was entirely absent from `人(char).md`'s Words list — added. `証.md`'s own citation was already correct. `characters:` confirmed correct (bare 証, no conflicting words/証.md exists). Homophone with [[認証]] re-verified via anchored grep — genuine, and confirmed both share the same kwin-divergence pattern. Stamped `date-last-perfect: 2026-09-10`.

Next: 人道.

### 2026-09-10, iteration 4163 — [[words/人道|人道]]
Wrote missing Notes section entirely (word had none). Removed dangling empty `hsk_level`/`swadesh`/`aliases` fields, added missing `date-last-perfect`. Found and fixed a missing-citation bug: 人道 was entirely absent from `道(char).md`'s Words list — added. Upgraded a bare numbered-list citation on `人(char).md` (item 22). `characters:` confirmed correct (both require disambiguation, conflicting words/道.md exists), `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 人間.

### 2026-09-10, iteration 4164 — [[words/人間|人間]]
Found and fixed a real content bug: `mandarin` was "rénjiā" (wrong reading, matches an unrelated word 人家), corrected to "rénjiān" (verified against 間(char)'s own stored jiān reading). Fixed mis-capitalized vietnamese (Nhân gian→nhân gian), removed dangling empty `hsk_level`/`swadesh` fields, added missing `date-last-perfect`, wrote missing Notes. Upgraded a bare numbered-list citation on `人(char).md` (item 30); `間.md`'s own citation was already correct. `characters:` confirmed correct (bare 間, no conflicting words/間.md exists), `kwin: false` confirmed via AND-rule (人(char) false overrides 間(char)'s own true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 人類.

### 2026-09-10, iteration 4165 — [[words/人類|人類]]
Fixed mis-capitalized vietnamese (Loài người→loài người, a real native term correctly preferred over a forced Sino-Vietnamese reading), removed dangling empty `swadesh`, added missing `date-last-perfect`, wrote missing Notes. Upgraded two bare numbered-list citations on `人(char).md` (items 33 and 35, 人類 and 人類学 — the latter opportunistically since trivial and directly adjacent); `類.md`'s own citations were already correct. `characters:` confirmed correct (bare 類, no conflicting words/類.md exists), `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 人類学.

### 2026-09-10, iteration 4166 — [[words/人類学|人類学]]
Fixed missing disambiguation (bare `人`→`人 (char)`, since `words/人.md` exists), mis-capitalized vietnamese (Nhân loại học→nhân loại học), normalized inline-flow `aliases: [人類學]` to block-list format, removed dangling empty `hsk_level`/`swadesh`, added missing `date-last-perfect`, wrote missing Notes. `characters:` otherwise confirmed correct (bare 類/学, no conflicting words/類.md or words/学.md exist). `kwin: false` confirmed via AND-rule (人 and 類 both false override 学(char)'s own true). All three character-page citations (人(char), 類, 学) already correctly ruby-formatted, no homophone collision. Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 人-prefixed word cluster.

Next: 仁徳.

### 2026-09-10, iteration 4167 — [[words/仁徳|仁徳]]
Fixed a stray space in `mandarin` ("rén dé"→"réndé", matching the vault's unspaced-mandarin convention). Removed dangling empty `hsk_level`/`swadesh` fields. `characters:` confirmed correct (bare 仁, no conflicting words/仁.md exists). `kwin: false` confirmed via AND-rule (both constituents independently false). Both character-page citations already correctly ruby-formatted, no homophone collision. Content already excellent (previously-fixed 徳(char) blank-vietnamese gap still holds). Stamped `date-last-perfect: 2026-09-10`.

Next: 仁慈.

### 2026-09-10, iteration 4168 — [[words/仁慈|仁慈]]
Fixed unspaced cantonese (jan4ci4→jan4 ci4), removed dangling empty `hsk_level`/`swadesh`/`aliases` fields. Added legitimizing-note phrasing (仁's own `stand_in` is this exact compound). `characters:` confirmed correct (bare 慈, no conflicting words/慈.md exists), `kwin: false` confirmed via AND-rule (both constituents independently false). Both character-page citations already correctly ruby-formatted. Homophone with [[人事]] re-verified via anchored grep — genuine. Content already good (nhân từ real everyday term, classical-vs-Dan'a'yo scope distinction). Stamped `date-last-perfect: 2026-09-10`.

Next: 仇恨.

### 2026-09-10, iteration 4169 — [[words/仇恨|仇恨]]
Fixed a missing `vietnamese` field entirely — filled cừu hận, a direct attested compositional match (仇's own cừu + 恨's own hận), consistent with the Notes' already-established Mandarin/Cantonese-centered pattern. Added missing `date-last-perfect`, and the standard legitimizing-note phrasing alongside the existing informal prose (仇's own `stand_in` is this exact compound). `characters:` confirmed correct (bare 仇, no conflicting words/仇.md exists). `kwin: false` confirmed via AND-rule (仇(char) false overrides 恨(char)'s own true). Both character-page citations already correctly ruby-formatted, no homophone collision. Content already outstanding (the deliberate 仇/敵 semantic split from [[仇敵]], honest cross-linguistic divergence note). Stamped `date-last-perfect: 2026-09-10`.

Next: 仇敵.

### 2026-09-10, iteration 4170 — [[words/仇敵|仇敵]]
Fixed missing `korean`/`vietnamese`/`kwin`/`date-last-perfect` fields entirely (word had none of these) — filled compositionally (구적, cừu địch), both directly attested real terms. Wrote missing Notes, explicitly cross-referencing the deliberate 仇/敵 semantic split into [[仇恨]]/[[敵人]] already documented on those pages. `characters:` confirmed correct (bare 仇/敵, no conflicting words exist). `kwin: false` confirmed via AND-rule (both constituents independently false). Both character-page citations already correctly ruby-formatted, no homophone collision. Confirmed neither constituent's own `stand_in` points to this compound, so no legitimizing note applies here. Stamped `date-last-perfect: 2026-09-10`.

Next: 今.

### 2026-09-10, iteration 4171 — [[words/今|今]]
Fixed duplicate `pos`/`品詞` (kept pos), fixed a missing `japanese` field entirely (filled こん, 今(char)'s own first-listed on'yomi KON, per the established convention). Added the standard self-referential legitimizing-note phrasing (matching 事/于/之/亦/人 exact wording). `characters:` confirmed correct (bare `今 (char)`), citation already correct on the character page. Re-verified the genuine homophone with [[金]] via anchored grep (also confirmed 襟/禁 are character-only matches with no independent word pages, so not real word-level homophones). Stamped `date-last-perfect: 2026-09-10`.

Next: 今世紀.

### 2026-09-10, iteration 4172 — [[words/今世紀|今世紀]]
Found and fixed a real content bug: `korean` was "이번세기" (unidiomatic native phrase), corrected to 금세기 — the standard, common Korean word for "this century" (compositional from 今's own 금 + 世紀's own 세기). Filled a missing `vietnamese` field with the natural native phrase thế kỷ này, preferred over a forced Sino-Vietnamese compound. Added missing `date-last-perfect`, expanded thin Notes. Found and fixed a missing-citation bug: 今世紀 was entirely absent from `今(char).md`'s Words list — added; `世.md`'s and `紀.md`'s own citations were already correct. `characters:` confirmed correct (bare 世/紀, no conflicting words exist). `kwin: false` confirmed via AND-rule (今 and 世 independently false, despite 紀 itself being kwin:true). No homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 今夜.

### 2026-09-10, iteration 4173 — [[words/今夜|今夜]]
Fixed missing disambiguation on both constituents (bare `今`/`夜`→`今 (char)`/`夜 (char)`, since both words/今.md and words/夜.md exist), normalized inline-flow `aliases: [今晚]` to block-list format, removed dangling empty `hsk_level`/`swadesh`. Upgraded a bare-format citation on `今(char).md`; `夜(char).md`'s own citation was already correct. `kwin: false` confirmed correct (Dan'a'yo 김야 vs. native-Korean 오늘밤, not a Sino-Korean compositional comparison). No homophone collision. Content already good (attested kim dạ). Stamped `date-last-perfect: 2026-09-10`.

Next: 今夜安.

### 2026-09-10, iteration 4174 — [[words/今夜安|今夜安]]
Found and fixed a real content bug: `mandarin`/`cantonese` were "dàishù"/"doi6 sou3" — an evident copy-paste leftover from the unrelated word 代数 ("algebra"), corrected to the real greeting terms (wǎnshàng hǎo, matching the alias already stored; maan5soeng6 hou2 as a flagged, honestly-uncertain Cantonese derivation). Fixed `japanese` (今晩は→こんばんは, matching the reading-not-orthography convention used on sibling greetings). Fixed a malformed comma-joined duplicate `vietnamese` value. Removed dangling empty `hsk_level`/`swadesh`, added missing `date-last-perfect`. `characters:` confirmed correct (bare 安, no conflicting words/安.md exists). Upgraded a bare-format citation on `今(char).md`; `夜(char).md`'s and `安.md`'s own citations were already correct. `kwin: false` confirmed correct (native-greeting-based Korean field, not compositional). No homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 今年.

### 2026-09-10, iteration 4175 — [[words/今年|今年]]
Already in excellent shape. `characters:` confirmed correct, both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already outstanding (honest treatment of Korean 금년 formal vs. native 올해 everyday, Vietnamese kim niên compositional vs. native năm nay). Just refreshed `date-last-perfect: 2026-09-10`.

Next: 今日.

### 2026-09-10, iteration 4176 — [[words/今日|今日]]
Found and fixed a real content bug: `mandarin`/`cantonese` were "jīntiān"/"gam1 tin1" — both using 天's own tiān/tin1 reading (the alias 今天's pronunciation) rather than 日's own rì/jat6, corrected to the headword's own compositional jīnrì/gam1 jat6. Fixed relative-link paths in Notes (missing `../` prefix, raw-markdown-link citations upgraded to wikilinks). Found and fixed a missing-citation bug: 今日 was entirely absent from `今(char).md`'s Words list — added; `日(char).md`'s own citation was already correct. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 今日安.

### 2026-09-10, iteration 4177 — [[words/今日安|今日安]]
Found and fixed a missing-citation bug: 今日安 was entirely absent from `今(char).md`'s Words list despite being present on `日(char).md` and `安.md` — added. `characters:` confirmed correct (bare 安, no conflicting words/安.md exists), no homophone collision. Content already good and consistent with the sibling greeting family (matches 今昼安's own mandarin/cantonese/japanese/korean/vietnamese values exactly, both being general-purpose "hello" greetings for unknown time-of-day). Stamped `date-last-perfect: 2026-09-10`.

Next: 今昼安.

### 2026-09-10, iteration 4178 — [[words/今昼安|今昼安]]
Removed dangling empty `hsk_level`/`swadesh`/`aliases` fields. Upgraded a bare-format citation on `今(char).md` (adjusted gloss to "good day," matching the word's own stored english field); `昼.md`'s and `安.md`'s own citations were already correct. `characters:` confirmed correct (bare 昼, no conflicting words/昼.md exists). `kwin: false` confirmed correct. No homophone collision. Content already good (Dan'a'yo-internal coinage, honest documentation that no source language has a real compound built from these same three characters). Stamped `date-last-perfect: 2026-09-10`.

Next: 今晩安.

### 2026-09-10, iteration 4179 — [[words/今晩安|今晩安]]
**Major finding and self-correction**: discovered that [[今夜安]] (processed last iteration, 4174) has its own `english: good night` — a distinct bedtime/parting farewell — but had been mistakenly filled with "good evening" arrival-greeting equivalents (晚上好/こんばんは/chào buổi tối) in that pass. Went back and corrected 今夜安 properly to the real "good night" farewell terms in each language: mandarin 晚安 (matching its own already-stored alias), cantonese maan5 on1, japanese おやすみなさい, korean 안녕히 주무세요 (a genuinely distinct sleep-specific farewell, unlike the general-purpose 안녕하세요 used by sibling greetings), vietnamese chúc ngủ ngon; also fixed its citation gloss on `今(char).md` from "good evening" to "good night." This resolves what looked like a same-meaning duplication between 今夜安 and today's word — they're a deliberate arrival/departure pair, like English "good evening" vs. "good night."
For 今晩安 itself ("good evening," arrival greeting): fixed `pos` (名詞→感詞, matching sibling greetings), `vietnamese` (generic "xin chào"→evening-specific chào buổi tối), normalized `mandarin` from bare hanzi to pinyin, removed dangling empty fields, added `aliases: [晚上好]`. Found and fixed a missing-citation bug on `今(char).md` (entirely absent) and upgraded a raw-markdown-link citation on `晩(char).md` to a proper wikilink. `characters:` confirmed correct (bare 安, no conflicting words/安.md; 晩 already disambiguated, conflicting words/晩.md exists). `kwin: false` confirmed correct. No homophone collision. Stamped `date-last-perfect: 2026-09-10` on both words.

Next: 今月.

### 2026-09-10, iteration 4180 — [[words/今月|今月]]
Found and fixed a real content bug: `korean` was a malformed comma-joined duplicate value ("이번달,금월"); split apart, keeping the formal Sino-Korean 금월 as the primary field (matching the [[今年]] convention) and moving native 이번달 into Notes. Filled a missing `vietnamese` field (kim nguyệt, honest compositional, noting native tháng này as the everyday alternative), added missing `kwin`/`date-last-perfect` fields entirely, wrote fuller Notes. Found and fixed a missing-citation bug on `今(char).md`; `月(char).md`'s own citation was already correct. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 今朝.

### 2026-09-10, iteration 4181 — [[words/今朝|今朝]]
Fixed missing disambiguation on both constituents (bare `今`/`朝`→`今 (char)`/`朝 (char)`, since both words/今.md and words/朝.md exist), normalized inline-flow `aliases: [今晨]` to block-list format, removed dangling empty `hsk_level`/`swadesh`. Found and fixed a missing-citation bug on `今(char).md`; `朝(char).md`'s own citation was already correct. `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already excellent (previously-fixed 朝(char) malformed-vietnamese-list bug still holds, honest tone-distinction between triêu/triều). Stamped `date-last-perfect: 2026-09-10`.

Next: 今朝安.

### 2026-09-10, iteration 4182 — [[words/今朝安|今朝安]]
Found and fixed stale cross-references: this page's Notes still described [[今夜安]] as "good evening" and claimed it shared Korean 안녕하세요 — both now outdated after the 4179 correction (今夜安 is actually "good night," using its own distinct 안녕히 주무세요). Corrected the family list to properly credit [[今晩安]] as the "good evening" member and [[今夜安]] as the "good night" bedtime counterpart. Fixed a stray missing comma-space in `japanese`, relative-link paths (missing `../` prefix). Upgraded a bare-format citation on `今(char).md`; `朝(char).md`'s and `安.md`'s own citations were already correct. `characters:` confirmed correct, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 今週.

### 2026-09-10, iteration 4183 — [[words/今週|今週]]
Filled a missing `vietnamese` field (kim chu, honest Sino-Vietnamese compositional, noting native tuần này as the everyday alternative), added missing `date-last-perfect`. Found and fixed a missing-citation bug on `今(char).md`; `週.md`'s own citation was already correct. `characters:` confirmed correct (bare 週, no conflicting words/週.md exists), `kwin: false` confirmed via AND-rule (both constituents independently false). Homophone with [[禁酒]] re-verified via anchored grep — genuine. Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 今-prefixed word cluster.

Next: 介紹.

### 2026-09-10, iteration 4184 — [[words/介紹|介紹]]
Reworded the informal stand-in note into the standard legitimizing-note phrasing, added explicit `kwin`/homophone-check statements. `characters:` confirmed correct (bare 介/紹, no conflicting words exist), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already outstanding (honest documentation of the Japanese/Korean word-order reversal to 紹介/소개, attested Vietnamese giới thiệu). Stamped `date-last-perfect: 2026-09-10`.

Next: 介詞.

### 2026-09-10, iteration 4185 — [[words/介詞|介詞]]
Fixed a missing `cantonese` field entirely (filled gaai3 ci4, compositional from each constituent's own reading). Removed dangling empty `hsk_level`/`swadesh`/`aliases`, added missing `date-last-perfect`, wrote missing Notes. `characters:` confirmed correct (bare 介/詞, no conflicting words exist), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (介(char) false overrides 詞(char)'s own true), no homophone collision. (Self-corrected an accidental stray non-schema field I briefly introduced mid-edit before catching and removing it.) Stamped `date-last-perfect: 2026-09-10`.

Next: 仍.

### 2026-09-10, iteration 4186 — [[words/仍|仍]]
Expanded thin Notes and added the standard self-referential legitimizing-note phrasing (matching 事/于/之/亦/人/今). Clarified that `vietnamese: nhưng` is the real Sino-Vietnamese reading of 仍, distinct from (though homographic with) the common native conjunction "nhưng" ("but") — verified as correct, not a mix-up. `characters:` confirmed correct, citation on `仍 (char).md` already correct, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 仍旧.

### 2026-09-10, iteration 4187 — [[words/仍旧|仍旧]]
Fixed missing disambiguation on both constituents (bare `仍`/`旧`→`仍 (char)`/`旧 (char)`, since both words/仍.md and words/旧.md exist), unspaced cantonese (jing4gau6→jing4 gau6), normalized inline-flow `aliases: [仍舊, 仍是, 亦是]` to block-list format, removed dangling empty `hsk_level`/`swadesh`. `kwin: false` confirmed via AND-rule (both constituents independently false — not merely "trivial" via the blank korean field as the old Notes phrased it). Both character-page citations already correctly ruby-formatted, no homophone collision. Content already good and honest about the Japanese/Korean attestation gap. Stamped `date-last-perfect: 2026-09-10`.

Next: 他.

### 2026-09-10, iteration 4188 — [[words/他|他]]
Fixed duplicate `pos`/`品詞` (kept pos). Added the standard self-referential legitimizing-note phrasing (matching 事/于/之/亦/人/今/仍). Found and fixed a real missing-citation bug: the word 他 itself was entirely absent from `他(char).md`'s own Words list despite being its stand-in — added. `characters:` confirmed correct (`他 (char)` required, no bare `characters/他.md`). No homophone collision. Noted (not fixed, out of this word's scope) that the compounds 他鄉/他動詞 cited on the character page use a different 注音 vowel (ㄊㄚ) than this word's own stored ㄊㄜ — flagged for their own alphabetical turns. Stamped `date-last-perfect: 2026-09-10`.

Next: 他動詞.

### 2026-09-10, iteration 4189 — [[words/他動詞|他動詞]]
**Major real content bug found and fixed**: `諺文`/`羅馬字`/`注音`/`kwin` had all been set by directly copying the Korean reading (타동사/tadongsa/ㄊㄚㄉㄛㄫㄙㄚ/true) wholesale, rather than compositing from each constituent's own Dan'a'yo reading — 他's own genuine 트/tǝ/ㄊㄜ (not 타/ta) had been dropped entirely. Corrected to the real compositional reading 트동사/tǝdongsa/ㄊㄜㄉㄛㄫㄙㄚ, with `kwin` following to false (confirmed via AND-rule: 他 false overrides 動/詞's own true). This required correcting the citation glyph on all three constituent character pages (他(char)/動(char)/詞), which had all inherited the same wrong vowel. Also fixed missing `pos` (blank), removed dangling `aliases: []`, filled missing `vietnamese` (ngoại động từ, real attested grammar term), added missing `date-last-perfect`, wrote missing Notes. No homophone collision with the corrected reading. **Discovered the same bug pattern on `words/他鄉.md`** (due next) — its own 諺文/羅馬字/注音/kwin are likewise a direct Korean-reading copy rather than a genuine composition from 他's own 트; will fix on its own turn next.

Next: 他鄉.

### 2026-09-10, iteration 4190 — [[words/他鄉|他鄉]]
Confirmed and fixed the same Korean-reading-copy bug flagged last iteration: `諺文`/`羅馬字`/`注音`/`kwin` had been set to a direct copy of the Korean reading (타향/tahyang/ㄊㄚㄏ⼘ㄫ/true) instead of compositing from 他's own genuine 트/tǝ/ㄊㄜ — corrected to 트향/tǝhyang/ㄊㄜㄏ⼘ㄫ/kwin:false. Also found and fixed a real alias-vs-parent bug: `characters:` cited the alias glyph `鄉` instead of the parent filename `郷` (鄉/鄕/乡 are all documented aliases of 郷) — corrected per the established convention. Fixed the citation glyph on `他(char).md` and added a missing citation entirely on `郷.md`. Removed dangling empty `hsk_level`/`swadesh`/`aliases: []`. No homophone collision with the corrected reading. Stamped `date-last-perfect: 2026-09-10`.

Next: 仙人掌.

### 2026-09-10, iteration 4191 — [[words/仙人掌|仙人掌]]
Filled a missing `vietnamese` field with the real, universal native term xương rồng ("dragon bone"), preferred over a forced Sino-Vietnamese "tiên nhân chưởng" compositional reading — paralleling this word's own already-documented Japanese サボテン loanword pattern. `characters:` confirmed correct (bare 仙/掌, no conflicting words exist), all three character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (仙 and 人 both independently false, despite 掌 itself being kwin:true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 代名詞.

### 2026-09-10, iteration 4192 — [[words/代名詞|代名詞]]
Added missing `date-last-perfect` (only gap found). `characters:` confirmed correct (bare 代, no conflicting words/代.md exists), all three character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (名(char) false makes the whole AND false, despite 代/詞 both being kwin:true), no homophone collision. Content already excellent (honest note on colloquial đại từ shortening, cross-references to 代用/代用字/形容詞). Stamped `date-last-perfect: 2026-09-10`.

Next: 代数.

### 2026-09-10, iteration 4193 — [[words/代数|代数]]
Confirmed this word itself is the legitimate source of the mandarin/cantonese "dàishù"/"doi6 sou3" values that turned up as a copy-paste leftover bug on 今夜安 earlier — this page's own values are correct for its own meaning. Fixed mis-capitalized vietnamese (Đại số→đại số), removed dangling empty `hsk_level`/`swadesh`, normalized inline-flow `aliases: [代數]` to block-list format, added missing `date-last-perfect`. Replaced a malformed stray line ("For the study theoreof , see 代数学") with a proper Notes section and wikilink to [[代数学]] (confirmed to exist). Found and added a genuine, previously undocumented homophone with [[大水]] ("flood") — added the Homophones callout here and reciprocally on 大水's own page (which was also missing a `vietnamese` field, filled with lũ lụt). Both character-page citations already correctly ruby-formatted, `kwin: true` confirmed via AND-rule (both constituents independently true). Stamped `date-last-perfect: 2026-09-10` on both words.

Next: 代数学.

### 2026-09-10, iteration 4194 — [[words/代数学|代数学]]
Fixed mis-capitalized vietnamese (Đại số học→đại số học), removed dangling empty `hsk_level`/`swadesh`, normalized inline-flow `aliases: [代數學]` to block-list format, added missing `date-last-perfect`, wrote missing Notes distinguishing it from [[代数]]. `characters:` confirmed correct, all three character-page citations already correctly ruby-formatted, `kwin: true` confirmed via AND-rule (all three constituents independently true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 代替.

### 2026-09-10, iteration 4195 — [[words/代替|代替]]
Fixed unspaced cantonese (doi6tai3→doi6 tai3), reworded the informal stand-in note into the standard legitimizing-note phrasing. `characters:` confirmed correct (bare 替, no conflicting words/替.md exists), both character-page citations already correctly ruby-formatted, `kwin: true` confirmed (both constituents independently match Sino-Korean exactly), no homophone collision. Content already outstanding (honest register notes on Japanese 代わる/Korean 대체로/Vietnamese thay thế alternatives). Stamped `date-last-perfect: 2026-09-10`.

Next: 代用.

### 2026-09-10, iteration 4196 — [[words/代用|代用]]
Already in excellent shape. `characters:` confirmed correct (bare 用, no conflicting words/用.md exists), both character-page citations already correctly ruby-formatted, `kwin: true` confirmed (both constituents match Sino-Korean exactly), no homophone collision. Content already thorough (cross-references to 代表/作用, honest connotation note on "making do"). Just refreshed `date-last-perfect: 2026-09-10`.

Next: 代用字.

### 2026-09-10, iteration 4197 — [[words/代用字|代用字]]
Filled a missing `vietnamese` field (đại dụng tự, honest Sino-Vietnamese compositional reading, no direct attestation found). `characters:` confirmed correct (`字 (char)` required, conflicting words/字.md exists), all three character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (字(char) false overrides 代/用's own true), no homophone collision. Content already outstanding (concrete 包/雹, 厳/儼, 井/丼 examples of the alias-authorization mechanism, careful Japanese だいようじ vs. Dan'a'yo coda-preservation phonological comparison). Stamped `date-last-perfect: 2026-09-10`.

Next: 代表.

### 2026-09-10, iteration 4198 — [[words/代表|代表]]
Removed dangling empty `hsk_level`/`swadesh`/`aliases` fields. `characters:` confirmed correct (bare 表, no conflicting words/表.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (代(char) true, 表(char) false). Homophone with [[大砲]] re-verified via anchored grep — genuine. Content already good (previously-fixed vietnamese capitalization and homophone-callout-format bugs still hold, correctly notes no stand-in relationship applies here). Stamped `date-last-perfect: 2026-09-10`.

Next: 代表之.

### 2026-09-10, iteration 4199 — [[words/代表之|代表之]]
Fixed missing disambiguation (bare `之`→`之 (char)`, since `words/之.md` exists), a broken relative link (`../characters/之.md` pointed at a nonexistent file — the real filename is `之 (char).md`), and a mislabeled link where display text "代表" pointed only at `characters/代.md` — rewrote to properly cite 代/表 separately plus a wikilink to the word [[代表]]. Removed dangling empty `hsk_level`/`swadesh`/`aliases`. Found and fixed a missing-citation bug: 代表之 was entirely absent from `之 (char).md`'s Words list — added; `代.md`'s and `表.md`'s own citations were already correct. `kwin: false` confirmed via AND-rule (代 true, 表 and 之(char) both false). No homophone collision. Content already good and honest (Dan'a'yo-internal coinage modeled on classical 爲, each language's own natural equivalent documented). Stamped `date-last-perfect: 2026-09-10`.

Next: 代詞.

### 2026-09-10, iteration 4200 — [[words/代詞|代詞]]
Fixed duplicate `pos`/`品詞` (kept pos). Found and fixed a real structural bug: `aliases` wrongly listed 代名詞/代名词 as if they were mere spelling variants of 代詞 — but [[代名詞]] is an independently-documented, distinct Dan'a'yo word with its own full frontmatter (processed at iteration 4192), not an alias; removed both, kept only the genuine simplified variant 代词, and rewrote the Notes to cross-reference 代名詞 properly instead. `characters:` confirmed correct, both character-page citations already correctly ruby-formatted, `kwin: true` confirmed (both constituents independently true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 代-prefixed word cluster.

Next: 令.

### 2026-09-10, iteration 4201 — [[words/令|令]]
Fixed duplicate `pos`/`品詞` (kept pos). Fixed a real content bug: `japanese` was りょう (令(char)'s second-listed on'yomi) instead of the first-listed れい, per the established convention — corrected, consistent with the word's own Notes examples (命令 めいれい, 法令 ほうれい). Added the standard self-referential legitimizing-note phrasing. Citation on `令 (char).md` already correct. Re-verified the three-way homophone group (令/鈴/零) is accurate and complete — the several character-only matches (齢/伶/羚/玲/澪/霊) have no independent word pages, so aren't real word-level collisions. Stamped `date-last-perfect: 2026-09-10`.

Next: 令和.

### 2026-09-10, iteration 4202 — [[words/令和|令和]]
Fixed duplicate `pos`/`品詞` (kept pos), a missing `kwin` field entirely (added false, confirmed via AND-rule), and broken relative-link paths in Notes (missing `../` prefix). Found and fixed a missing-citation bug on `令(char).md`; `和.md`'s own citation was already correct. `characters:` confirmed correct (bare 和, no conflicting words/和.md exists). No homophone collision. Content already outstanding (traced the etymology through the Man'yōshū foreword back to Zhang Heng's 歸田賦, correctly kept capitalized as a genuine proper noun/era name). Stamped `date-last-perfect: 2026-09-10`.

Next: 令圄.

### 2026-09-10, iteration 4203 — [[words/令圄|令圄]]
Found and fixed a real content bug: `korean` had been set to the South-Korean 두음법칙-shifted form 영어 (coincidentally homophonic with 英語, "English") instead of the vault's standard unshifted North-Korean 령어. Explained the deliberate, correct split where mandarin/cantonese/japanese/vietnamese follow 囹圄's own real attested reading (령's alias 囹) while the Dan'a'yo-internal fields and korean follow 令's own regular identity, per the vault's alias-borrowing convention. Normalized inline-flow `characters:` to block-list format, fixed duplicate `pos`/`品詞`, added missing `date-last-perfect`, wrote missing Notes with legitimizing-note phrasing (圄's own `stand_in` is this word). Found and fixed a missing-citation bug on `令(char).md`; `圄.md`'s own citation was already correct. No homophone collision.

Next: 令聞.

### 2026-09-10, iteration 4204 — [[words/令聞|令聞]]
Found and fixed the same real content bug just found on [[令圄]]: `korean` had been set to the South-Korean 두음법칙-shifted form 영문 (coincidentally homophonic with 英文, "English text") instead of the vault's standard unshifted North-Korean 령문, compositional from 令's own 령 + 聞's own 문. Removed a dangling empty `swadesh: ""`. Found and fixed a missing-citation bug on `令(char).md`; `聞 (char).md`'s own citation was already correct. `kwin: false` confirmed via AND-rule (令(char) false overrides 聞(char)'s own true), no homophone collision. Content otherwise already excellent (previously-fixed 令(char) missing-vietnamese-readings gap still holds). Stamped `date-last-perfect: 2026-09-10`. **Watch for this same 두음법칙 bug pattern on remaining 令-compounds** (令色 due next).

Next: 令色.

### 2026-09-10, iteration 4205 — [[words/令色|令色]]
Confirmed the same 두음법칙-shift bug a third consecutive time: `korean` was 영색 instead of the correct unshifted 령색. Fixed missing disambiguation (bare `令`→`令 (char)`), removed dangling empty `hsk_level`/`swadesh`/`aliases`, merged a non-standard `## Etymology` heading into `## Notes`. Upgraded a bare-format citation on `令(char).md`; `色.md`'s own citation was already correct. `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. This closes out the entire 令-prefixed word cluster — the 두음법칙 korean-field bug was confirmed on all 3 compounds checked (令圄/令聞/令色), so the whole cluster has now been fully swept for it.

Next: 以.

### 2026-09-10, iteration 4206 — [[words/以|以]]
Fixed a broken Homophones callout (a stray blank line was breaking the Obsidian callout syntax, splitting the [[擬]] line out of the box). Added the standard self-referential legitimizing-note phrasing (matching 事/于/之/亦/人/今/仍/他/令). Re-verified the genuine homophone with [[擬]] via anchored grep, confirming several character-only matches (疑/飴/頤/異) aren't real word-level collisions. `characters:` confirmed correct, citation on `以 (char).md` already correct. Content already outstanding (thorough instrumental-case comparison chart, honest note on 以→用 diachronic shift in spoken Mandarin). Stamped `date-last-perfect: 2026-09-10`.

Next: 以便.

### 2026-09-10, iteration 4207 — [[words/以便|以便]]
Normalized inline-flow `characters:` to block-list format, removed dangling empty `hsk_level`/`swadesh`/`aliases: []`. `characters:` otherwise confirmed correct (both require disambiguation, conflicting words/便.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (以(char) true, 便(char) false), no homophone collision. Content already good (attested Vietnamese để purpose-clause conjunction). Stamped `date-last-perfect: 2026-09-10`.

Next: 以前.

### 2026-09-10, iteration 4208 — [[words/以前|以前]]
Normalized inline-flow `characters:` to block-list format, removed dangling empty `hsk_level`/`swadesh`/`aliases: []`. Found and fixed a missing-citation bug: 以前 was entirely absent from `前(char).md`'s Words list — added; `以(char).md`'s own citation was already correct. `kwin: true` confirmed (both constituents independently true), no homophone collision. Content already good (consistent 以-family pattern with 以後/以上). Stamped `date-last-perfect: 2026-09-10`.

Next: 以後.

### 2026-09-10, iteration 4209 — [[words/以後|以後]]
Already in excellent shape. `characters:` confirmed correct, both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (以(char) true, 後(char) false), no homophone collision. Content already good (honest note on modern Vietnamese preferring native sau đó/sau này over classical dĩ hậu). Just refreshed `date-last-perfect: 2026-09-10`. This closes out the entire 以-prefixed word cluster.

Next: 仮借.

### 2026-09-10, iteration 4210 — [[words/仮借|仮借]]
Fixed a missing `korean` field entirely (filled 가차, compositional, and confirmed as the real standard Korean term for this linguistic concept). Removed dangling empty `hsk_level`/`swadesh`, added missing `kwin`/`date-last-perfect`, wrote missing Notes explaining the 六書 phonetic-loan concept plus legitimizing-note phrasing (仮's own `stand_in` is this exact compound). `characters:` confirmed correct (bare 仮, no conflicting words/仮.md exists), both character-page citations already correctly ruby-formatted, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 仮定.

### 2026-09-10, iteration 4211 — [[words/仮定|仮定]]
**Real content bug found and fixed on both this word and `仮.md`'s own character page**: `仮(char).md` itself had stored `mandarin: fǎn`/`cantonese: faan2` — the readings of the unrelated character 反, not 假/仮's real jiǎ/gaa2 (confirmed by cross-checking against its own internally-consistent korean 가/諺文 가/注音 ㄍㄚ, all pointing to "ga," and against sibling word [[仮借]]'s own already-correct cantonese gaa2 ze3) — corrected on the character page itself. This word's own `cantonese` had inherited the same wrong faan2 compositionally; corrected to gaa2 ding6. `characters:` confirmed correct (bare 定, no conflicting words/定.md exists), both character-page citations already correctly ruby-formatted, `kwin: true` confirmed (both constituents independently true — unaffected by the mandarin/cantonese fix since kwin only compares 諺文/korean), no homophone collision. Stamped `date-last-perfect: 2026-09-10` on both files.

Next: 仮面.

### 2026-09-10, iteration 4212 — [[words/仮面|仮面]]
Confirmed the same inherited-wrong-cantonese bug found on [[仮定]]: `cantonese` was faan2 min6 (反's reading) instead of gaa2 min6 (仮's own now-corrected reading) — fixed. Merged a non-standard `## Etymology` heading into `## Notes`, removed dangling empty `hsk_level`/`swadesh`. `characters:` confirmed correct (bare 面, no conflicting words/面.md exists), both character-page citations already correctly ruby-formatted, `kwin: true` confirmed (already correctly resolved in a previous pass), no homophone collision. Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 仮-prefixed word cluster — the wrong-cantonese bug was found on 2 of 3 compounds (仮定, 仮面; 仮借 was already correct).

Next: 仰望.

### 2026-09-10, iteration 4213 — [[words/仰望|仰望]]
Removed dangling empty `hsk_level`/`swadesh`/`aliases: []`. Added legitimizing-note phrasing (仰's own `stand_in` is this exact compound). `characters:` confirmed correct (bare 仰, no conflicting words/仰.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (仰(char) false overrides 望(char)'s own true), no homophone collision. Content already good (attested ぎょうぼう/ngưỡng vọng). Stamped `date-last-perfect: 2026-09-10`.

Next: 仲介.

### 2026-09-10, iteration 4214 — [[words/仲介|仲介]]
Already in excellent shape. Verified the `#cranberry` tag: both 仲's and 介's own `stand_in` fields genuinely point to this exact compound, so transitivity holds and the tag is legitimate (double-checked after briefly second-guessing it against an unrelated memory of 介's stand_in — confirmed no conflict, that was 紹's own stand_in from a different word). `characters:` confirmed correct (bare 仲, no conflicting words/仲.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Just refreshed `date-last-perfect: 2026-09-10`.

Next: 仲冬.

### 2026-09-10, iteration 4215 — [[words/仲冬|仲冬]]
Fixed duplicate `pos`/`品詞` (kept pos), added missing `date-last-perfect`. Verified the capitalized single-item-list `vietnamese: [Trọng Đông]` format against sibling seasonal words (仲春/仲夏/仲秋 all use the identical "Trọng X" capitalized pattern) — confirmed as the vault's deliberate, consistent style for this family, not a bug; left unchanged. `characters:` confirmed correct (`冬 (char)` required, conflicting words/冬.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision.

Next: 仲夏.

### 2026-09-10, iteration 4216 — [[words/仲夏|仲夏]]
Fixed duplicate `pos`/`品詞` (kept pos), added missing `date-last-perfect`. `characters:` confirmed correct (`夏 (char)` required, conflicting words/夏.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already good (Shakespeare cross-cultural note).

Next: 仲媒.

### 2026-09-10, iteration 4217 — [[words/仲媒|仲媒]]
Removed dangling empty `hsk_level`/`swadesh` fields, added legitimizing-note phrasing (媒's own `stand_in` is this exact compound). `characters:` confirmed correct (bare 媒, no conflicting words/媒.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already good (previously-fixed mandarin/cantonese/self-referential-alias bugs still hold). Stamped `date-last-perfect: 2026-09-10`.

Next: 仲春.

### 2026-09-10, iteration 4218 — [[words/仲春|仲春]]
Fixed duplicate `pos`/`品詞` (kept pos), added missing `date-last-perfect`. `characters:` confirmed correct (`春 (char)` required, conflicting words/春.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (仲(char) false overrides 春(char)'s own true), no homophone collision.

Next: 仲秋.

### 2026-09-10, iteration 4219 — [[words/仲秋|仲秋]]
Fixed duplicate `pos`/`品詞` (kept pos), added missing `date-last-perfect`. `characters:` confirmed correct (`秋 (char)` required, conflicting words/秋.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. This closes out the entire 仲-prefixed word cluster.

Next: 企劃.

### 2026-09-10, iteration 4220 — [[words/企劃|企劃]]
Filled a missing `vietnamese` field (xí hoạch, honest compositional, noting the far more common real term kế hoạch belongs to the near-synonym 計劃 instead). Added legitimizing-note phrasing (企's own `stand_in` is this exact compound). `characters:` confirmed correct (bare 企, no conflicting words/企.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 企図.

### 2026-09-10, iteration 4221 — [[words/企図|企図]]
Fixed unspaced cantonese (kei5tou4→kei5 tou4), removed dangling empty `hsk_level`/`swadesh`, merged a non-standard `## Etymology` heading into `## Notes`. `characters:` confirmed correct (bare 図, no conflicting words/図.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (企(char) false overrides 図(char)'s own true), no homophone collision. Content already good (previously-fixed 図's own blank-vietnamese gap still holds). Stamped `date-last-perfect: 2026-09-10`.

Next: 企業.

### 2026-09-10, iteration 4222 — [[words/企業|企業]]
Fixed unspaced cantonese (kei5jip6→kei5 jip6), removed dangling empty `swadesh`/`aliases`, added missing `date-last-perfect`, wrote missing Notes (merged from a non-standard `## Etymology` heading). Found and fixed a missing-citation bug: 企業 was entirely absent from `業(char).md`'s Words list — added; `企.md`'s own citation was already correct. `characters:` confirmed correct (`業 (char)` required, conflicting words/業.md exists), `kwin: false` confirmed via AND-rule (企(char) false overrides 業(char)'s own true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 企鵝.

### 2026-09-10, iteration 4223 — [[words/企鵝|企鵝]]
Normalized inline-flow `characters:`/`aliases: [人鳥]` to block-list format, added missing `date-last-perfect`, merged a non-standard `## Etymology` heading into `## Notes` with fuller content — correctly identified 企's role here as its own well-documented "tiptoe" etymology (a goose standing upright like a person on tiptoe) rather than its usual "plan, scheme" sense, verified against 企(char)'s own stored Notes. `characters:` confirmed correct (bare 鵝, no conflicting words/鵝.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (企(char) false overrides 鵝(char)'s own true), no homophone collision. Content already good (real natural terms 펭귄/chim cánh cụt correctly preferred over compositional readings). Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 企-prefixed word cluster.

Next: 伍.

### 2026-09-10, iteration 4224 — [[words/伍|伍]]
Fixed duplicate `pos`/`品詞` (kept pos). Added the standard self-referential legitimizing-note phrasing (matching 事/于/之/亦/人/今/仍/他/令/以). Upgraded a raw-markdown-link citation on `伍 (char).md`'s own Words list to a proper wikilink. Re-verified the 4-way homophone group (五/汚/於/伍) via anchored grep as complete and accurate — several character-only matches (誤/悟/嗚/娯/烏/呉/午) have no independent word pages. Content already outstanding (financial anti-forgery numeral role cross-referenced with 壱/貳/漆/玖). Stamped `date-last-perfect: 2026-09-10`.

Next: 伎倆.

### 2026-09-10, iteration 4225 — [[words/伎倆|伎倆]]
Reworded the informal stand-in note into the standard legitimizing-note phrasing. Deliberately left `vietnamese` undocumented rather than fabricated: the naive compositional reading "kỹ lưỡng" (伎's kĩ/kỹ + 両's lưỡng) is already a real, unrelated Vietnamese word meaning "careful, thorough," not "skill/trick" — using it would introduce a misleading false-friend, so the honest gap is noted instead. `characters:` confirmed correct (bare 伎, no conflicting words/伎.md exists; 両 correctly cites the parent glyph rather than the alias 倆), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (伎(char) false overrides 両(char)'s own true), no homophone collision. Content already excellent (honest register-shift note between classical-neutral and modern-negative Mandarin senses, Japanese 技量 spelling-variant cross-reference). Stamped `date-last-perfect: 2026-09-10`.

Next: 伏.

### 2026-09-10, iteration 4226 — [[words/伏|伏]]
Fixed a missing `japanese` field entirely (filled ふく, 伏(char)'s own first-listed on'yomi FUKU, per the established convention). Added the standard self-referential legitimizing-note phrasing. Found and fixed a real missing-citation bug: the word 伏 itself was entirely absent from `伏(char).md`'s own Words list despite being its stand-in — added. Verified several character-only homophone matches (復/複/蔔/北/畐/服) have no independent word pages, so aren't real word-level collisions. Stamped `date-last-perfect: 2026-09-10`.

Next: 休息.

### 2026-09-10, iteration 4227 — [[words/休息|休息]]
Filled a missing `vietnamese` field (nghỉ ngơi, the real standard everyday phrase, matching 休's own already-stored reading). Added the standard legitimizing-note phrasing (休's own `stand_in` is this exact compound). `characters:` confirmed correct (bare 休/息, no conflicting words exist), both character-page citations already correctly ruby-formatted, `kwin: true` confirmed (both constituents independently true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 休息室.

### 2026-09-10, iteration 4228 — [[words/休息室|休息室]]
Normalized `characters:` indentation, removed dangling empty `hsk_level`/`swadesh`/`aliases`, merged a stray unheaded paragraph and a non-standard `## Etymology` heading into `## Notes`. Upgraded a bare-format citation on `休.md`; `息.md`'s and `室.md`'s own citations were already correct. `characters:` confirmed correct (bare 室, no conflicting words/室.md exists). `kwin: false` confirmed correct (compares against the real 휴게실-based Korean field, not a naive AND-rule, matching the established real-term-exception pattern). No homophone collision. Verified the page's own "休憩 isn't [attested]" claim against [[休憩]] (which now exists as its own word) — confirmed [[休憩]]'s own Notes already document this, self-consciously, as outdated-but-historically-accurate context, so left unchanged per that word's own guidance. Stamped `date-last-perfect: 2026-09-10`.

Next: 休憩.

### 2026-09-10, iteration 4229 — [[words/休憩|休憩]]
Normalized `characters:` indentation, removed dangling empty `hsk_level`/`swadesh`/`aliases`, added the legitimizing-note phrasing (憩's own `stand_in` is this exact compound). Found and fixed a missing-citation bug on `休.md`; `憩.md`'s own citation was already correct. `kwin: false` confirmed correct (real divergence in the second syllable's vowel). No homophone collision. Content already excellent (already self-consciously documents the 休息室 outdated-claim cross-reference, previously-fixed 憩's own missing-vietnamese gap still holds). Stamped `date-last-perfect: 2026-09-10`.

Next: 休日.

### 2026-09-10, iteration 4230 — [[words/休日|休日]]
Filled a missing `vietnamese` field (ngày nghỉ, the real standard everyday phrase). Found and fixed a missing-citation bug on `休.md`; `日(char).md`'s own citation was already correct. `characters:` confirmed correct, `kwin: false` confirmed via AND-rule (休(char) true, 日(char) false), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 休暇.

### 2026-09-10, iteration 4231 — [[words/休暇|休暇]]
Normalized `characters:` indentation, removed dangling empty `hsk_level`/`swadesh`/`aliases`, merged a non-standard `## Etymology` heading into `## Notes`. Upgraded a bare-format citation on `休.md`; `暇.md`'s own citation was already correct. `characters:` confirmed correct (bare 暇, no conflicting words/暇.md exists), `kwin: false` confirmed via AND-rule (休(char) true, 暇(char) false), no homophone collision. Content already good (previously-fixed crammed-cantonese bug still holds, honest hưu hạ vs. hưu giá distinction). Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 休-prefixed word cluster.

Next: 会.

### 2026-09-10, iteration 4232 — [[words/会|会]]
Fixed duplicate `pos`/`品詞` (kept pos). Added the standard self-referential legitimizing-note phrasing (matching 事/于/之/亦/人/今/仍/他/令/以/伏). Citation on `会 (char).md` already correct, no homophone collision. Content already excellent (honest distinction between everyday hội and the specifically-Vietnamese hụi rotating-credit-circle loanword sense). Stamped `date-last-perfect: 2026-09-10`.

Next: 会員.

### 2026-09-10, iteration 4233 — [[words/会員|会員]]
Normalized `characters:` indentation, fixed a typo ("personel"→"personnel"), removed dangling empty `swadesh`/`aliases`, added missing `date-last-perfect`, wrote missing Notes (merged from a non-standard `## Etymology` heading). `characters:` confirmed correct, both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (会(char) false overrides 員(char)'s own true), no homophone collision. Verified the `-2` tone-sandhi cantonese notation as the established legitimate convention, not a bug. Stamped `date-last-perfect: 2026-09-10`.

Next: 会堂.

### 2026-09-10, iteration 4234 — [[words/会堂|会堂]]
Normalized `characters:`/`aliases: [會堂]` to block-list format, removed dangling empty `hsk_level`/`swadesh`, merged a non-standard `## Etymology` heading into `## Notes`, added legitimizing-note phrasing (堂's own `stand_in` is this exact compound). `characters:` confirmed correct (bare 堂, no conflicting words/堂.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (会(char) false overrides 堂(char)'s own true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 会意.

### 2026-09-10, iteration 4235 — [[words/会意|会意]]
Fixed duplicate `pos`/`品詞` (kept pos). Verified `vietnamese: hội ý` is the real, standard Vietnamese Han-Nom term for this 六書 category (lục thư: tượng hình/chỉ sự/hội ý/hình thanh/chuyển chú/giả tá), not a false-friend — confirmed correct, not a bug. Re-verified the Korean-only homophone claim with [[会議]]: 会議's own 注音 (ㄏ⼔ㄜㄧ) differs from this word's (ㄏ⼔ㄜ), confirming it's genuinely just a Sino-Korean coincidence (both 회의), not a Dan'a'yo-level homophone — matches the established genuine-vs-Korean-only-coincidence distinction pattern. `characters:` confirmed correct, both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (both constituents independently false). Content already outstanding (信/休 worked examples, 象形→指事→会意→形声 abstraction progression). Stamped `date-last-perfect: 2026-09-10`.

Next: 会社.

### 2026-09-10, iteration 4236 — [[words/会社|会社]]
Normalized `characters:`/`aliases: [會社]` to block-list format, removed dangling empty `hsk_level`/`swadesh`, merged a non-standard `## Etymology` heading into `## Notes`. `characters:` confirmed correct (bare 社, no conflicting words/社.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already good (honest confirmation that 會社/会社 is a real, if dated/regional, Mandarin/Cantonese term, not a Japanese-only fabrication). Stamped `date-last-perfect: 2026-09-10`.

Next: 会社員.

### 2026-09-10, iteration 4237 — [[words/会社員|会社員]]
Fixed a spaced `mandarin` ("huì shè yuán"→"huìshèyuán"), a typo ("personel"→"personnel"), normalized inline-flow `characters:`/`aliases: [會社員]` to block-list format, removed dangling empty `hsk_level`/`swadesh`, merged a non-standard `## Etymology` heading into `## Notes`. `characters:` confirmed correct, all three character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (会/社 both false, despite 員 itself being kwin:true), no homophone collision. Content already good (honest note on everyday nhân viên công ty vs. compositional hội xã viên). Stamped `date-last-perfect: 2026-09-10`.

Next: 会話.

### 2026-09-10, iteration 4238 — [[words/会話|会話]]
Already in excellent shape. `characters:` confirmed correct (both require disambiguation, conflicting words/話.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (both constituents independently false), no homophone collision. Content already good (会話文/日常会話 real usage examples, correctly-preserved -2 tone-sandhi cantonese notation). Just refreshed `date-last-perfect: 2026-09-10`.

Next: 会議.

### 2026-09-10, iteration 4239 — [[words/会議|会議]]
Fixed a missing `kwin` field entirely (added false, confirmed via AND-rule), normalized inline-flow `characters:`/`aliases: [會議]` to block-list format, removed dangling empty `hsk_level`/`swadesh`, wrote missing Notes (merged from a non-standard `## Etymology` heading), explicitly cross-referencing the Korean-only near-homophone [[会意]]. `characters:` confirmed correct (bare 議, no conflicting words/議.md exists), both character-page citations already correctly ruby-formatted. Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 会-prefixed word cluster.

Next: 伝播.

### 2026-09-10, iteration 4240 — [[words/伝播|伝播]]
Fixed a malformed comma-joined `mandarin` (an incorrect tone variant crammed in alongside the correct chuánbō) — trimmed to the single correct value. Filled a missing `vietnamese` field (truyền bá, directly attested and extremely common). Added legitimizing-note phrasing (伝's own `stand_in` is this exact compound), wrote fuller Notes. `characters:` confirmed correct (bare 伝, no conflicting words/伝.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed (both constituents independently false), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 伝統.

### 2026-09-10, iteration 4241 — [[words/伝統|伝統]]
Normalized inline-flow `characters:`/`aliases: [傳統]` to block-list format, removed dangling empty `swadesh`, added missing `date-last-perfect`, wrote missing Notes (merged from a non-standard `## Etymology` heading). `characters:` confirmed correct (bare 統, no conflicting words/統.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (伝(char) false overrides 統(char)'s own true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 伝説.

### 2026-09-10, iteration 4242 — [[words/伝説|伝説]]
Normalized inline-flow `characters:`/`aliases: [傳說, 传说]` to block-list format, removed dangling empty `swadesh`, added missing `date-last-perfect`, wrote missing Notes (merged from a non-standard `## Etymology` heading). `characters:` confirmed correct (bare 説, no conflicting words/説.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed (both constituents independently false), no homophone collision. Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 伝-prefixed word cluster.

Next: 伯伯.

### 2026-09-10, iteration 4243 — [[words/伯伯|伯伯]]
Fixed the reduplicated-constituent bug (characters: had `伯` listed twice; deduped to a single entry per the established 九九/仁人 convention). Fixed unspaced cantonese (baak3baak3→baak3 baak3), removed dangling empty `swadesh`/`aliases: []`, merged a non-standard `## Etymology` heading into `## Notes`. `characters:` confirmed correct (bare 伯, no conflicting words/伯.md exists), citation on `伯.md` already correct, no homophone collision. Content already good (previously-fixed non-idiomatic Korean compositional bug still holds). Stamped `date-last-perfect: 2026-09-10`.

Next: 伯母.

### 2026-09-10, iteration 4244 — [[words/伯母|伯母]]
Removed dangling empty `swadesh`/`aliases: []`. `characters:` confirmed correct (bare 母, no conflicting words/母.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed (both constituents independently false), no homophone collision. Content already excellent (contrast with colloquial [[伯伯]], genuine formal kinship terms verified). Stamped `date-last-perfect: 2026-09-10`.

Next: 伯爵.

### 2026-09-10, iteration 4245 — [[words/伯爵|伯爵]]
Removed a stray duplicate `## Etymology` section left over below `## Notes`, repeating the same character breakdown with worse/inconsistent glosses ("uncle"/"baron" instead of the Notes' own "count-rank"/"noble title"). Removed dangling empty `hsk_level`/`swadesh`/`aliases: []`. `characters:` confirmed correct (bare 爵, no conflicting words/爵.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (伯(char) false overrides 爵(char)'s own true), no homophone collision. Content already good (公侯伯子男 five-rank peerage cross-reference). Stamped `date-last-perfect: 2026-09-10`.

Next: 伯父.

### 2026-09-10, iteration 4246 — [[words/伯父|伯父]]
Removed dangling empty `swadesh`/`aliases: []`. Found the real legitimizing relationship: `伯(char).md`'s own `stand_in` is this exact word (not a "bare self-standing character" as assumed while processing its siblings [[伯伯]]/[[伯母]]/[[伯爵]]) — added the legitimizing-note phrasing here specifically, since this is the one word that actually legitimizes 伯. `characters:` confirmed correct (bare 父, no conflicting words/父.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (伯(char) false overrides 父(char)'s own true), no homophone collision. Content already excellent (honest bá phụ vs. thúc phụ paternal-uncle-age distinction). Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 伯-prefixed word cluster.

Next: 伴侶.

### 2026-09-10, iteration 4247 — [[words/伴侶|伴侶]]
Removed dangling empty `hsk_level`/`swadesh` fields, added legitimizing-note phrasing (侶's own `stand_in` is this exact compound). `characters:` confirmed correct (bare 伴/侶, no conflicting words exist), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (伴(char) true, 侶(char) false), no homophone collision. Content already good (attested bạn lữ life-companion term, 伴侶動物 usage example). Stamped `date-last-perfect: 2026-09-10`.

Next: 伶俐.

### 2026-09-10, iteration 4248 — [[words/伶俐|伶俐]]
Fixed relative-link paths in Notes (missing `../` prefix), removed dangling empty `hsk_level`/`swadesh`/`aliases`. Verified the `#cranberry` tag: both 伶's and 俐's own `stand_in` fields genuinely point to this exact compound, transitivity holds. `characters:` confirmed correct, both character-page citations already correctly ruby-formatted, `kwin: false` confirmed (both constituents independently false), no homophone collision. Content already good (previously-fixed hidden-zero-width-space Japanese bug still holds). Stamped `date-last-perfect: 2026-09-10`.

Next: 伸展.

### 2026-09-10, iteration 4249 — [[words/伸展|伸展]]
Removed dangling empty `hsk_level`/`swadesh`/`aliases: []`, added legitimizing-note phrasing (展's own `stand_in` is this exact compound). `characters:` confirmed correct (bare 伸/展, no conflicting words exist), both character-page citations already correctly ruby-formatted, `kwin: true` confirmed (both constituents independently true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 伸長.

### 2026-09-10, iteration 4250 — [[words/伸長|伸長]]
Removed dangling empty `hsk_level`/`swadesh`/`aliases: []`, added legitimizing-note phrasing (伸's own `stand_in` is this exact compound). Found and fixed a missing-citation bug: 伸長 was entirely absent from `長(char).md`'s Words list — added. `characters:` confirmed correct (`長 (char)` required, conflicting words/長.md exists). Re-verified the genuine homophone with [[腎臓]]. Noted (not fixed, out of this word's scope) that `長(char).md`'s own Words list is also missing a citation for the bare word [[長]] itself — flagged for that word's own alphabetical turn. Stamped `date-last-perfect: 2026-09-10`.

Next: 伺候.

### 2026-09-10, iteration 4251 — [[words/伺候|伺候]]
Removed dangling empty `hsk_level`/`swadesh`/`aliases: []`, added legitimizing-note phrasing (伺's own `stand_in` is this exact compound). `characters:` confirmed correct (bare 伺/候, no conflicting words exist), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed (both constituents independently false). Homophone with [[時候]] re-verified via anchored grep — genuine. Content already good (special cì reading distinction, literary-vs-everyday hầu register note). Stamped `date-last-perfect: 2026-09-10`.

Next: 似.

### 2026-09-10, iteration 4252 — [[words/似|似]]
Fixed duplicate `pos`/`品詞` (kept pos). Added the standard self-referential legitimizing-note phrasing (matching 事/于/之/亦/人/今/仍/他/令/以/伏/会/伍). Re-verified the genuine homophone with [[沙]] via anchored grep, confirming several character-only matches (飼/思/些/司/祠/寺/詞/糸) have no independent word pages. Citation on `似 (char).md` already correct. Content already outstanding (thorough similative-vs-comparative contrast with 比, extensive cross-linguistic examples). Stamped `date-last-perfect: 2026-09-10`.

Next: 但.

### 2026-09-10, iteration 4253 — [[words/但|但]]
Added the standard self-referential legitimizing-note phrasing (matching 事/于/之/亦/人/今/仍/他/令/以/伏/会/伍/似). Re-verified the genuine homophone with [[壇]] via anchored grep, confirming several character-only matches (単/丹/蛋/誕/弾/惮/旦/綻/檀/亶/簞) have no independent word pages. Citation on `但 (char).md` already correct. Content already outstanding (contrast with 不過, kwin phonological breakdown). Stamped `date-last-perfect: 2026-09-10`.

Next: 佇立.

### 2026-09-10, iteration 4254 — [[words/佇立|佇立]]
Removed dangling empty `hsk_level`/`swadesh`/`aliases` fields, added legitimizing-note phrasing (佇's own `stand_in` is this exact compound). `characters:` confirmed correct (bare 佇, no conflicting words/佇.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (佇(char) false overrides 立(char)'s own true), no homophone collision. Content already honest (no fixed Vietnamese idiom found, presented as compositional rather than fabricated attestation). Stamped `date-last-perfect: 2026-09-10`.

Next: 位相.

### 2026-09-10, iteration 4255 — [[words/位相|位相]]
Normalized inline-flow `characters:` to block-list format, filled a blank `pos: 名詞`, removed dangling empty `hsk_level`/`swadesh`/`aliases: []`, added missing `date-last-perfect`, wrote missing Notes. Corrected `vietnamese` from the overly-specific "pha sóng" ("wave phase") to the standard general physics term pha (as in độ lệch pha, "phase difference"). `characters:` confirmed correct (bare 位/相, no conflicting words exist), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (位(char) false overrides 相(char)'s own true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 位置.

### 2026-09-10, iteration 4256 — [[words/位置|位置]]
Removed dangling empty `hsk_level`/`swadesh`/`aliases: []`. `characters:` confirmed correct (`置 (char)` required, conflicting words/置.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (位(char) false overrides 置(char)'s own true), no homophone collision. Content already good (previously-fixed 位's own blank-vietnamese gap still holds). Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 位-prefixed word cluster.

Next: 低下.

### 2026-09-10, iteration 4257 — [[words/低下|低下]]
Normalized `characters:` indentation, removed dangling empty `hsk_level`/`swadesh`/`aliases`, added legitimizing-note phrasing (低's own `stand_in` is this exact compound). `characters:` confirmed correct (`下 (char)` required, conflicting words/下.md exists — verified separately), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (低(char) false overrides 下(char)'s own true), no homophone collision. Content already good (previously-fixed 低's own blank-vietnamese gap still holds). Stamped `date-last-perfect: 2026-09-10`.

Next: 低廉.

### 2026-09-10, iteration 4258 — [[words/低廉|低廉]]
Fixed missing disambiguation (bare `廉`→`廉 (char)`, since `words/廉.md` exists), removed dangling empty `hsk_level`/`swadesh`/`aliases`, merged a non-standard `## Etymology` heading into `## Notes`. Both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (低(char) false overrides 廉(char)'s own true), no homophone collision. Content already good (honest note on 廉's secondary "affordable" sense vs. its more familiar "honest, incorrupt" sense). Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 低-prefixed word cluster.

Next: 住宅.

### 2026-09-10, iteration 4259 — [[words/住宅|住宅]]
Removed dangling empty `hsk_level`/`swadesh`/`aliases` fields, added legitimizing-note phrasing (宅's own `stand_in` is this exact compound). `characters:` confirmed correct (bare 住/宅, no conflicting words exist), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (住(char) true, 宅(char) false), no homophone collision. Content already good (previously-fixed crammed-korean-gloss bug still holds). Stamped `date-last-perfect: 2026-09-10`.

Next: 佐理.

### 2026-09-10, iteration 4260 — [[words/佐理|佐理]]
Normalized `characters:` indentation, removed dangling empty `hsk_level`/`swadesh`/`aliases: []`, added legitimizing-note phrasing (佐's own `stand_in` is this exact compound). Re-verified [[体現]]'s own fields are clean, confirming no further cross-contamination from the previously-fixed copy-paste bug between these two alphabetically-adjacent pages. `characters:` confirmed correct, both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (佐(char) false overrides 理(char)'s own true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 体制.

### 2026-09-10, iteration 4261 — [[words/体制|体制]]
Fixed a missing `kwin` field entirely (added false, confirmed via AND-rule), added missing `date-last-perfect`, wrote fuller Notes. `characters:` confirmed correct (bare 体/制, no conflicting words exist), both character-page citations already correctly ruby-formatted, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 体液.

### 2026-09-10, iteration 4262 — [[words/体液|体液]]
Found and fixed a real YAML bug: `date-last-perfect` was duplicated as two separate keys with different values (2026-08-03 and 2026-06-20) — removed the stale duplicate. Fixed a missing `kwin` field entirely (added false, confirmed via AND-rule). `characters:` confirmed correct (bare 液, no conflicting words/液.md exists), both character-page citations already correctly ruby-formatted, no homophone collision. Content already good (previously-fixed vietnamese attestation correction, miễn dịch thể dịch immunology cross-reference). Stamped `date-last-perfect: 2026-09-10`.

Next: 体現.

### 2026-09-10, iteration 4263 — [[words/体現|体現]]
Fixed a spaced `mandarin` ("tǐ xiàn"→"tǐxiàn"), removed dangling empty `hsk_level`/`swadesh`/`aliases: []`. `characters:` confirmed correct (`現 (char)` required, conflicting words/現.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (体(char) false overrides 現(char)'s own true), no homophone collision. Re-confirmed this page's own fields are fully clean, with no residual cross-contamination from the earlier-found [[佐理]] copy-paste bug. Stamped `date-last-perfect: 2026-09-10`.

Next: 体積.

### 2026-09-10, iteration 4264 — [[words/体積|体積]]
Filled a blank `pos: 名詞`, removed dangling empty `swadesh`, added missing `date-last-perfect`, wrote missing Notes (merged from a non-standard `## Etymology` heading). `characters:` confirmed correct (bare 積, no conflicting words/積.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (体(char) false overrides 積(char)'s own true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 体系.

### 2026-09-10, iteration 4265 — [[words/体系|体系]]
Added missing `date-last-perfect` and the standard legitimizing-note phrasing alongside the existing informal note (体's own `stand_in` is this exact compound). `characters:` confirmed correct (bare 系, no conflicting words/系.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed (both constituents independently false), no homophone collision. Content already outstanding (thorough 体制/全体/液体系 contrast with 身体's concrete-body sense). Stamped `date-last-perfect: 2026-09-10`.

Next: 体育.

### 2026-09-10, iteration 4266 — [[words/体育|体育]]
Already in excellent shape. `characters:` confirmed correct (`育 (char)` required, conflicting words/育.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (体(char) false overrides 育(char)'s own true), no homophone collision. Content already outstanding (correctly notes neither constituent's own stand_in points here). Just refreshed `date-last-perfect: 2026-09-10`.

Next: 体育館.

### 2026-09-10, iteration 4267 — [[words/体育館|体育館]]
Found and fixed a real content bug: `vietnamese` had simply reused [[体育]]'s own "thể dục" verbatim, dropping 館's own "building/hall" contribution entirely — corrected to nhà thể dục. Fixed a typo ("nuture"→"nurture"), filled a blank `pos: 名詞`, removed dangling empty `hsk_level`/`swadesh`, merged a non-standard `## Etymology` heading into `## Notes`. `characters:` confirmed correct (bare 館, no conflicting words/館.md exists), all three character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (体(char) false overrides 育/館's own true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 体言.

### 2026-09-10, iteration 4268 — [[words/体言|体言]]
Removed dangling empty `hsk_level`/`swadesh` fields, merged a non-standard `## Etymology` heading into `## Notes`. `characters:` confirmed correct (`言 (char)` required, conflicting words/言.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (体(char) false overrides 言(char)'s own true), no homophone collision. Content already outstanding (体・用 substance/function philosophical origin, honest Chinese/Vietnamese attestation gaps). Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 体-prefixed word cluster.

Next: 何.

### 2026-09-10, iteration 4269 — [[words/何|何]]
Fixed duplicate `pos`/`品詞` (kept pos). Added the standard self-referential legitimizing-note phrasing (matching 事/于/之/亦/人/今/仍/他/令/以/伏/会/伍/似/但). Re-verified the genuine homophone with [[下]] via anchored grep, confirming several character-only matches (蝦/廈/霞/暇/賀/河/苛/呵/荷) have no independent word pages. Citation on `何 (char).md` already correct. Content already outstanding (full correlative-chart interrogative generation, honest note on modern Mandarin colloquial 什么/哪 displacement). Stamped `date-last-perfect: 2026-09-10`.

Next: 何事.

### 2026-09-10, iteration 4270 — [[words/何事|何事]]
Fixed duplicate `pos`/`品詞` (kept pos), a missing `korean` field entirely (filled 하사, the archaic compositional reading — matching the "archaic" register already documented in the Notes prose), and a missing `vietnamese` field (hà sự, honest compositional, matching the column's classical/literary character). `characters:` confirmed correct, both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (事(char) false overrides 何(char)'s own true), no homophone collision. Content already outstanding (full correlative-column classical-antecedent survey: 何事/何物/何人/何名/何処/何時/何様). Stamped `date-last-perfect: 2026-09-10`.

Next: 何人.

### 2026-09-10, iteration 4271 — [[words/何人|何人]]
**Major real content bug found and fixed**: `mandarin`/`cantonese`/`japanese`/`korean`/`vietnamese` had all been filled with the *semantic equivalents* this word's own Notes already discuss for contrast (誰/shéi, 邊個/bin1 go3, だれ, 누구, ai) — entirely different written words sharing no characters with 何人 — rather than the compound's own attested reading. Corrected to 何人's own compositional/attested forms: mandarin hérén (matching the classical reading already cited in this very page's own prose — the bug directly contradicted the page's own text), cantonese ho4 jan4, japanese なにびと (a real attested classical/literary word, as in 何人たりとも "no matter who"), korean 하인 (mechanical Sino-Korean composition, honestly noted as coinciding with the unrelated everyday word 하인 "servant"), vietnamese hà nhân (honest compositional). Fixed duplicate `pos`/`品詞`. Found and fixed a missing-citation bug on `人(char).md`; `何(char).md`'s own citation was already correct. `kwin: false` confirmed via AND-rule (人(char) false overrides 何(char)'s own true). Stamped `date-last-perfect: 2026-09-10`. **Watch for the same "real-equivalent-instead-of-own-reading" bug pattern on the other correlative-column entries** (何処/何時/何名/何様 etc. — 何処 due next).

Next: 何処.

### 2026-09-10, iteration 4272 — [[words/何処|何処]]
Confirmed the same real-equivalent-instead-of-own-reading bug found on [[何人]]: `mandarin`/`korean`/`vietnamese` had been filled with everyday semantic-equivalent words (哪裡/nǎlǐ, 어디, đâu) instead of 何処's own compositional reading; `cantonese` was missing entirely. Corrected to héchǔ/ho4 cyu2/하처/hà xử. Notably, `japanese: どこ` was correctly left untouched — 何処 really is read どこ as these exact characters in genuine everyday Japanese (unlike 何人/だれ, an entirely different character pair), so this is a real ateji-like exception, not the same bug. Fixed duplicate `pos`/`品詞`. `characters:` confirmed correct, both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (処(char) false overrides 何(char)'s own true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 何名.

### 2026-09-10, iteration 4273 — [[words/何名|何名]]
Confirmed the same real-equivalent-instead-of-own-reading bug on `mandarin`/`japanese`/`korean` (哪位/どなた/어느 분→hémíng/かめい/하명), with `cantonese`/`vietnamese` missing entirely (added ho4 ming4/hà danh). This page's own prose explicitly confirmed the bug: it already stated 何名 is "derived compositionally... not a borrowing" from どなた, unlike 何処's genuine どこ exception. Fixed duplicate `pos`/`品詞`. `characters:` confirmed correct, both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (名(char) false overrides 何(char)'s own true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 何多.

### 2026-09-10, iteration 4274 — [[words/何多|何多]]
Confirmed the same real-equivalent-instead-of-own-reading bug on ALL five language fields (多少/duōshǎo, 幾多/gei2 do1, いくら/いくつ, 얼마나, bao nhiêu — none of them readings of 何多 itself) — corrected to héduō/ho4 do1/かた/하다/hà đa. Honestly noted `korean: 하다` coincides with the unrelated common verb 하다 ("to do"), same category as [[何人]]'s own 하인 collision. Fixed duplicate `pos`/`品詞`. `characters:` confirmed correct, both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (多(char) false overrides 何(char)'s own true), no homophone collision. Content already good (previously-fixed 注音 ㄉㄚ→ㄉㄜ error, comma-separated-string-to-list fix still hold). Stamped `date-last-perfect: 2026-09-10`.

Next: 何故.

### 2026-09-10, iteration 4275 — [[words/何故|何故]]
Confirmed the same real-equivalent-instead-of-own-reading bug on `cantonese`/`japanese`/`korean`/`vietnamese` (點解/なぜ/왜/sao→ho4 gu3/かこ/하고/hà cớ) — `mandarin: hégù` was already correctly compositional. This correction flipped `kwin` from false to true, since the corrected compositional Sino-Korean 하고 now exactly matches the word's own stored 諺文. Honestly noted かこ's homograph risk with 過去 ("the past"). Removed dangling empty `hsk_level`/`swadesh`, merged a non-standard `## Etymology` heading, added missing `date-last-perfect`. `characters:` confirmed correct (bare 故, no conflicting words/故.md exists), both character-page citations already correctly ruby-formatted, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 何時.

### 2026-09-10, iteration 4276 — [[words/何時|何時]]
Found that `korean` had already gone through two rounds of the same underlying bug: first "몇 시" (mistranslation), then "corrected" to 언제 (real everyday word, but still not 何時's own reading) — the same real-equivalent-instead-of-own-reading bug found on the other 何-correlatives. Corrected to the genuine compositional 하시 (matching 時's own korean field), which exactly matches this word's own stored 諺文, flipping `kwin` false→true. Filled a missing `vietnamese` field (hà thì). `mandarin`/`cantonese` were already correctly compositional; `japanese: いつ` was correctly left untouched, as this page's own prose already establishes the genuine real-world orthographic identity (like [[何処]]/どこ). Removed a circular self-referential alias in a prior pass (already noted in the file). `characters:` confirmed correct, both character-page citations already correctly ruby-formatted, no homophone collision.

Next: 何様.

### 2026-09-10, iteration 4277 — [[words/何様|何様]]
Confirmed the same real-equivalent-instead-of-own-reading bug on ALL five language fields (怎麼樣/zěnmeyàng, 點樣/dim2 joeng6, どのように, 어떻게, như thế nào) — corrected to héyàng/ho4 joeng4/なにさま/하양/hà dạng. Notably `japanese: なにさま` turned out to be a genuine, real attested Japanese word (rhetorical "who do you think you are?!"), not mere compositional filler — a third case (with 何処/どこ, 何時/いつ) of a correlative whose Dan'a'yo-adjacent reading is also real in a source language. Correcting `korean` to 하양 exactly matched the word's own stored 諺文, flipping `kwin` false→true. Removed the `neologism` tag, which directly contradicted this page's own prose. `characters:` confirmed correct, both character-page citations already correctly ruby-formatted, no homophone collision. **Note**: [[何物]] (due next) is also part of this correlative family and still needs the same per-language check.

Next: 何物.

### 2026-09-10, iteration 4278 — [[words/何物|何物]]
Filled `cantonese`/`korean`/`vietnamese` fields entirely missing from frontmatter (ho4 mat6, 하물, hà vật, all compositional) — `mandarin: héwù` and `japanese: なにもの` were already correctly 何物's own genuine readings, both explicitly confirmed in this page's own prose. Fixed duplicate `pos`/`品詞`, standardized a non-standard `>[!info]` homophone callout to the vault's usual `>[!warning] Homophones` format. `characters:` confirmed correct, both character-page citations already correctly ruby-formatted. Homophone with [[荷物]] re-verified as genuine via anchored grep. Stamped `date-last-perfect: 2026-09-10`. **Note**: [[何類]] (due next) is yet another 何-correlative-family word not previously known — needs the same per-language check.

Next: 何類.

### 2026-09-10, iteration 4279 — [[words/何類|何類]]
Confirmed the same real-equivalent-instead-of-own-reading bug on all five language fields (哪種/邊種/どんな/무슨/loại nào), compounded by a prior pass that had already "corrected" the mandarin/cantonese fields from an even-worse earlier value (什麼/甚麼) to a still-wrong equivalent (哪種/邊種) without ever landing on the headword's own reading. Corrected to hélèi/ho4 leoi6/かるい/하류/hà loại, honestly noting かるい/하류 as coincidental homographs with unrelated common words (軽い "light," 下流 "downstream"). Fixed duplicate `pos`/`品詞`, removed the `neologism` tag. `characters:` confirmed correct, both character-page citations already correctly ruby-formatted, `kwin: false` confirmed (still diverges from the corrected compositional Sino-Korean). No homophone collision. Stamped `date-last-perfect: 2026-09-10`. **This closes out the entire 何-prefixed correlative-family investigation** — 何/何事/何人/何処/何名/何多/何故/何時/何様/何物/何類 (11 words), with the real-equivalent bug found and fixed on 9 of them.

Next: 余割.

### 2026-09-10, iteration 4280 — [[words/余割|余割]]
Fixed a missing `korean` field entirely (filled 여할, compositional), normalized inline-flow `characters:`/`aliases: [餘割]` to block-list format, added missing `kwin`/`date-last-perfect`, wrote missing Notes cross-referencing the sibling trig terms [[余弦]]/[[余接]]. Upgraded a bare-format citation on `割 (char).md`; `余.md`'s own citation was already correct. `characters:` confirmed correct (bare 余, no conflicting words/余.md exists), `kwin: false` confirmed (both constituents independently false), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 余弦.

### 2026-09-10, iteration 4281 — [[words/余弦|余弦]]
Removed dangling empty `hsk_level`/`swadesh` fields. `characters:` confirmed correct (`弦 (char)` required, conflicting words/弦.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed (both constituents independently false), no homophone collision. Content already outstanding (Johann Schreck's 大測 (1631) coinage history, honest documentation of Vietnamese's exclusive-loanword usage vs. Korean's surviving formal term). Stamped `date-last-perfect: 2026-09-10`.

Next: 余接.

### 2026-09-10, iteration 4282 — [[words/余接|余接]]
Normalized inline-flow `characters:` to block-list format, removed dangling empty `hsk_level`/`swadesh`/`aliases: []`, merged a stray unheaded line and a non-standard `## Etymology` heading into `## Notes`, upgraded the bare "正接" mention to a proper wikilink. `characters:` confirmed correct (`接 (char)` required, conflicting words/接.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed (both constituents independently false), no homophone collision. Content already good (parallel with 余弦's own 여현/côsin pattern). Stamped `date-last-perfect: 2026-09-10`.

Next: 余波.

### 2026-09-10, iteration 4283 — [[words/余波|余波]]
Normalized inline-flow `characters:`/`aliases: [餘波]` to block-list format, fixed a comma-joined `japanese` string into a proper YAML list, removed dangling empty `hsk_level`/`swadesh`, merged a non-standard `## Etymology` heading into `## Notes`. `characters:` confirmed correct (bare 波, no conflicting words/波.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed (both constituents independently false), no homophone collision. Content already good (attested dư ba "remaining waves/ripples"). Stamped `date-last-perfect: 2026-09-10`.

Next: 余震.

### 2026-09-10, iteration 4284 — [[words/余震|余震]]
Normalized inline-flow `characters:`/`aliases: [餘震]` to block-list format, removed dangling empty `hsk_level`/`swadesh`, added missing `date-last-perfect`, wrote missing Notes (merged from a non-standard `## Etymology` heading). `characters:` confirmed correct (bare 震, no conflicting words/震.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (余(char) false overrides 震(char)'s own true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 余-prefixed word cluster.

Next: 佛.

### 2026-09-10, iteration 4285 — [[words/佛|佛]]
Fixed a missing `japanese` field entirely (filled ぶつ, 佛(char)'s own first-listed on'yomi BUTSU, per the established convention). Added the standard self-referential legitimizing-note phrasing. Citation on `佛 (char).md` already correct, no homophone collision. Content already excellent (Sanskrit *buddha* transliteration history, honest flagging of a phất contamination candidate from an unrelated 弗-phonetic character). Stamped `date-last-perfect: 2026-09-10`.

Next: 佛教.

### 2026-09-10, iteration 4286 — [[words/佛教|佛教]]
Fixed mis-capitalized vietnamese (phật giáo→Phật giáo, matching [[佛]]'s own capitalized proper-noun Phật), removed dangling empty `hsk_level`/`swadesh`, added missing `date-last-perfect`, wrote missing Notes. Found and fixed a missing-citation bug: 佛教 was entirely absent from `佛(char).md`'s Words list — added; `教.md`'s own citation was already correct. `characters:` confirmed correct (bare 教, no conflicting words/教.md exists), `kwin: false` confirmed via AND-rule (教(char) false overrides 佛(char)'s own true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 佛陀.

### 2026-09-10, iteration 4287 — [[words/佛陀|佛陀]]
Fixed a capitalized `mandarin` ("Fótuó"→"fótuó", matching [[佛]]'s own lowercase pinyin convention), removed dangling empty `hsk_level`/`swadesh`/`aliases`. Found and fixed a missing-citation bug: 佛陀 was entirely absent from both `佛(char).md`'s and `陀.md`'s own Words lists (only mentioned in etymology prose on the former) — added to both. `characters:` confirmed correct (bare 陀, no conflicting words/陀.md exists), `kwin: false` confirmed via AND-rule (陀(char) false overrides 佛(char)'s own true), no homophone collision. Content already good (Sanskrit *buddhá* transliteration, formal Phật Đà vs. everyday Phật distinction). Stamped `date-last-perfect: 2026-09-10`.

Next: 佛雷素.

### 2026-09-10, iteration 4288 — [[words/佛雷素|佛雷素]]
Already in excellent shape. `characters:` confirmed correct (`雷 (char)` required, conflicting words/雷.md exists; bare 素 correct, no conflict), all three character-page citations already correctly ruby-formatted, `kwin: false` confirmed correct (word's own 諺文 diverges entirely from the loanword-based Korean field). Content already outstanding — one of the periodic-table neologism entries, thoroughly self-aware about why this specific coinage's mandarin/cantonese hold direct compositional readings rather than the avoided single-character alternative 鈇/𫓧, following the established "-i" Vietnamese suffix pattern. Just refreshed `date-last-perfect: 2026-09-10`. This closes out the entire 佛-prefixed word cluster.

Next: 作.

### 2026-09-10, iteration 4289 — [[words/作|作]]
Fixed a broken Homophones callout (stray blank line breaking Obsidian syntax), added the standard self-referential legitimizing-note phrasing. Found and fixed a real missing-citation bug: the word 作 itself was entirely absent from `作(char).md`'s own Words list despite being its stand-in — added. Re-verified the genuine homophone with [[昨]] via anchored grep, confirming several character-only matches (雀/爵/炸/搾/宅/酢/灼/酌/窄/責/捉) have no independent word pages. Stamped `date-last-perfect: 2026-09-10`.

Next: 作坊.

### 2026-09-10, iteration 4290 — [[words/作坊|作坊]]
Fixed missing disambiguation (`characters:` cited bare `作` instead of the parent filename `作 (char)`), fixed relative-link paths in Notes (missing `../` prefix), removed dangling empty `hsk_level`/`swadesh`/`aliases`, added legitimizing-note phrasing (坊's own `stand_in` is this exact compound). Found and fixed a missing-citation bug on `作(char).md`; `坊.md`'s own citation was already correct. `kwin: false` confirmed via AND-rule (作(char) true, 坊(char) false), no homophone collision. Content already excellent (honest Chinese-specific-term note distinguishing from 工房/工作室, cross-linguistic real-equivalent documentation). Stamped `date-last-perfect: 2026-09-10`.

Next: 作業.

### 2026-09-10, iteration 4291 — [[words/作業|作業]]
Already in excellent shape. `characters:` confirmed correct, both character-page citations already correctly ruby-formatted, `kwin: true` confirmed (both constituents independently true), no homophone collision. Content already outstanding (honest Japanese 宿題-vs-作業 homework distinction, Vietnamese tác nghiệp's narrower professional-register note vs. công tác). Just refreshed `date-last-perfect: 2026-09-10`.

Next: 作用.

### 2026-09-10, iteration 4292 — [[words/作用|作用]]
Fixed missing disambiguation (bare `作`→`作 (char)`, since `words/作.md` exists), removed dangling empty `hsk_level`/`swadesh`/`aliases`, added missing `date-last-perfect`, wrote missing Notes. `characters:` confirmed correct (bare 用, no conflicting words/用.md exists), both character-page citations already correctly ruby-formatted, `kwin: true` confirmed (both constituents independently true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 作-prefixed word cluster.

Next: 佩戴.

### 2026-09-10, iteration 4293 — [[words/佩戴|佩戴]]
Fixed missing `japanese`/`vietnamese` fields entirely (filled はいたい/bội đái, honest compositional, no independent attestation found), added legitimizing-note phrasing (佩's own `stand_in` is this exact compound). `characters:` confirmed correct (bare 佩, no conflicting words/佩.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed (both constituents independently false), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 佳.

### 2026-09-10, iteration 4294 — [[words/佳|佳]]
Fixed a missing `japanese` field entirely (filled か, 佳(char)'s only on'yomi candidate KA). Added the standard self-referential legitimizing-note phrasing. Citation on `佳 (char).md` already correct. Confirmed the character-only match 街 has no independent word page. Content already excellent (honest note on 佳's own dai/lai/trai corpus-contamination candidates, 解 homophone flagged for its own turn). Stamped `date-last-perfect: 2026-09-10`.

Next: 佳人.

### 2026-09-10, iteration 4295 — [[words/佳人|佳人]]
Fixed missing disambiguation (bare `人`→`人 (char)`, since `words/人.md` exists), normalized indentation, removed dangling empty `hsk_level`/`swadesh`/`aliases`, added missing `date-last-perfect`, wrote missing Notes. Upgraded a bare numbered-list citation on `人(char).md` (item 11); `佳 (char).md`'s own citation was already correct. `kwin: false` confirmed (both constituents independently false), no homophone collision. Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 佳-prefixed word cluster.

Next: 使徒.

### 2026-09-10, iteration 4296 — [[words/使徒|使徒]]
Added missing `date-last-perfect`. Fixed a malformed reference where "使徒" plain text was glued directly to a broken `[[行傳]]` wikilink (neither 使徒行傳 nor 行傳 has its own vault page yet) — unwrapped into plain text with an honest note rather than a dangling broken link. `characters:` confirmed correct (bare 使/徒, no conflicting words exist), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (使(char) false overrides 徒(char)'s own true), no homophone collision. Content already good (honest Protestant/Orthodox vs. Catholic [[宗徒]] terminology distinction). Stamped `date-last-perfect: 2026-09-10`.

Next: 使用.

### 2026-09-10, iteration 4297 — [[words/使用|使用]]
Reworded the informal stand-in note into the standard legitimizing-note phrasing (用's own `stand_in` is this exact compound), added explicit `kwin` AND-rule reasoning. `characters:` confirmed correct, both character-page citations already correctly ruby-formatted, no homophone collision. Content already outstanding (使用説明書/사용설명서 cross-reference, "no native displacement or homophone collision found" honesty note). Stamped `date-last-perfect: 2026-09-10`.

Next: 使者.

### 2026-09-10, iteration 4298 — [[words/使者|使者]]
Removed dangling empty `hsk_level`/`swadesh`/`aliases: []`, added legitimizing-note phrasing (使's own `stand_in` is this exact compound). `characters:` confirmed correct (`者 (char)` required, conflicting words/者.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed (both constituents independently false). Re-verified the 3-way homophone group (使者/侍者/時差) via anchored grep — genuine. Content already good (previously-fixed pinyin-instead-of-jyutping cantonese bug still holds). Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 使-prefixed word cluster.

Next: 侍奉.

### 2026-09-10, iteration 4299 — [[words/侍奉|侍奉]]
Fixed a Japanese full-width-comma-joined `japanese` field into a proper YAML list, removed dangling empty `hsk_level`/`swadesh`, added legitimizing-note phrasing (奉's own `stand_in` is this exact compound). `characters:` confirmed correct (bare 侍/奉, no conflicting words exist), both character-page citations already correctly ruby-formatted, `kwin: true` confirmed (both constituents independently true), no homophone collision. Content already good (attested 시봉하다, parallels with phụng dưỡng/cung phụng). Stamped `date-last-perfect: 2026-09-10`.

Next: 侍者.

### 2026-09-10, iteration 4300 — [[words/侍者|侍者]]
Removed dangling empty `hsk_level`/`swadesh`/`aliases: []`, added legitimizing-note phrasing (侍's own `stand_in` is this exact compound). `characters:` confirmed correct (`者 (char)` required, conflicting words/者.md exists), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed (侍(char) true, 者(char) false). Homophone callout with [[使者]]/[[時差]] already complete and correct. Content already good (Sanskrit antevāsin parallel for the Buddhist attendant sense). Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 侍-prefixed word cluster. Milestone: iteration 4300.

Next: 侏儒.

### 2026-09-10, iteration 4301 — [[words/侏儒|侏儒]]
Fixed a real formatting bug: `vietnamese` was a broken two-item list `[chu, nhu]` (each character's own bare first-candidate syllable, never combined) instead of the single compositional value "chu nhu" — corrected. Normalized `characters:` indentation, removed dangling empty `hsk_level`/`swadesh`/`aliases`, added missing `date-last-perfect`, wrote missing Notes with legitimizing-note phrasing (侏's own `stand_in` is this exact compound). `characters:` confirmed correct (bare 侏/儒, no conflicting words exist), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed via AND-rule (侏(char) true, 儒(char) false), no homophone collision. Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 侏-prefixed word cluster.

Next: 供給.

### 2026-09-10, iteration 4302 — [[words/供給|供給]]
Removed dangling empty `hsk_level`/`swadesh`/`aliases` fields. `characters:` confirmed correct (bare 供/給, no conflicting words exist), both character-page citations already correctly ruby-formatted, `kwin: false` confirmed (both constituents independently false), no homophone collision. Content already good (供給と需要 real usage example, attested cung cấp). Stamped `date-last-perfect: 2026-09-10`. This closes out the entire 供-prefixed word cluster.

Next: 依.

### 2026-09-10, iteration 4303 — [[words/依|依]]
Added the standard self-referential legitimizing-note phrasing, expanded thin Notes. Found and fixed a real missing-citation bug: the word 依 itself was entirely absent from `依(char).md`'s own Words list despite being its stand-in — added. Verified several character-only homophone matches (伊/羨/衣/懿/姨/胰/夷/毅) have no independent word pages. Stamped `date-last-perfect: 2026-09-10`.

Next: 依存.

### 2026-09-10, iteration 4304 — [[words/依存|依存]]
Fixed a malformed reference where "相互" was wikilinked but glued to plain-text "依存" (相互依存 has no dedicated vault page yet) — unwrapped with an honest note. Filled a missing `vietnamese` field entirely (y tồn, honest compositional, noting the more common everyday native phụ thuộc). `characters:` confirmed correct (bare 存, no conflicting words/存.md exists), both character-page citations already correctly ruby-formatted, `kwin: true` confirmed (both constituents independently true), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 依拠.

### 2026-09-10, iteration 4305 — [[words/依拠|依拠]]
Disambiguated bare 依 to "依 (char)" (words/依.md exists — confirmed via `ls`); converted inline-flow `characters:` to block list; removed dangling blank `hsk_level:`/`swadesh:`/empty `aliases: []`; merged non-standard `## Etymology` heading into `## Notes`. Added a legitimizing note for 拠, whose own `stand_in` points to this word (依拠) — confirmed via reading 拠.md. `kwin: false` confirmed correct (own 諺文 의교 vs own korean 의거 genuinely diverge). No homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 依然.

### 2026-09-10, iteration 4306 — [[words/依然|依然]]
Disambiguated bare 依 to "依 (char)" (words/依.md exists); converted inline-flow `characters:` to block list; removed dangling blank `hsk_level:`/`swadesh:`/empty `aliases: []`; merged `## Etymology` into `## Notes`. **Found and fixed a missing homophone callout**: 依然 shares 注音 ㄧㄜㄋ⼶ㄋ with [[毅然]] (confirmed via anchored grep) — added standard `>[!warning] Homophones` callout plus prose mention. Reciprocal callout on 毅然's own page deferred to its own alphabetical turn (also noted: 毅然 is missing a `vietnamese` field entirely — flag for that turn too). Both character-page citations (依(char), 然(char)) already correctly present. Stamped `date-last-perfect: 2026-09-10`.

Next: 依頼.

### 2026-09-10, iteration 4307 — [[words/依頼|依頼]]
Disambiguated bare 依 to "依 (char)" (words/依.md exists); removed dangling blank `hsk_level:`/`swadesh:`. Added a missing legitimizing note for 頼, whose own `stand_in` points to this word (confirmed via reading 頼.md). Both character-page citations already correctly present, `kwin: false` and `aliases:` list already correct from a prior pass, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 侠客.

### 2026-09-10, iteration 4308 — [[words/侠客|侠客]]
Removed duplicate `品詞` key (kept `pos`). Fixed broken relative links in Notes prose (bare `characters/X.md` missing the `../` prefix used everywhere else in the vault). Replaced casual stand-in prose with the standard legitimizing-note phrasing (侠's own `stand_in` points to this word, confirmed via reading 侠(char).md). `characters:` (bare 侠, 客) confirmed correct via `ls` (no conflicting word files), both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 価値.

### 2026-09-10, iteration 4309 — [[words/価値|価値]]
Removed dangling blank `swadesh:`/`aliases:`. Standardized casual stand-in prose into the standard legitimizing-note phrasing (値's own `stand_in` confirmed pointing to this word). `characters:` (bare 価, 値) confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed, reciprocal homophone callout with [[加持]] already correctly present on both pages. Stamped `date-last-perfect: 2026-09-10`.

Next: 価格.

### 2026-09-10, iteration 4310 — [[words/価格|価格]]
Quoted bare `hsk_level: 2` → `"2"` (string convention); removed dangling blank `swadesh:`. Replaced the non-standard `>[!tip]` stand-in callout with a proper Notes paragraph plus the standard legitimizing-note phrasing (価's own `stand_in` confirmed pointing to this word). `characters:` confirmed correct ("格 (char)" disambiguation verified necessary via `ls words/格.md`), both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 侮辱.

### 2026-09-10, iteration 4311 — [[words/侮辱|侮辱]]
Removed dangling blank `hsk_level:`/`swadesh:`/`aliases:`; merged `## Etymology` into `## Notes`. Added a missing legitimizing note for 侮, whose own `stand_in` points to this word (confirmed via reading 侮.md). `characters:` (bare 侮, 辱) confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 侯.

### 2026-09-10, iteration 4312 — [[words/侯|侯]]
Filled a missing `japanese` field (こう, compositional from 侯(char)'s own KOU on'yomi). Added a missing self-referential legitimizing note (侯(char)'s own `stand_in` points to itself). `characters:` correct, citation on 侯(char).md already present, `kwin: false` confirmed, homophone callout with [[厚]]/[[吼]] already correctly present (reciprocal halves deferred to each word's own turn, per existing note). Stamped `date-last-perfect: 2026-09-10`.

Next: 侵入.

### 2026-09-10, iteration 4313 — [[words/侵入|侵入]]
Removed duplicate `品詞` key (kept `pos`); flattened single-item `japanese`/`vietnamese` lists to scalar values. Replaced casual stand-in prose with the standard legitimizing-note phrasing (侵's own `stand_in` confirmed pointing to this word). `characters:` confirmed correct via `ls` (bare 侵, disambiguated 入 (char)), both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 侵犯.

### 2026-09-10, iteration 4314 — [[words/侵犯|侵犯]]
Fixed unindented `characters:` list items to standard 2-space indent; removed dangling blank `hsk_level:`/`swadesh:`/`aliases:`; filled a missing `date-last-perfect` entirely; merged the thin `## Etymology` heading into a proper `## Notes` section with full readings synthesis, kwin/homophone verification. `characters:` (bare 侵, 犯) confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 侵略.

### 2026-09-10, iteration 4315 — [[words/侵略|侵略]]
Removed dangling blank `hsk_level:`/`swadesh:`/`aliases:`; filled a missing `date-last-perfect` entirely; merged the thin `## Etymology` heading into a proper `## Notes` section with full readings synthesis. `characters:` (bare 侵, disambiguated 略 (char)) confirmed correct via `ls`, both character-page citations already present, `kwin: true` confirmed (own 諺文 침략 matches own korean 침략 exactly), no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 便.

### 2026-09-10, iteration 4316 — [[words/便|便]]
Removed duplicate `品詞` key (kept `pos`); flattened single-item `japanese` list to scalar. Added a missing self-referential legitimizing note (便(char)'s own `stand_in` points to itself). Confirmed the character-only 注音 matches (編/卞/鞭) have no independent word pages, so aren't real homophone collisions beyond the already-noted [[変]]. `kwin: false` confirmed. Stamped `date-last-perfect: 2026-09-10`.

Next: 便乗.

### 2026-09-10, iteration 4317 — [[words/便乗|便乗]]
Filled a missing `vietnamese` field with honest compositional "tiện thừa" (no independently attested Vietnamese loanword found for this sense); closed up mandarin "biàn chéng" → "biànchéng" to match compound-reading convention. **Found and fixed a missing citation** on 便(char).md's own Words list (便乗 was documented on 乗(char).md but never cited back on 便(char).md); also fixed a malformed `vietnamese` list there (was "tiện, biền" crammed into one item). `characters:` confirmed correct via `ls`, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-10`.

Next: 便宜.

### 2026-09-10, iteration 4318 — [[words/便宜|便宜]]
Already fully compliant from a thorough prior pass (heteronym-pair correction, cross-linguistic asymmetry disclosure, vietnamese field all previously fixed) — re-verified `characters:`, both citations, `kwin: false`, and no homophone collision; no changes needed beyond the date stamp. Stamped `date-last-perfect: 2026-09-10`.

Next: 便箋.

### 2026-09-11, iteration 4319 — [[words/便箋|便箋]]
Removed dangling blank `hsk_level:`/`swadesh:`/`aliases:`. Added a missing legitimizing note for 箋 (its own `stand_in` points to this word). **Found and fixed a missing citation** on 便(char).md's own Words list (便箋 was documented on 箋.md but never cited back on 便(char).md). `characters:` confirmed correct, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11` (date rolled over).

Next: 促.

### 2026-09-11, iteration 4320 — [[words/促|促]]
Filled a missing `japanese` field (そく, matching 促(char)'s own SOKU on'yomi, already documented in prose but absent from frontmatter). Added a missing self-referential legitimizing note. Confirmed character-only 注音 matches (燭, 触) have no independent word pages, so aren't real homophone collisions. `kwin: true` confirmed exact match. Stamped `date-last-perfect: 2026-09-11`.

Next: 俄然.

### 2026-09-11, iteration 4321 — [[words/俄然|俄然]]
Removed dangling blank `hsk_level:`/`swadesh:`/empty `aliases: []`. Fixed broken relative links in Notes prose (missing `../` prefix). Added a missing legitimizing note for 俄, whose own `stand_in` points to this word. `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 俄雨.

### 2026-09-11, iteration 4322 — [[words/俄雨|俄雨]]
Fixed broken relative links in Notes prose (missing `../` prefix). Added `kwin`/homophone verification sentence to Notes. `characters:` confirmed correct via `ls` (bare 俄, disambiguated 雨 (char)), both character-page citations already present, `kwin: true` confirmed (own 諺文 아우 matches own korean 아우 exactly), no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 俊傑.

### 2026-09-11, iteration 4323 — [[words/俊傑|俊傑]]
Fixed unindented `characters:` list to standard 2-space indent; removed dangling blank `hsk_level:`/`swadesh:`/`aliases:`; merged `## Etymology` into `## Notes`. Added a missing legitimizing note for 俊, whose own `stand_in` points to this word. `characters:` (bare 俊, 傑) confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed correct from a prior pass, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 俊馬.

### 2026-09-11, iteration 4324 — [[words/俊馬|俊馬]]
Standardized a wikilink-vs-markdown-link inconsistency (`[[俊]]` → `[俊](../characters/俊.md)`, matching the sibling constituent's format). Added `kwin`/homophone verification sentence. Confirmed 駿/骏 aliases on 俊.md support the prose's alias explanation, both character-page citations already present, `kwin: true` confirmed exact match, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 俗.

### 2026-09-11, iteration 4325 — [[words/俗|俗]]
Filled a missing `japanese` field (ぞく, already documented in prose but absent from frontmatter). Added a missing self-referential legitimizing note. Confirmed the character-only 注音 match (蜀) has no independent word page, so isn't a real homophone collision beyond the already-noted [[速]]. `kwin: true` confirmed. Stamped `date-last-perfect: 2026-09-11`.

Next: 俘虜.

### 2026-09-11, iteration 4326 — [[words/俘虜|俘虜]]
Removed dangling blank `hsk_level:`/`swadesh:`/empty `aliases: []`. Fixed broken relative links in Notes prose (missing `../` prefix). Re-verified `#cranberry` tag transitivity (both 俘 and 虜's own `stand_in` point to this word, A=B=AB confirmed). Both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 保存.

### 2026-09-11, iteration 4327 — [[words/保存|保存]]
Fixed unindented `characters:` list; quoted bare `hsk_level: 2` → `"2"`; removed dangling blank `swadesh:`/`aliases:`. `characters:` (bare 保, 存) confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 保持.

### 2026-09-11, iteration 4328 — [[words/保持|保持]]
Removed dangling blank `swadesh:`/`aliases:`. Replaced casual "viable form of 保" prose with the standard legitimizing-note phrasing (保's own `stand_in` confirmed pointing to this word). **Found and fixed a missing "(stand-in for 保)" suffix** on 保.md's own citation for this word. Confirmed 持(char).md's `vietnamese` list (previously fixed) is still correctly formatted. `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 保母.

### 2026-09-11, iteration 4329 — [[words/保母|保母]]
Removed dangling blank `hsk_level:`/`swadesh:`. `characters:` (bare 保, 母) confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 保留.

### 2026-09-11, iteration 4330 — [[words/保留|保留]]
Disambiguated bare 留 to "留 (char)" (words/留.md exists — confirmed via `ls`; the frontmatter/prose were already inconsistent, prose already used the disambiguated form). Fixed unindented `characters:` list, quoted `hsk_level`, removed dangling blank `swadesh:`/`aliases:`, filled a missing `date-last-perfect` entirely, merged the thin `## Etymology` heading into a proper `## Notes` section. Both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 保衛.

### 2026-09-11, iteration 4331 — [[words/保衛|保衛]]
Filled an entirely-missing `japanese` field with honest compositional "ほえい" (no attested Japanese loanword found — Japanese uses 防衛 for this sense instead). Fixed inline-flow `characters:` list; removed dangling blank `hsk_level:`/`swadesh:`/empty `aliases: []`; filled a missing `date-last-perfect` entirely; merged the thin `## Etymology` heading into a proper `## Notes` section. `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed. Stamped `date-last-perfect: 2026-09-11`.

Next: 保証.

### 2026-09-11, iteration 4332 — [[words/保証|保証]]
**Found and fixed a nonsensical `english` gloss entry**: "sweat" had no plausible relation to 保証's actual meaning — removed (kept "ensure/attest/stipulate/vouch", matching both character-page citations). Fixed unindented `characters:` list, inline-flow `aliases:` list; removed dangling blank `hsk_level:`/`swadesh:`; merged the thin `## Etymology` heading into a proper `## Notes` section; filled a missing `date-last-perfect` entirely. `characters:` (bare 保, 証) confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 保護.

### 2026-09-11, iteration 4333 — [[words/保護|保護]]
Fixed a typo ("sheild" → "shield"), an unspaced cantonese field, quoted bare `hsk_level`, removed a dangling blank `swadesh:`, and filled a missing `date-last-perfect` entirely. `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 保険.

### 2026-09-11, iteration 4334 — [[words/保険|保険]]
Disambiguated bare 険 to "険 (char)" (words/険.md exists — confirmed via `ls`; prose was already using the disambiguated form, frontmatter wasn't). Fixed unindented `characters:` list, inline-flow `aliases:` list, quoted bare `hsk_level`, removed dangling blank `swadesh:`, merged thin `## Etymology` into proper `## Notes`. Both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 信任.

### 2026-09-11, iteration 4335 — [[words/信任|信任]]
Filled a blank `pos:` (事詞), fixed inline-flow `characters:` list, removed dangling blank `hsk_level:`/`swadesh:`/empty `aliases: []`, filled an entirely-missing `date-last-perfect`, and wrote a `## Notes` section from scratch (page previously had none). Added a missing legitimizing note for 信, whose own `stand_in` points to this word. `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 信天翁.

### 2026-09-11, iteration 4336 — [[words/信天翁|信天翁]]
Fixed inline-flow `characters:` list, removed dangling blank `hsk_level:`/`swadesh:`/empty `aliases: []`, filled entirely-missing `date-last-perfect`, wrote a `## Notes` section from scratch. **Found and fixed a Japanese typo** (あはうどり → あほうどり). Replaced the overly-specific taxonomic `vietnamese` value ("Họ Hải âu mày đen," a single species' formal name) with the general everyday word hải âu. `characters:` confirmed correct via `ls` (both 天/翁 disambiguation necessary), all three character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 信奉.

### 2026-09-11, iteration 4337 — [[words/信奉|信奉]]
Fixed inline-flow `characters:` list; removed dangling blank `hsk_level:`/`swadesh:`/empty `aliases: []`; merged `## Etymology` into `## Notes`. `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: true` confirmed exact match, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 信徒.

### 2026-09-11, iteration 4338 — [[words/信徒|信徒]]
Removed dangling blank `hsk_level:`/`swadesh:`/empty `aliases: []`. Added a missing legitimizing note for 徒, whose own `stand_in` points to this word. `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: true` confirmed exact match, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 信条.

### 2026-09-11, iteration 4339 — [[words/信条|信条]]
Removed duplicate `品詞` key, flattened single-item lists, fixed a garbled all-caps gloss ("LONG-THIN" → proper "clause, article; classifier for long, thin objects"), filled a missing `date-last-perfect` entirely, wrote a proper `## Notes` paragraph (avoiding the previously-flagged incorrect 会意 mischaracterization noted on 条(char).md). **Found and fixed a raw-markdown-link-instead-of-wikilink citation** on 条(char).md's own Words list. `characters:` confirmed correct via `ls`, `kwin: true` confirmed exact match, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 信用.

### 2026-09-11, iteration 4340 — [[words/信用|信用]]
Fixed inline-flow `characters:` list, quoted bare `hsk_level`, removed dangling blank `swadesh:`/empty `aliases: []`, merged `## Etymology` into `## Notes`. `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: true` confirmed exact match, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 修理.

### 2026-09-11, iteration 4341 — [[words/修理|修理]]
Fixed inline-flow `characters:` list, removed dangling blank `hsk_level:`/`swadesh:`/empty `aliases: []`, merged `## Etymology` into `## Notes`. Added a missing legitimizing note for 修, whose own `stand_in` points to this word. `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 修繕.

### 2026-09-11, iteration 4342 — [[words/修繕|修繕]]
Fixed inline-flow `characters:`/`aliases:` lists; removed dangling blank `hsk_level:`/`swadesh:`. Added a missing legitimizing note for 繕, whose own `stand_in` points to this word. **Found and fixed a missing citation** on 修.md's own Words list (修繕 was documented on 繕.md but never cited back on 修.md). `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 修補.

### 2026-09-11, iteration 4343 — [[words/修補|修補]]
Fixed inline-flow `characters:` list, an unspaced cantonese field, removed dangling blank `hsk_level:`/`swadesh:`/empty `aliases: []`, merged `## Etymology` into `## Notes`. Added a missing legitimizing note for 補, whose own `stand_in` points to this word. Both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 修道.

### 2026-09-11, iteration 4344 — [[words/修道|修道]]
Added `kwin`/homophone verification sentence. **Found and fixed a typo** on 道(char).md's own citation ("spiritual disciple" → "spiritual discipline"). `characters:` confirmed correct via `ls` (道 (char) disambiguation necessary), both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 修道院.

### 2026-09-11, iteration 4345 — [[words/修道院|修道院]]
Added `kwin`/homophone verification sentence. `characters:` confirmed correct via `ls` (bare 院, 道 (char) disambiguation necessary), all three character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 修飾語.

### 2026-09-11, iteration 4346 — [[words/修飾語|修飾語]]
Removed dangling blank `hsk_level:`/`swadesh:`/`aliases:`. `characters:` confirmed correct via `ls`, all three character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 俯仰.

### 2026-09-11, iteration 4347 — [[words/俯仰|俯仰]]
Filled a missing `vietnamese` field with honest compositional "phủ ngưỡng" (no attested loanword found); filled an entirely-missing `date-last-perfect`. Replaced casual stand-in prose with the standard legitimizing-note phrasing (俯's own `stand_in` confirmed pointing to this word; verified 仰's own `stand_in` is a different word, [[仰望]], so no cranberry transitivity applies here). Both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 俯瞰.

### 2026-09-11, iteration 4348 — [[words/俯瞰|俯瞰]]
Filled a missing `vietnamese` field with honest compositional "phủ khám" (no attested loanword found); standardized wikilinks to the constituent character pages into the standard markdown-link format. Added a missing legitimizing note for 瞰, whose own `stand_in` points to this word. Both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 俳優.

### 2026-09-11, iteration 4349 — [[words/俳優|俳優]]
**Found and fixed a real-equivalent-word-instead-of-own-reading bug**: `japanese` had been filled with 役者 (yakusha, a completely different Japanese word for "actor," different characters entirely) instead of 俳優's own reading — corrected to はいゆう. **Found and fixed a bad aliases entry**: 演員/演员 (the standard Mandarin word for "actor," unrelated characters) had been listed as if they were spelling variants of 俳優 — removed, keeping only genuine simplified form 俳优. Removed dangling blank `hsk_level:`/`swadesh:`; filled entirely-missing `date-last-perfect`; merged `## Etymology` into `## Notes`; fixed broken relative links. Added a missing legitimizing note for 俳, whose own `stand_in` points to this word. `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 俸祿.

### 2026-09-11, iteration 4350 — [[words/俸祿|俸祿]]
Filled a missing `vietnamese` field with directly-attested "bổng lộc" (compositional 俸's bổng + 祿's lộc, and a genuine everyday Vietnamese word in its own right). Fixed broken relative links (missing `../` prefix). Replaced casual stand-in prose with the standard legitimizing-note phrasing (祿's own `stand_in` confirmed pointing to this word). `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 俸給.

### 2026-09-11, iteration 4351 — [[words/俸給|俸給]]
Fixed broken relative links (missing `../` prefix); replaced casual stand-in prose with the standard legitimizing-note phrasing (俸's own `stand_in` confirmed pointing to this word); added `kwin`/homophone verification sentence. `characters:` confirmed correct via `ls`, both character-page citations already present, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 倉庫.

### 2026-09-11, iteration 4352 — [[words/倉庫|倉庫]]
Removed duplicate `品詞` key. Filled a missing `vietnamese` field with honest compositional "thương kho" (noting the everyday word is simply kho/nhà kho). Replaced casual stand-in prose with the standard legitimizing-note phrasing (庫's own `stand_in` confirmed pointing to this word). `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 倉鼠.

### 2026-09-11, iteration 4353 — [[words/倉鼠|倉鼠]]
**Found and removed a stray gibberish leftover line** ("very C. Use instead of 絹毛鼠" — 絹毛鼠 doesn't even exist as a vault page, confirmed via `ls`). Removed dangling blank `hsk_level:`/`swadesh:`/`aliases:`; merged `## Etymology` into `## Notes`. **Found and fixed a missing citation** on 鼠.md's own Words list (倉鼠 was documented on 倉.md but never cited back on 鼠.md). `characters:` confirmed correct via `ls`, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 個.

### 2026-09-11, iteration 4354 — [[words/個|個]]
Removed duplicate `品詞` key. **Found and fixed a missing homophone callout**: 個 shares 注音 ㄍㄜ with [[其]] (confirmed via anchored grep) — added standard callout plus prose mention; reciprocal callout on 其's own page (which also has the same duplicate-品詞 bug) deferred to its own alphabetical turn. Trimmed a redundant mid-paragraph self-referential mention in favor of a standard legitimizing-note line at the end (個(char)'s own `stand_in` points to itself). Confirmed character-only 注音 matches (哥, 歌) have no independent word pages. `kwin: false` confirmed. Stamped `date-last-perfect: 2026-09-11`.

Next: 個人.

### 2026-09-11, iteration 4355 — [[words/個人|個人]]
Disambiguated bare 個 and 人 to "個 (char)"/"人 (char)" (words/個.md and words/人.md both exist — confirmed via `ls`). Fixed unindented `characters:` list, quoted bare `hsk_level`, removed dangling blank `swadesh:`/`aliases:`, filled a missing `date-last-perfect` entirely, wrote a `## Notes` section from scratch (page had none). **Found and fixed a missing homophone callout**: 個人 shares 注音 ㄍㄜㄋㄧㄋ with [[其人]] (confirmed via anchored grep) — added standard callout; reciprocal callout on 其人 (which also has the same duplicate-品詞 bug as 其) deferred to its own alphabetical turn. 個(char)'s citation already present; 人(char)'s citation for this word is only a bare numbered-list item, part of that page's already-flagged larger disorganized-Words-section cleanup, deferred. `kwin: false` confirmed. Stamped `date-last-perfect: 2026-09-11`.

Next: 個別.

### 2026-09-11, iteration 4356 — [[words/個別|個別]]
Added `kwin`/homophone verification sentence. `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 倍.

### 2026-09-11, iteration 4357 — [[words/倍|倍]]
Filled a missing `japanese` field (ばい, already documented in prose but absent from frontmatter). **Found and fixed a gloss error** in the homophone prose (唄's gloss given as "ugh" — corrected to its actual meaning, "Buddhist chant, hymn," confirmed via 唄.md's own english field). Added a missing self-referential legitimizing note. Confirmed character-only 注音 matches (敗, 貝, 罷, 稗, 狽) have no independent word pages. `kwin: true` confirmed. Stamped `date-last-perfect: 2026-09-11`.

Next: 倒.

### 2026-09-11, iteration 4358 — [[words/倒|倒]]
Filled a missing `japanese` field (とう, already documented in prose but absent from frontmatter). Fixed a broken relative link and non-standard tip-callout phrasing. **Found and fixed a missing self-citation** on 倒(char).md's own Words list (the self-referential stand-in citation was entirely absent). Added a missing self-referential legitimizing note. Confirmed character-only 注音 matches (刀, 討, 𢭏, 挑) have no independent word pages. `kwin: false` confirmed. Stamped `date-last-perfect: 2026-09-11`.

Next: 倚.

### 2026-09-11, iteration 4359 — [[words/倚|倚]]
Filled a missing `japanese` field (い, matching 倚(char)'s own primary I on'yomi). **Found and fixed a real `kwin` bug**: stored `true`, but byte-level verification shows own 諺文 읫 (U+C76B) genuinely differs from own korean 의 (U+C758) — corrected to `false`. This resolved the long-standing flagged open question about 義(char)'s identical 읫/의 divergence — checked 義.md directly and found the same bug there (`kwin: true` despite genuinely divergent 諺文/korean), fixed it too. Added a missing self-referential legitimizing note for 倚. Confirmed character-only 注音 matches (議, 誼, 義, 儀, 椅, 宜) have no independent word pages. Stamped `date-last-perfect: 2026-09-11`.

Next: 借.

### 2026-09-11, iteration 4360 — [[words/借|借]]
Filled a missing `japanese` field (しゃく, matching 借(char)'s own primary on'yomi). Fixed a broken relative link and non-standard tip-callout phrasing. Added a missing self-referential legitimizing note. Confirmed character-only 注音 matches (査, 詐, 遮, 左, 乍, 佐) have no independent word pages; confirmed reciprocal three-way homophone callouts with [[姉]]/[[諸]] already correctly present on both other pages. `kwin: false` confirmed. Stamped `date-last-perfect: 2026-09-11`.

Next: 倦厭.

### 2026-09-11, iteration 4361 — [[words/倦厭|倦厭]]
Flattened a single-item `vietnamese` list to scalar. Replaced casual stand-in prose with the standard legitimizing-note phrasing (倦's own `stand_in` confirmed pointing to this word). Confirmed 厭 is a genuine alias of 嫌 (matching the used-alias-not-primary-sense pattern, consistent with 波蘭/六楽/魏峨). Both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 倫理.

### 2026-09-11, iteration 4362 — [[words/倫理|倫理]]
Fixed unindented `characters:` list; **found and fixed a bad aliases entry** (倫理 was listed as its own alias — removed, keeping only the genuine simplified form 伦理); removed dangling blank `hsk_level:`/`swadesh:`; filled a missing `date-last-perfect` entirely; merged the thin `## Etymology` heading plus a stray unformatted reference line into a proper `## Notes` section, honestly noting 倫理学 has no dedicated page yet. Added a missing legitimizing note for 倫, whose own `stand_in` points to this word. Both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 倭人.

### 2026-09-11, iteration 4363 — [[words/倭人|倭人]]
Filled a missing `vietnamese` field with honest compositional "oa nhân" (no attested loanword found). Replaced casual stand-in prose with the standard legitimizing-note phrasing (倭's own `stand_in` confirmed pointing to this word). Both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 倭猩.

### 2026-09-11, iteration 4364 — [[words/倭猩|倭猩]]
Added `kwin`/homophone verification sentence. `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed, no homophone collision (`japanese: ボノボ` confirmed a genuine English loanword, not a bug, matching the 倉鼠/ハムスター pattern). Stamped `date-last-perfect: 2026-09-11`.

Next: 倶.

### 2026-09-11, iteration 4365 — [[words/倶|倶]]
Filled a missing `japanese` field (く, already documented in prose but absent from frontmatter). Added a missing self-referential legitimizing note. Confirmed character-only 注音 matches (惧, 駒, 具, 拘, 邱) have no independent word pages. `kwin: true` confirmed. Stamped `date-last-perfect: 2026-09-11`.

Next: 倶楽部.

### 2026-09-11, iteration 4366 — [[words/倶楽部|倶楽部]]
Disambiguated bare 部 to "部 (char)" (words/部.md exists — confirmed via `ls`). Fixed unindented `characters:` list, removed dangling blank `hsk_level:`/`swadesh:`/`aliases:`, filled a missing `date-last-perfect` entirely, wrote a `## Notes` section from scratch. Confirmed `japanese: クラブ` is a genuine everyday loanword variant, not a bug. All three character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 倹素.

### 2026-09-11, iteration 4367 — [[words/倹素|倹素]]
Fixed unindented `characters:` list, inline-flow `aliases:` list, removed dangling blank `hsk_level:`, merged `## Etymology` into `## Notes`. Added a missing legitimizing note for 倹, whose own `stand_in` points to this word. Both character-page citations already present, `kwin: true` confirmed exact match, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 偈陀.

### 2026-09-11, iteration 4368 — [[words/偈陀|偈陀]]
Filled missing `japanese`/`vietnamese` fields with honest compositional readings (げだ, kệ đà). **Found and fixed a missing `#cranberry` tag**: both 偈 and 陀's own `stand_in` fields point to this word (transitivity A=B=AB confirmed), a genuine cranberry case that had gone untagged — added the tag and standardized the prose accordingly, replacing casual single-character stand-in phrasing. Both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 偉大.

### 2026-09-11, iteration 4369 — [[words/偉大|偉大]]
Removed redundant duplicate stand-in mentions (appeared twice in prose) in favor of a single standard legitimizing-note line at the end (偉's own `stand_in` confirmed pointing to this word). `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: true` confirmed exact match, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 偏.

### 2026-09-11, iteration 4370 — [[words/偏|偏]]
Filled a missing `japanese` field (へん, already documented in prose but absent from frontmatter). **Found and fixed a raw-markdown-link-instead-of-wikilink citation** on 偏(char).md's own self-citation. Added a missing self-referential legitimizing note. Confirmed character-only 注音 match (扁) has no independent word page. `kwin: true` confirmed. Stamped `date-last-perfect: 2026-09-11`.

Next: 偏差.

### 2026-09-11, iteration 4371 — [[words/偏差|偏差]]
Fixed a semicolon-joined `english` string into a proper YAML list. Filled a missing `vietnamese` field with honest compositional "thiên sai" (noting the everyday term is độ lệch chuẩn). `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: true` confirmed exact match, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 偏重.

### 2026-09-11, iteration 4372 — [[words/偏重|偏重]]
Added `kwin`/homophone verification sentence. `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 偕同.

### 2026-09-11, iteration 4373 — [[words/偕同|偕同]]
Filled a missing `vietnamese` field with honest compositional "giai đồng" (no attested loanword found). Replaced casual stand-in prose with the standard legitimizing-note phrasing (偕's own `stand_in` confirmed pointing to this word). Both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 偕者.

### 2026-09-11, iteration 4374 — [[words/偕者|偕者]]
Fixed a bare `english:` string into a proper YAML list (LORD, Yahweh); closed up spaced `mandarin` pinyin and capitalized it as a proper noun (matching sibling divine-name words 上帝/天主/救偕). Added `kwin`/homophone verification sentence. `characters:` confirmed correct via `ls` (者 (char) disambiguation necessary), both character-page citations already present (including the compound [[愛偕者神]]), `kwin: false` confirmed, no homophone collision. Confirmed 偕's own `stand_in` is [[偕同]] (not this word), so no legitimizing note needed here. Stamped `date-last-perfect: 2026-09-11`.

Next: 停止.

### 2026-09-11, iteration 4375 — [[words/停止|停止]]
Fixed an unspaced cantonese field; removed dangling blank `swadesh:`/empty `aliases: []`; filled a missing `date-last-perfect` entirely (was absent). `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed, no homophone collision.

Next: 停泊.

### 2026-09-11, iteration 4376 — [[words/停泊|停泊]]
Fixed an unspaced cantonese field; removed dangling blank `hsk_level:`/`swadesh:`/`aliases:`. Added a missing legitimizing note for 泊, whose own `stand_in` points to this word. `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 停滞.

### 2026-09-11, iteration 4377 — [[words/停滞|停滞]]
Removed dangling blank `hsk_level:`/`swadesh:`/`aliases:`; filled a missing `date-last-perfect` entirely (was absent); merged `## Etymology` into `## Notes`. Added a missing legitimizing note for 滞, whose own `stand_in` points to this word. Both character-page citations already present, `kwin: false` confirmed, no homophone collision.

Next: 停留.

### 2026-09-11, iteration 4378 — [[words/停留|停留]]
Filled a missing `vietnamese` field with honest compositional "đình lưu" (no attested loanword found); filled a missing `date-last-perfect` entirely (was absent); fixed an unspaced cantonese romanization in prose. Replaced casual stand-in prose with the standard legitimizing-note phrasing (停's own `stand_in` confirmed pointing to this word). Both character-page citations already present, `kwin: false` confirmed, no homophone collision.

Next: 健全.

### 2026-09-11, iteration 4379 — [[words/健全|健全]]
Filled a missing `vietnamese` field with directly-attested "kiện toàn"; filled a missing `date-last-perfect` entirely; fixed an unspaced cantonese romanization in prose. **Found and fixed a malformed vietnamese list on 全(char).md** (was "toàn, tuyền" crammed into one item — reformatted). Replaced casual stand-in prose with the standard legitimizing-note phrasing (健's own `stand_in` confirmed pointing to this word). Both character-page citations already present, `kwin: false` confirmed, no homophone collision.

Next: 健康.

### 2026-09-11, iteration 4380 — [[words/健康|健康]]
Fixed an unspaced cantonese romanization in prose and removed a stray nonsensical clause ("健康保険 not applicable here"); added a missing blank line after the meta-bind-embed block; added "No homophones" closer. `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed correct (per-constituent divergence explanation already present and accurate). Stamped `date-last-perfect: 2026-09-11`.

Next: 偪陽.

### 2026-09-11, iteration 4381 — [[words/偪陽|偪陽]]
Filled a missing `vietnamese` field with honest compositional "Phúc Dương" (capitalized proper noun; no attested form found); filled a missing `date-last-perfect` entirely; fixed a stray unformatted parenthetical line into proper prose. Replaced casual stand-in prose with the standard legitimizing-note phrasing (偪's own `stand_in` confirmed pointing to this word). Both character-page citations already present, `kwin: true` confirmed exact match, no homophone collision.

Next: 側面.

### 2026-09-11, iteration 4382 — [[words/側面|側面]]
Removed duplicate `品詞` key; flattened single-item `japanese`/`vietnamese` lists to scalars. Replaced casual stand-in prose with the standard legitimizing-note phrasing (側's own `stand_in` confirmed pointing to this word). Verified the word's own 直面-resembling 諺文/羅馬字 (직면/jigmyen) is a genuine coincidental Dan'a'yo-internal concatenation (側's own assigned reading 직 diverges from Sino-Korean 측), not a copy-paste error from the unrelated word 直面 — clarified in prose. Both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 偵.

### 2026-09-11, iteration 4383 — [[words/偵|偵]]
Filled a missing `japanese` field (てい, already documented in prose but absent from frontmatter). Added a missing self-referential legitimizing note. Confirmed character-only 注音 match (貞) has no independent word page. `kwin: false` confirmed. Stamped `date-last-perfect: 2026-09-11`.

Next: 偶像.

### 2026-09-11, iteration 4384 — [[words/偶像|偶像]]
Removed dangling blank `hsk_level:`/`swadesh:`/empty `aliases: []`; filled a missing `date-last-perfect` entirely; wrote a `## Notes` section from scratch (page had none). Added a missing legitimizing note for 偶, whose own `stand_in` points to this word. Both character-page citations already present, `kwin: false` confirmed, no homophone collision.

Next: 偶数.

### 2026-09-11, iteration 4385 — [[words/偶数|偶数]]
Fixed inline-flow `characters:`/`aliases:` lists; removed dangling blank `hsk_level:`/`swadesh:`; merged `## Etymology` into `## Notes`. `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 偶然.

### 2026-09-11, iteration 4386 — [[words/偶然|偶然]]
Filled a blank `pos:` (性詞, matching sibling 突然). Fixed inline-flow `characters:` list, quoted bare `hsk_level`, removed dangling blank `swadesh:`/empty `aliases: []`, merged `## Etymology` into `## Notes`, fixed a typo ("doppleganger" → "doppelganger"). Both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 偶爾.

### 2026-09-11, iteration 4387 — [[words/偶爾|偶爾]]
Fixed inline-flow `characters:` list, quoted bare `hsk_level`, removed dangling blank `swadesh:`/empty `aliases: []`, merged `## Etymology` into `## Notes`. `characters:` confirmed correct via `ls` (爾 (char) disambiguation necessary), both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 偽.

### 2026-09-11, iteration 4388 — [[words/偽|偽]]
Filled a missing `japanese` field (ぎ, primary on'yomi matching 偽(char)'s own GI). Added a missing self-referential legitimizing note. Confirmed character-only 注音 matches (萎, 位, 倭, 危) have no independent word pages. `kwin: false` confirmed. Stamped `date-last-perfect: 2026-09-11`.

Next: 偽善.

### 2026-09-11, iteration 4389 — [[words/偽善|偽善]]
Removed dangling blank `hsk_level:`/`swadesh:`; merged `## Etymology` into `## Notes`. `characters:` confirmed correct via `ls` (both 偽/善 disambiguation necessary), both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 傀儡.

### 2026-09-11, iteration 4390 — [[words/傀儡|傀儡]]
Fixed a typo'd mandarin field ("kuǐlěil" → "kuǐlěi"); trimmed a comma-joined `korean` field that crammed the Sino-Korean reading together with two unrelated native synonyms (꼭두각시, 허수아비) into one string — kept 괴뢰 alone, moved the native synonyms to prose. Filled a missing `kwin` field entirely (false: own 諺文 쾨뢰 diverges from own korean 괴뢰) and a missing `date-last-perfect` entirely. Removed dangling blank fields, merged `## Etymology` into `## Notes`. Re-verified `#cranberry` tag transitivity (both 傀 and 儡's own `stand_in` point here, A=B=AB confirmed). Both character-page citations already present, no homophone collision.

Next: 傍.

### 2026-09-11, iteration 4391 — [[words/傍|傍]]
Filled a missing `japanese` field (ぼう, primary on'yomi). **Found and fixed a raw-markdown-link-instead-of-wikilink self-citation** on 傍(char).md's own Words list. Added a missing self-referential legitimizing note. Confirmed character-only 注音 matches (彷, 榜, 謗, 膨) have no independent word pages. `kwin: false` confirmed. Stamped `date-last-perfect: 2026-09-11`.

Next: 傑作.

### 2026-09-11, iteration 4392 — [[words/傑作|傑作]]
Added full readings synthesis plus `kwin`/homophone verification sentence to Notes. `characters:` confirmed correct, both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 傑出.

### 2026-09-11, iteration 4393 — [[words/傑出|傑出]]
Fixed unindented `characters:` list, inline-flow `aliases:` list, removed dangling blank `hsk_level:`/`swadesh:`, filled a missing `date-last-perfect` entirely, wrote a `## Notes` section from scratch. **Found and fixed a real `kwin` bug**: stored `true`, but byte-level verification shows own 諺文 걷춛 genuinely diverges from own korean 걸출 in both syllables — corrected to `false`. Added a missing legitimizing note for 傑, whose own `stand_in` points to this word. Both character-page citations already present, no homophone collision.

Next: 催.

### 2026-09-11, iteration 4394 — [[words/催|催]]
Filled a missing `japanese` field (さい, already documented in prose but absent from frontmatter); fixed unindented `english:` list. **Found and fixed a raw-markdown-link-instead-of-wikilink self-citation** on 催(char).md's own Words list. Added a missing self-referential legitimizing note. Confirmed character-only 注音 match (崔) has no independent word page. `kwin: true` confirmed exact match. Stamped `date-last-perfect: 2026-09-11`.

Next: 傲慢.

### 2026-09-11, iteration 4395 — [[words/傲慢|傲慢]]
Fixed inline-flow `characters:` list; removed dangling blank `hsk_level:`/`swadesh:`/empty `aliases: []`; merged `## Etymology` into `## Notes`. Added a missing legitimizing note for 傲, whose own `stand_in` points to this word. Both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 傷害.

### 2026-09-11, iteration 4396 — [[words/傷害|傷害]]
Filled a blank `pos:` (事詞); removed dangling blank `hsk_level:`/`swadesh:`/empty `aliases: []`. Added a missing legitimizing note for 傷, whose own `stand_in` points to this word. Both character-page citations already present, `kwin: false` confirmed, reciprocal homophone callout with [[上海]] already correctly present on both pages.

Next: 傾向.

### 2026-09-11, iteration 4397 — [[words/傾向|傾向]]
Replaced casual stand-in prose with the standard legitimizing-note phrasing (傾's own `stand_in` confirmed pointing to this word); added `kwin`/homophone verification sentence. `characters:` confirmed correct via `ls` (向 (char) disambiguation necessary), both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 傾斜.

### 2026-09-11, iteration 4398 — [[words/傾斜|傾斜]]
Replaced casual stand-in prose with the standard legitimizing-note phrasing (斜's own `stand_in` confirmed pointing to this word); added `kwin`/homophone verification sentence. `characters:` confirmed correct via `ls`, both character-page citations already present, `kwin: false` confirmed, no homophone collision. Stamped `date-last-perfect: 2026-09-11`.

Next: 僅僅.
