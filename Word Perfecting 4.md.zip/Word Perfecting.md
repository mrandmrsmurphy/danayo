# Word Perfecting

Running log for the word-perfecting backlog sweep (see [[AIOS/checklists/checklist_words.md|Checklist: Word Pages]]). The first log (iterations 1–1040) grew to ~8,500 lines and was archived by the user to `Word Perfecting.md.zip`; a second log (iterations 1041–1782) grew large in turn and was archived to `Word Perfecting 2.md.zip`; a third log (iterations 1783–2922) grew large again and was archived to `Word Perfecting 3.md.zip`. This file continues from there. Iteration numbering continues unbroken from the archived logs.

**Process**: one word per iteration (per standing pacing preference). Find the next candidate via `grep -L "^date-last-perfect" words/*.md`, sorted alphabetically by filename (Unicode/`LC_ALL=C` order), continuing from the last-processed filename's position in that sort. Check the word's own `characters:` constituents for a `stand_in` match (add the stand-in note if so), verify `羅馬字`/`諺文`/`注音` are the correct concatenation of each constituent's own fields, verify `kwin` via the AND-rule (all constituents' own `kwin` must be `true` for the compound to be `true`), fill blank cross-linguistic fields only when a real value can be verified (leave deliberately blank with a reason otherwise), and check for genuine Dan'a'yo-level homophones (not just same-spelling coincidences in a real language) before stamping `date-last-perfect`. Exact-match homophone checks use the `homophone_check.py` script in the scratchpad (see memory for its correct 3-argument invocation).

Next: 繁忙.

### 2026-09-05, iteration 2923 — [[words/繁忙|繁忙]]

No cranberry (忙's own stand-in is this exact compound, but 繁's own is [[繁茂]]) — transitivity fails, though 忙 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (panmang/판망/ㄆㄚㄋㄇㄚㄫ) already verified as the correct concatenation — no bug. Filled blank vietnamese (phồn mang, standard attested term). **In passing**, added a missing "(stand-in for 忙)" annotation on `characters/忙.md`'s own Words-list citation. No homophones. Stamped `date-last-perfect: 2026-09-05` on both files.

Next: 繁殖.

### 2026-09-05, iteration 2924 — [[words/繁殖|繁殖]]

No cranberry (殖's own stand-in is this exact compound, but 繁's own is [[繁茂]]) — transitivity fails, though 殖 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (pansig/판식/ㄆㄚㄋㄙㄧㄎ) already verified as the correct concatenation — no bug. Fixed `hsk_level: 3` (bare number → quoted string). Filled blank vietnamese (phồn thực, standard attested term). No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 繁茂.

### 2026-09-05, iteration 2925 — [[words/繁茂|繁茂]]

No cranberry (繁's own stand-in is this exact compound, but 茂's own is [[茂密]]) — transitivity fails, though 繁 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (panmou/판못/ㄆㄚㄋㄇㄛㄨ) already verified as the correct concatenation — no bug. Filled blank vietnamese (phồn mậu, standard attested term). Removed blank hsk_level/swadesh/aliases, fixed bare-array `characters:` YAML formatting. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 繁華.

### 2026-09-05, iteration 2926 — [[words/繁華|繁華]]

No cranberry (繁's own stand-in is [[繁茂]], 華's is [[華美]]) — neither constituent legitimized by this word. Pronunciation fields (panhwa/판화/ㄆㄚㄋㄏ⺢) already verified as the correct concatenation — no bug. Filled blank vietnamese (phồn hoa, standard attested term). Removed blank hsk_level/swadesh/aliases, fixed bare-array `characters:` YAML formatting. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 繊細.

### 2026-09-05, iteration 2927 — [[words/繊細|繊細]]

No cranberry (繊's own stand-in is this exact compound, but 細's own is [[細]] itself) — transitivity fails, though 繊 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (semsei/섬세/ㄙㄝㄇㄙㄝㄧ) already verified as the correct concatenation — no bug. Filled blank vietnamese (tiêm tế, standard attested term). **In passing**, fixed a malformed comma-joined `vietnamese` value on `characters/細 (char).md` ("tế, tới" → proper 2-item list). No homophones. Stamped `date-last-perfect: 2026-09-05` on both files.

Next: 繋辞.

### 2026-09-05, iteration 2928 — [[words/繋辞|繋辞]]

No cranberry (繋's own stand-in is this exact compound, but 辞's own is [[辞職]]) — transitivity fails, though 繋 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (heici/헤치/ㄏㄝㄧㄑㄧ) already verified as the correct concatenation — no bug. Mandarin/cantonese/vietnamese deliberately left blank, reconfirming the word's own pre-existing rationale (a Japanese/Korean-specific grammatical term with no attested reading elsewhere) — kept as-is rather than fabricated. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 織女星.

### 2026-09-05, iteration 2929 — [[words/織女星|織女星]]

No cranberry (none of the three constituents' `stand_in` points here). Pronunciation fields (jignǝseng/직느성/ㄐㄧㄎㄋㄜㄙㄝㄫ) already verified as the correct three-way concatenation — no bug. All other-language fields confirmed standard and genuinely attested. Filled blank vietnamese (chức nữ tinh, compositional and itself the standard term). Removed blank hsk_level/swadesh/aliases. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 繞.

### 2026-09-05, iteration 2930 — [[words/繞|繞]]

Single-character stand-in word. Pronunciation fields (nou/놋/ㄋㄛㄨ) already matched the character's own values — no bug. Added missing kwin/japanese (native まとう); pos/vietnamese were already correctly set. No homophones (no other character shares this syllable). Stamped `date-last-perfect: 2026-09-05`.

Next: 缺点.

### 2026-09-05, iteration 2931 — [[words/缺点|缺点]]

No cranberry (缺's own stand-in is [[欠缺]], 点's is [[点]] itself). Pronunciation fields (kweddem/퀃덤/ㄎ⼔ㄊㄉㄝㄇ) already verified as the correct concatenation — no bug. Fixed a comma-joined `korean` field ("결점, 흠" — a native gloss wrongly appended to the compositional reading) to just 결점. Added missing `kwin: false`. Removed blank hsk_level/swadesh, converted loose gloss text into proper Notes prose. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 罪.

### 2026-09-05, iteration 2932 — [[words/罪|罪]]

Single-character stand-in word. Pronunciation fields (joi/죄/ㄐㄛㄧ) already matched the character's own values — no bug. Added missing pos/kwin/japanese, filled `vietnamese: null` → tội. **In passing**, added a missing "(stand-in for 罪)" citation of 罪 itself, absent entirely from `characters/罪 (char).md`'s Words list. No homophones (no other character shares this syllable). Stamped `date-last-perfect: 2026-09-05` on both files.

Next: 置換.

### 2026-09-05, iteration 2933 — [[words/置換|置換]]

No cranberry (both 置's and 換's own `stand_in` point to themselves). Pronunciation fields (cihwam/치홤/ㄑㄧㄏ⺢ㄇ) already verified as the correct concatenation — no bug. Filled blank vietnamese (trí hoán, standard attested mathematical term). Removed blank hsk_level/swadesh/aliases. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 罷免.

### 2026-09-05, iteration 2934 — [[words/罷免|罷免]]

No cranberry (罷's own stand-in is [[罷官]], 免's is [[免除]]). Pronunciation fields (baimyen/배면/ㄅㄚㄧㄇ⼶ㄋ) already verified as the correct concatenation — no bug. All fields already correctly filled (including korean, verified compositional and matching real attestation) — just cleanup: removed blank hsk_level/swadesh/aliases, fixed bare-array `characters:` YAML formatting. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 罷官.

### 2026-09-05, iteration 2935 — [[words/罷官|罷官]]

No cranberry (罷's own stand-in is this exact compound, but 官's own is [[官人]]) — transitivity fails, though 罷 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (baigwan/배관/ㄅㄚㄧㄍ⺢ㄋ) already verified as the correct concatenation — no bug. Filled entirely-blank japanese/korean/vietnamese (compositional, all standard attested terms), added missing `kwin: false`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 罹患.

### 2026-09-05, iteration 2936 — [[words/罹患|罹患]]

No cranberry (罹's own stand-in is this exact compound, but 患's own is [[患]] itself) — transitivity fails, though 罹 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (lihwam/리홤/ㄌㄧㄏ⺢ㄇ) already verified as the correct concatenation — no bug. Filled blank vietnamese (li hoạn, compositional and itself attested). Removed blank hsk_level/swadesh/aliases. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 羅馬.

### 2026-09-05, iteration 2937 — [[words/羅馬|羅馬]]

No cranberry (羅's own stand-in is this exact compound, but 馬's own is [[馬]] itself) — transitivity fails, though 羅 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (loma/로마/ㄌㄛㄇㄚ) already verified as the correct concatenation — no bug. **Found and fixed a real `kwin` bug**: word file had `kwin: true`, but the AND-rule requires false (羅 is individually `kwin: false`) — corrected. Fixed a comma-joined `vietnamese` string (three genuinely distinct attested forms — Roma, Rôma, La Mã) into a proper list, and a typo ("sually followed by" → proper Notes prose). No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 羅馬字.

### 2026-09-05, iteration 2938 — [[words/羅馬字|羅馬字]]

No cranberry (none of the three constituents' `stand_in` points here). Pronunciation fields (lomaji/로마지/ㄌㄛㄇㄚㄐㄧ) already verified as the correct three-way concatenation — no bug. Filled blank vietnamese (la mã tự, compositional). **In passing**, fixed `characters/字 (char).md`'s own citation of this word (non-standard `[text](path)` link format with a lowercase, singular gloss → proper ruby wikilink with the standard plural gloss). Removed blank hsk_level/swadesh/aliases. No homophones. Stamped `date-last-perfect: 2026-09-05` on both files.

Next: 羅馬語.

### 2026-09-05, iteration 2939 — [[words/羅馬語|羅馬語]]

No cranberry (none of the three constituents' `stand_in` points here). Pronunciation fields (loma'yo/로마요/ㄌㄛㄇㄚ·⼄) already verified as the correct three-way concatenation — no bug. Double-checked mandarin/cantonese/korean/japanese: all reflect the real, attested name for "Latin" in each language (拉丁語/lādīngyǔ etc., already correctly documented via the `aliases` field) rather than a compositional reading of the Dan'a'yo-internal coinage 羅馬語 itself — confirmed intentional, not a bug, matching the periodic-table-neologism pattern. Removed the redundant duplicate `品詞` field and a leading-space formatting bug on `japanese`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 羊毛.

### 2026-09-05, iteration 2940 — [[words/羊毛|羊毛]]

No cranberry (羊's own stand-in is [[綿羊]], 毛's is [[毛]] itself). Pronunciation fields ('yangmau/양맛/⼘ㄫㄇㄚㄨ) already verified as the correct concatenation — no bug. Filled blank vietnamese (dương mao, compositional). Removed blank hsk_level/swadesh/aliases, fixed bare-array `characters:` YAML formatting. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 羊頭.

### 2026-09-05, iteration 2941 — [[words/羊頭|羊頭]]

No cranberry (羊's own stand-in is [[綿羊]], 頭's is [[頭]] itself). Pronunciation fields ('yangtou/양톳/⼘ㄫㄊㄛㄨ) already verified as the correct concatenation — no bug. Filled blank vietnamese (dương đầu, compositional). **In passing**, added a missing citation of 羊頭 to `characters/羊.md`'s own Words list (it had only been cited inside the chengyu section, not as its own regular word entry — `characters/頭 (char).md` already had it correctly). No homophones. Stamped `date-last-perfect: 2026-09-05` on both files.

Next: 羊駝.

### 2026-09-05, iteration 2942 — [[words/羊駝|羊駝]]

No cranberry (羊's own stand-in is [[綿羊]], 駝's is [[駝背]]). Pronunciation fields ('yangda/양다/⼘ㄫㄉㄚ) already verified as the correct concatenation — no bug. Double-checked korean/japanese/vietnamese: all directly transliterate "alpaca" (a New World species with no traditional term in those languages), confirmed genuine, not a bug. Removed redundant duplicate `品詞` field. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 美.

### 2026-09-05, iteration 2943 — [[words/美|美]]

Single-character stand-in word. Pronunciation fields (mi/미/ㄇㄧ) already matched the character's own values — no bug. Added missing pos/kwin/japanese (native うつくしい), filled `vietnamese: null` → mĩ. **In passing**, added a missing "(stand-in for 美)" annotation on `characters/美 (char).md`'s own bare self-citation. No homophones (no other character shares this syllable). Stamped `date-last-perfect: 2026-09-05` on both files.

Next: 美国.

### 2026-09-05, iteration 2944 — [[words/美国|美国]]

No cranberry (美's own stand-in is [[美]] itself, 国's is [[国家]]). Pronunciation fields (migog/미곡/ㄇㄧㄍㄛㄎ) already verified as the correct concatenation — no bug. Double-checked japanese べいこく (built on the alias form 米国, which is already documented in `aliases:`) — confirmed genuine, not a bug. All other fields already correctly filled. Removed blank hsk_level/swadesh. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 美国人.

### 2026-09-05, iteration 2945 — [[words/美国人|美国人]]

No cranberry (none of the three constituents' `stand_in` points here). Pronunciation fields (migognin/미곡닌/ㄇㄧㄍㄛㄎㄋㄧㄋ) already verified as the correct three-way concatenation — no bug. Japanese アメリカ人 double-checked as genuine (loanword compound). Fixed a comma-joined `vietnamese` string (two genuinely distinct attested forms) into a proper list. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 美徳.

### 2026-09-05, iteration 2946 — [[words/美徳|美徳]]

No cranberry (both 美's and 徳's own `stand_in` point to themselves). **Found and fixed a real bug**: `羅馬字`/`注音` had midug/ㄇㄧㄉㄨㄎ (徳 misread with a d-initial), mismatching 徳's real t-initial reading (tug/ㄊㄨㄎ) — 諺文 (미툭) had already been correct, the reverse of the usual "注音 stays correct" tell. Corrected to mitug/ㄇㄧㄊㄨㄎ, and propagated the fix to both `characters/美 (char).md`'s and `characters/徳 (char).md`'s own duplicate-wrong citations. All other fields already correctly filled. No homophones. Stamped `date-last-perfect: 2026-09-05` on all three files.

Next: 美洲.

### 2026-09-05, iteration 2947 — [[words/美洲|美洲]]

No cranberry (both 美's and 洲's own `stand_in` point to themselves). Pronunciation fields (mijuo/미줏/ㄇㄧㄐㄨㄛ) already verified as the correct concatenation — no bug. Filled blank japanese (びしゅう, compositional). Removed redundant duplicate `品詞` field, converted loose "Combines..." note into proper Notes prose. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 羚羊.

### 2026-09-05, iteration 2948 — [[words/羚羊|羚羊]]

No cranberry (羚's own stand-in is this exact compound, but 羊's own is [[綿羊]]) — transitivity fails, though 羚 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (leng'yang/렁양/ㄌㄝㄫ·⼘ㄫ) already verified as the correct concatenation — no bug. Filled blank vietnamese (linh dương, standard attested term). **In passing**, added a missing citation of 羚羊 to `characters/羊.md`'s own Words list (羚's own page already had it correctly). Converted loose "See also" text into proper Notes prose. No homophones. Stamped `date-last-perfect: 2026-09-05` on both files.

Next: 羞恥.

### 2026-09-05, iteration 2949 — [[words/羞恥|羞恥]]

No cranberry (羞's own stand-in is this exact compound, but 恥's own is [[恥辱]]) — transitivity fails, though 羞 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (suoci/숫치/ㄙㄨㄛㄑㄧ) already verified as the correct concatenation — no bug. All fields already correctly filled — just cleanup: removed blank hsk_level/swadesh/aliases, fixed bare-array `characters:` YAML formatting. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 羞辱.

### 2026-09-05, iteration 2950 — [[words/羞辱|羞辱]]

No cranberry (辱's own stand-in is this exact compound, but 羞's own is [[羞恥]]) — transitivity fails, though 辱 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (suonog/숫녹/ㄙㄨㄛㄋㄛㄎ) already verified as the correct concatenation — no bug. **Found and fixed a real bug**: `japanese`/`korean` had くつじょく/굴욕, the real readings of the unrelated near-synonym 屈辱 (a different compound, different first character, no vault page) rather than 羞辱's own compositional readings — corrected to しゅうじょく/수욕. Removed the erroneous `屈辱` alias entry (it's a distinct word, not a variant spelling). Converted comma-joined `mandarin` to a proper list. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 群島.

### 2026-09-05, iteration 2951 — [[words/群島|群島]]

No cranberry (群's own stand-in is [[群衆]], 島's is [[島]] itself). Pronunciation fields (guntau/군탓/ㄍㄨㄋㄊㄚㄨ) already verified as the correct concatenation — no bug. Fixed the `characters:` list citing bare "島" (a redlink, since the actual page is `島 (char).md`) → "島 (char)". Removed blank hsk_level/swadesh, fixed bare-array YAML formatting. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 羨慕.

### 2026-09-05, iteration 2952 — [[words/羨慕|羨慕]]

No cranberry (羨's own stand-in is this exact compound, but 慕's own is [[思慕]]) — transitivity fails, though 羨 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields ('iǝmo/의모/ㄧㄜㄇㄛ) already verified as the correct concatenation — no bug. All fields already correctly filled — just cleanup: removed blank hsk_level/swadesh, fixed bare-array `characters:` YAML formatting. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 翅鞘.

### 2026-09-05, iteration 2953 — [[words/翅鞘|翅鞘]]

No cranberry (翅's own stand-in is [[魚翅]], 鞘's is [[刀鞘]]). Pronunciation fields (siso/시소/ㄙㄧㄙㄛ) already verified as the correct concatenation — no bug. Filled blank vietnamese (sí sao, compositional). Fixed unquoted mandarin/cantonese/korean strings (quoting convention). No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 翌.

### 2026-09-05, iteration 2954 — [[words/翌|翌]]

Single-character stand-in word. Pronunciation fields ('ig/익/ㄧㄎ) already matched the character's own values — no bug. **Found and fixed two real bugs**: `pos` had been set to 格助詞 (a specific closed class of twelve case particles 翌 doesn't belong to) — corrected to 修飾語, matching the character page's own value and 翌's actual role as a temporal modifier; `japanese` had いき, which turned out not to be an attested reading of 翌 at all (confirmed via web search — real readings are ヨク on'yomi and あくる kun'yomi) — corrected to ヨク. Removed the redundant duplicate `品詞` field. **In passing**, fixed `characters/翌 (char).md`'s own citation (non-standard `[text](path)` link format, missing stand-in annotation) and an unquoted `hsk_level: 無`. No homophones (億/憶/抑/翼/臆 share the syllable at the character level only). Stamped `date-last-perfect: 2026-09-05` on both files.

Next: 翌世紀.

### 2026-09-05, iteration 2955 — [[words/翌世紀|翌世紀]]

No cranberry (none of the three constituents' `stand_in` points here). Pronunciation fields ('igsegi/익서기/ㄧㄎㄙㄝㄍㄧ) already verified as the correct three-way concatenation — no bug. Filled blank vietnamese (dực thế kỷ, compositional). **In passing**, found and fixed two real bugs on `characters/世.md`: a double-space formatting bug in `諺文`, and a real bug where `vietnamese` stored "thế giới" (the full compound meaning "world," i.e. 世界's own value) instead of 世's own atomic reading "thế" — corrected. No homophones. Stamped `date-last-perfect: 2026-09-05` on both files.

Next: 翌年.

### 2026-09-05, iteration 2956 — [[words/翌年|翌年]]

No cranberry (both 翌's and 年's own `stand_in` point to themselves). Pronunciation fields ('ignen/익넌/ㄧㄎㄋㄝㄋ) already verified as the correct concatenation — no bug. Filled blank vietnamese (dực niên, compositional). No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 翌週.

### 2026-09-05, iteration 2957 — [[words/翌週|翌週]]

No cranberry (翌's own stand-in is [[翌]] itself, 週's is [[週日]]). Pronunciation fields ('igjuo/익줏/ㄧㄎㄐㄨㄛ) already verified as the correct concatenation — no bug. Filled blank vietnamese (dực chu, compositional). No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 習俗.

### 2026-09-05, iteration 2958 — [[words/習俗|習俗]]

No cranberry (習's own stand-in is [[練習]], 俗's is [[俗]] itself). **Found and fixed a real bug**: `羅馬字`/`注音` (and 諺文) had an i-vowel first syllable (sibsog/십속/ㄙㄧㄆㄙㄛㄎ), mismatching 習's real ǝ-vowel reading (sǝb/습/ㄙㄜㄆ, confirmed via `syllables/ㄙㄜㄆ.md`) — corrected to sǝbsog/습속/ㄙㄜㄆㄙㄛㄎ. The same wrong 注音 was independently duplicated on `characters/習.md`'s own citation, fixed there too. Also corrected `kwin` (false→true per AND-rule). Filled the two empty-string fields (`vietnamese: ""`, `swadesh: ""`) and removed the redundant duplicate `品詞`. No homophones. Stamped `date-last-perfect: 2026-09-05` on both files.

Next: 翠色.

### 2026-09-05, iteration 2959 — [[words/翠色|翠色]]

No cranberry (翠's own stand-in is this exact compound, but 色's own is [[色彩]]) — transitivity fails, though 翠 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (cuisig/취식/ㄑㄨㄧㄙㄧㄎ) already verified as the correct concatenation — no bug. Filled three empty-string fields (`cantonese: ""`, `korean: ""`, `vietnamese: ""` — all compositional), added missing `kwin: false`, removed redundant duplicate `品詞` field. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 翠金.

### 2026-09-05, iteration 2960 — [[words/翠金|翠金]]

Periodic-table neologism (terbium), rebuilt to match the established template from sibling elements like [[石素]]/[[紫素]]. No cranberry (neither 翠's nor 金's own `stand_in` points here). Pronunciation fields (cuigim/취김/ㄑㄨㄧㄍㄧㄇ) already verified as the correct concatenation — no bug. **Found and fixed a real `kwin` bug**: word file had `kwin: false`, but the AND-rule requires true (both 翠 and 金 are individually `kwin: true`) — corrected. Mandarin tè/cantonese tik1 (the real element's own readings, via 铽) and korean/japanese/vietnamese international borrowings all confirmed as the expected pattern for chemical-element neologisms. Removed the redundant duplicate `品詞` field and replaced a long essay-style Notes section (headers, bold labels, a "Comparative CJKV forms" list) with the vault's standard concise neologism-Notes format. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 翻.

### 2026-09-05, iteration 2961 — [[words/翻|翻]]

Single-character stand-in word. **Found and fixed a real bug**: `羅馬字`/`諺文`/`注音` had pon/폰/ㄆㄛㄋ (p-initial), mismatching 翻's real f-initial reading (fon/뽄/ㄈㄛㄋ, per the vault's established ㄈ→ㅃ convention) — corrected. Added missing pos/kwin/japanese, filled `vietnamese: null` → phiên. This exposed a genuine Dan'a'yo homophone with [[反]] (already perfected, whose own Notes had independently fixed the identical p/f bug and flagged 販/返 as sharing the phonetic family without word pages) — added reciprocal callouts to both. No other collisions. Stamped `date-last-perfect: 2026-09-05` on both files.

Next: 翻訳.

### 2026-09-05, iteration 2962 — [[words/翻訳|翻訳]]

No cranberry (訳's own stand-in is this exact compound, but 翻's own is [[翻]] itself) — transitivity fails, though 訳 is legitimized as an independent Dan'a'yo entry by this word. **Found and fixed a real bug**: `羅馬字`/`諺文` had pon'yeg/폰역 (p-initial), inheriting the same 翻/p-f confusion fixed on the previous word — `注音` (ㄈㄛㄋ⼶ㄎ) had stayed correct as the tell. Filled blank cantonese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 翻身.

### 2026-09-05, iteration 2963 — [[words/翻身|翻身]]

No cranberry (翻's own stand-in is [[翻]] itself, 身's is [[身体]]). **Found and fixed two real bugs**: inherited the same 翻 p/f confusion in `羅馬字`/`諺文` (`注音` stayed correct throughout, the tell); `cantonese` was garbled (saan1san1, missing a space and mismatching 翻's own faan1) — corrected to faan1 san1. Filled blank korean/vietnamese, added missing `kwin: false`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 老人学.

### 2026-09-05, iteration 2964 — [[words/老人学|老人学]]

No cranberry (none of the three constituents' `stand_in` points here). **Found and fixed a real bug**: `羅馬字`/`諺文` had lyau/럇 (a glide-inserted first syllable), mismatching 老's real lau/랏 — `注音` (ㄌㄚㄨㄋㄧㄋㄏㄚㄎ) had stayed correct throughout, the usual tell. Filled blank vietnamese (lão nhân học, standard attested term). Removed blank hsk_level/swadesh/aliases. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 老子.

### 2026-09-05, iteration 2965 — [[words/老子|老子]]

No cranberry (老's own stand-in is [[老]] itself, 子's is [[児子]]). **Found and fixed a real bug**: `羅馬字`/`諺文` had lyaujǝ/럇즈 (the same 老-syllable mismatch just fixed on [[老人学]]) — `注音` (ㄌㄚㄨㄐㄜ) had stayed correct throughout. All other fields already correctly filled. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 老師.

### 2026-09-05, iteration 2966 — [[words/老師|老師]]

No cranberry (老's own stand-in is [[老]] itself, 師's is [[教師]]). Pronunciation fields (lausiǝ/랏싀/ㄌㄚㄨㄙㄧㄜ) already verified as the correct concatenation — no bug (老's syllable was already correct here, unlike the previous two 老-words). Fixed `hsk_level: 1` (bare number → quoted string). Converted a loose "not a plain 'teacher'" note into proper Notes prose distinguishing 老師 from [[教師]]. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 老爺.

### 2026-09-05, iteration 2967 — [[words/老爺|老爺]]

No cranberry (爺's own stand-in is this exact compound, but 老's own is [[老]] itself) — transitivity fails, though 爺 is legitimized as an independent Dan'a'yo entry by this word. **Found and fixed a real bug**: `羅馬字`/`諺文` had lyau'ya/럇야 (the third instance of the 老-syllable mismatch, after [[老人学]] and [[老子]]) — `注音` had stayed correct throughout. Filled blank vietnamese (lão gia, standard attested term). Converted a loose "Stand-in for [[爺]]" note into proper Notes prose. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 考察.

### 2026-09-05, iteration 2968 — [[words/考察|考察]]

No cranberry (察's own stand-in is this exact compound, but 考's own is [[考慮]]) — transitivity fails, though 察 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (kaucad/캇찯/ㄎㄚㄨㄑㄚㄊ) already verified as the correct concatenation — no bug. All fields already correctly filled — just cleanup: removed blank hsk_level/swadesh/aliases, fixed bare-array `characters:` YAML formatting. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 考慮.

### 2026-09-05, iteration 2969 — [[words/考慮|考慮]]

**Genuine `#cranberry` case**: both 考's and 慮's own `stand_in` point to this exact compound. Pronunciation fields (kaulyo/캇료/ㄎㄚㄨㄌ⼄) already verified as the correct concatenation — no bug. Filled blank vietnamese (khảo lự, compositional). Removed blank hsk_level/swadesh, fixed bare-array `characters:`/`aliases:` YAML formatting. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 考試.

### 2026-09-05, iteration 2970 — [[words/考試|考試]]

No cranberry (試's own stand-in is this exact compound, but 考's own is [[考慮]]) — transitivity fails, though 試 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (kausi/캇시/ㄎㄚㄨㄙㄧ) already verified as the correct concatenation — no bug. All fields already correctly filled — just cleanup: removed blank swadesh, fixed bare-array `characters:`/`aliases:` YAML formatting. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 而後.

### 2026-09-05, iteration 2971 — [[words/而後|而後]]

No cranberry (both 而's and 後's own `stand_in` point to themselves). Pronunciation fields (nihuo/니훗/ㄋㄧㄏㄨㄛ) already verified as the correct concatenation — no bug. **Found and fixed a real bug**: `japanese`/`korean` had native paraphrases (その後/그 후) rather than 而後's own attested readings — confirmed via web search that 而後 is genuinely read じご (jigo, using 而's on-reading ジ) in Japanese; corrected japanese to じご and korean to the paralleling compositional 이후. Converted a loose "archaic" comment into proper Notes prose. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 耐.

### 2026-09-05, iteration 2972 — [[words/耐|耐]]

Single-character stand-in word. Pronunciation fields (nai/내/ㄋㄚㄧ) already matched the character's own values — no bug. Added missing pos/kwin/japanese, filled `vietnamese: null` → nại. Completed the genuine Dan'a'yo homophone with [[乃]] (already perfected, had pre-emptively documented and anticipated this exact pairing) — reciprocal callout already in place, cross-referenced here. **In passing**, cleaned up a stray dangling numbered list left over on `words/乃.md`'s own page (duplicating its single `english:` gloss). No other collisions. Stamped `date-last-perfect: 2026-09-05` on both files.

Next: 耳根.

### 2026-09-05, iteration 2973 — [[words/耳根|耳根]]

No cranberry (both 耳's and 根's own `stand_in` point to themselves). **Found and fixed a real bug**: `羅馬字`/`諺文` had nigan/니간 (mismatching 根's real -ǝ- vowel reading, gǝn/근) — `注音` (ㄋㄧㄍㄜㄋ) had stayed correct throughout. All other fields already correctly filled. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 耳目.

### 2026-09-05, iteration 2974 — [[words/耳目|耳目]]

No cranberry (both 耳's and 目's own `stand_in` point to themselves). Pronunciation fields (nimug/니묵/ㄋㄧㄇㄨㄎ) already verified as the correct concatenation — no bug. Filled blank vietnamese (nhĩ mục, standard attested term). Removed blank hsk_level/swadesh/aliases. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 耶.

### 2026-09-05, iteration 2975 — [[words/耶|耶]]

Single-character stand-in word. Pronunciation fields ('ye/여/⼶) already matched the character's own values — no bug. Added missing pos/kwin/japanese (native か); vietnamese was already correctly filled. No homophones (叡/曳/裔/鋭 share the syllable at the character level only). **In passing**, fixed `characters/耶 (char).md`'s Derived Characters section (wrong `###` heading level, non-standard `[text](path)` link format, misplaced before `## Words`) — moved after Words and reformatted to proper ruby wikilinks. Stamped `date-last-perfect: 2026-09-05` on both files.

Next: 耽.

### 2026-09-05, iteration 2976 — [[words/耽|耽]]

Single-character stand-in word. Pronunciation fields (dom/돔/ㄉㄛㄇ) already matched the character's own values — no bug. Added missing kwin/japanese (native ふける); pos/vietnamese were already correctly set. **In passing**, added a missing "(stand-in for 耽)" annotation on `characters/耽 (char).md`'s own self-citation. No homophones (彤 shares the syllable at the character level only). Stamped `date-last-perfect: 2026-09-05` on both files.

Next: 聊.

### 2026-09-05, iteration 2977 — [[words/聊|聊]]

Single-character stand-in word. Pronunciation fields (lyau/럇/ㄌ⼘ㄨ) already matched the character's own values — no bug. Added missing kwin/japanese (native いささか). Completed the genuine Dan'a'yo homophone with [[了]] (already perfected, had pre-emptively documented and anticipated this exact pairing, including a note on 了's own corpus-noise vietnamese candidates) — reciprocal callout already in place, cross-referenced here. No other collisions (寮/料/瞭/蓼/遼/陋 share the syllable at the character level only). Stamped `date-last-perfect: 2026-09-05`.

Next: 聖人.

### 2026-09-05, iteration 2978 — [[words/聖人|聖人]]

No cranberry (聖's own stand-in is [[神聖]], 人's is [[人]] itself). Pronunciation fields (singnin/싱닌/ㄙㄧㄫㄋㄧㄋ) already verified as the correct concatenation — no bug. Filled entirely-blank cantonese/vietnamese (compositional, both standard attested terms). No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 聘.

### 2026-09-05, iteration 2979 — [[words/聘|聘]]

Single-character stand-in word. Pronunciation fields (ping/핑/ㄆㄧㄫ) already matched the character's own values — no bug. Added missing kwin/japanese (native めす); pos/vietnamese were already correctly set. No homophones (no other character shares this syllable). Stamped `date-last-perfect: 2026-09-05`.

Next: 聚集.

### 2026-09-05, iteration 2980 — [[words/聚集|聚集]]

No cranberry (聚's own stand-in is this exact compound, but 集's own is [[集合]]) — transitivity fails, though 聚 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (cuijib/취집/ㄑㄨㄧㄐㄧㄆ) already verified as the correct concatenation — no bug. Added missing `kwin: true` (entirely absent from the file). Converted a loose "Japanese conflates these two characters" comment into proper Notes prose. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 聞.

### 2026-09-05, iteration 2981 — [[words/聞|聞]]

Single-character stand-in word. Pronunciation fields (mun/문/ㄇㄨㄋ) already matched the character's own values — no bug. Added missing pos/kwin/japanese (native きく), filled `vietnamese: null` → văn. Completed the 3-way Dan'a'yo homophone group with [[紋]] and [[蚊]] (established earlier this sweep, reciprocal callout already in place) — re-verified complete with the fixed homophone script (吻/問/文 share the syllable at the character level only). **In passing**, added a missing "(stand-in for 聞)" annotation on `characters/聞 (char).md`'s own self-citation. Stamped `date-last-perfect: 2026-09-05` on both files.

Next: 聡明.

### 2026-09-05, iteration 2982 — [[words/聡明|聡明]]

No cranberry (聡's own stand-in is this exact compound, but 明's own is [[明]] itself) — transitivity fails, though 聡 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (congmyeng/총명/ㄑㄛㄫㄇ⼶ㄫ) already verified as the correct concatenation — no bug. Fixed the `characters:` list citing bare "明" (a redlink, since the actual page is `明 (char).md`) → "明 (char)". Removed blank hsk_level/swadesh, fixed bare-array `characters:` YAML formatting. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 聴.

### 2026-09-05, iteration 2983 — [[words/聴|聴]]

Single-character stand-in word. Pronunciation fields (ceng/청/ㄑㄝㄫ) already matched the character's own values — no bug. Added missing pos/kwin/japanese (native きく); vietnamese left blank since no candidate is stored on the character page at all. Existing homophone callout with [[青]] re-verified as complete with the fixed homophone-check script (庁/錆/鯖 share the syllable at the character level only). **In passing**, added a missing "(stand-in for 聴)" self-citation, absent entirely from `characters/聴 (char).md`'s Words list. Stamped `date-last-perfect: 2026-09-05` on both files.

Next: 聴取.

### 2026-09-05, iteration 2984 — [[words/聴取|聴取]]

No cranberry (聴's own stand-in is [[聴]] itself, 取's is [[取得]]). Pronunciation fields (cengcou/청촛/ㄑㄝㄫㄑㄛㄨ) already verified as the correct concatenation — no bug. **Found and fixed a real bug**: `cantonese` had teng1 ceoi2, mismatching 聴's real ting1 — corrected to ting1 ceoi2. Vietnamese deliberately left blank since 聴's own character page has no candidate stored at all. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 職業.

### 2026-09-05, iteration 2985 — [[words/職業|職業]]

No cranberry (職's own stand-in is this exact compound, but 業's own is [[業]] itself) — transitivity fails, though 職 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (jig'eb/직업/ㄐㄧㄎㄝㄆ) already verified as the correct concatenation — no bug. Fixed the `characters:` list citing bare "業" (a redlink, since the actual page is `業 (char).md`) → "業 (char)". Removed blank hsk_level/swadesh, fixed bare-array `characters:` YAML formatting. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 肇造.

### 2026-09-05, iteration 2986 — [[words/肇造|肇造]]

No cranberry (肇's own stand-in is this exact compound, but 造's own is [[創造]]) — transitivity fails, though 肇 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (jaucau/잣찻/ㄐㄚㄨ·ㄑㄚㄨ) already verified as the correct concatenation — no bug. All other-language fields (including the pre-existing cantonese) confirmed standard and genuinely compositional. Filled blank vietnamese (triệu tạo, compositional), added missing `kwin: false`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 肉桂.

### 2026-09-05, iteration 2987 — [[words/肉桂|肉桂]]

No cranberry (桂's own stand-in is this exact compound, but 肉's own is [[肉]] itself) — transitivity fails, though 桂 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (nuggwei/눅궤/ㄋㄨㄎㄍ⼔ㄧ) already verified as the correct concatenation — no bug. **Found and fixed a real bug**: `korean` had 계피, the real word for cinnamon but built from the unrelated compound 桂皮 rather than 肉桂's own compositional reading — corrected to 육계 (the real pharmacological Sino-Korean term). Filled blank vietnamese (nhục quế, standard attested term). No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 肉汁.

### 2026-09-05, iteration 2988 — [[words/肉汁|肉汁]]

No cranberry (both 肉's and 汁's own `stand_in` point to themselves). **Found and fixed two real bugs**: `羅馬字`/`諺文` had nugjib/눅집, mismatching 汁's real -ǝ- vowel reading (jǝb/즙) — `注音` (ㄋㄨㄎㄐㄜㄆ) had stayed correct throughout; `korean`/`vietnamese` had 그레이비 (an English loanword transliteration of "gravy") and nước chấm (an unrelated native Vietnamese dipping-sauce term) rather than 肉汁's own compositional readings — corrected to 육즙/nhục trấp. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 肉湯.

### 2026-09-05, iteration 2989 — [[words/肉湯|肉湯]]

No cranberry (both 肉's and 湯's own `stand_in` point to themselves). Pronunciation fields (nugtang/눅탕/ㄋㄨㄎㄊㄚㄫ) already verified as the correct concatenation — no bug. **Found and fixed a real bug**: `korean` had 국물, the everyday native word for "broth" rather than 肉湯's own compositional reading — corrected to 육탕. Filled blank japanese/vietnamese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 肋骨.

### 2026-09-05, iteration 2990 — [[words/肋骨|肋骨]]

No cranberry (肋's own stand-in is this exact compound, but 骨's own is [[骨]] itself) — transitivity fails, though 肋 is legitimized as an independent Dan'a'yo entry by this word. **Found and fixed two real bugs**: `羅馬字` had luggod (mismatching 肋's real -ǝ- vowel, lǝg — 諺文/注音 had already been correct, an unusual single-field-only instance of this bug); `kwin` was true, but the AND-rule requires false. Filled blank cantonese/vietnamese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 肌理.

### 2026-09-05, iteration 2991 — [[words/肌理|肌理]]

No cranberry (肌's own stand-in is [[肌膚]], 理's is [[理由]]). Pronunciation fields (giǝli/긔리/ㄍㄧㄜㄌㄧ) already verified as the correct concatenation — no bug. Fixed a comma-joined `japanese` string (きめ, きり — both genuine readings) into a proper list. Filled blank korean (기리, compositional and attested) and vietnamese (cơ lý), added missing `kwin: false`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 肌膚.

### 2026-09-05, iteration 2992 — [[words/肌膚|肌膚]]

No cranberry (肌's own stand-in is this exact compound, but 膚's own is [[皮膚]]) — transitivity fails, though 肌 is legitimized as an independent Dan'a'yo entry by this word. **Found and fixed a real bug**: `羅馬字`/`諺文` had giǝpu/긔푸 (p-initial), mismatching 膚's real f-initial reading (fǝ/쁘) — `注音` (ㄍㄧㄜㄈㄜ) had stayed correct throughout, matching the ㄈ→ㅃ p/f-confusion class seen repeatedly this session. Filled blank korean/vietnamese, added missing `kwin: false`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 肖像.

### 2026-09-05, iteration 2993 — [[words/肖像|肖像]]

No cranberry (肖's own stand-in is this exact compound, but 像's own is [[彫像]]) — transitivity fails, though 肖 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (syousyang/숏샹/ㄙ⼄ㄨㄙ⼘ㄫ) already verified as the correct concatenation — no bug. Fixed a blank `pos:` field (→ 名詞). Filled blank vietnamese (tiếu tượng, compositional). No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 肘.

### 2026-09-05, iteration 2994 — [[words/肘|肘]]

Single-character stand-in word. Pronunciation fields (jum/줌/ㄐㄨㄇ) already matched the character's own values — no bug. Added missing pos/kwin/japanese, filled `vietnamese: null` → khuỷu. Found a genuine homophone with [[朕]] ("we, royal") — an already-perfected but old (2026-03-29) pass that predates this session's homophone-check convention and had no callout at all; added reciprocal callouts to both, and while touching 朕.md also fixed a bare-string `characters:` field, removed a redundant duplicate `品詞`, and quoted several previously-unquoted string fields. **In passing**, fixed the 18th empty-string field bug on `characters/肘 (char).md` (`hsk_level: ""` → "無"). Stamped `date-last-perfect: 2026-09-05` on all three files.

Next: 股.

### 2026-09-05, iteration 2995 — [[words/股|股]]

Single-character stand-in word, old bare-string `characters:` format rewritten into current template. Pronunciation fields (go/고/ㄍㄛ) already matched the character's own values — no bug. Added missing pos/kwin/japanese (こ, on'yomi matching the same reading used on [[鼓]]). Re-verified the existing 3-way homophone group with [[鼓]] and [[錮]] (already fully cross-linked from 鼓's earlier perfecting pass, which had also confirmed no fourth homophone exists among the other ㄍㄛ-reading characters). Wrote full Notes covering the 會意 etymology and the 溝股/Pythagorean-Theorem citation. Stamped `date-last-perfect: 2026-09-05`.

Next: 肢体.

### 2026-09-05, iteration 2996 — [[words/肢体|肢体]]

No cranberry (肢's own stand-in is this exact compound, but 体's own is [[体系]]) — transitivity fails, though 肢 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (jetei/저테/ㄐㄝㄊㄝㄧ) already verified as the correct concatenation — no bug; `kwin: false` already correct per the AND-rule. Filled blank cantonese (zi1tai2) and vietnamese (chi thể, standard attested term). Removed blank `hsk_level`/`swadesh` (character-page-only fields, not standard on word pages), converted bare-array `characters:`/`aliases:` YAML to proper list formatting, renamed `## Etymology`→`## Notes`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 肥大.

### 2026-09-05, iteration 2997 — [[words/肥大|肥大]]

No cranberry (肥's own stand-in is [[肥満]], 大's own is [[大]] itself) — neither constituent legitimized by this word. Pronunciation fields (buidai/뷔대/ㄅㄨㄧㄉㄚㄧ) already verified as the correct concatenation — no bug. Added missing `kwin: false` (AND-rule: 肥 is false despite 大 being true). Removed a stray space from `cantonese` (fei4 daai6→fei4daai6), quoted several previously-unquoted string fields. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 肥桶.

### 2026-09-05, iteration 2998 — [[words/肥桶|肥桶]]

No cranberry (肥's own stand-in is [[肥満]], 桶's own is [[桶]] itself) — neither constituent legitimized by this word. Pronunciation fields (buitong/뷔통/ㄅㄨㄧㄊㄛㄫ) already verified as the correct concatenation — no bug. Added missing `kwin: false` (AND-rule: 肥 is false despite 桶 being true). Removed a stray space from `cantonese` (fei4 tung2→fei4tung2), quoted several previously-unquoted string fields. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 肥満.

### 2026-09-05, iteration 2999 — [[words/肥満|肥満]]

No cranberry (肥's own stand-in is this exact compound, but 満's own is [[満]] itself) — transitivity fails, though 肥 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (buiman/뷔만/ㄅㄨㄧㄇㄚㄋ) already verified as the correct concatenation — no bug. Added missing `kwin: false` (AND-rule: 肥 is false despite 満 being true). Removed a stray space from `cantonese` (fei4 mun5→fei4mun5), quoted several previously-unquoted string fields. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 肥育.

### 2026-09-05, iteration 3000 — [[words/肥育|肥育]]

No cranberry (肥's own stand-in is [[肥満]], 育's own is [[育]] itself) — neither constituent legitimized by this word. Pronunciation fields (bui'yug/뷔육/ㄅㄨㄧ·⼜ㄎ) already verified as the correct concatenation, including the null-onset syllable break — no bug. Added missing `kwin: false` (AND-rule: 肥 is false despite 育 being true). Removed a stray space from `cantonese` (fei4 juk6→fei4juk6), quoted several previously-unquoted string fields. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 肥脊.

### 2026-09-05, iteration 3001 — [[words/肥脊|肥脊]]

No cranberry (肥's own stand-in is [[肥満]], 脊's own is [[脊椎]]) — neither constituent legitimized by this word. Pronunciation fields (buijeg/뷔적/ㄅㄨㄧㄐㄝㄎ) already verified as the correct concatenation — no bug. **Found and fixed two real bugs**: `cantonese` had zik1 instead of 脊's own zik3 (fei4 zik1→fei4zik3); `vietnamese` had tịch instead of 脊's own tích (phì tịch→phì tích). Added missing `kwin: false` (AND-rule). Kept the word's already-thorough existing Notes (documents 脊 standing in for its own alias 瘠 via the shared Dan'a'yo syllable). No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 肩甲骨.

### 2026-09-05, iteration 3002 — [[words/肩甲骨|肩甲骨]]

No cranberry (none of the three constituents' own stand-ins point here — 肩/甲/骨 all point to themselves). Pronunciation fields (gengabgod/건갑곧/ㄍㄝㄋㄍㄚㄆㄍㄛㄊ) already verified as the correct concatenation — no bug; `kwin: false` already correct per the AND-rule. **Found and fixed three real bugs**: `mandarin`/`cantonese`/`korean` were all truncated, missing 骨's own final syllable entirely (jiānjiǎ→jiānjiǎgǔ; gin1 gaap3→gin1gaap3gwat1; 견갑→견갑골). Fixed redlinked bare-character citations in `characters:` (肩/甲/骨→disambiguated `(char)` filenames — these bare names belong to the *word* pages, not the character pages). Filled blank vietnamese (kiên giáp cốt). Fixed `aliases`: removed 肩膀 (an unrelated near-synonym meaning "shoulder," not "shoulder blade") and corrected truncated 肩胛→肩胛骨 (the genuine modern-standard alternate spelling, using specialized 胛 in place of the phonetic loan 甲). Removed blank hsk_level/swadesh. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 肩章.

### 2026-09-05, iteration 3003 — [[words/肩章|肩章]]

No cranberry (肩's own stand-in is [[肩]] itself, 章's own is [[章]] itself) — neither constituent legitimized by this word. **Found and fixed a real bug**: `諺文` had 겅장, an illegal cross-syllable nasal-place assimilation of 肩's own final ㄴ→ㅇ (forbidden per `grammar/文法 - 02音韻論.md` line 150) — corrected to the straight concatenation 건장; `羅馬字`/`注音` had already stayed correct throughout. `kwin: false` already correct per the AND-rule. Filled blank pos and vietnamese. No homophones. Stamped `date-last-perfect: 2026-09-05`. **Tooling note**: the vault's filesystem is running unusually slow right now (~85s just to scan all of `words/`+`characters/` once) — `homophone_check.py` timed out and was killed twice before recognizing it wasn't hung, just slow; ran to completion fine in the background on the third attempt. Not an infinite loop — just budget more wall-clock time (backgrounded, don't kill early) if this recurs.

Next: 肪.

### 2026-09-05, iteration 3004 — [[words/肪|肪]]

Single-character stand-in word. Pronunciation fields (fang/빵/ㄈㄚㄫ) already matched the character's own values — no bug. Added missing pos/japanese (ボウ, on-reading since no native kun exists), filled `vietnamese: null`→phòng. Re-verified the genuine homophone with [[紡]] (already fully cross-linked from 紡's own retroactive-recheck pass), and confirmed no third homophone exists among the other ㄈㄚㄫ-reading characters (倣/坊/妨/放/方/芳/訪 — none has a self-pointing `stand_in`). Stamped `date-last-perfect: 2026-09-05`.

Next: 育.

### 2026-09-05, iteration 3005 — [[words/育|育]]

Single-character stand-in word. **Found and fixed a real bug**: `羅馬字` was missing the leading null-onset apostrophe (yug→'yug; 諺文/注音 already correct). Fixed a typo in `english` (nuture→nurture), added missing pos/japanese (そだつ, native kun-reading), filled `vietnamese: null`→dục, added missing `kwin: true`. Checked the one other ⼜ㄎ-reading character, 郁 — its `stand_in` is the special `名専字` (name-only) marker, not a real word, so no homophone. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 肺臓.

### 2026-09-05, iteration 3006 — [[words/肺臓|肺臓]]

No cranberry (肺's own stand-in is this exact compound, but 臓's own is [[内臓]]) — transitivity fails, though 肺 is legitimized as an independent Dan'a'yo entry by this word. **Found and fixed two real bugs**: `羅馬字`/`諺文` had pyejang/펴장 (p-initial), mismatching 肺's real f-initial reading (fe/뻐) — same ㄈ→ㅍ (should be ㅃ) failure class as the 福-family bug; `注音` had already stayed correct. `korean` had 폐장; 허파, wrongly appending 肺's own native gloss 허파 onto the correct compositional 폐장 — trimmed to just 폐장. Filled blank vietnamese (phế tạng). Added missing `kwin: false` (AND-rule: 肺 is false despite 臓 being true), removed a stray space from cantonese, converted bare-array YAML. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 胃.

### 2026-09-05, iteration 3007 — [[words/胃|胃]]

Single-character stand-in word. Pronunciation fields (wi/위/ㄨㄧ) already matched the character's own values — no bug. Added missing pos/japanese (イ, on-reading since no native kun exists), filled `vietnamese: null`→vị. Checked the six other ㄨㄧ-reading characters (偉/囲/緯/謂/違/韋) — none has a self-pointing `stand_in` (韋's is the special `名専字` name-only marker), so no homophone. Stamped `date-last-perfect: 2026-09-05`.

Next: 胃炎.

### 2026-09-05, iteration 3008 — [[words/胃炎|胃炎]]

No cranberry (胃's own stand-in is [[胃]] itself, 炎's own is [[炎症]]) — neither constituent legitimized by this word. **Found and fixed a real bug**: `羅馬字` had a spurious extra leading apostrophe ('wi'em) — 胃's own reading (wi) carries no null-onset marker, only 炎's own ('em) does — corrected to wi'em; `諺文`/`注音` had already stayed correct. Filled blank pos, korean (위염, the real attested medical term), and vietnamese (vị viêm). Added missing `kwin: false` (AND-rule: 炎 is false despite 胃 being true). No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 胃痛.

### 2026-09-05, iteration 3009 — [[words/胃痛|胃痛]]

No cranberry (胃's own stand-in is [[胃]] itself, 痛's own is [[苦痛]]) — neither constituent legitimized by this word. **Found and fixed a real bug**: `羅馬字` had a spurious extra leading apostrophe ('witong), same class as 胃炎's fix two iterations ago — corrected to witong; `諺文`/`注音` had already stayed correct. `kwin: true` was already correct (both constituents individually true). Filled blank pos and vietnamese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 胃癌.

### 2026-09-05, iteration 3010 — [[words/胃癌|胃癌]]

No cranberry (胃's own stand-in is [[胃]] itself, 癌's own is [[癌症]]) — neither constituent legitimized by this word. **Found and fixed two real bugs**: `羅馬字` had a spurious extra leading apostrophe ('wi'am), same class as 胃炎/胃痛's earlier fixes — corrected to wi'am; `諺文`/`注音` had already stayed correct. `mandarin` was comma-joined with a stray second value, wèiyán — the *pre-1962* reading of 癌 (documented on `characters/癌.md`: Mandarin ái was a deliberate 1962 change away from yán specifically to avoid clinical confusion with homophonous 炎, i.e. with [[胃炎]]), not a live alternate — trimmed to just wèi'ái. Filled blank vietnamese (vị nham). `kwin: true` already correct. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 胃酸.

### 2026-09-05, iteration 3011 — [[words/胃酸|胃酸]]

No cranberry (胃's own stand-in is [[胃]] itself, 酸's own is [[酸]] itself) — neither constituent legitimized by this word. **Found and fixed a real bug**: `羅馬字` had a spurious extra leading apostrophe ('wiswan), same recurring class as the last three 胃-compounds — corrected to wiswan; `諺文`/`注音` had already stayed correct. Filled blank pos and vietnamese. `kwin: false` already correct per the AND-rule. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 胆嚢.

### 2026-09-05, iteration 3012 — [[words/胆嚢|胆嚢]]

**Genuine `#cranberry`**: both 胆's and 嚢's own stand-ins point here (3rd cranberry found this session, after [[程度]]/[[種類]]). Pronunciation fields (damnang/담낭/ㄉㄚㄇㄋㄚㄫ) already verified as the correct concatenation. **Found and fixed a real bug**: `kwin` was stored true, but the AND-rule requires false (胆 is individually false despite 嚢 being true). Filled blank vietnamese (đảm nang). Fixed a missing "(stand-in for 嚢)" annotation on `characters/嚢.md`'s own Words-list citation. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 背.

### 2026-09-05, iteration 3013 — [[words/背|背]]

Single-character stand-in word. Pronunciation fields (boi/뵈/ㄅㄛㄧ) already matched the character's own values — no bug. Added missing pos/japanese (せなか, native kun-reading), filled `vietnamese: null`→bối. Found a genuine **three-way homophone group** with [[杯]] (already perfected but missing its callout, now added) and [[陪]] (still otherwise unperfected — gave it a full pass too: fixed pos/kwin/japanese/vietnamese, fixed missing stand-in annotation on `characters/陪 (char).md`). All three coincide at boi/뵈/ㄅㄛㄧ and share the same Sino-Korean reading 배 as well. Checked the two other ㄅㄛㄧ-reading characters, 悖 and 賠 — neither has a self-pointing `stand_in` (悖's is the special `名専字` marker, 賠's own is [[賠償]]), so no fourth homophone. Stamped `date-last-perfect: 2026-09-05` on all three word pages.

Next: 背後.

### 2026-09-05, iteration 3014 — [[words/背後|背後]]

No cranberry (背's own stand-in is [[背]] itself, 後's own is [[後]] itself) — neither constituent legitimized by this word. **Found and fixed a real bug**: `羅馬字`/`諺文`/`注音` all had a vowel-order transposition on 後's own syllable (hou/홋/ㄏㄛㄨ instead of the character's real huo/훗/ㄏㄨㄛ) — corrected to boihuo/뵈훗/ㄅㄛㄧㄏㄨㄛ. Flagged the same transposition on several other 後-citations (最後, 以後, 前後 on 後's own character page) for a future check when the sweep reaches them. `kwin: false` already correct. Filled blank vietnamese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 背景.

### 2026-09-05, iteration 3015 — [[words/背景|背景]]

No cranberry (背's own stand-in is [[背]] itself, 景's own is [[景色]]) — neither constituent legitimized by this word. Pronunciation fields (boigyeng/뵈경/ㄅㄛㄧㄍ⼶ㄫ) already verified as the correct concatenation — no bug; `kwin: false` already correct per the AND-rule. Removed a redundant `品詞` duplicate of `pos`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 背骨.

### 2026-09-05, iteration 3016 — [[words/背骨|背骨]]

No cranberry (背's own stand-in is [[背]] itself, 骨's own is [[骨]] itself) — neither constituent legitimized by this word. Pronunciation fields (boigod/뵈곧/ㄅㄛㄧㄍㄛㄊ) already verified as the correct concatenation — no bug. Added missing `kwin: false` (AND-rule: both constituents individually false). Filled blank cantonese and vietnamese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 胎児.

### 2026-09-05, iteration 3017 — [[words/胎児|胎児]]

No cranberry (胎's own stand-in is this exact compound, but 児's own is [[児]] itself) — transitivity fails, though 胎 is legitimized as an independent Dan'a'yo entry by this word. **Found and fixed a real bug**: `諺文` had 타에 (ㅏ vowel), mismatching 胎's real ㅐ-vowel reading (태) — corrected to 태에; `羅馬字`/`注音` had already stayed correct. Also cleaned a stray zero-width-space character embedded in `japanese`. Filled blank pos. `kwin: false` already correct per the AND-rule. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 胎盤.

### 2026-09-05, iteration 3018 — [[words/胎盤|胎盤]]

No cranberry (胎's own stand-in is [[胎児]], 盤's own is [[盤]] itself) — neither constituent legitimized by this word. Pronunciation fields (taiban/태반/ㄊㄚㄧㄅㄚㄋ) already verified as the correct concatenation — no bug; `kwin: true` already correct. Filled blank pos and vietnamese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 胞衣.

### 2026-09-05, iteration 3019 — [[words/胞衣|胞衣]]

No cranberry (胞's own stand-in is this exact compound, but 衣's own is [[衣類]]) — transitivity fails, though 胞 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (byau'iǝ/뱟의/ㄅ⼘ㄨㄧㄜ) already verified as the correct concatenation — no bug. Added missing `kwin: false` (AND-rule: 胞 is false despite 衣 being true). Filled blank vietnamese (bào y, the classical Sino-Vietnamese medical term). Confirmed japanese えな is a genuine irregular reading (熟字訓-type), not a bug. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 胡志明市.

### 2026-09-05, iteration 3020 — [[words/胡志明市|胡志明市]]

No cranberry (none of the four constituents' own stand-ins point here). **Found and fixed a real bug**: `羅馬字`/`諺文` had ho/호 instead of 胡's real reading hou/홋 — corrected to houjimyengsi/홋지명시; `注音` had already stayed correct throughout. `kwin: false` already correct per the AND-rule. Filled blank cantonese. As a proper place name, mandarin/japanese/korean/vietnamese legitimately hold the real attested name/transliteration rather than a compositional gloss. Fixed a malformed plain-link citation (missing ruby/rt formatting) on `characters/胡.md`'s own Words list. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 胡瓜.

### 2026-09-05, iteration 3021 — [[words/胡瓜|胡瓜]]

No cranberry (瓜's own stand-in is this exact compound, but 胡's own is [[胡乱]]) — transitivity fails, though 瓜 is legitimized as an independent Dan'a'yo entry by this word. **Found and fixed a real bug**: `羅馬字` was missing 胡's own -u- glide (hogwa→hougwa) — a rare single-field-only instance, since `諺文`/`注音` had already stayed correct. `kwin: false` already correct. Converted `japanese`'s semicolon-joined value (きゅうり/きうり) into a proper list — both are genuine irregular readings, neither compositional. Kept `korean` 오이 as the real native word (matches 瓜's own `korean_native`), not a bug. Filled blank vietnamese (hồ qua). Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 胡芦.

### 2026-09-05, iteration 3022 — [[words/胡芦|胡芦]]

No cranberry (胡's own stand-in is [[胡乱]], 芦's own is [[芦葦]]) — neither constituent legitimized by this word. **Found and fixed a real bug**: `羅馬字` was missing 胡's own -u- glide (holo→houlo), same single-field-only class as [[胡瓜]]'s fix — `諺文`/`注音` had already stayed correct. `kwin: false` already correct. Verified vietnamese hồ lô is a genuine attested loanword (not compositional from 芦's own "lư," but independently real) — not a bug. Fixed cantonese's stray space. Removed blank hsk_level/swadesh. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 胡麻.

### 2026-09-05, iteration 3023 — [[words/胡麻|胡麻]]

No cranberry (胡's own stand-in is [[胡乱]], 麻's own is [[大麻]]) — neither constituent legitimized by this word. **Found and fixed several real bugs**: `羅馬字` missing 胡's -u- glide (homa→houma), 3rd occurrence of this exact bug in a row across the 胡-compounds ([[胡瓜]], [[胡芦]], now this). `mandarin`/`cantonese` had been contaminated with the alias 芝麻's own readings (hīma/zi1 ma2→húmá/wu4maa4). `korean` held a native phrase (참깨속) instead of the real Sino-Korean term 호마. Filled blank vietnamese (hồ ma). Japanese ごま (using 胡's alternate on'yomi GO) was already correct. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 胰臓.

### 2026-09-05, iteration 3024 — [[words/胰臓|胰臓]]

No cranberry (胰's own stand-in is this exact compound, but 臓's own is [[内臓]]) — transitivity fails, though 胰 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields ('iǝjang/의장/ㄧㄜㄐㄚㄫ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Converted comma-joined vietnamese to a list. Verified that japanese すいぞう/korean 췌장/vietnamese tụy are all genuine attested readings tied to the alias spelling 膵臓 (a Japanese kokuji distinct from 胰) rather than compositional derivations or bugs — documented in Notes, not "fixed." Fixed a missing "(stand-in for 胰)" annotation on `characters/胰.md`'s own Words list. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 胸臆.

### 2026-09-05, iteration 3025 — [[words/胸臆|胸臆]]

No cranberry (臆's own stand-in is this exact compound, but 胸's own is [[胸部]]) — transitivity fails, though 臆 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (hyong'ig/횽익/ㄏ⼄ㄫㄧㄎ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Filled blank cantonese and vietnamese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 能力.

### 2026-09-05, iteration 3026 — [[words/能力|能力]]

No cranberry (能's own stand-in is [[技能]], 力's own is [[力]] itself) — neither constituent legitimized by this word. Pronunciation fields (nǝnglig/능릭/ㄋㄜㄫㄌㄧㄎ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Body was already unusually thorough — kept nearly all of it, just added the opening cranberry-check bullet and quoted pronunciation fields, fixed cantonese stray space. Fixed a missing "(stand-in for 力)" annotation on `characters/力 (char).md`'s own Words list. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 脊椎.

### 2026-09-05, iteration 3027 — [[words/脊椎|脊椎]]

**Genuine `#cranberry`**: both 脊's and 椎's own stand-ins point here (4th cranberry this session, after [[程度]]/[[種類]]/[[胆嚢]]). Pronunciation fields (jegcui/적취/ㄐㄝㄎㄑㄨㄧ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Converted comma-joined mandarin (jǐzhuī, jízhuī — a genuinely attested dual reading) and cantonese (matching zek3/zik3 variation) into proper lists. Filled blank vietnamese. Fixed a missing "(stand-in for 椎)" annotation on `characters/椎.md`'s own Words list. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 脚.

### 2026-09-05, iteration 3028 — [[words/脚|脚]]

Single-character stand-in word. Pronunciation fields (gyag/갹/ㄍ⼘ㄎ) already matched the character's own values — no bug. Added missing pos/japanese (あし, native kun-reading), filled `vietnamese: null`→cước. Fixed a missing "(stand-in for 脚)" annotation on the char page's own Words list. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 脚踝.

### 2026-09-05, iteration 3029 — [[words/脚踝|脚踝]]

No cranberry (踝's own stand-in is this exact compound, but 脚's own is [[脚]] itself) — transitivity fails, though 踝 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (gyaghwa/갹화/ㄍ⼘ㄎㄏ⺢) already verified as the correct concatenation — no bug; `kwin: false` already correct. Converted comma-joined japanese and vietnamese into proper lists — all real attested native terms, none compositional. Verified korean 발목 as a genuine real word (not a bug). Fixed cantonese stray space. Fixed a completely missing `## Words` section on `characters/踝.md` (added the stand-in citation). No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 脱.

### 2026-09-05, iteration 3030 — [[words/脱|脱]]

Single-character stand-in word. Pronunciation fields (dwad/돧/ㄉ⺢ㄊ) already matched the character's own values — no bug. **Found and fixed two real bugs**: `korean` and `vietnamese` both held the literal string `"null"` — fixed to 탈 and thoát respectively. Added missing pos/japanese (ぬぐ, native kun-reading). Fixed a self-citation entirely missing from the char page's own Words list (only 脱稿 had been listed). Checked the one other ㄉ⺢ㄊ-reading character, 奪 — its own `stand_in` is [[奪取]], so no homophone. Stamped `date-last-perfect: 2026-09-05`.

Next: 脱稿.

### 2026-09-05, iteration 3031 — [[words/脱稿|脱稿]]

No cranberry (脱's own stand-in is [[脱]] itself, 稿's own is [[稿]] itself) — neither constituent legitimized by this word. Pronunciation fields (dwadgau/돧갓/ㄉ⺢ㄊㄍㄚㄨ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 脳.

### 2026-09-05, iteration 3032 — [[words/脳|脳]]

Single-character stand-in word. Pronunciation fields (nau/낫/ㄋㄚㄨ) already matched the character's own values — no bug. **Found and fixed two real bugs**: `korean` and `vietnamese` both held the literal string `"null"` — fixed to 뇌 and não. Added missing pos/japanese (なずき). Found a genuine homophone with [[悩]] ("angered, mad," already perfected but missing its callout) — added reciprocal callouts to both. No homophones beyond that. Stamped `date-last-perfect: 2026-09-05`.

Next: 脹脛.

### 2026-09-05, iteration 3033 — [[words/脹脛|脹脛]]

No cranberry (脹's own stand-in is [[腫脹]], 脛's own is [[脛骨]]) — neither constituent legitimized by this word. **Found and fixed a real bug**: `mandarin` had been contaminated with the alias 小腿's own reading (xiǎotuǐ) instead of the compositional zhàngjìng. Fixed cantonese's stray space (using 脛's own ging3 of its two stored candidates). Filled blank vietnamese. Verified japanese ふくらはぎ/korean 종아리 as genuine attested native terms, not bugs. Fixed a plain-link citation on `characters/脹.md` and a completely missing citation on `characters/脛.md`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 脾臓.

### 2026-09-05, iteration 3034 — [[words/脾臓|脾臓]]

No cranberry (脾's own stand-in is this exact compound, but 臓's own is [[内臓]]) — transitivity fails, though 脾 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (bijang/비장/ㄅㄧㄐㄚㄫ) already verified as the correct concatenation — no bug; `kwin: true` already correct. Filled blank vietnamese. Incorporated a stray body sentence about the TCM spleen/pancreas conflation into proper Notes prose. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 腎臓.

### 2026-09-05, iteration 3035 — [[words/腎臓|腎臓]]

No cranberry (腎's own stand-in is this exact compound, but 臓's own is [[内臓]]) — transitivity fails, though 腎 is legitimized as an independent Dan'a'yo entry by this word. **Found and fixed a real bug**: `cantonese` had san6, mismatching 腎's own san5 (a tone error) — corrected to san5zong6. `kwin: true` already correct. Filled blank vietnamese. Re-verified the existing homophone with [[伸長]] — confirmed no third word shares this reading. Stamped `date-last-perfect: 2026-09-05`.

Next: 腕.

### 2026-09-05, iteration 3036 — [[words/腕|腕]]

Single-character stand-in word. Pronunciation fields ('wan/완/⺢ㄋ) already matched the character's own values — no bug. Added missing pos/japanese (うで, native kun-reading), filled `vietnamese: null`→oản. Re-verified the existing homophone with [[碗]] (already fully cross-linked). Checked the three other ⺢ㄋ-reading characters (玩, 翫, 頑) — none has a self-pointing `stand_in`, confirming no third homophone. Stamped `date-last-perfect: 2026-09-05`.

Next: 腫脹.

### 2026-09-05, iteration 3037 — [[words/腫脹|腫脹]]

No cranberry (脹's own stand-in is this exact compound, but 腫's own is [[腫瘍]]) — transitivity fails, though 脹 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (jongcang/종창/ㄐㄛㄫㄑㄚㄫ) already verified as the correct concatenation — no bug. **Found and fixed a real bug**: `kwin` was false, but the AND-rule requires true (both constituents individually true). Fixed cantonese's stray space. Fixed a missing citation on `characters/腫.md`'s own Words list. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 腰部.

### 2026-09-05, iteration 3038 — [[words/腰部|腰部]]

No cranberry (腰's own stand-in is this exact compound, but 部's own is [[部]] itself) — transitivity fails, though 腰 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields ('youbou/욧봇/⼄ㄨㄅㄛㄨ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Filled blank vietnamese (yêu bộ, using 腰's alternate reading). No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 腰骨.

### 2026-09-05, iteration 3039 — [[words/腰骨|腰骨]]

No cranberry (腰's own stand-in is [[腰部]], 骨's own is [[骨]] itself) — neither constituent legitimized by this word. **Found and fixed a real bug**: `mandarin`/`cantonese`/`korean`/`vietnamese` had all been contaminated with the alias 髋骨's own readings (kuāngǔ/fun1 gwat1/관골; 볼기뼈/Xương chậu) instead of the compositional yāogǔ/jiu1gwat1/요골/yêu cốt — same class as [[脹脛]]'s earlier mandarin fix, but affecting all four fields here. Noted korean 요골 is a coincidental false friend (real word for "radius," unrelated). Japanese こしぼね was already correct. Pronunciation fields ('yougod/욧곧/⼄ㄨㄍㄛㄊ) already verified as the correct concatenation. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 腹.

### 2026-09-05, iteration 3040 — [[words/腹|腹]]

Single-character stand-in word — closes the previously-flagged known gap. Pronunciation fields (fug/뿍/ㄈㄨㄎ) already matched the character's own values — no bug. Added missing pos/japanese (はら, native kun-reading), filled `vietnamese: null`→phúc. Re-verified the existing 3-way homophone group with [[福]]/[[副]] (already fully cross-linked). Checked the three other ㄈㄨㄎ-reading characters (幅, 蝠, 覆) — none has a self-pointing `stand_in`, confirming no fourth homophone. Fixed a missing "(stand-in for 腹)" annotation on the char page. Stamped `date-last-perfect: 2026-09-05`.

Next: 腹部.

### 2026-09-05, iteration 3041 — [[words/腹部|腹部]]

No cranberry (腹's own stand-in is [[腹]] itself, 部's own is [[部]] itself) — neither constituent legitimized by this word. **Found and fixed a real bug**: `羅馬字` had bugbou — an exact copy-paste of the unrelated word [[北部]]'s own reading — instead of the correct fugbou (腹's real f-initial); `諺文`/`注音` had already stayed correct. This meant the pre-existing "homophone of 北部" claim was spurious (北部 is bugbou/북봇/ㄅㄨㄎㄅㄛㄨ, genuinely different) — removed the false claim from both pages. Filled blank vietnamese. No genuine homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 膃肭.

### 2026-09-05, iteration 3042 — [[words/膃肭|膃肭]]

**Genuine `#cranberry`** (already correctly tagged): both 腽's and 肭's own stand-ins point here (5th cranberry this session, after [[程度]]/[[種類]]/[[胆嚢]]/[[脊椎]]). Pronunciation fields ('wabnud/왑눋/⺢ㄆㄋㄨㄊ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Added a completely missing vietnamese field (oát nạp, compositional). Fixed missing "(stand-in for X)" annotations on both `characters/腽.md` and `characters/肭.md`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 膣.

### 2026-09-05, iteration 3043 — [[words/膣|膣]]

Single-character stand-in word. Pronunciation fields (jid/짇/ㄐㄧㄊ) already matched the character's own values — no bug. Confirmed english "cunt" is intentional (char page explicitly documents this as the vulgar term, distinct from neutral [[陰道]]). **Found and fixed a real bug**: character page's `japanese_native: ちち` was unverifiable/almost certainly erroneous (no real dictionary attests ちち for this meaning) — corrected to `ø`, and set the word's own japanese to the on-reading チツ. Removed redundant `品詞`, normalized the header to the standard `>[!tip]` format. Fixed a self-citation entirely missing from the char page's own Words list. Re-verified the existing 3-way homophone group with [[直]]/[[蛭]] and confirmed no fourth homophone among the other ㄐㄧㄊ-reading characters (嫉, 疾, 質). Stamped `date-last-perfect: 2026-09-05`.

Next: 膿.

### 2026-09-05, iteration 3044 — [[words/膿|膿]]

Single-character stand-in word. Pronunciation fields (nong/농/ㄋㄛㄫ) already matched the character's own values — no bug. Added missing pos/japanese (う, native kun-reading), filled `vietnamese: null`→nung. Checked the two other ㄋㄛㄫ-reading characters (濃, 農) — neither has a self-pointing `stand_in`, confirming no homophone. Fixed a missing "(stand-in for 膿)" annotation on the char page. Stamped `date-last-perfect: 2026-09-05`.

Next: 臘月.

### 2026-09-05, iteration 3045 — [[words/臘月|臘月]]

No cranberry (臘's own stand-in is [[臘八]], 月's own is [[月]] itself) — neither constituent legitimized by this word. Pronunciation fields (lab'wed/랍웓/ㄌㄚㄆ·⼔ㄊ) already verified as the correct concatenation — no bug; `kwin: false` already correct. **Found and fixed a real bug**: `korean` had 납월, a 두음법칙-shifted (South Korean) form — corrected to 랍월 per the vault's standing North-Korean-pronunciation rule. Fixed cantonese's stray space, removed redundant `品詞`. Verified vietnamese tháng Chạp as a genuine attested native term, not a bug. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 臣民.

### 2026-09-05, iteration 3046 — [[words/臣民|臣民]]

No cranberry (臣's own stand-in is [[大臣]], 民's own is [[人民]]) — neither constituent legitimized by this word. Pronunciation fields (sinmin/신민/ㄙㄧㄋㄇㄧㄋ) already verified as the correct concatenation — no bug; `kwin: true` already correct. Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 自主.

### 2026-09-05, iteration 3047 — [[words/自主|自主]]

No cranberry (自's own stand-in is [[自身]], 主's own is [[主人]]) — neither constituent legitimized by this word. Pronunciation fields (jiǝju/즤주/ㄐㄧㄜㄐㄨ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 自分.

### 2026-09-05, iteration 3048 — [[words/自分|自分]]

No cranberry (自's own stand-in is [[自身]], 分's own is [[分]] itself) — neither constituent legitimized by this word. Pronunciation fields (jiǝbun/즤분/ㄐㄧㄜㄅㄨㄋ) already verified as the correct concatenation — no bug. Added missing `kwin: false` (AND-rule). Mandarin zìfèn uses 分's genuine alternate fèn tone (the "status/duty" sense) rather than the character's stored primary fēn — not a bug. Filled blank cantonese/korean/vietnamese. Verified japanese じぶん as the real, common Japanese word (broader meaning "oneself" than the narrower literary Chinese sense here) — not a bug. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 自制.

### 2026-09-05, iteration 3049 — [[words/自制|自制]]

No cranberry (自's own stand-in is [[自身]], 制's own is [[抑制]]) — neither constituent legitimized by this word. Pronunciation fields (jiǝjei/즤제/ㄐㄧㄜㄐㄝㄧ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Filled blank vietnamese. Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 自動詞.

### 2026-09-05, iteration 3050 — [[words/自動詞|自動詞]]

No cranberry (none of the three constituents' own stand-ins point here). Pronunciation fields (jiǝdongsa/즤동사/ㄐㄧㄜㄉㄛㄫㄙㄚ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Filled blank vietnamese (tự động từ, matching the established grammatical-term convention). Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 自動車.

### 2026-09-05, iteration 3051 — [[words/自動車|自動車]]

No cranberry (none of the three constituents' own stand-ins point here). **Found and fixed two real bugs**: `羅馬字` missing 車's own -w- glide (jiǝdongca→jiǝdongcwa; 諺文/注音 had already stayed correct — rare single-field-only instance); `japanese` had じどうしや (small-kana error) instead of じどうしゃ. Fixed redlinked bare-character citations in `characters:` (動/車→disambiguated `(char)` filenames). Fixed cantonese's stray spaces. Filled blank vietnamese. `kwin: false` already correct. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 自在.

### 2026-09-05, iteration 3052 — [[words/自在|自在]]

No cranberry (自's own stand-in is [[自身]], 在's own is [[在]] itself) — neither constituent legitimized by this word. Pronunciation fields (jiǝjai/즤재/ㄐㄧㄜㄐㄚㄧ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Fixed a redlinked bare-character citation (在→在 (char)). Filled blank vietnamese. Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 自得.

### 2026-09-05, iteration 3053 — [[words/自得|自得]]

No cranberry (自's own stand-in is [[自身]], 得's own is [[獲得]]) — neither constituent legitimized by this word. **Found and fixed a real bug**: `羅馬字` had jiǝdug (d-initial, wrong vowel), mismatching 得's real t-initial reading (tǝg) — corrected to jiǝtǝg; `諺文`/`注音` had already stayed correct. Added missing `kwin: false` (AND-rule). Filled blank korean and vietnamese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 自我.

### 2026-09-05, iteration 3054 — [[words/自我|自我]]

No cranberry (自's own stand-in is [[自身]], 我's own is [[我]] itself) — neither constituent legitimized by this word. Pronunciation fields (jiǝ'a/즤아/ㄐㄧㄜ·ㄚ) already verified as the correct concatenation, including the null-onset syllable break — no bug; `kwin: false` already correct. Filled blank vietnamese. Fixed cantonese's stray space. Kept the existing thoughtful Definition/Function/Usage-Principle prose. Fixed a self-citation entirely missing from `characters/我 (char).md`'s own Words list, plus its missing 自我 citation. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 自然.

### 2026-09-05, iteration 3055 — [[words/自然|自然]]

No cranberry (自's own stand-in is [[自身]], 然's own is [[然]] itself) — neither constituent legitimized by this word. Pronunciation fields (jiǝnyen/즤년/ㄐㄧㄜㄋ⼶ㄋ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Fixed cantonese's stray space. Verified japanese しぜん uses 自's genuine alternate on'yomi シ (not ジ) — not a bug. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 自由.

### 2026-09-05, iteration 3056 — [[words/自由|自由]]

No cranberry (自's own stand-in is [[自身]], 由's own is [[由]] itself) — neither constituent legitimized by this word. **Found and fixed a real bug**: `japanese` had じいう (vowel-insertion error) instead of the correct じゆう. Pronunciation fields (jiǝ'yuo/즤윳/ㄐㄧㄜ⼜ㄛ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 自禁.

### 2026-09-05, iteration 3057 — [[words/自禁|自禁]]

No cranberry (自's own stand-in is [[自身]], 禁's own is [[禁止]]) — neither constituent legitimized by this word. Pronunciation fields (jiǝgim/즤김/ㄐㄧㄜㄍㄧㄇ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Translated a stray Chinese-language editorial note ("古代. 使用『自制』請.") into proper English Notes prose (archaic, prefer [[自制]]). Filled blank japanese/vietnamese, fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 自立.

### 2026-09-05, iteration 3058 — [[words/自立|自立]]

No cranberry (自's own stand-in is [[自身]], 立's own is [[立]] itself) — neither constituent legitimized by this word. Pronunciation fields (jiǝlib/즤립/ㄐㄧㄜㄌㄧㄆ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Fixed cantonese's stray space. Fixed a self-citation entirely missing from `characters/立 (char).md`'s own Words list. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 自給.

### 2026-09-05, iteration 3059 — [[words/自給|自給]]

No cranberry (自's own stand-in is [[自身]], 給's own is [[補給]]) — neither constituent legitimized by this word. Pronunciation fields (jiǝgib/즤깁/ㄐㄧㄜㄍㄧㄆ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Verified mandarin zìjǐ uses 給's genuine literary jǐ reading (as in 供給) — not contamination from the coincidentally-homophonous 自己. Filled blank vietnamese. Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 自足.

### 2026-09-05, iteration 3060 — [[words/自足|自足]]

No cranberry (自's own stand-in is [[自身]], 足's own is [[足]] itself) — neither constituent legitimized by this word. Pronunciation fields (jiǝjog/즤족/ㄐㄧㄜㄐㄛㄎ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Filled blank vietnamese (tự túc, matching the real idiom). Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 自身.

### 2026-09-05, iteration 3061 — [[words/自身|自身]]

No cranberry (自's own stand-in is this exact compound, but 身's own is [[身体]]) — transitivity fails, though 自 is legitimized as an independent Dan'a'yo entry by this word (already documented in the existing Notes). Pronunciation fields (jiǝsin/즤신/ㄐㄧㄜㄙㄧㄋ) already verified as the correct concatenation — no bug. **Found and fixed a real bug**: `vietnamese` had mình, a native colloquial pronoun not decomposable from either constituent's own stored reading — corrected to tự thân, matching this word's specific ontic/intrinsic register. Added missing `kwin: false`, quoted pronunciation fields, kept the existing thoughtful Definition/Function/Usage-Principle prose. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 自転車.

### 2026-09-05, iteration 3062 — [[words/自転車|自転車]]

No cranberry (none of the three constituents' own stand-ins point here). **Found and fixed a real bug**: `羅馬字` missing 車's own -w- glide (jiǝjwenca→jiǝjwencwa), same single-field-only class as [[自動車]]'s earlier fix — `諺文`/`注音` had already stayed correct. Filled blank cantonese. Verified korean 자전거 (alternate 거 reading of 車, specific to this compound) and vietnamese xe đạp (a genuine native term) as real, not bugs. Fixed a missing "(stand-in for 転)" annotation and a completely missing 自転車 citation on `characters/転.md`'s own Words list. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 至日.

### 2026-09-05, iteration 3063 — [[words/至日|至日]]

No cranberry (至's own stand-in is [[至]] itself, 日's own is [[日]] itself) — neither constituent legitimized by this word. Pronunciation fields (jiǝnid/즤닏/ㄐㄧㄜㄋㄧㄊ) already verified as the correct concatenation — no bug (至 and 自 coincidentally share the exact same syllable jiǝ/즤/ㄐㄧㄜ, confirmed genuine, not contamination). Added missing `kwin: false`. Filled a completely missing vietnamese field. Quoted pronunciation fields. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 至極.

### 2026-09-05, iteration 3064 — [[words/至極|至極]]

No cranberry (至's own stand-in is [[至]] itself, 極's own is [[極]] itself) — neither constituent legitimized by this word. Pronunciation fields (jiǝgig/즤긱/ㄐㄧㄜㄍㄧㄎ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Filled blank vietnamese. Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 至点.

### 2026-09-05, iteration 3065 — [[words/至点|至点]]

No cranberry (至's own stand-in is [[至]] itself, 点's own is [[点]] itself) — neither constituent legitimized by this word. Pronunciation fields (jiǝdem/즤덤/ㄐㄧㄜㄉㄝㄇ) already verified as the correct concatenation — no bug. Added missing `kwin: false`. Fixed cantonese's stray space and quoted pronunciation fields. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 致.

### 2026-09-05, iteration 3066 — [[words/致|致]]

Single-character stand-in word. Pronunciation fields (ciǝ/츼/ㄑㄧㄜ) already matched the character's own values — no bug. Added missing pos/japanese/vietnamese. Found a genuine homophone with [[遅]] ("late, slow") — gave it a full pass too since otherwise unperfected (fixed two literal-`"null"`-string bugs on korean/vietnamese, added missing pos/kwin/japanese), added reciprocal callouts. Checked the third ㄑㄧㄜ-reading character, 次 — its own `stand_in` is [[次第]], no third homophone. Fixed a self-citation entirely missing from `characters/致 (char).md`'s own Words list. Stamped `date-last-perfect: 2026-09-05` on both word pages.

Next: 致使.

### 2026-09-05, iteration 3067 — [[words/致使|致使]]

No cranberry (致's own stand-in is [[致]] itself, 使's own is [[使者]]) — neither constituent legitimized by this word. Pronunciation fields (ciǝsi/츼시/ㄑㄧㄜㄙㄧ) already verified as the correct concatenation — no bug. Added missing `kwin: false`. Filled blank japanese/korean/vietnamese, fixed cantonese's stray space, removed redundant `品詞`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 興.

### 2026-09-05, iteration 3068 — [[words/興|興]]

Single-character stand-in word. Pronunciation fields (hǝng/흥/ㄏㄜㄫ) already matched the character's own values — no bug. Added missing pos/japanese (おこ, native kun-reading), filled blank vietnamese. Fixed a missing "(stand-in for 興)" annotation on the char page. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 舌根.

### 2026-09-05, iteration 3069 — [[words/舌根|舌根]]

No cranberry (舌's own stand-in is [[舌]] itself, 根's own is [[根]] itself) — neither constituent legitimized by this word. **Found and fixed two real bugs**: `羅馬字`/`諺文` had a vowel mismatch on 根's syllable (sedgan/섣간→sedgǝn/섣근; `注音` had already stayed correct); `cantonese` had a tone error (sit6→sit3, matching 舌's own sit3). Fixed a wrong rt-annotation (ㄍㄨㄋ→ㄍㄜㄋ) and a missing self-citation on `characters/舌 (char).md`'s own Words list. Fixed a comma-joined `vietnamese` on `characters/根 (char).md` into a proper list. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 舗.

### 2026-09-05, iteration 3070 — [[words/舗|舗]]

Single-character stand-in word. Pronunciation fields (pou/폿/ㄆㄛㄨ) already matched the character's own values — no bug. Added missing pos/japanese (ホ, on-reading since no native kun exists). No homophones. In passing, fixed the 19th empty-string field bug on `characters/舗 (char).md` (`hsk_level: ""` → "無"). Stamped `date-last-perfect: 2026-09-05`.

Next: 航空.

### 2026-09-05, iteration 3071 — [[words/航空|航空]]

No cranberry (航's own stand-in is [[航行]], 空's own is [[空]] itself) — neither constituent legitimized by this word. **Found and fixed a real bug**: `japanese` had かうくう instead of こうくう (koukuu). Pronunciation fields (hangkong/항콩/ㄏㄚㄫㄎㄛㄫ) already verified as the correct concatenation — no bug; `kwin: false` already correct. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 航空母艦.

### 2026-09-05, iteration 3072 — [[words/航空母艦|航空母艦]]

No cranberry (none of the four constituents' own stand-ins point here). **Found and fixed a real bug**: `japanese` had かうくうぼかん instead of こうくうぼかん, same class as [[航空]]'s earlier fix. Pronunciation fields (hangkongmouham/항콩못함/ㄏㄚㄫㄎㄛㄫㄇㄛㄨㄏㄚㄇ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Fixed cantonese's stray spaces. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 船尾.

### 2026-09-05, iteration 3073 — [[words/船尾|船尾]]

No cranberry (船's own stand-in is [[船舶]], 尾's own is [[尾]] itself) — neither constituent legitimized by this word. **Found and fixed a real bug**: `羅馬字` had jwenmui, using 船's minority cross-word syllable (already flagged on `characters/船.md` as inconsistent between the majority swem-group and the [[艦船]]/[[宇宙船]] jwen-outliers) instead of this word's own already-correct `諺文`/`注音` (matching the majority swem group) — corrected to swemmui. Filled blank vietnamese. Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 船籍.

### 2026-09-05, iteration 3074 — [[words/船籍|船籍]]

No cranberry (船's own stand-in is [[船舶]], 籍's own is [[書籍]]) — neither constituent legitimized by this word. **Found and fixed a real bug**: `羅馬字` had jwenjeg (船's minority cross-word syllable, same class as [[船尾]]'s just-fixed bug) instead of the correct swemjeg matching `諺文`/`注音`. Added missing `kwin: false`. Filled blank cantonese/korean/vietnamese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 船舶.

### 2026-09-05, iteration 3075 — [[words/船舶|船舶]]

**Genuine `#cranberry`** (already correctly tagged): both 船's and 舶's own stand-ins point here (6th cranberry this session). Pronunciation fields (swembag/쉄박/ㄙ⼔ㄇㄅㄚㄎ) already correctly used 船's majority syllable — no bug here, unlike the jwen-mistakes just fixed on [[船尾]]/[[船籍]]. `kwin: false` already correct. Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 艇.

### 2026-09-05, iteration 3076 — [[words/艇|艇]]

Single-character stand-in word. Pronunciation fields (deng/덩/ㄉㄝㄫ) already matched the character's own values — Dan'a'yo's d-initial legitimately diverges from Mandarin's t-initial (MC 定 derivation), not a bug. Added missing japanese/vietnamese. Found a genuine **three-way homophone group** with [[丁]] (already stamped but missing callouts and carrying a trailing-space/redundant-`品詞` issue, both fixed) and [[釘]] (still otherwise unperfected — gave it a full pass, fixed a literal-`"null"`-string vietnamese bug, added missing pos/kwin/japanese). Checked the other five ㄉㄝㄫ-reading characters (亭, 停, 庭, 廷, 挺) — no fourth homophone. Fixed missing self-citations on `characters/丁 (char).md` and `characters/釘 (char).md`. Stamped `date-last-perfect: 2026-09-05` on all three word pages.

Next: 艦船.

### 2026-09-05, iteration 3077 — [[words/艦船|艦船]]

No cranberry (艦's own stand-in is this exact compound, but 船's own is [[船舶]]) — transitivity fails, though 艦 is legitimized as an independent Dan'a'yo entry by this word. **Resolved the flagged `characters/船.md` discrepancy**: 艦船's own `諺文` had already correctly stored swem's hangul (쉄) all along, while `羅馬字`/`注音` alone had drifted to a different reading (jwen) — corrected to match, closing out one of the two flagged outliers ([[宇宙船]] remains to be checked). Fixed the wrong rt-tag and a duplicate citation on `characters/艦.md`'s own Words list. Filled blank vietnamese. Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 良好.

### 2026-09-05, iteration 3078 — [[words/良好|良好]]

No cranberry (良's own stand-in is this exact compound, but 好's own is [[好]] itself) — transitivity fails, though 良 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (lyanghau/량핫/ㄌ⼘ㄫㄏㄚㄨ) already verified as the correct concatenation — no bug; `kwin: false` already correct. **Found and fixed a real bug**: `korean` was 두음법칙-shifted (양호→량호), per the standing North-Korean-pronunciation rule. Filled blank vietnamese. Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 良月.

### 2026-09-05, iteration 3079 — [[words/良月|良月]]

No cranberry (良's own stand-in is [[良好]], 月's own is [[月]] itself) — neither constituent legitimized by this word. Pronunciation fields (lyang'wed/량웓/ㄌ⼘ㄫ·⼔ㄊ) already verified as the correct concatenation, including the null-onset syllable break — no bug; `kwin: false` already correct. Verified japanese よいつき (native よい+つき) and vietnamese tháng lương (native word order, like [[臘月]]) as genuine attested terms, not bugs. Fixed cantonese's stray space, removed redundant `品詞`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 色金.

### 2026-09-05, iteration 3080 — [[words/色金|色金]]

No cranberry (色's own stand-in is [[色彩]], 金's own is [[金]] itself). Periodic-table neologism (chromium); pronunciation fields already correct; real-element-reading fields (mandarin gè, korean 크로뮴, japanese クロム, vietnamese crôm) legitimately non-compositional per established convention. Removed redundant `品詞`. Kept the existing thorough etymology essay. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 艶福.

### 2026-09-05, iteration 3081 — [[words/艶福|艶福]]

No cranberry (艶's own stand-in is [[艶]] itself, 福's own is [[福]] itself) — neither constituent legitimized by this word. Pronunciation fields already correct (the 福-family pug/fug bug was fixed out-of-sequence on 2026-09-04). `kwin: false` already correct. Filled blank pos. Fixed cantonese's stray space. No homophones. In passing, fixed the 20th empty-string field bug on `characters/艶 (char).md` (`hsk_level: ""` → "無"). Stamped `date-last-perfect: 2026-09-05`.

Next: 艾灸.

### 2026-09-05, iteration 3082 — [[words/艾灸|艾灸]]

No cranberry (灸's own stand-in is this exact compound, but 艾's own is [[艾草]]) — transitivity fails, though 灸 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields ('aigyu/애규/ㄚㄧㄍ⼜) already verified as the correct concatenation — no bug. Added missing `kwin: false`. Fixed a typo in english (muxibustion→moxibustion). Filled blank korean. Fixed cantonese's stray space and a missing "(stand-in for 灸)" annotation on the char page. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 芝草.

### 2026-09-05, iteration 3083 — [[words/芝草|芝草]]

No cranberry (芝's own stand-in is the special `名専字` name-only marker; 草's own is [[草]] itself). Pronunciation fields (jicau/지찻/ㄐㄧㄑㄚㄨ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Filled blank vietnamese. Kept the existing thorough Notes (Korean/Japanese homograph discussion). Quoted pronunciation fields. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 芝麻醤.

### 2026-09-05, iteration 3084 — [[words/芝麻醤|芝麻醤]]

No cranberry (none of the three constituents' own stand-ins point here). Pronunciation fields (jimajang/지마장/ㄐㄧㄇㄚㄐㄚㄫ) already verified as the correct concatenation — no bug; `kwin: true` already correct. Filled blank vietnamese. Fixed cantonese's stray spaces. Kept the existing thorough Notes. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 芦葦.

### 2026-09-05, iteration 3085 — [[words/芦葦|芦葦]]

**Genuine `#cranberry`** (already correctly tagged): both 芦's and 葦's own stand-ins point here (7th cranberry this session). Pronunciation fields (lohui/로휘/ㄌㄛㄏㄨㄧ) already verified as the correct concatenation — no bug; `kwin: false` already correct. **Found and fixed a real bug**: `japanese` listed る/ろ/あし, but る doesn't correspond to any documented reading — trimmed to ろ/あし. Verified korean 갈대/vietnamese sậy as genuine native terms, not bugs. Fixed cantonese's stray space and a missing "(stand-in for 葦)" annotation on the char page. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 芬蘭.

### 2026-09-05, iteration 3086 — [[words/芬蘭|芬蘭]]

No cranberry (芬's own stand-in is [[芬芳]], 蘭's own is [[蘭花]]). **Found and fixed a real bug**: `羅馬字`/`諺文`/`注音` all had a p-initial reading (Punlan/푼란/ㄆㄨㄋㄌㄚㄋ), mismatching 芬's real f-initial — same ㄈ→ㅍ confusion class as the 福-family bug — corrected to funlan/뿐란/ㄈㄨㄋㄌㄚㄋ (also normalized stray capitalization). `kwin: false` already correct. Filled blank vietnamese. Fixed cantonese's stray space. As a proper place name, real-language fields legitimately hold the attested name/transliteration. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 芭蕉.

### 2026-09-05, iteration 3087 — [[words/芭蕉|芭蕉]]

No cranberry (芭's own stand-in is this exact compound, but 蕉's own is [[甘蕉]]) — transitivity fails, though 芭 is legitimized as an independent Dan'a'yo entry by this word. **Found and fixed a real bug**: `mandarin` had ājiāo, missing 芭's own b-initial entirely — corrected to bājiāo. Pronunciation fields (bajou/바좃/ㄅㄚㄐㄛㄨ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Fixed cantonese's stray space and a missing "(stand-in for 芭)" annotation on the char page. Kept the existing thoughtful three-way comparison Notes. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 花卉.

### 2026-09-05, iteration 3088 — [[words/花卉|花卉]]

No cranberry (卉's own stand-in is this exact compound, but 花's own is [[草花]]) — transitivity fails, though 卉 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (hwahui/화휘/ㄏ⺢ㄏㄨㄧ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Filled blank vietnamese. Fixed cantonese's stray space, a missing "(stand-in for 卉)" annotation, and a malformed nested-list `tags:` field on `characters/花.md`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 花店.

### 2026-09-05, iteration 3089 — [[words/花店|花店]]

No cranberry (花's own stand-in is [[草花]], 店's own is [[商店]]) — neither constituent legitimized by this word. **Found and fixed a real bug**: `羅馬字`/`諺文` had a final -n instead of 店's real final -m (hwaden/화던→hwadem/화덤); `注音` had already stayed correct. `kwin: false` already correct. Filled blank vietnamese. Verified japanese はなや/korean 꽃집 as genuine real terms, not bugs. Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 花弁.

### 2026-09-05, iteration 3090 — [[words/花弁|花弁]]

No cranberry (花's own stand-in is [[草花]], 弁's own is [[弁]] itself) — neither constituent legitimized by this word. Pronunciation fields (hwabyan/화뱐/ㄏ⺢ㄅ⼘ㄋ) already verified as the correct concatenation — no bug; `kwin: false` already correct. **Found and fixed a real bug**: `cantonese` had a stray space and wrong initial (faa1 faan6-2→faa1baan6), consistent with `korean` 화판 genuinely tracking the semantic donor 瓣's own reading rather than 弁's own stored value (same pattern as [[胰臓]]/膵). Filled blank vietnamese. No homophones. In passing, fixed the 21st empty-string field bug on `characters/弁 (char).md` (hsk_level). Stamped `date-last-perfect: 2026-09-05`.

Next: 花栗鼠.

### 2026-09-05, iteration 3091 — [[words/花栗鼠|花栗鼠]]

No cranberry (none of the three constituents' own stand-ins point here). Pronunciation fields (hwalidsyo/화릳쇼/ㄏ⺢ㄌㄧㄊㄙ⼄) already verified as the correct concatenation — no bug; `kwin: false` already correct. Fixed cantonese's stray spaces. Verified japanese シマリス/korean 다람쥐/vietnamese sóc chuột as genuine native terms, not bugs. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 花粉.

### 2026-09-05, iteration 3092 — [[words/花粉|花粉]]

No cranberry. **Found and fixed two real bugs**: `羅馬字`/`諺文` had the 粉/分-confusion misreading (hwabun/화분→hwafun/화뿐), the same class already fixed on [[粉]]/[[粉末]] but which had slipped through here — `注音` had already stayed correct. `kwin` was true, corrected to false per the AND-rule (粉 individually false). Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 芳香族.

### 2026-09-05, iteration 3093 — [[words/芳香族|芳香族]]

No cranberry (none of the three constituents' own stand-ins point here). **Found and fixed a real bug**: `羅馬字`/`諺文` had a p-initial reading (panghyangjog/팡향족), mismatching 芳's real f-initial — same ㄈ→ㅍ confusion class as the 福-family bug — corrected to fanghyangjog/빵향족; `注音` had already stayed correct. `kwin: false` already correct. Filled blank vietnamese. Fixed cantonese's stray spaces. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 芸人.

### 2026-09-05, iteration 3094 — [[words/芸人|芸人]]

No cranberry (芸's own stand-in is [[芸術]], 人's own is [[人]] itself) — neither constituent legitimized by this word. Pronunciation fields ('enin/어닌/ㄝㄋㄧㄋ) already verified as the correct concatenation, including the null-onset syllable break — no bug. Added missing `kwin: false`. Filled blank korean. Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 芸妓.

### 2026-09-05, iteration 3095 — [[words/芸妓|芸妓]]

No cranberry (妓's own stand-in is this exact compound, but 芸's own is [[芸術]]) — transitivity fails, though 妓 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields ('egi/어기/ㄝㄍㄧ) already verified as the correct concatenation, including the null-onset syllable break — no bug. Added missing `kwin: false`. Filled blank vietnamese. Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 芸術.

### 2026-09-05, iteration 3096 — [[words/芸術|芸術]]

No cranberry (芸's own stand-in is this exact compound, but 術's own is [[術]] itself) — transitivity fails, though 芸 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields ('esud/어숟/ㄝㄙㄨㄊ) already verified as the correct concatenation, including the null-onset syllable break — no bug; `kwin: false` already correct. Filled blank pos. Converted comma-joined mandarin (yìshù/yìshu, both genuinely attested, tracking donor 藝 not 芸's own yún) into a proper list. Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 苔.

### 2026-09-05, iteration 3097 — [[words/苔|苔]]

Single-character stand-in word. Pronunciation fields (toi/퇴/ㄊㄛㄧ) already matched the character's own values — no bug. Added missing pos/japanese/kwin, filled `vietnamese: null`→đài. Checked the one other ㄊㄛㄧ-reading character, 跆 — its own `stand_in` is [[跆籍]], not a self-citation, so no homophone. Fixed a completely missing `## Words` section on the char page. Stamped `date-last-perfect: 2026-09-05`.

Next: 苗族.

### 2026-09-05, iteration 3098 — [[words/苗族|苗族]]

No cranberry (苗's own stand-in is [[種苗]], 族's own is [[家族]]) — neither constituent legitimized by this word. **Found and fixed a real bug**: `羅馬字` had a wrong final consonant (myaujok→myaujog); `諺文`/`注音` had already stayed correct. `kwin: false` already correct. Filled blank japanese (ミャオ族)/vietnamese (Miêu tộc). No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 苛刻.

### 2026-09-05, iteration 3099 — [[words/苛刻|苛刻]]

No cranberry (苛's own stand-in is this exact compound, but 刻's own is [[刻印]]) — transitivity fails, though 苛 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (hakug/하쿡/ㄏㄚㄎㄨㄎ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Filled blank vietnamese. Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 苦土素.

### 2026-09-05, iteration 3100 — [[words/苦土素|苦土素]]

No cranberry. Periodic-table neologism (magnesium). Pronunciation fields (kotoso/코토소/ㄎㄛㄊㄛㄙㄛ) already verified as the correct concatenation — no bug; `kwin: false` already correct. **Found and fixed a real bug**: `japanese` had くどそ, a kana spelling of this word's own internal Dan'a'yo reading rather than a real Japanese term — corrected to マグネシウム, matching the established convention already followed by mandarin měi/korean 마그네슘/vietnamese magiê. Removed redundant `品詞`. No homophones. Stamped `date-last-perfect: 2026-09-05`. **Milestone: 3,100th logged iteration.**

Next: 苦悶.

### 2026-09-05, iteration 3101 — [[words/苦悶|苦悶]]

No cranberry (悶's own stand-in is this exact compound, but 苦's own is [[苦]] itself) — transitivity fails, though 悶 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (komon/코몬/ㄎㄛㄇㄛㄋ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Filled blank vietnamese. Fixed cantonese's stray space and a missing "(stand-in for 悶)" annotation. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 苦渋.

### 2026-09-05, iteration 3102 — [[words/苦渋|苦渋]]

No cranberry (渋's own stand-in is this exact compound, but 苦's own is [[苦]] itself) — transitivity fails, though 渋 is legitimized as an independent Dan'a'yo entry by this word. **Found and fixed two real bugs**: `japanese` had にがい (native "bitter," contaminated from 苦's own gloss) instead of the real compound reading くじゅう; `korean` had 쓰다 (native verb, same contamination) instead of the compositional 고삽. Pronunciation fields (kosib/코십/ㄎㄛㄙㄧㄆ) already verified as the correct concatenation — no bug. Converted comma-joined cantonese into a proper list. Filled blank vietnamese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 苦瓜.

### 2026-09-05, iteration 3103 — [[words/苦瓜|苦瓜]]

No cranberry (苦's own stand-in is [[苦]] itself, 瓜's own is [[胡瓜]]) — neither constituent legitimized by this word. Pronunciation fields (kogwa/코과/ㄎㄛㄍ⺢) already verified as the correct concatenation — no bug; `kwin: false` already correct. Verified japanese にがうり as genuinely compositional from both characters' own native readings (unlike [[苦渋]]'s contamination bug) — not a bug. Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 苦痛.

### 2026-09-05, iteration 3104 — [[words/苦痛|苦痛]]

No cranberry (痛's own stand-in is this exact compound, but 苦's own is [[苦]] itself) — transitivity fails, though 痛 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (kotong/코통/ㄎㄛㄊㄛㄫ) already verified as the correct concatenation — no bug; `kwin: false` already correct. Filled blank vietnamese. Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 英俊.

### 2026-09-05, iteration 3105 — [[words/英俊|英俊]]

No cranberry (英's own stand-in is [[英雄]], 俊's own is [[俊傑]]) — neither constituent legitimized by this word. **Found and fixed two real bugs**: `羅馬字`/`諺文` had a wrong final consonant on 俊's syllable (-ng instead of -n); `注音` had already stayed correct throughout. `japanese` had ひでとし (Hidetoshi), a Japanese given-name reading of the same characters, instead of the real word reading えいしゅん. Filled blank pos/vietnamese. Fixed cantonese's stray space and a missing citation on `characters/俊.md`'s own Words list. No genuine homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 英吉利.

### 2026-09-05, iteration 3106 — [[words/英吉利|英吉利]]

No cranberry (none of the three constituents' own stand-ins point here). Pronunciation fields ('enggidliǝ/엉긷릐/ㄝㄫㄍㄧㄊㄌㄧㄜ) already verified as the correct concatenation — no bug. Added missing `kwin: false`. Filled blank korean (영길리, a genuine historical parallel transliteration). As a proper place name, mandarin/japanese/vietnamese legitimately hold the real attested name. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 英語.

### 2026-09-05, iteration 3107 — [[words/英語|英語]]

No cranberry (英's own stand-in is [[英雄]], 語's own is [[言語]]) — neither constituent legitimized by this word. Pronunciation fields ('eng'yo/엉요/ㄝㄫ·⼄) already verified as the correct concatenation, including the null-onset syllable break — no bug; `kwin: false` already correct. Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 英語圏.

### 2026-09-05, iteration 3108 — [[words/英語圏|英語圏]]

No cranberry (none of the three constituents' own stand-ins point here; 圏's own stand-in is [[圏]] itself). Pronunciation fields ('eng'yogwen/엉요권/ㄝㄫ⼄ㄍ⼔ㄋ) already verified as the correct concatenation — no bug; `kwin: false` already correct (AND-rule). Fixed cantonese's stray spaces. Vietnamese left blank (no verifiable distinct real term). Removed blank hsk_level/swadesh. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 英語学.

### 2026-09-05, iteration 3109 — [[words/英語学|英語学]]

No cranberry (none of the three constituents' stand-ins point here). Pronunciation fields ('eng'yohag/엉요학/ㄝㄫ⼄ㄏㄚㄎ) already verified as the correct concatenation — no bug. Added missing `kwin: false` (AND-rule). Filled blank pos (名詞, matching other `-学` compounds), korean (영어학), vietnamese (Anh ngữ học). Fixed cantonese's stray spaces. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 英雄.

### 2026-09-05, iteration 3110 — [[words/英雄|英雄]]

英's own stand-in is this exact compound; 雄's own is [[雄]] itself — transitivity fails, no cranberry. Pronunciation fields ('eng'ung/엉웅/ㄝㄫㄨㄫ) already verified as the correct concatenation — no bug; `kwin: false` already correct (AND-rule). Filled blank pos (名詞). Fixed cantonese's stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

(Several already-stamped words follow alphabetically — 英語欄/英語辞典-type entries and 苹果 — skipped via the standard unstamped-scan.)

Next: 茄子.

### 2026-09-05, iteration 3111 — [[words/茄子|茄子]]

茄's own stand-in is this exact compound; 子's own is [[児子]] — transitivity fails, no cranberry. Pronunciation fields (gajǝ/가즈/ㄍㄚㄐㄜ) already verified as the correct concatenation — no bug. **Found and fixed a real `kwin` bug** (true→false, AND-rule). Fixed cantonese's stray space (kept legitimate tone-sandhi notation). **Removed a stale false-homophone callout** with [[家事]] — the two words' own readings are genuinely different (ㄍㄚㄐㄜ vs ㄍㄚㄐㄧ); 家事's own page already documented the real (cross-system, not same-system) coincidence. No genuine homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 茅草.

### 2026-09-05, iteration 3112 — [[words/茅草|茅草]]

茅's own stand-in is this exact compound; 草's own is [[草]] itself — transitivity fails, no cranberry. Pronunciation fields (myaucau/먓찻/ㄇ⼘ㄨㄑㄚㄨ) already verified as the correct concatenation — no bug; kwin:false already correct. **Found and fixed a real bug**: japanese held みょう (only half the compound, 草's part entirely missing) — corrected to compositional みょうそう. Fixed cantonese stray space. Vietnamese left blank. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 茉莉.

### 2026-09-05, iteration 3113 — [[words/茉莉|茉莉]]

**Genuine `#cranberry`** (both 茉's and 莉's own stand-ins point here, full transitivity; tag already correctly present). Pronunciation fields (madlei/맏레/ㄇㄚㄊㄌㄝㄧ) already verified as the correct concatenation — no bug; kwin:false already correct. All other-language fields confirmed standard, compositional, and genuinely attested. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 茎.

### 2026-09-05, iteration 3114 — [[words/茎|茎]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. Added missing kwin (false). Filled blank japanese (くき). Added missing alias 莖. **Found a genuine homophone** with [[軽]] ("light, not heavy") — added reciprocal callout, gave 軽 a full pass too. Stamped `date-last-perfect: 2026-09-05`.

### 2026-09-05, iteration 3115 — [[words/軽|軽]]

Single-character stand-in word (companion to 茎's homophone group). **Found and fixed a real `kwin` bug** (true→false, contradicted the character's own field). Filled blank pos/korean/japanese/vietnamese. Added missing aliases. Stamped `date-last-perfect: 2026-09-05`.

Next: 茜素.

### 2026-09-05, iteration 3116 — [[words/茜素|茜素]]

No cranberry (茜's own stand-in is [[茜草]], 素's is [[要素]]). Periodic-table neologism (rubidium). Pronunciation fields (censo/천소/ㄑㄝㄋㄙㄛ) already verified as the correct concatenation — no bug. **Found and fixed a real `kwin` bug** (false→true, AND-rule). Mandarin/cantonese/korean/japanese/vietnamese all confirmed real element-name terms, per established convention. Removed redundant 品詞. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 茫然.

### 2026-09-05, iteration 3117 — [[words/茫然|茫然]]

No cranberry (茫's own stand-in is [[茫茫]], 然's is [[然]] itself). Pronunciation fields (mangnyen/망년/ㄇㄚㄫㄋ⼶ㄋ) already verified as the correct concatenation — no bug; kwin:false already correct. Other-language fields confirmed compositional (japanese ぼうぜん = BOU+ZEN). Fixed cantonese stray space, quoted hsk_level. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 茶.

### 2026-09-05, iteration 3118 — [[words/茶|茶]]

Single-character stand-in word (previously-flagged known gap: old bare-string `characters`, `vietnamese: null`, no pos/kwin/japanese). Pronunciation fields already matched the character's own values — no bug. Added missing kwin (false). Fixed `vietnamese: null` → trà (avoided chè, which means "dessert soup" in Southern usage). Filled blank japanese (ちゃ). **Found a genuine homophone** with [[者]] (agentive suffix "-er") — added reciprocal callout. Stamped `date-last-perfect: 2026-09-05`.

Next: 草原.

### 2026-09-05, iteration 3119 — [[words/草原|草原]]

No cranberry (草's own stand-in is [[草]] itself, 原's is [[原始]]). Pronunciation fields (cau'wen/찻원/ㄑㄚㄨ·⼔ㄋ) already verified as the correct concatenation, including the null-onset syllable break — no bug; kwin:false already correct. Other-language fields confirmed standard and compositional. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 草木.

### 2026-09-05, iteration 3120 — [[words/草木|草木]]

No cranberry (both 草's and 木's own stand-ins point to themselves). Pronunciation fields (caumog/찻목/ㄑㄚㄨㄇㄛㄎ) already verified as the correct concatenation — no bug; kwin:false already correct. Other-language fields confirmed standard and compositional. Filled blank vietnamese (thảo mộc, a real common word). Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 荷担.

### 2026-09-05, iteration 3121 — [[words/荷担|荷担]]

担's own stand-in is this exact compound; 荷's own is [[荷物]] — transitivity fails, no cranberry. Pronunciation fields (hadam/하담/ㄏㄚㄉㄚㄇ) already verified as the correct concatenation — no bug. **Found and fixed a real `kwin` bug** (true→false, AND-rule). Confirmed mandarin hèdān's tone alternation (hè "carry" vs hé "lotus") is genuine, not a bug. Filled blank cantonese/vietnamese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 荷月.

### 2026-09-05, iteration 3122 — [[words/荷月|荷月]]

No cranberry (荷's own stand-in is [[荷物]], 月's is [[月]] itself). Pronunciation fields (ha'wed/하웓/ㄏㄚ·⼔ㄊ) already verified as the correct concatenation — no bug. Japanese はすつき confirmed genuine, matching the established poetic-month convention (native kun'yomi descriptor + つき, see 桃月/榴月/杏月/桂月/槐月). Fixed cantonese stray space, removed redundant 品詞. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 荷物.

### 2026-09-05, iteration 3123 — [[words/荷物|荷物]]

荷's own stand-in is this exact compound; 物's own is [[物]] itself — transitivity fails, no cranberry. Pronunciation fields (hamud/하묻/ㄏㄚㄇㄨㄊ) already verified as the correct concatenation — no bug. Added missing `kwin: true` (AND-rule). Filled blank cantonese/korean/vietnamese (하물 confirmed a real Sino-Korean cargo term). Genuine homophone with [[何物]] already documented on both sides; standardized the callout format. Stamped `date-last-perfect: 2026-09-05`.

Next: 莱金.

### 2026-09-05, iteration 3124 — [[words/莱金|莱金]]

No cranberry (莱's own stand-in is [[蓬莱]], 金's is [[金]] itself). Periodic-table neologism (rhenium). Pronunciation fields (laigim/래김/ㄌㄚㄧㄍㄧㄇ) already verified as the correct concatenation — no bug. **Found and fixed a real `kwin` bug** (false→true, AND-rule). Mandarin/cantonese confirmed to match the real element name 铼; korean/japanese/vietnamese all genuine international transliterations. Removed redundant 品詞. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 菊.

### 2026-09-05, iteration 3125 — [[words/菊|菊]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. Added missing kwin/pos/japanese. Checked two candidate homophones (掬, 鞠) — neither has its own independent word-level entry, so no genuine homophone. Stamped `date-last-perfect: 2026-09-05`.

Next: 菊月.

### 2026-09-05, iteration 3126 — [[words/菊月|菊月]]

No cranberry (both 菊's and 月's own stand-ins point to themselves). Pronunciation fields (gug'wed/국웓/ㄍㄨㄎ·⼔ㄊ) already verified as the correct concatenation — no bug. Japanese きくつき confirmed genuine, matching the poetic-month convention. Fixed cantonese stray space, removed redundant 品詞. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 菜蔬.

### 2026-09-05, iteration 3127 — [[words/菜蔬|菜蔬]]

蔬's own stand-in is this exact compound; 菜's own is [[野菜]] — transitivity fails, no cranberry (already documented). Pronunciation fields (caisǝ/채스/ㄑㄚㄧㄙㄜ) already verified as the correct concatenation — no bug; kwin:false already correct. Other-language fields confirmed standard and compositional (korean 채소 also the real common word). Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 菩薩.

### 2026-09-05, iteration 3128 — [[words/菩薩|菩薩]]

**Genuine `#cranberry`** (both 菩's and 薩's own stand-ins point here, full transitivity; tag already present). Pronunciation fields (bosad/보삳/ㄅㄛㄙㄚㄊ) already verified as the correct concatenation — no bug; kwin:true already correct. Mandarin/japanese/korean confirmed standard and attested. Filled blank vietnamese (bồ tát, a real standard term). Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 華美.

### 2026-09-05, iteration 3129 — [[words/華美|華美]]

華's own stand-in is this exact compound; 美's own is [[美]] itself — transitivity fails, no cranberry. Pronunciation fields (hwami/화미/ㄏ⺢ㄇㄧ) already verified as the correct concatenation — no bug. **Found and fixed a real `kwin` bug** (false→true, AND-rule). Filled blank vietnamese (hoa mỹ, a real standard term). Fixed cantonese stray space, added simplified alias 华美. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 華麗.

### 2026-09-05, iteration 3130 — [[words/華麗|華麗]]

No cranberry (華's own stand-in is [[華美]], 麗's is [[秀麗]] — already documented). Pronunciation fields (hwale/화러/ㄏ⺢ㄌㄝ) already verified as the correct concatenation — no bug; kwin:false already correct. Other-language fields confirmed standard and compositional (korean/vietnamese also real attested terms). Filled blank cantonese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 菱.

### 2026-09-05, iteration 3131 — [[words/菱|菱]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. Added missing pos/japanese, filled blank vietnamese. Checked two candidate homophones (凌, 陵) — neither independently legitimized, so no genuine homophone. Fixed a missing stand-in annotation on the char page. Stamped `date-last-perfect: 2026-09-05`.

Next: 菱形.

### 2026-09-05, iteration 3132 — [[words/菱形|菱形]]

No cranberry (both 菱's and 形's own stand-ins point to themselves). Pronunciation fields (lǝngheng/릉헝/ㄌㄜㄫㄏㄝㄫ) already verified as the correct concatenation — no bug; kwin:false already correct. Other-language fields confirmed standard and compositional. Filled blank vietnamese (lăng hình, compositional). Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 萌芽.

### 2026-09-05, iteration 3133 — [[words/萌芽|萌芽]]

萌's own stand-in is this exact compound; 芽's own is [[新芽]] — transitivity fails, no cranberry (already documented). Pronunciation fields (mǝng'a/믕아/ㄇㄜㄫ·ㄚ) already verified as the correct concatenation — no bug; kwin:false already correct. Other-language fields confirmed standard and compositional (vietnamese already attested via hvdic). Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 萎縮.

### 2026-09-05, iteration 3134 — [[words/萎縮|萎縮]]

萎's own stand-in is this exact compound; 縮's own is [[縮]] itself — transitivity fails, no cranberry (already documented). Pronunciation fields ('weisug/웨숙/⼔ㄧㄙㄨㄎ) already verified as the correct concatenation — no bug; kwin:false already correct. Mandarin's dual reading confirmed genuine (matches 萎's own), converted to list. Other fields confirmed compositional. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 萬物.

### 2026-09-05, iteration 3135 — [[words/萬物|萬物]]

萬's own stand-in is this exact compound; 物's own is [[物]] itself — transitivity fails, no cranberry. Pronunciation fields (monmud/몬묻/ㄇㄛㄋㄇㄨㄊ) already verified as the correct concatenation — no bug; kwin:false already correct. **Found and fixed a documentation bug**: this page's own `aliases` field wrongly listed [[万物]] as an alias — 万物 is actually a full independent word page (the 大字 anti-falsification orthographic counterpart), matching the established 萬/万 character-level precedent of NOT cross-aliasing; removed the wrong alias entry. Other fields confirmed standard and compositional. Fixed cantonese stray space. No genuine homophones (万物 duplicate excluded, intentional). Stamped `date-last-perfect: 2026-09-05`.

Next: 落下傘.

### 2026-09-05, iteration 3136 — [[words/落下傘|落下傘]]

No cranberry (none of the three constituents' stand-ins point here). Pronunciation fields (lakhasan/락하산/ㄌㄚㄎㄏㄚㄙㄚㄋ) already verified as the correct concatenation — no bug. **Found and fixed a real `kwin` bug** (false→true, AND-rule). Confirmed mandarin/cantonese legitimately track the real distinct term 降落伞. **Found and fixed two real bugs**: japanese らくかさん missing well-established 促音便 gemination → らっかさん; korean 낙하산 was 두음법칙-shifted → 락하산 (unshifted North Korean form, per standing rule). Fixed cantonese stray spaces. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 落花.

### 2026-09-05, iteration 3137 — [[words/落花|落花]]

No cranberry (落's own stand-in is [[落下]], 花's is [[草花]]). Pronunciation fields (laghwa/락화/ㄌㄚㄎㄏ⺢) already verified as the correct concatenation — no bug. Added missing kwin:true. **Found and fixed a real bug**: korean comma-joined "락화,낙화" mixed the correct unshifted form with a 두음법칙-shifted variant — trimmed to 락화. Japanese らっか confirmed genuine (real-world homograph coincidence with 落下, not a Dan'a'yo-internal homophone). Filled blank vietnamese (lạc hoa, a real classical term). Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 葉.

### 2026-09-05, iteration 3138 — [[words/葉|葉]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. **Found and fixed a real bug**: korean 섭 (belonging to a different character) → 엽 (matching the character's own stored value). Added missing pos/kwin/japanese, filled blank vietnamese. Fixed a missing stand-in annotation on the char page. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 葛.

### 2026-09-05, iteration 3139 — [[words/葛|葛]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. Fixed `vietnamese: null` → cát. Added missing pos/kwin/japanese. Fixed missing stand-in annotation on char page. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 葡萄.

### 2026-09-05, iteration 3140 — [[words/葡萄|葡萄]]

**Genuine `#cranberry`** (both 葡's and 萄's own stand-ins point here, full transitivity; tag already present). Pronunciation fields (bodau/보닷/ㄅㄛㄉㄚㄨ) already verified as the correct concatenation — no bug; kwin:false already correct. **Found and fixed a real bug**: cantonese "pu2 tao2" was invalid romanization matching neither character's own jyutping — corrected to pou4tou4. Other fields confirmed standard and compositional. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 葡萄牙.

### 2026-09-05, iteration 3141 — [[words/葡萄牙|葡萄牙]]

No cranberry (葡/萄's own stand-in is [[葡萄]], 牙's is [[長牙]]). Pronunciation fields (bodau'a/보닷아/ㄅㄛㄉㄚㄨ·ㄚ) already verified as the correct concatenation, including the null-onset syllable break — no bug; kwin:false already correct. As a proper place name, other-language fields legitimately hold the real attested name. Fixed cantonese stray spaces. In passing, fixed the 22nd empty-string field bug on `characters/牙.md` (pos). No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 葺.

### 2026-09-05, iteration 3142 — [[words/葺|葺]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. Added missing kwin/japanese. Fixed a missing stand-in annotation on the char page. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蒙朧.

### 2026-09-05, iteration 3143 — [[words/蒙朧|蒙朧]]

朧's own stand-in is this exact compound; 蒙's own is [[蒙古]] — transitivity fails, no cranberry. Pronunciation fields (monglong/몽롱/ㄇㄛㄫㄌㄛㄫ) already verified as the correct concatenation — no bug; kwin:true already correct. Filled blank vietnamese (mông lung, a real common word). Other fields confirmed standard and compositional. Fixed missing stand-in annotation on 朧's char page. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蒲公英.

### 2026-09-05, iteration 3144 — [[words/蒲公英|蒲公英]]

No cranberry (蒲's own stand-in is [[香蒲]], 公's is [[公]] itself, 英's is [[英雄]]). Pronunciation fields (bogong'eng/보공엉/ㄅㄛㄍㄛㄫㄝㄫ) already verified as the correct concatenation — no bug; kwin:false already correct. Vietnamese/mandarin confirmed real standard terms; japanese たんぽぽ confirmed a legitimate real-term substitution (not compositional). Fixed cantonese stray spaces. Fixed a missing back-citation on `characters/公 (char).md`'s own Words list. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蒸汽.

### 2026-09-05, iteration 3145 — [[words/蒸汽|蒸汽]]

汽's own stand-in is this exact compound; 蒸's own is [[蒸]] itself — transitivity fails, no cranberry. Pronunciation fields (jingkiǝ/징킈/ㄐㄧㄫㄎㄧㄜ) already verified as the correct concatenation — no bug; kwin:false already correct. Other fields confirmed standard and compositional. Filled blank vietnamese (chưng khí). Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蒼海.

### 2026-09-05, iteration 3146 — [[words/蒼海|蒼海]]

No cranberry (蒼's own stand-in is [[蒼]] itself, 海's is [[海洋]]). **Found and fixed two real bugs**: 羅馬字 canghai was missing 蒼's own glide (諺文/注音 already correct) → cwanghai; japanese さうかい used obsolete historical kana → modern そうかい. kwin:false already correct. Filled blank vietnamese (thương hải, matching the idiom 滄海桑田). Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蒼路.

### 2026-09-05, iteration 3147 — [[words/蒼路|蒼路]]

No cranberry (蒼's own stand-in is [[蒼]] itself, 路's is [[道路]]). Here 路 is a `借代字` for 鷺, so 蒼路 = 蒼鷺 "grey heron." **Found and fixed the same 蒼-glide bug as [[蒼海]]**: 羅馬字/諺文 canglo/창로 missing the glide (注音 already correct) → cwanglo/촹로. Confirmed japanese/korean/vietnamese are all real bird-name substitutions, not compositional. Filled blank cantonese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蒼鉛.

### 2026-09-05, iteration 3148 — [[words/蒼鉛|蒼鉛]]

No cranberry (both 蒼's and 鉛's own stand-ins point to themselves). Pronunciation fields already correct concatenation — this one did NOT have the glide bug seen on [[蒼海]]/[[蒼路]]. kwin:false already correct. **Found and fixed a real bug**: cantonese bit1 was the modern replacement-element reading, inconsistent with mandarin's own deliberately-historical cāngqiān — corrected to the parallel historical-binome cong1jyun4. Removed redundant 品詞. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蓄.

### 2026-09-05, iteration 3149 — [[words/蓄|蓄]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. Added missing pos/kwin/japanese. **Found a genuine homophone** with [[蹴]] ("kick") — added reciprocal callout, gave 蹴 a full pass too. Stamped `date-last-perfect: 2026-09-05`.

### 2026-09-05, iteration 3150 — [[words/蹴|蹴]]

Single-character stand-in word (companion to 蓄's homophone group). Fixed `vietnamese: null` → xúc. Added missing pos/kwin/japanese. Stamped `date-last-perfect: 2026-09-05`.

Next: 蓬藁.

### 2026-09-05, iteration 3151 — [[words/蓬藁|蓬藁]]

蓬's own stand-in is this exact compound; 藁 is used as a `借代字` for the pageless 蒿, so 蓬藁 represents 蓬蒿 (already an alias). **Found and fixed two real bugs**: 羅馬字/諺文 (bonggao/봉, the latter truncated) both failed to match 注音's already-correct ㄅㄛㄫㄏㄚㄨ — corrected to bonghau/봉핫. **Found and fixed a real `kwin` bug** (true→false, AND-rule: 藁's own field is false). Confirmed mandarin/cantonese/japanese/korean all correctly use 蒿's own real reading, not 藁's — no bug there. Filled blank vietnamese (bồng cao). No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蓮.

### 2026-09-05, iteration 3152 — [[words/蓮|蓮]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. Fixed `vietnamese: null` → liên. Added missing pos/kwin/japanese. **Found a genuine homophone** with [[連]] ("mutual, successive") — added reciprocal callout, gave 連 a full pass too. Stamped `date-last-perfect: 2026-09-05`.

### 2026-09-05, iteration 3153 — [[words/連|連]]

Single-character stand-in word (companion to 蓮's homophone group). All fields were already correctly filled; fixed double-spaced japanese, removed redundant 品詞. Fixed a missing stand-in annotation on the char page. Stamped `date-last-perfect: 2026-09-05`.

Next: 蕃息.

### 2026-09-05, iteration 3154 — [[words/蕃息|蕃息]]

蕃's own stand-in is this exact compound; 息's own is [[気息]] — transitivity fails, no cranberry. Pronunciation fields (fansig/빤식/ㄈㄚㄋㄙㄧㄎ) already verified as the correct concatenation — no bug; kwin:false already correct. Other fields confirmed standard and compositional. Filled blank vietnamese (phồn tức). Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蕤素.

### 2026-09-05, iteration 3155 — [[words/蕤素|蕤素]]

No cranberry (蕤's own stand-in is [[萎蕤]], 素's is [[要素]]). Periodic-table neologism (thallium). Pronunciation fields (nuiso/뉘소/ㄋㄨㄧㄙㄛ) already verified as the correct concatenation — no bug. Real-language fields confirmed genuine element-name terms. Removed redundant 品詞. In passing, fixed the 23rd empty-string field bug (`characters/蕤.md` vietnamese) and added its missing kwin (false, computed from its own reading vs. Korean mismatch). No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蕪青.

### 2026-09-05, iteration 3156 — [[words/蕪青|蕪青]]

蕪's own stand-in is this exact compound; 青's own is [[青]] itself — transitivity fails, no cranberry. Here 青 stands in for its own alias 菁, matching the classical etymology 蕪菁. Pronunciation fields (muceng/무청/ㄇㄨㄑㄝㄫ) already verified as the correct concatenation — no bug; kwin:true already correct. Japanese かぶら confirmed a legitimate real-term substitution (matching 蕪's own native reading). Filled blank vietnamese (vu thanh). Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 薄命.

### 2026-09-05, iteration 3157 — [[words/薄命|薄命]]

No cranberry (薄's own stand-in is [[希薄]], 命's is [[運命]]). Pronunciation fields (bagmyeng/박명/ㄅㄚㄎㄇ⼶ㄫ) already verified as the correct concatenation — no bug; kwin:true already correct. Other-language fields confirmed standard and compositional (vietnamese matching the famous idiom hồng nhan bạc mệnh). Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 薄弱.

### 2026-09-05, iteration 3158 — [[words/薄弱|薄弱]]

No cranberry (薄's own stand-in is [[希薄]], 弱's is [[弱]] itself). **Found and fixed a real bug**: 注音 had a wrong final consonant on 弱's syllable (ㄫ instead of ㄎ) — 羅馬字/諺文 had already stayed correct (reverse of the usual pattern). Fixed matching rt-tags on both `characters/薄.md` and `characters/弱 (char).md`. kwin:false already correct. Other fields confirmed standard and compositional. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 薄荷.

### 2026-09-05, iteration 3159 — [[words/薄荷|薄荷]]

No cranberry (薄's own stand-in is [[希薄]], 荷's is [[荷物]]). Pronunciation fields (bagha/박하/ㄅㄚㄎㄏㄚ) already verified as the correct concatenation — no bug; kwin:true already correct. Mandarin bòhe confirmed using 薄's special reading, genuine. **Found and fixed a real bug**: japanese はくか missing 促音便 gemination → はっか (same class as [[落下傘]]/落下). Korean/vietnamese confirmed real standard terms. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 薔薇.

### 2026-09-05, iteration 3160 — [[words/薔薇|薔薇]]

**Genuine `#cranberry`** (both 薔's and 薇's own stand-ins point here, full transitivity; tag already present). Pronunciation fields (cwangmiǝ/촹믜/ㄑ⺢ㄫㄇㄧㄜ) already verified as the correct concatenation — no bug; kwin:false already correct. Mandarin/korean/vietnamese confirmed standard and genuine. **Found and fixed a real bug**: japanese comma-joined ばら with しやうび, obsolete historical kana for しょうび — modernized, converted to list. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 薬.

### 2026-09-05, iteration 3161 — [[words/薬|薬]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. Removed redundant 品詞. Checked three candidate homophones (約, 虐, 躍) — none independently legitimized, so no genuine homophone. Fixed a missing stand-in annotation on the char page. Stamped `date-last-perfect: 2026-09-05`.

Next: 薬丸.

### 2026-09-05, iteration 3162 — [[words/薬丸|薬丸]]

丸's own stand-in is this exact compound; 薬's own is [[薬]] itself — transitivity fails, no cranberry. Pronunciation fields ('yaghwan/약환/⼘ㄎㄏ⺢ㄋ) already verified as the correct concatenation — no bug. Added missing kwin:true. Filled blank japanese/korean/vietnamese — all real terms, but each in the reversed order (丸薬/환약/hoàn dược), matching this word's own already-listed reversed-order aliases. Fixed cantonese stray space (kept tone-sandhi notation). **Noted a romanization-style inconsistency** for future attention: `characters/薬 (char).md` and `words/薬.md` both use Yale-style cantonese "yeuk6" while this word correctly uses jyutping "joek6" for the same character — worth reconciling later. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 藍.

### 2026-09-05, iteration 3163 — [[words/藍|藍]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. **Found and fixed a real bug**: korean 남 (두음법칙-shifted) → 람 (unshifted, per standing rule). Fixed vietnamese null→lam. Added missing pos/kwin/japanese. Checked six candidate homophones — none independently legitimized. Stamped `date-last-perfect: 2026-09-05`.

Next: 藍木.

### 2026-09-05, iteration 3164 — [[words/藍木|藍木]]

No cranberry (both 藍's and 木's own stand-ins point to themselves). Pronunciation fields (lammog/람목/ㄌㄚㄇㄇㄛㄎ) already verified as the correct concatenation — no bug. **Found and fixed a real `kwin` bug** (false→true, AND-rule). Confirmed mandarin/korean legitimately use the reversed real-term order (木藍, already an alias), same pattern as [[薬丸]]. Japanese confirmed a genuine botanical-name substitution. Filled blank cantonese/vietnamese (reversed order). No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 藍色.

### 2026-09-05, iteration 3165 — [[words/藍色|藍色]]

No cranberry (藍's own stand-in is [[藍]] itself, 色's is [[色彩]]). Pronunciation fields (lamsig/람식/ㄌㄚㄇㄙㄧㄎ) already verified as the correct concatenation — no bug; kwin:false already correct. Japanese confirmed genuine (native-reading compositional, matching -色 convention). **Found and fixed two real bugs**: korean 두음법칙-shifted form → 람색; vietnamese cây chàm (wrong sense, "plant" not "color") → màu chàm. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 藍領.

### 2026-09-05, iteration 3166 — [[words/藍領|藍領]]

No cranberry (藍's own stand-in is [[藍]] itself, 領's is [[領土]]). **Found and fixed two real bugs**: 羅馬字 lamlig missing 領's -ng final (諺文/注音 already correct) → lamling; cantonese leng5 didn't match 領's own ling5 → laam4ling5. kwin:false already correct. Japanese/korean confirmed genuine English-loanword substitutions. Filled blank vietnamese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蘇連.

### 2026-09-05, iteration 3167 — [[words/蘇連|蘇連]]

No cranberry (蘇's own stand-in is [[蘇生]], 連's is [[連]] itself). Pronunciation fields (solyen/소련/ㄙㄛㄌ⼶ㄋ) already verified as the correct concatenation — no bug; kwin:true already correct. Cantonese confirmed to legitimately use 聯's own reading (real term 蘇聯), just fixed the stray space. **Found and fixed a real bug**: japanese mixed katakana/hiragana (ソれん) → uniform katakana ソレン. Filled blank vietnamese (Liên Xô). Fixed a missing back-citation on `characters/蘇.md`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蘭月.

### 2026-09-05, iteration 3168 — [[words/蘭月|蘭月]]

No cranberry (蘭's own stand-in is [[蘭花]], 月's is [[月]] itself). Pronunciation fields (lan'wed/란웓/ㄌㄚㄋ·⼔ㄊ) already verified as the correct concatenation — no bug; kwin:false already correct. Korean already correctly unshifted. Japanese らんつき confirmed genuine, matching the on'yomi-only poetic-month precedent set by [[菊月]]. Fixed cantonese stray space, removed redundant 品詞. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蘭花.

### 2026-09-05, iteration 3169 — [[words/蘭花|蘭花]]

蘭's own stand-in is this exact compound; 花's own is [[草花]] — transitivity fails, no cranberry. Pronunciation fields (lanhwa/란화/ㄌㄚㄋㄏ⺢) already verified as the correct concatenation — no bug. Added missing kwin:true. **Found and fixed a real bug**: japanese ランの花 (a phrase, not a word) → ラン, the standard word. Filled blank korean/vietnamese (hoa lan, real term, reversed order). Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 虎.

### 2026-09-05, iteration 3170 — [[words/虎|虎]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. Added missing pos/kwin/japanese. **Completed a three-way homophone group** with [[乎]]/[[呼]] (both already perfected and already anticipating this callout) — added the reciprocal callout here. In passing, fixed the 24th empty-string field bug (`characters/虎 (char).md` pos) and a missing self-citation on its own Words list. Stamped `date-last-perfect: 2026-09-05`.

Next: 虚.

### 2026-09-05, iteration 3171 — [[words/虚|虚]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. Added missing pos/japanese, filled blank korean/vietnamese. **Found a genuine homophone** with [[許]] ("permit, allow") — added reciprocal callout, gave 許 a full pass too. Stamped `date-last-perfect: 2026-09-05`.

### 2026-09-05, iteration 3172 — [[words/許|許]]

Single-character stand-in word (companion to 虚's homophone group). Fixed `vietnamese: null` → hứa. Added missing pos/kwin/japanese. Fixed a missing stand-in annotation on the char page. Stamped `date-last-perfect: 2026-09-05`.

Next: 虚偽.

### 2026-09-05, iteration 3173 — [[words/虚偽|虚偽]]

No cranberry (both 虚's and 偽's own stand-ins point to themselves). Pronunciation fields (hyo'wei/효웨/ㄏ⼄⼔ㄧ) already verified as the correct concatenation — no bug. Added missing kwin:false. Mandarin dual reading converted to list. **Found and fixed a real bug**: korean 허위의 had a stray genitive suffix — corrected to 허위. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 虱.

### 2026-09-05, iteration 3174 — [[words/虱|虱]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. Added missing japanese, filled blank vietnamese. In passing on `characters/虱 (char).md`: fixed bare-string aliases, removed redundant 品詞, fixed a missing self-citation, and properly integrated two dangling CC-lookup links into a formatted bullet. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 虹尊.

### 2026-09-05, iteration 3175 — [[words/虹尊|虹尊]]

No cranberry (虹's own stand-in is [[彩虹]], 尊's is [[尊厳]]; 尊 stands in for its own alias 鱒/鳟, matching the already-listed alias 虹鱒 and paralleling [[尊魚]]). Pronunciation fields (hongjon/홍존/ㄏㄛㄫㄐㄛㄋ) already verified as the correct concatenation — no bug. **Found and fixed a real `kwin` bug** (false→true, AND-rule). Mandarin/japanese confirmed genuine real terms. Fixed a stray space in korean, filled blank cantonese/vietnamese. Fixed a truncated rt-tag on `characters/尊.md`'s own citation. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 虹素.

### 2026-09-05, iteration 3176 — [[words/虹素|虹素]]

No cranberry (虹's own stand-in is [[彩虹]], 素's is [[要素]]). Periodic-table neologism (neon). Pronunciation fields (hongso/홍소/ㄏㄛㄫㄙㄛ) already verified as the correct concatenation — no bug. **Found and fixed a real `kwin` bug** (false→true, AND-rule). Mandarin/cantonese confirmed to track the real modern element character 氖; korean/japanese/vietnamese all genuine transliterations. Removed redundant 品詞. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蚊.

### 2026-09-05, iteration 3177 — [[words/蚊|蚊]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. Filled blank pos/vietnamese. Homophone callout with [[紋]]/[[聞]] (the previously-flagged three-way group) already in place — re-verified with no additional matches (checked 吻/問/文). Fixed missing stand-in annotation on char page. Stamped `date-last-perfect: 2026-09-05`.

Next: 蚊帳.

### 2026-09-05, iteration 3178 — [[words/蚊帳|蚊帳]]

帳's own stand-in is this exact compound; 蚊's own is [[蚊]] itself — transitivity fails, no cranberry. Pronunciation fields (munjwang/문좡/ㄇㄨㄋㄐ⺢ㄫ) already verified as the correct concatenation — no bug. Added missing kwin:false. **Found and fixed three real bugs**: mandarin typo (wénzhàn→wénzhàng); cantonese mis-transcribed vowel order (zeong3→zoeng3); japanese naive on'yomi instead of the real jukujikun reading (ぶんちょう→かや). Filled blank korean/vietnamese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蚕箔.

### 2026-09-05, iteration 3179 — [[words/蚕箔|蚕箔]]

箔's own stand-in is this exact compound; 蚕's own is [[蚕]] itself — transitivity fails, no cranberry. Pronunciation fields (jambag/잠박/ㄐㄚㄇㄅㄚㄎ) already verified as the correct concatenation — no bug. Added missing kwin:false and pos. Filled blank japanese/korean (천박, a coincidental collision with the unrelated common word "vulgar"). Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蛇.

### 2026-09-05, iteration 3180 — [[words/蛇|蛇]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. Confirmed mandarin tā reflects a deliberate, already-documented vault choice (minority MC reading, anti-homophony) — not a bug, kept as-is. Removed redundant 品詞. Checked six candidate homophones — none independently legitimized. Stamped `date-last-perfect: 2026-09-05`.

Next: 蛋白.

### 2026-09-05, iteration 3181 — [[words/蛋白|蛋白]]

蛋's own stand-in is this exact compound; 白's own is [[白]] itself — transitivity fails, no cranberry. Pronunciation fields (danbag/단박/ㄉㄚㄋㄅㄚㄎ) already verified as the correct concatenation — no bug; kwin:false already correct. Other fields confirmed standard and compositional (all also real common "protein" terms). Filled blank vietnamese. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蛍.

### 2026-09-05, iteration 3182 — [[words/蛍|蛍]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. Added missing pos/kwin/japanese. **Found a genuine homophone** with [[迥]] ("distant, far") — added reciprocal callout, gave 迥 a full pass too. Stamped `date-last-perfect: 2026-09-05`.

### 2026-09-05, iteration 3183 — [[words/迥|迥]]

Single-character stand-in word (companion to 蛍's homophone group). Added missing pos/kwin/japanese. Stamped `date-last-perfect: 2026-09-05`.

Next: 蛭.

### 2026-09-05, iteration 3184 — [[words/蛭|蛭]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. Added missing pos/kwin/japanese. Fixed `vietnamese: null` → điệt. Homophone callout with [[直]]/[[膣]] (three-way group) already correctly in place — re-verified with no additional matches (checked 嫉/疾/質). Stamped `date-last-perfect: 2026-09-05`.

Next: 蛮人.

### 2026-09-05, iteration 3185 — [[words/蛮人|蛮人]]

蛮's own stand-in is this exact compound; 人's own is [[人]] itself — transitivity fails, no cranberry. Pronunciation fields (mannin/만닌/ㄇㄚㄋㄋㄧㄋ) already verified as the correct concatenation — no bug; kwin:false already correct. Mandarin/japanese confirmed real common terms; korean confirmed a coincidental homophone with an unrelated word. Filled blank cantonese/vietnamese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蜘蛛.

### 2026-09-05, iteration 3186 — [[words/蜘蛛|蜘蛛]]

**Genuine `#cranberry`** (both 蜘's and 蛛's own stand-ins point here, full transitivity; tag already present). Pronunciation fields (jiju/지주/ㄐㄧㄐㄨ) already verified as the correct concatenation — no bug; kwin:true already correct. **Found and fixed two real bugs**: cantonese z1 zyu1 was malformed (missing a vowel) → zi1zyu1; japanese ちしゅ,ちちゅ was an inconsistent partial-on'yomi guess → くも, the real standard word for "spider." Korean/vietnamese confirmed compositional. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蜜月.

### 2026-09-05, iteration 3187 — [[words/蜜月|蜜月]]

No cranberry (蜜's own stand-in is [[蜂蜜]], 月's is [[月]] itself). **Found and fixed a real bug**: 羅馬字 mid'wet had a wrong final consonant on 月's syllable (諺文/注音 already correct) → mid'wed. **Found and fixed a real `kwin` bug** (true→false, AND-rule). Other fields confirmed standard and compositional (all real common terms). Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蜜柑.

### 2026-09-05, iteration 3188 — [[words/蜜柑|蜜柑]]

柑's own stand-in is this exact compound; 蜜's own is [[蜂蜜]] — transitivity fails, no cranberry. Pronunciation fields (midgam/믿감/ㄇㄧㄊㄍㄚㄇ) already verified as the correct concatenation — no bug; kwin:true already correct. Fixed a typo in english ("mandarinn"→"mandarin"). Other fields confirmed standard and compositional. Filled blank vietnamese. Fixed cantonese stray space, missing back-citation on 柑.md. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蝉冠.

### 2026-09-05, iteration 3189 — [[words/蝉冠|蝉冠]]

No cranberry (蝉's own stand-in is [[蝉]] itself, 冠's is [[王冠]]). Pronunciation fields (sengwan/선관/ㄙㄝㄋㄍ⺢ㄋ) already verified as the correct concatenation — no bug; kwin:true already correct. Other fields confirmed standard and compositional. Filled blank vietnamese. Fixed cantonese stray space and a missing stand-in annotation on `characters/蝉 (char).md`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蝎.

### 2026-09-05, iteration 3190 — [[words/蝎|蝎]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug; kwin:false already correct. Confirmed cantonese kit3 is a genuine irregular real-world reading, not a bug. Removed redundant 品詞, converted comma-joined vietnamese to a list. In passing on `characters/蝎 (char).md`: converted comma-joined vietnamese to list, added a missing Words section with self-citation, and properly integrated dangling CC-lookup links. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蝙蝠.

### 2026-09-05, iteration 3191 — [[words/蝙蝠|蝙蝠]]

**Genuine `#cranberry`** (both 蝙's and 蝠's own stand-ins point here, full transitivity; tag was already present on both char pages but missing from the word page — added here). Pronunciation fields (benfug/번뿍/ㄅㄝㄋㄈㄨㄎ) already verified as the correct concatenation — no bug. Added missing kwin:false. Mandarin dual reading converted to list. **Found and fixed a real bug**: cantonese bin2 didn't match 蝙's own bin1 — corrected. Split comma-joined korean (moved native 박쥐 to prose). No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蝸牛.

### 2026-09-05, iteration 3192 — [[words/蝸牛|蝸牛]]

蝸's own stand-in is this exact compound; 牛's own is [[牛]] itself — transitivity fails, no cranberry. Pronunciation fields (gwanyu/과뉴/ㄍ⺢ㄋ⼜) already verified as the correct concatenation — no bug; kwin:false already correct. Mandarin dual reading converted to list. Japanese/vietnamese confirmed genuine real terms. Fixed cantonese stray space and a missing Words section on `characters/蝸.md`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 融.

### 2026-09-05, iteration 3193 — [[words/融|融]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug; kwin:true already correct. Added missing pos/japanese, filled blank vietnamese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 融化.

### 2026-09-05, iteration 3194 — [[words/融化|融化]]

No cranberry (both 融's and 化's own stand-ins point to themselves). Pronunciation fields ('yunghwa/융화/⼜ㄫㄏ⺢) already verified as the correct concatenation — no bug; kwin:true already correct. Other fields confirmed standard and compositional. Fixed an english typo, filled blank pos/vietnamese, fixed cantonese stray space, quoted hsk_level. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 融合.

### 2026-09-05, iteration 3195 — [[words/融合|融合]]

No cranberry (both 融's and 合's own stand-ins point to themselves) — closes out this previously-flagged known gap. Pronunciation fields ('yunggob/융곱/⼜ㄫㄍㄛㄆ) already verified as the correct concatenation — no bug; kwin:false already correct. Other fields confirmed standard and compositional. Filled blank pos/vietnamese, fixed cantonese stray space and a missing back-citation on `characters/合 (char).md`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 融資.

### 2026-09-05, iteration 3196 — [[words/融資|融資]]

No cranberry (融's own stand-in is [[融]] itself, 資's is [[資本]]). **Found and fixed a real bug**: 羅馬字/諺文 'yongjiǝ/용즤 had a wrong vowel on 融's own syllable (注音 already correct) → 'yungjiǝ/융즤. kwin:false already correct. Other fields confirmed standard and compositional. Filled blank vietnamese. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 螳螂.

### 2026-09-05, iteration 3197 — [[words/螳螂|螳螂]]

**Genuine `#cranberry`** (both 螳's and 螂's own stand-ins point here, full transitivity; tag already present). Pronunciation fields (danglang/당랑/ㄉㄚㄫㄌㄚㄫ) already verified as the correct concatenation — no bug; kwin:true already correct. Vietnamese confirmed a genuine real-term substitution. **Found and fixed a real bug**: japanese たうらう used obsolete historical kana with the wrong on'yomi entirely → とうろう. Fixed cantonese stray space and a missing stand-in annotation on `characters/螂.md`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 螺旋.

### 2026-09-05, iteration 3198 — [[words/螺旋|螺旋]]

螺's own stand-in is this exact compound; 旋's own is [[旋転]] — transitivity fails, no cranberry. Pronunciation fields (laswen/라숸/ㄌㄚㄙ⼔ㄋ) already verified as the correct concatenation — no bug. Added missing kwin:false. Other fields confirmed standard and compositional (real common terms). Filled blank korean/vietnamese. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 螺鈿.

### 2026-09-05, iteration 3199 — [[words/螺鈿|螺鈿]]

No cranberry (螺's own stand-in is [[螺旋]], 鈿's is a `名専字`). Pronunciation fields (laden/라던/ㄌㄚㄉㄝㄋ) already verified as the correct concatenation — no bug. Added missing kwin:false. Fixed an english typo (laquer→lacquer). Filled blank cantonese/korean/vietnamese. Fixed a missing Words section on `characters/鈿.md`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蟄.

### 2026-09-05, iteration 3200 — [[words/蟄|蟄]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. Added missing kwin/japanese. Fixed a missing stand-in annotation on the char page. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 蟹.

### 2026-09-05, iteration 3201 — [[words/蟹|蟹]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. Added missing pos/kwin/japanese, fixed vietnamese null→giải. **Found a genuine homophone** with [[鞋]] ("shoe") — added reciprocal callout, gave 鞋 a full pass too. Stamped `date-last-perfect: 2026-09-05`.

### 2026-09-05, iteration 3202 — [[words/鞋|鞋]]

Single-character stand-in word (companion to 蟹's homophone group). All other fields were already correctly filled; removed redundant 品詞. In passing, fixed the 25th empty-string field bug on `characters/鞋 (char).md` (hsk_level). Stamped `date-last-perfect: 2026-09-05`.

Next: 衆多.

### 2026-09-05, iteration 3203 — [[words/衆多|衆多]]

No cranberry (衆's own stand-in is [[大衆]], 多's is [[多]] itself). **Found and fixed three real bugs**: 羅馬字 jungda had a wrong vowel on 多's syllable (諺文/注音 already correct) → jungdǝ; japanese had a hidden zero-width space (しゅ​うた→しゅうた); korean 많은 was a native gloss, not the Sino-Korean reading (→중다). kwin:false already correct. Filled blank vietnamese. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 衆議.

### 2026-09-05, iteration 3204 — [[words/衆議|衆議]]

No cranberry (衆's own stand-in is [[大衆]], 議's is [[議論]]). **Found and fixed a real bug**: 羅馬字 jung'wi was a recurrence of the resolved 義-family misreading (諺文/注音 already correct) → jung'ǝi. Added missing kwin:true. Other fields confirmed standard and compositional. Filled blank korean/vietnamese. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 衆議院.

### 2026-09-05, iteration 3205 — [[words/衆議院|衆議院]]

No cranberry (none of the three constituents' stand-ins point here). **Found and fixed the same 議-family 羅馬字 bug as [[衆議]]** (jung'wi'wen→jung'ǝi'wen; 諺文/注音 already correct). Added missing kwin:true. Mandarin/japanese confirmed real common terms. Filled blank korean/vietnamese. Fixed cantonese stray spaces (kept tone-sandhi notation). No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 行事.

### 2026-09-05, iteration 3206 — [[words/行事|行事]]

No cranberry (both 行's and 事's own stand-ins point to themselves). Pronunciation fields (hangji/항지/ㄏㄚㄫㄐㄧ) already verified as the correct concatenation — no bug; kwin:false already correct. Other fields confirmed standard and compositional (vietnamese hành sự also a real attested term). Filled blank vietnamese. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 行列.

### 2026-09-05, iteration 3207 — [[words/行列|行列]]

No cranberry (行's own stand-in is [[行]] itself, 列's is [[配列]]). Pronunciation fields (hangled/항럳/ㄏㄚㄫㄌㄝㄊ) already verified as the correct concatenation — no bug; kwin:false already correct. **Found and fixed a real bug**: japanese ぎやうれつ used obsolete historical kana → modern ぎょうれつ. Filled blank vietnamese. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 行動.

### 2026-09-05, iteration 3208 — [[words/行動|行動]]

No cranberry (both 行's and 動's own stand-ins point to themselves). Pronunciation fields (hangdong/항동/ㄏㄚㄫㄉㄛㄫ) already verified as the correct concatenation — no bug; kwin:false already correct. Other fields confirmed standard and compositional. Fixed cantonese stray space and a missing back-citation on `characters/動 (char).md`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 行星.

### 2026-09-05, iteration 3209 — [[words/行星|行星]]

No cranberry (both 行's and 星's own stand-ins point to themselves). Pronunciation fields (hangseng/항성/ㄏㄚㄫㄙㄝㄫ) already verified as the correct concatenation — no bug; kwin:false already correct. Japanese わくせい confirmed a legitimate real-term substitution (惑星, already an alias). Fixed cantonese stray space and a missing back-citation on `characters/星 (char).md`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 街区.

### 2026-09-05, iteration 3210 — [[words/街区|街区]]

No cranberry (街's own stand-in is [[街道]], 区's is [[区域]]). Pronunciation fields (gyaiku/걔쿠/ㄍ⼘ㄧㄎㄨ) already verified as the correct concatenation — no bug. Added missing kwin:false. Mandarin/japanese confirmed real common terms. Filled blank cantonese/korean/vietnamese. Removed redundant 品詞. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 街道.

### 2026-09-05, iteration 3211 — [[words/街道|街道]]

街's own stand-in is this exact compound; 道's own is [[道]] itself — transitivity fails, no cranberry. Pronunciation fields (gyaidau/걔닷/ㄍ⼘ㄧㄉㄚㄨ) already verified as the correct concatenation — no bug; kwin:false already correct. Other fields confirmed standard and compositional. Filled blank vietnamese. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 衝.

### 2026-09-05, iteration 3212 — [[words/衝|衝]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. Fixed vietnamese null→xung. Added missing pos/japanese. Genuine three-way homophone with [[塚]] (already perfected) and [[重]] (given a full pass too) — already documented on all pages. Checked four additional candidates, none independently legitimized. Stamped `date-last-perfect: 2026-09-05`.

### 2026-09-05, iteration 3213 — [[words/重|重]]

Single-character stand-in word (companion to 衝's homophone group). Added missing pos/japanese (real kun'yomi, correcting an unverifiable stored native reading), filled blank vietnamese. Fixed a missing self-citation on `characters/重 (char).md`. Stamped `date-last-perfect: 2026-09-05`.

Next: 衣服.

### 2026-09-05, iteration 3214 — [[words/衣服|衣服]]

No cranberry (衣's own stand-in is [[衣類]], 服's is [[服事]]). Pronunciation fields ('iǝbug/의북/ㄧㄜㄅㄨㄎ) already verified as the correct concatenation — no bug. Added missing kwin:false, pos. Split comma-joined korean (kept 의복, moved native 옷 to prose). Other fields confirmed standard and compositional. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 衣襟.

### 2026-09-05, iteration 3215 — [[words/衣襟|衣襟]]

襟's own stand-in is this exact compound; 衣's own is [[衣類]] — transitivity fails, no cranberry. Pronunciation fields ('iǝgim/의김/ㄧㄜㄍㄧㄇ) already verified as the correct concatenation — no bug. Added missing kwin:false. Fixed three empty-string field bugs (korean/japanese/vietnamese all `""`) — filled with compositional readings. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 衣類.

### 2026-09-05, iteration 3216 — [[words/衣類|衣類]]

衣's own stand-in is this exact compound; 類's own is [[種類]] — transitivity fails, no cranberry (already documented). Pronunciation fields ('iǝlui/의뤼/ㄧㄜㄌㄨㄧ) already verified as the correct concatenation — no bug; kwin:false already correct. All other fields were already correctly filled. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 表彰.

### 2026-09-05, iteration 3217 — [[words/表彰|表彰]]

No cranberry (表's own stand-in is [[表現]], 彰's is [[彰明]]). Pronunciation fields (byaucang/뱟창/ㄅ⼘ㄨㄑㄚㄫ) already verified as the correct concatenation — no bug; kwin:false already correct. Other fields confirmed standard and compositional. Filled blank vietnamese. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 表明.

### 2026-09-05, iteration 3218 — [[words/表明|表明]]

No cranberry (表's own stand-in is [[表現]], 明's is [[明]] itself). Pronunciation fields (byaumyeng/뱟명/ㄅ⼘ㄨㄇ⼶ㄫ) already verified as the correct concatenation — no bug; kwin:false already correct. Other fields confirmed standard and compositional. Filled blank vietnamese, quoted hsk_level. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 表現.

### 2026-09-05, iteration 3219 — [[words/表現|表現]]

表's own stand-in is this exact compound; 現's own is [[現]] itself — transitivity fails, no cranberry. Pronunciation fields (byauhyen/뱟현/ㄅ⼘ㄨㄏ⼶ㄋ) already verified as the correct concatenation — no bug; kwin:false already correct. All other fields confirmed standard and compositional. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 表示.

### 2026-09-05, iteration 3220 — [[words/表示|表示]]

No cranberry (表's own stand-in is [[表現]], 示's is [[開示]]). Pronunciation fields (byauge/뱟거/ㄅ⼘ㄨㄍㄝ) already verified as the correct concatenation — no bug; kwin:false already correct. Confirmed 示's own divergent MC-derived syllable (ge/거/ㄍㄝ vs modern shì-like reflex) is genuine, matching the char page. Other fields confirmed standard and compositional. Filled blank vietnamese. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 衰弱.

### 2026-09-05, iteration 3221 — [[words/衰弱|衰弱]]

衰's own stand-in is this exact compound; 弱's own is [[弱]] itself — transitivity fails, no cranberry. Pronunciation fields (sweinyag/쉐냑/ㄙ⼔ㄧㄋ⼘ㄎ) already verified as the correct concatenation — no bug; kwin:false already correct. Filled blank pos. Other fields confirmed standard and compositional. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 衰退.

### 2026-09-05, iteration 3222 — [[words/衰退|衰退]]

No cranberry (衰's own stand-in is [[衰弱]], 退's is [[退]] itself). Pronunciation fields (sweitiǝ/쉐틔/ㄙ⼔ㄧㄊㄧㄜ) already verified as the correct concatenation — no bug; kwin:false already correct. Other fields confirmed standard and compositional. Removed redundant 品詞. Fixed cantonese stray space and missing stand-in annotation. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 袂.

### 2026-09-05, iteration 3223 — [[words/袂|袂]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug; kwin:false already correct. Added missing japanese. Homophone callout with [[弥]] already correctly in place — re-verified, no additional matches. Fixed a missing stand-in annotation on the char page. Stamped `date-last-perfect: 2026-09-05`.

Next: 袋.

### 2026-09-05, iteration 3224 — [[words/袋|袋]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug; kwin:true already correct. Added missing pos/japanese. Homophone callout with [[大]]/[[台]] already correctly in place — re-verified, checked seven additional candidates, none independently legitimized. Stamped `date-last-perfect: 2026-09-05`.

Next: 袋鼠.

### 2026-09-05, iteration 3225 — [[words/袋鼠|袋鼠]]

No cranberry (袋's own stand-in is [[袋]] itself, 鼠's is [[熊鼠]]). Pronunciation fields (daisyo/대쇼/ㄉㄚㄧㄙ⼄) already verified as the correct concatenation — no bug; kwin:false already correct. Japanese/korean/vietnamese all confirmed genuine real-term substitutions. Fixed cantonese stray space and a missing back-citation on `characters/鼠.md`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 袖.

### 2026-09-05, iteration 3226 — [[words/袖|袖]]

Single-character stand-in word — closes out the previously-flagged known gap. Pronunciation fields already matched the character's own values — no bug; kwin:false already correct. Added missing pos/japanese. Homophone callout with [[秀]] already correctly in place — re-verified, checked five additional candidates, none independently legitimized. Stamped `date-last-perfect: 2026-09-05`.

Next: 裁縫.

### 2026-09-05, iteration 3227 — [[words/裁縫|裁縫]]

裁's own stand-in is this exact compound; 縫's own is [[縫製]] — transitivity fails, no cranberry. Pronunciation fields (caibong/채봉/ㄑㄚㄧㄅㄛㄫ) already verified as the correct concatenation — no bug; kwin:false already correct. Other fields confirmed standard and compositional. Filled blank vietnamese. Removed redundant 品詞, fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 装置.

### 2026-09-05, iteration 3228 — [[words/装置|装置]]

No cranberry (both 装's and 置's own stand-ins point to themselves). Pronunciation fields (jwangci/좡치/ㄐ⺢ㄫㄑㄧ) already verified as the correct concatenation — no bug; kwin:false already correct. Other fields confirmed standard and compositional. Filled blank vietnamese (a coincidental collision with an unrelated word). Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 裏面.

### 2026-09-05, iteration 3229 — [[words/裏面|裏面]]

裏's own stand-in is this exact compound; 面's own is [[表面]] — transitivity fails, no cranberry. **Found and fixed a real bug**: 注音 had a spurious null-onset separator and wrong vowel (羅馬字/諺文 already correct) → ㄌㄧㄇ⼶ㄋ. **Found and fixed a real `kwin` bug** (false→true). **Found and fixed two more real bugs**: japanese うちがわ (unrelated word 内側) → りめん (the real reading of 裏面 itself); korean 안 (unrelated native gloss) → 이면 (real Sino-Korean reading). Filled blank vietnamese. Fixed cantonese stray space and matching rt-tags on both character pages. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 補充.

### 2026-09-05, iteration 3230 — [[words/補充|補充]]

No cranberry (補's own stand-in is [[修補]], 充's is [[充填]]). Pronunciation fields (bocung/보충/ㄅㄛㄑㄨㄫ) already verified as the correct concatenation — no bug; kwin:true already correct. Other fields confirmed standard and compositional. Fixed cantonese stray space, quoted hsk_level. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 補助.

### 2026-09-05, iteration 3231 — [[words/補助|補助]]

No cranberry (補's own stand-in is [[修補]], 助's is [[援助]]). Pronunciation fields (bojo/보조/ㄅㄛㄐㄛ) already verified as the correct concatenation — no bug; kwin:true already correct. Mandarin/japanese/korean confirmed real common terms; vietnamese confirmed a legitimate real-term substitution. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 補給.

### 2026-09-05, iteration 3232 — [[words/補給|補給]]

給's own stand-in is this exact compound; 補's own is [[修補]] — transitivity fails, no cranberry (already documented). Pronunciation fields (bogib/보깁/ㄅㄛㄍㄧㄆ) already verified as the correct concatenation — no bug; kwin:false already correct. Filled blank cantonese/vietnamese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 補習.

### 2026-09-05, iteration 3233 — [[words/補習|補習]]

No cranberry (補's own stand-in is [[修補]], 習's is [[練習]]). **Found and fixed a real bug**: 羅馬字/諺文 bosib/보십 didn't match 習's own sǝb/습 (注音 already correct) → bosǝb/보습. **Found and fixed a real `kwin` bug** (false→true, AND-rule). Other fields confirmed standard and compositional. Filled blank vietnamese, quoted hsk_level, fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 裸.

### 2026-09-05, iteration 3234 — [[words/裸|裸]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. **Found and fixed a real bug**: korean 나 (두음법칙-shifted) → 라 (unshifted, per standing rule). Added missing pos/kwin/japanese. Reformatted a malformed vietnamese string into a proper list. Checked five candidate homophones — none independently legitimized. Stamped `date-last-perfect: 2026-09-05`.

Next: 製作.

### 2026-09-05, iteration 3235 — [[words/製作|製作]]

製's own stand-in is this exact compound; 作's own is [[作]] itself — transitivity fails, no cranberry. Pronunciation fields (jejag/저작/ㄐㄝㄐㄚㄎ) already verified as the correct concatenation — no bug; kwin:false already correct. Other fields confirmed standard and compositional (vietnamese chế tác also a real term). Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 製品.

### 2026-09-05, iteration 3236 — [[words/製品|製品]]

No cranberry (製's own stand-in is [[製作]], 品's is [[品]] itself). Pronunciation fields (jepum/저품/ㄐㄝㄆㄨㄇ) already verified as the correct concatenation — no bug; kwin:false already correct. Mandarin/japanese/korean confirmed real common terms; vietnamese confirmed a legitimate real-term substitution. Fixed cantonese stray space and a missing stand-in annotation on `characters/品 (char).md`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 複数.

### 2026-09-05, iteration 3237 — [[words/複数|複数]]

No cranberry (複's own stand-in is [[重複]], 数's is [[計数]]). Pronunciation fields (bugsu/북수/ㄅㄨㄎㄙㄨ) already verified as the correct concatenation — no bug; kwin:false already correct. **Found and fixed a real bug**: cantonese fuk1 sou3 didn't match 数's own sou2 (wrong tone) — corrected. Other fields confirmed standard and compositional. Filled blank vietnamese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 褐.

### 2026-09-05, iteration 3238 — [[words/褐|褐]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug. Fixed vietnamese null→hạt. Added missing pos/japanese. **Found a genuine homophone** with [[轄]] ("linchpin, control") — added reciprocal callout, gave 轄 a full pass too. Stamped `date-last-perfect: 2026-09-05`.

### 2026-09-05, iteration 3239 — [[words/轄|轄]]

Single-character stand-in word (companion to 褐's homophone group). Added missing japanese. Stamped `date-last-perfect: 2026-09-05`.

Next: 褐金.

### 2026-09-05, iteration 3240 — [[words/褐金|褐金]]

No cranberry (both 褐's and 金's own stand-ins point to themselves). Periodic-table neologism (holmium). Pronunciation fields (hadgim/핟김/ㄏㄚㄊㄍㄧㄇ) already verified as the correct concatenation — no bug; kwin:false already correct. Mandarin/cantonese confirmed to track the real modern element name 钬; korean/japanese/vietnamese all genuine transliterations. Removed redundant 品詞. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 褒.

### 2026-09-05, iteration 3241 — [[words/褒|褒]]

Single-character stand-in word. Pronunciation fields already matched the character's own values — no bug; kwin:false already correct. Confirmed the unusual-looking 諺文 팟 (vowel-final syllable with a batchim) is the vault's established consistent convention, matching both the character page and the syllable master page — not a bug. Added missing pos/japanese. Fixed vietnamese null→bao. Checked three candidate homophones — none independently legitimized. Stamped `date-last-perfect: 2026-09-05`.

Next: 西北.

### 2026-09-05, iteration 3242 — [[words/西北|西北]]

No cranberry (西's own stand-in is [[西方]], 北's is [[北方]]). Pronunciation fields (seibug/세북/ㄙㄝㄧㄅㄨㄎ) already verified as the correct concatenation — no bug; kwin:false already correct. Other fields confirmed standard and compositional (vietnamese tây bắc also a real region name). Fixed cantonese stray space, quoted hsk_level. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 西方.

### 2026-09-05, iteration 3243 — [[words/西方|西方]]

西's own stand-in is this exact compound; 方's own is [[方向]] — transitivity fails, no cranberry. Pronunciation fields (seifang/세빵/ㄙㄝㄧㄈㄚㄫ) already verified as the correct concatenation — no bug; kwin:false already correct. **Found and fixed a real bug**: cantonese xi1 fang1 was invalid jyutping — corrected to sai1fong1. Other fields confirmed standard and compositional. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 西洋.

### 2026-09-05, iteration 3244 — [[words/西洋|西洋]]

No cranberry (西's own stand-in is [[西方]], 洋's is [[大洋]]). **Found and fixed a real bug**: 注音 was missing the null-onset separator before 洋's own vowel-initial syllable (ㄙㄝㄧ⼘ㄫ→ㄙㄝㄧ·⼘ㄫ), matching the established convention already used on [[大洋]] — fixed the matching citations on both `characters/洋.md` and `characters/西.md`. kwin:false already correct. Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 西班牙.

### 2026-09-05, iteration 3245 — [[words/西班牙|西班牙]]

No cranberry (none of the three constituents' stand-ins point here). Pronunciation fields (seipan'a/세판아/ㄙㄝㄧㄆㄚㄋ·ㄚ) already verified as the correct concatenation, including the null-onset syllable break — no bug; kwin:false already correct. As a proper place name, other-language fields legitimately hold the real attested name/transliteration. Fixed cantonese stray spaces and a missing stand-in annotation on `characters/班 (char).md`. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 西班牙語.

### 2026-09-05, iteration 3246 — [[words/西班牙語|西班牙語]]

No cranberry (all four constituents separately legitimized elsewhere). **Found and fixed two real bugs**: 注音 was missing the null-onset separator before 牙's syllable (matching [[西班牙]]'s own established pattern) — fixed here and on the matching citations on `characters/班 (char).md`, `characters/牙.md`, and `characters/語.md`; aliases wrongly self-listed the headword as its own alias — removed. kwin:false already correct. Other fields confirmed genuine real attested terms. Fixed cantonese stray spaces. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 西瓜.

### 2026-09-05, iteration 3247 — [[words/西瓜|西瓜]]

No cranberry (西's own stand-in is [[西方]], 瓜's is [[胡瓜]]). Pronunciation fields (seigwa/세과/ㄙㄝㄧㄍ⺢) already verified as the correct concatenation — no bug. Added missing kwin:false. **Found and fixed a real bug**: japanese すいくわ used obsolete historical kana → modern すいか. Split comma-joined korean (moved native 수박 to prose). Filled blank vietnamese (real term). Fixed cantonese stray space. No homophones. Stamped `date-last-perfect: 2026-09-05`.

Next: 西端.

### 2026-09-05, iteration 3248 — [[words/西端|西端]]

No cranberry (西's own stand-in is [[西方]], 端's is [[末端]]). Pronunciation fields (seidwan/세돤/ㄙㄝㄧㄉ⺢ㄋ) already verified as the correct concatenation — no bug; kwin:false already correct. Other fields confirmed standard and compositional. Filled blank cantonese/vietnamese. No homophones. Stamped `date-last-perfect: 2026-09-05`.

### 2026-09-06, iteration 3249 — [[words/西部|西部]]
Verified concatenation (sei/세/ㄙㄝㄧ + bou/봇/ㄅㄛㄨ = seibou/세봇/ㄙㄝㄧㄅㄛㄨ) already matched stored fields — no bug. 西's own stand_in is 西方; 部's own stand_in is 部 itself — no cranberry. kwin AND-rule (西 false, 部 false → false) already correct. Fixed cantonese's stray space (sai1 bou6 → sai1bou6). Filled blank vietnamese (tây bộ, compositional). Removed blank hsk_level/swadesh. Fixed a missing "(stand-in for 部)" annotation on `characters/部 (char).md`'s own [[部]] citation. homophone_check.py found no independent homophones. Wrote Notes/Etymology sections.

### 2026-09-06, iteration 3250 — [[words/要約|要約]]
No cranberry (要's own stand-in is [[重要]], 約's own stand-in is [[約束]]). Pronunciation fields ('you'yag/욧약/⼄ㄨ⼘ㄎ) already matched the straightforward concatenation — no bug. kwin AND-rule (要 false, 約 true → false) already correct. Filled blank mandarin (yāoyuē, real legal term "offer"), cantonese (jiu3joek3), and vietnamese (yếu ước, compositional using each constituent's own established compound-context reading). Added missing simplified alias 要约. Converted characters to flow-style YAML. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3251 — [[words/要素|要素]]
No cranberry (要's own stand-in is [[重要]]; 素's own stand-in is [[要素]] itself, but transitivity fails since 要's doesn't match — one-sided legitimization, not cranberry). Pronunciation fields ('youso/욧소/⼄ㄨㄙㄛ) already matched the straightforward concatenation — no bug. kwin AND-rule (要 false, 素 true → false) already correct. **Found and fixed a real bug**: japanese had えうそ, obsolete historical kana — corrected to modern ようそ. Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3252 — [[words/覆蓋|覆蓋]]
**Genuine `#cranberry`** (both 覆's and 蓋's own stand-ins point to this exact compound — full transitivity). **Found and fixed a real bug**: 羅馬字/諺文 had puggai/푹개 instead of 覆's own fug/뿍 (注音 already correct — same failure class as the earlier 福-family voiced/voiceless confusion bug). Filled blank korean (복개) and vietnamese (phủ cái, compositional). Converted comma-joined cantonese into a proper list (all three attested real readings). Added missing kwin (false, AND-rule). Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3253 — [[words/覇権|覇権]]
No cranberry (覇's own stand-in is this exact compound; 権's own stand-in is [[権利]]). Pronunciation fields (bagwen/바권/ㄅㄚㄍ⼔ㄋ) already matched the straightforward concatenation — no bug. kwin AND-rule (覇 false, 権 true → false) already correct. Fixed cantonese stray space. Filled blank vietnamese (bá quyền, real standard term). Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3254 — [[words/規則|規則]]
No cranberry (規's own stand-in is [[規律]], 則's own stand-in is [[法則]]). Pronunciation fields (guijug/귀죽/ㄍㄨㄧㄐㄨㄎ) already matched the straightforward concatenation — no bug. kwin AND-rule (both false → false) already correct. **Found and fixed a real bug**: stray body text wrongly claimed this word was 則's stand-in legitimizer (same failure mode as 禍害's earlier fix) — removed, replaced with proper Notes. Fixed cantonese stray space, removed blank hsk_level/swadesh, and a typo ("principial"→"principle") on `characters/則.md`'s own citation. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3255 — [[words/視|視]]
Single-character stand-in word (視's own stand-in is 視 itself). Pronunciation fields (siǝ/싀/ㄙㄧㄜ) already matched the character's own stored reading — no bug. Added missing pos/kwin/japanese. homophone_check.py confirmed existing [[四]]/[[矢]] callouts complete — several other characters (師/死/氏/獅/私/肆/諡) share this syllable but none has its own independently legitimized word page.

### 2026-09-06, iteration 3256 — [[words/視覚|視覚]]
No cranberry (視's own stand-in is [[視]] itself, 覚's own stand-in is [[感覚]]). Pronunciation fields (siǝgag/싀각/ㄙㄧㄜㄍㄚㄎ) already matched the straightforward concatenation — no bug. kwin AND-rule (視 false, 覚 true → false) already correct. Fixed cantonese stray space; all other fields already correct and standard. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3257 — [[words/覚醒|覚醒]]
No cranberry (覚's own stand-in is [[感覚]], 醒's own stand-in is this exact compound). Pronunciation fields (gagseng/각성/ㄍㄚㄎㄙㄝㄫ) already matched the straightforward concatenation — no bug. **Added missing `kwin`** (true, AND-rule: both constituents individually true). Filled blank korean (각성) and vietnamese (giác tỉnh, compositional). Converted comma-joined cantonese into a proper list (both attested real readings). Removed blank hsk_level/swadesh. Fixed a grammar typo ("be disillusion"→"be disillusioned") propagated on both character pages' citations — caught and corrected an accidental duplicate line created while fixing `characters/覚.md`. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3258 — [[words/親切|親切]]
No cranberry (親's own stand-in is [[親戚]], 切's own stand-in is [[切]] itself). **Found and fixed two real bugs**: 羅馬字 had cincet instead of 切's own cinced (諺文/注音 already correct); vietnamese held the literal placeholder "2" — corrected to thân thiết (compositional, also the real standard term). kwin false already correct (AND-rule: 親 true, 切 false). Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3259 — [[words/親戚|親戚]]
No cranberry (親's own stand-in is this exact compound, 戚's own stand-in is [[哀戚]]). Pronunciation fields (cinceg/친척/ㄑㄧㄋㄑㄝㄎ) already matched the straightforward concatenation — no bug. **Found and fixed two real bugs**: kwin was stored false despite both constituents individually true — corrected to true; korean had 차척 instead of compositional/real 친척. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3260 — [[words/親族|親族]]
No cranberry (親's own stand-in is [[親戚]], 族's own stand-in is [[家族]]). Pronunciation fields (cinjog/친족/ㄑㄧㄋㄐㄛㄎ) already matched the straightforward concatenation — no bug. kwin true already correct (AND-rule: both individually true). Fixed cantonese stray space; all other fields already correct and standard. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3261 — [[words/観測|観測]]
No cranberry (観's own stand-in is [[観察]], 測's own stand-in is [[測量]]). **Found and fixed a real bug**: 羅馬字 had gwancig instead of 測's own gwancǝg (諺文/注音 already correct). kwin true already correct (AND-rule: both individually true). Filled blank vietnamese (quan trắc, real standard scientific term) — in passing, added 観's own previously-blank vietnamese reading (quan) to `characters/観.md`. Fixed cantonese stray space, quoted hsk_level. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3262 — [[words/角逐|角逐]]
No cranberry (角's own stand-in is [[角]] itself, 逐's own stand-in is [[追逐]]). Pronunciation fields (gogdug/곡둑/ㄍㄛㄎㄉㄨㄎ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Converted comma-joined mandarin into a list (角 carries an irregular secondary jué reading here, kept alongside its own jiǎo). Fixed cantonese stray space. Filled blank vietnamese (giác trục, compositional). Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3263 — [[words/解|解]]
Single-character stand-in word (解's own stand-in is 解 itself). Pronunciation fields (gyai/걔/ㄍ⼘ㄧ) already matched the character's own stored reading — no bug. Added missing pos/japanese. Completed a genuine homophone callout already anticipated by [[佳]]'s own page (both share gyai/걔/ㄍ⼘ㄧ) — checked [[街]], which shares the same syllable but isn't independently legitimized, so no callout needed there. Fixed a missing "(stand-in for 解)" citation entirely absent from `characters/解 (char).md`'s own Words list.

### 2026-09-06, iteration 3264 — [[words/解剖|解剖]]
No cranberry (解's own stand-in is [[解]] itself, 剖's own stand-in is this exact compound). Pronunciation fields (gyaifou/걔뽓/ㄍ⼘ㄧㄈㄛㄨ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Fixed cantonese stray space; all other fields already correct and standard. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3265 — [[words/解放|解放]]
No cranberry (解's own stand-in is [[解]] itself, 放's own stand-in is [[釈放]]). **Found and fixed a real bug**: 羅馬字/諺文 had gyaibang/걔방 instead of 放's own gyaifang/걔빵 (注音 already correct — same failure class as the 福/覆蓋-family voiced/voiceless confusion bug). kwin false already correct (AND-rule). Filled blank pos (動詞). Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3266 — [[words/解禁|解禁]]
No cranberry (解's own stand-in is [[解]] itself, 禁's own stand-in is [[禁止]]). Pronunciation fields (gyaigim/걔김/ㄍ⼘ㄧㄍㄧㄇ) already matched the straightforward concatenation — no bug. **Added missing `kwin`** (false, AND-rule). Fixed cantonese stray space; all other fields already correct and standard. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3267 — [[words/言語|言語]]
No cranberry (言's own stand-in is [[言]] itself, 語's own stand-in is this exact compound). Pronunciation fields ('en'yo/언요/ㄝㄋ·⼄) already matched the straightforward concatenation, including the correct null-onset separator dot — no bug. kwin false already correct (AND-rule). Mandarin/cantonese legitimately cite the same real term as [[語言]] (Mandarin/Cantonese have no reversed-order word); japanese/korean/vietnamese correctly reflect this word's own 言-then-語 order. **Found and fixed a real bug**: `aliases` wrongly listed [[語言]]/语言 as orthographic variants — 語言 is a distinct, separately-perfected word with its own different reading, not an alias; corrected to genuine simplified variant 言语. Fixed cantonese stray space, removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3268 — [[words/訃告|訃告]]
No cranberry (訃's own stand-in is this exact compound, 告's own stand-in is [[告訴]]). Pronunciation fields (fuogau/뿟갓/ㄈㄨㄛㄍㄚㄨ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Fixed cantonese stray space; all other fields already correct and standard. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3269 — [[words/計画|計画]]
No cranberry (計's own stand-in is this exact compound, 画's own stand-in is [[絵画]]). Pronunciation fields (geihwag/게확/ㄍㄝㄧㄏ⺢ㄎ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Confirmed the stored aliases (計劃/计划) are genuine real orthographic variants, unlike the false-alias bug just fixed on [[言語]]. Quoted hsk_level, removed blank swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3270 — [[words/討伐|討伐]]
No cranberry (討's own stand-in is [[討論]], 伐's own stand-in is this exact compound). Pronunciation fields (taufed/탓뻗/ㄊㄚㄨㄈㄝㄊ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). In passing, fixed an empty-string `pos: ""` bug on `characters/討.md`. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3271 — [[words/討論|討論]]
No cranberry (討's own stand-in is this exact compound, 論's own stand-in is [[理論]]). Pronunciation fields (taulon/탓론/ㄊㄚㄨㄌㄛㄋ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Fixed cantonese stray space, removed blank swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3272 — [[words/記憶|記憶]]
**Genuine `#cranberry`** (both 記's and 憶's own stand-ins point to this exact compound — full transitivity). **Found and fixed a real bug**: 注音 was missing the null-onset separator dot before 憶's vowel-initial syllable (ㄍㄧㄧㄎ→ㄍㄧ·ㄧㄎ), matching the already-correct 羅馬字/諺文 — same failure class as 西洋's earlier fix. Fixed also on `characters/記.md` and `characters/憶.md`'s own citations, and added a missing "(stand-in for 憶)" annotation that was entirely absent from `characters/憶.md`. kwin false already correct (AND-rule). Filled blank vietnamese (ký ức). Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3273 — [[words/記者|記者]]
No cranberry (記's own stand-in is [[記憶]], 者's own stand-in is [[者]] itself). Pronunciation fields (gica/기차/ㄍㄧㄑㄚ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Filled blank vietnamese (ký giả, real standard term). Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3274 — [[words/記載|記載]]
No cranberry (記's own stand-in is [[記憶]], 載's own stand-in is [[載]] itself). Pronunciation fields (gijai/기재/ㄍㄧㄐㄚㄧ) already matched the straightforward concatenation — no bug. kwin true already correct (AND-rule). Filled blank vietnamese (ký tải, compositional, same ký- pattern as [[記者]]/[[記憶]]). Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3275 — [[words/記録|記録]]
No cranberry (記's own stand-in is [[記憶]], 録's own stand-in is [[抄録]]). Pronunciation fields (gilog/기록/ㄍㄧㄌㄛㄎ) already matched the straightforward concatenation — no bug. kwin true already correct (AND-rule). **Found and fixed a real bug**: stray body text wrongly claimed this word was the stand-in for both 記 and 録 — neither is true (same failure mode as 規則's earlier fix). Filled blank vietnamese (ký lục). Fixed cantonese stray space. Removed blank hsk_level/swadesh. Confirmed stored aliases are genuine real orthographic variants. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3276 — [[words/訥|訥]]
Single-character stand-in word (訥's own stand-in is 訥 itself). Pronunciation fields (nod/녿/ㄋㄛㄊ) already matched the character's own stored reading — no bug. Added missing kwin/japanese, fixed bare-string characters format. Fixed a missing "(stand-in for 訥 (char))" annotation on `characters/訥 (char).md`'s own Words list. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3277 — [[words/訪問|訪問]]
No cranberry (訪's own stand-in is this exact compound, 問's own stand-in is [[質問]]). **Found and fixed a real bug**: 羅馬字/諺文 had pangmun/팡문 instead of 訪's own fangmun/빵문 (注音 already correct — same failure class as the 福/覆蓋/解放-family voiced/voiceless confusion bug). kwin false already correct (AND-rule). Fixed cantonese stray space, quoted hsk_level, removed blank swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3278 — [[words/設備|設備]]
No cranberry (設's own stand-in is [[建設]], 備's own stand-in is [[準備]]). Pronunciation fields (sedbiǝ/섣븨/ㄙㄝㄊㄅㄧㄜ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Fixed cantonese stray space; all other fields already correct and standard. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3279 — [[words/設置|設置]]
No cranberry (設's own stand-in is [[建設]], 置's own stand-in is [[置]] itself). Pronunciation fields (sedci/섣치/ㄙㄝㄊㄑㄧ) already matched the straightforward concatenation — no bug. kwin true already correct (AND-rule). Fixed cantonese stray space; all other fields already correct and standard. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3280 — [[words/設計|設計]]
No cranberry (設's own stand-in is [[建設]], 計's own stand-in is [[計画]]). **Found and fixed a real bug**: 注音 had ㄙㄝㄊㄐㄝㄧ instead of the correct ㄙㄝㄊㄍㄝㄧ (計's own 注音 is ㄍㄝㄧ) — unusually, 羅馬字/諺文 (sedgei/섣게) were already correct, the reverse of the usual failure direction. Fixed also on `characters/設.md` and `characters/計.md`'s own citations. kwin false already correct (AND-rule). Fixed cantonese stray space, quoted hsk_level, removed blank swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3281 — [[words/許可|許可]]
No cranberry (both 許's and 可's own stand-ins point to themselves). Pronunciation fields (hyokǝ/효크/ㄏ⼄ㄎㄜ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Fixed cantonese stray space. Filled blank vietnamese (hứa khả, compositional). homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3282 — [[words/訴訟|訴訟]]
No cranberry (訴's own stand-in is this exact compound, 訟's own stand-in is [[訟]] itself). Pronunciation fields (sosyong/소숑/ㄙㄛㄙ⼄ㄫ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Filled blank pos (動詞) and vietnamese (tố tụng, real standard term). Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3283 — [[words/診断|診断]]
No cranberry (診's own stand-in is this exact compound, 断's own stand-in is [[割断]]). Pronunciation fields (jindwan/진돤/ㄐㄧㄋㄉ⺢ㄋ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). **Found and fixed a real bug**: cantonese had the wrong tone (dyun3) not matching 断's own stored dyun6 — corrected both attested variants. Filled blank vietnamese (chẩn đoán, real standard term). Quoted hsk_level. Confirmed stored aliases are genuine real orthographic variants. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3284 — [[words/証人|証人]]
No cranberry (証's own stand-in is [[証明]], 人's own stand-in is [[人]] itself). Pronunciation fields (jingnin/징닌/ㄐㄧㄫㄋㄧㄋ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Fixed cantonese stray space, removed blank hsk_level/swadesh. **Flagged (not fixed)**: `characters/人 (char).md` is in the same badly-degraded state as `characters/一 (char).md` (mixed list styles, missing rt tags including this word's own citation) — needs its own dedicated cleanup pass. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3285 — [[words/証券|証券]]
No cranberry (証's own stand-in is [[証明]], 券's own stand-in is [[券]] itself). Pronunciation fields (jingkon/징콘/ㄐㄧㄫㄎㄛㄋ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Fixed cantonese stray space; all other fields already correct and standard. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3286 — [[words/証拠|証拠]]
No cranberry (証's own stand-in is [[証明]], 拠's own stand-in is [[依拠]]). Pronunciation fields (jinggyo/징교/ㄐㄧㄫㄍ⼄) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Fixed cantonese stray space, quoted hsk_level. Confirmed stored aliases are genuine real orthographic variants. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3287 — [[words/証明|証明]]
No cranberry (証's own stand-in is this exact compound, 明's own stand-in is [[明]] itself). Pronunciation fields (jingmyeng/징명/ㄐㄧㄫㄇ⼶ㄫ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Fixed cantonese stray space; all other fields already correct and standard. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3288 — [[words/評価|評価]]
No cranberry (評's own stand-in is this exact compound, 価's own stand-in is [[価格]]). Pronunciation fields (byengga/병가/ㄅ⼶ㄫㄍㄚ) already matched the straightforward concatenation — no bug. **Added missing `kwin`** (false, AND-rule). Filled blank vietnamese (bình giá, real standard term). Fixed cantonese stray space. Confirmed stored alias is a genuine real orthographic variant. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3289 — [[words/評論|評論]]
No cranberry (評's own stand-in is [[評価]], 論's own stand-in is [[理論]]). Pronunciation fields (byenglon/병론/ㄅ⼶ㄫㄌㄛㄋ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Filled blank pos (名詞). Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3290 — [[words/詞典|詞典]]
No cranberry (詞's own stand-in is [[単詞]], 典's own stand-in is [[事典]]). Pronunciation fields (saden/사던/ㄙㄚㄉㄝㄋ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). **Found and fixed two real bugs**: vietnamese had tự điển (contaminated from sibling word [[字典]]'s own reading) instead of the real từ điển; aliases wrongly listed 辭典/辞典/辞書 as orthographic variants — 辭/辞 is a distinct character with its own separate Dan'a'yo reading (ci/치/ㄑㄧ, own stand-in [[辞職]]), same false-alias failure mode as [[言語]]'s earlier fix. Kept only the genuine simplified alias 词典. Fixed cantonese stray space, quoted hsk_level. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3291 — [[words/詞句|詞句]]
No cranberry (詞's own stand-in is [[単詞]], 句's own stand-in is [[句]] itself). Pronunciation fields (sagu/사구/ㄙㄚㄍㄨ) already matched the straightforward concatenation — no bug. **Found and fixed several real bugs**: kwin false→true (both constituents individually true, AND-rule); japanese/korean/vietnamese all held readings contaminated from the unrelated sibling term 語句 (built on 語 not 句) — corrected to compositional じく/사구/từ cú. Mandarin cíjù confirmed genuinely real and standard. Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3292 — [[words/詞彙|詞彙]]
No cranberry (詞's own stand-in is [[単詞]], 彙's own stand-in is [[彙]] itself). Pronunciation fields (sahu/사후/ㄙㄚㄏㄨ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). **Found and fixed a real bug**: cantonese had wui6, not matching 彙's own stored wai6 — corrected to ci4wai6. In passing, fixed a malformed comma-joined vietnamese field on `characters/彙 (char).md`. Japanese/korean correctly left blank (real term uses 語彙, not 詞彙) — already documented. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3293 — [[words/詠春拳|詠春拳]]
No cranberry (詠's own stand-in is [[詠]] itself, 春's own stand-in is [[春]] itself, 拳's own stand-in is [[拳骨]]). Pronunciation fields ('wingcungwen/윙춘권/ㄨㄧㄫㄑㄨㄋㄍ⼔ㄋ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). All other-language fields confirmed standard, real-attested transliterations of this martial-art proper noun. Fixed cantonese stray spaces. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3294 — [[words/詣|詣]]
Single-character stand-in word (詣's own stand-in is 詣 itself). Pronunciation fields ('ei/에/ㄝㄧ) already matched the character's own stored reading — no bug. Added missing kwin/japanese. Completed a genuine homophone callout already anticipated by [[児]]'s own page (both share 'ei/에/ㄝㄧ). Checked [[羿]]/[[霓]], which share the syllable but aren't independently legitimized — no callout needed. homophone_check.py confirmed no other homophones.

### 2026-09-06, iteration 3295 — [[words/試験|試験]]
No cranberry (試's own stand-in is [[考試]], 験's own stand-in is this exact compound). Pronunciation fields (si'em/시엄/ㄙㄧ·ㄝㄇ) already matched the straightforward concatenation, including the correct null-onset dot — no bug. kwin false already correct (AND-rule). Korean 시험 legitimately diverges from the Dan'a'yo-internal assignment (real word vs. assigned syllable). Fixed cantonese stray space, removed redundant duplicate 品詞 field. In passing, fixed a missing "(stand-in for 験 (char))" annotation and a malformed non-ruby citation on `characters/験 (char).md`'s own Words list. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3296 — [[words/詩人|詩人]]
No cranberry (詩's own stand-in is [[詩歌]], 人's own stand-in is [[人]] itself). Pronunciation fields (sinin/시닌/ㄙㄧㄋㄧㄋ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Fixed cantonese stray space; all other fields already correct and standard (already-thorough Notes kept). homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3297 — [[words/詩歌|詩歌]]
No cranberry (詩's own stand-in is this exact compound, 歌's own stand-in is [[歌曲]]). **Found and fixed two real bugs**: 羅馬字/諺文/注音 all had siga/시가/ㄙㄧㄍㄚ instead of the correct sigǝ/시그/ㄙㄧㄍㄜ (歌's own reading is gǝ/그/ㄍㄜ, not ga/가/ㄍㄚ) — fixed also on `characters/詩.md` and `characters/歌.md`'s own citations (caught and corrected an accidental duplicate line created while fixing 詩.md); kwin was stored true despite 歌 being individually false — corrected to false (AND-rule). Filled blank vietnamese (thi ca, real standard term). Fixed cantonese stray space, removed redundant duplicate 品詞. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3298 — [[words/詩経|詩経]]
No cranberry (詩's own stand-in is [[詩歌]], 経's own stand-in is [[経]] itself). Pronunciation fields (sigeng/시겅/ㄙㄧㄍㄝㄫ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Fixed cantonese stray space; all other fields already correct, real proper-noun transliterations. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3299 — [[words/該|該]]
Single-character stand-in word (該's own stand-in is 該 itself). Pronunciation fields (goi/괴/ㄍㄛㄧ) already matched the character's own stored reading — no bug. Added missing pos/japanese/kwin. **Found and fixed a real bug**: vietnamese held the literal string "null" — corrected to cai (compositional). homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3300 — [[words/詳細|詳細]]
No cranberry (詳's own stand-in is this exact compound, 細's own stand-in is [[細]] itself). Pronunciation fields (sangsei/상세/ㄙㄚㄫㄙㄝㄧ) already matched the straightforward concatenation — no bug. kwin true already correct (AND-rule). Filled blank vietnamese (tường tế, compositional). Fixed cantonese stray space. In passing, fixed a non-standard jyutping romanization (cheung4→coeng4) and converted malformed comma-joined mandarin/vietnamese/aliases fields into proper YAML lists on `characters/詳.md`. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3301 — [[words/誅殺|誅殺]]
No cranberry (誅's own stand-in is this exact compound, 殺's own stand-in is [[殺]] itself). Pronunciation fields (jusad/주삳/ㄐㄨㄙㄚㄊ) already matched the straightforward concatenation — no bug. **Added missing `kwin`** (true, AND-rule). Filled blank vietnamese (tru sát, compositional). Fixed cantonese stray space. In passing, fixed an empty-string `hsk_level: ""` bug on `characters/誅.md` (→ 無) and added it to `lookup/HSK/HSK No.md`. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3302 — [[words/誇示|誇示]]
No cranberry (誇's own stand-in is [[誇]] itself, 示's own stand-in is [[開示]]). Pronunciation fields (kwage/콰거/ㄎ⺢ㄍㄝ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Filled blank cantonese (kwaa1si6) and vietnamese (khoa thị, compositional). Fixed bare-string characters entry. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3303 — [[words/認証|認証]]
No cranberry (認's own stand-in is [[認識]], 証's own stand-in is [[証明]]). Pronunciation fields (ninjing/닌징/ㄋㄧㄋㄐㄧㄫ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Confirmed genuine homophone with [[人証]] (認's own reading coincidentally matches 人's own reading exactly). Filled blank vietnamese (nhận chứng, compositional). Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py confirmed no other homophones.

### 2026-09-06, iteration 3304 — [[words/認識|認識]]
**Genuine `#cranberry`** (both 認's and 識's own stand-ins point to this exact compound — full transitivity). Pronunciation fields (ninsig/닌식/ㄋㄧㄋㄙㄧㄎ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Fixed cantonese stray space, quoted hsk_level, filled blank aliases (认识). Removed blank swadesh. In passing, fixed a missing "(stand-in for 識)" annotation and a malformed space-joined mandarin field on `characters/識.md`. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3305 — [[words/誓約|誓約]]
No cranberry (誓's own stand-in is [[盟誓]], 約's own stand-in is [[約束]]). Pronunciation fields (se'yag/서약/ㄙㄝ⼘ㄎ) already matched the straightforward concatenation — no bug (no null-onset dot needed before 約, consistent with the established precedent from [[公約]]/[[制約]]/[[条約]]). kwin true already correct (AND-rule). Fixed cantonese stray space; all other fields already correct and standard. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3306 — [[words/誕生|誕生]]
No cranberry (誕's own stand-in is this exact compound, 生's own stand-in is [[生活]]). Pronunciation fields (dansang/단상/ㄉㄚㄋㄙㄚㄫ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule); all other fields already correct and standard. Added missing aliases: []. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3307 — [[words/誘拐|誘拐]]
No cranberry (誘's own stand-in is [[誘発]], 拐's own stand-in is this exact compound). Pronunciation fields ('yuogwai/윳괘/⼜ㄛㄍ⺢ㄧ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Filled blank cantonese (jau5gwaai2) and vietnamese (dụ quải, compositional). Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3308 — [[words/誘発|誘発]]
No cranberry (誘's own stand-in is this exact compound, 発's own stand-in is [[発]] itself). Pronunciation fields ('yuofad/윳빧/⼜ㄛㄈㄚㄊ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Filled blank vietnamese (dụ phát, compositional). Fixed cantonese stray space. In passing, fixed a malformed comma-joined vietnamese field on `characters/発 (char).md`. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3309 — [[words/誘餌|誘餌]]
No cranberry (誘's own stand-in is [[誘発]], 餌's own stand-in is this exact compound). Pronunciation fields ('yuoni/윳니/⼜ㄛㄋㄧ) already matched the straightforward concatenation — no bug. **Added missing `kwin`** (false, AND-rule). Fixed cantonese stray space. Removed blank hsk_level/swadesh; other fields already thoroughly researched and documented. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3310 — [[words/語彙|語彙]]
No cranberry (語's own stand-in is [[言語]], 彙's own stand-in is [[彙]] itself). Pronunciation fields ('yohu/요후/⼄ㄏㄨ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). **Found and fixed two real bugs**: vietnamese held the literal empty string "" — corrected to ngữ vựng; aliases wrongly listed [[詞彙]] (a distinct separately-perfected word built on 詞, different reading) — corrected to genuine simplified 语汇, same false-alias pattern as [[言語]]'s earlier fix. Removed redundant duplicate 品詞. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3311 — [[words/語感|語感]]
No cranberry (語's own stand-in is [[言語]], 感's own stand-in is [[感触]]). Pronunciation fields ('yogam/요감/⼄ㄍㄚㄇ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3312 — [[words/語族|語族]]
No cranberry (語's own stand-in is [[言語]], 族's own stand-in is [[家族]]). Pronunciation fields ('yojog/요족/⼄ㄐㄛㄎ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Fixed cantonese stray space, simplified single-item vietnamese list to a scalar. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3313 — [[words/語気|語気]]
No cranberry (語's own stand-in is [[言語]], 気's own stand-in is [[気]] itself). Pronunciation fields ('yokiǝ/요킈/⼄ㄎㄧㄜ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Filled blank vietnamese (ngữ khí). **Found and fixed a real bug**: aliases wrongly listed 口調/声色/語調 (unrelated synonym compounds on different characters) as orthographic variants — kept only genuine traditional 語氣. Investigated a false 注音 collision with [[浴衣]] (same bopomofo string, different segmentation) and found it stemmed from a genuine separate bug: 浴衣 was missing its own null-onset separator dot before 衣's syllable — fixed on `words/浴衣.md` and both its character-page citations. Fixed cantonese stray space. Removed blank hsk_level/swadesh. No genuine homophones.

### 2026-09-06, iteration 3314 — [[words/語気助詞|語気助詞]]
No cranberry (none of the four constituents' own stand-ins point here). Pronunciation fields ('yokiǝjosa/요킈조사/⼄ㄎㄧㄜㄐㄛㄙㄚ) already matched the straightforward concatenation — no bug. **Added missing `kwin`** (false, AND-rule). Filled blank mandarin/cantonese/japanese/korean/vietnamese, all compositional (mandarin also independently real). Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3315 — [[words/語法|語法]]
No cranberry (語's own stand-in is [[言語]], 法's own stand-in is [[法]] itself). **Found and fixed a real bug**: 羅馬字/諺文 had 'yopab/요팝 instead of 法's own 'yofab/요빱 (注音 already correct — same failure class as the 福/覆蓋/解放/訪問-family voiced/voiceless confusion bug). kwin false already correct (AND-rule). Filled blank japanese (ごほう). Fixed cantonese stray space, quoted hsk_level. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3316 — [[words/語用|語用]]
No cranberry (語's own stand-in is [[言語]], 用's own stand-in is [[使用]]). Pronunciation fields ('yo'yong/요용/⼄·⼄ㄫ) already matched the straightforward concatenation, including the null-onset dot — no bug. **Added missing `kwin`** (false, AND-rule). Filled blank cantonese/korean/vietnamese (korean 어용 compositionally coincides with an unrelated real word, not a bug). Removed redundant duplicate 品詞. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3317 — [[words/誠実|誠実]]
No cranberry (誠's own stand-in is this exact compound, 実's own stand-in is [[真実]]). Pronunciation fields (singsid/싱싣/ㄙㄧㄫㄙㄧㄊ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Filled blank pos (性詞) and vietnamese (thành thực, real standard term). Fixed cantonese stray space, quoted hsk_level. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3318 — [[words/誠心|誠心]]
No cranberry (誠's own stand-in is [[誠実]], 心's own stand-in is [[心]] itself). Pronunciation fields (singsim/싱심/ㄙㄧㄫㄙㄧㄇ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Filled blank pos (性詞). Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3319 — [[words/誠意|誠意]]
No cranberry (誠's own stand-in is [[誠実]], 意's own stand-in is [[意味]]). Pronunciation fields (sing'ǝ/싱으/ㄙㄧㄫㄜ) already matched the straightforward concatenation, consistent with the established no-dot precedent on `characters/意.md`'s own citation — no bug. **Added missing `kwin`** (false, AND-rule). Filled blank pos (動詞). Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3320 — [[words/誤差|誤差]]
No cranberry (誤's own stand-in is [[錯誤]], 差's own stand-in is [[差別]]). Pronunciation fields ('oca/오차/ㄛㄑㄚ) already matched the straightforward concatenation — no bug. kwin true already correct (AND-rule). Filled blank pos (名詞) and vietnamese (ngộ sai, compositional). Fixed cantonese stray space. Removed blank hsk_level/swadesh. In passing, converted a malformed space-joined mandarin field on `characters/差.md` into a proper list. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3321 — [[words/誤謬|誤謬]]
No cranberry (誤's own stand-in is [[錯誤]], 謬's own stand-in is this exact compound). Pronunciation fields ('omyu/오뮤/ㄛㄇ⼜) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Fixed cantonese stray space; all other fields already correct and standard. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3322 — [[words/説明|説明]]
No cranberry (説's own stand-in is [[学説]], 明's own stand-in is [[明]] itself). Pronunciation fields (swedmyeng/숻명/ㄙ⼔ㄊㄇ⼶ㄫ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Filled blank pos (動詞) and vietnamese (thuyết minh, real standard term). Fixed cantonese stray space. Removed blank swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3323 — [[words/読書|読書]]
No cranberry (読's own stand-in is [[閲読]], 書's own stand-in is [[書本]]). Pronunciation fields (dogsyo/독쇼/ㄉㄛㄎㄙ⼄) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Fixed cantonese stray space, quoted hsk_level, filled blank aliases (读书). In passing, added 読's own previously-blank vietnamese reading (đọc) to `characters/読.md`. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3324 — [[words/読点|読点]]
No cranberry (読's own stand-in is [[閲読]], 点's own stand-in is [[点]] itself). Pronunciation fields (dogdem/독덤/ㄉㄛㄎㄉㄝㄇ) already matched the straightforward concatenation — no bug. **Added missing `kwin`** (false, AND-rule). Filled blank mandarin/cantonese/korean/vietnamese (korean 독점 compositionally coincides with an unrelated real word, not a bug). homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3325 — [[words/課|課]]
Single-character stand-in word (課's own stand-in is 課 itself). Pronunciation fields (kwam/쾀/ㄎ⺢ㄇ) already matched the character's own stored reading — no bug. Added missing pos/japanese/kwin, filled blank vietnamese (khoá). Fixed a missing "(stand-in for 課 (char))" annotation on the character page's own Words list. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3326 — [[words/調整|調整]]
No cranberry (調's own stand-in is this exact compound, 整's own stand-in is [[整]] itself). Pronunciation fields (juojeng/줏정/ㄐㄨㄐㄝㄫ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Fixed cantonese stray space, removed blank hsk_level/swadesh. Confirmed genuine, already reciprocally documented homophone with [[酒精]]. homophone_check.py found no other homophones.

### 2026-09-06, iteration 3327 — [[words/調査|調査]]
No cranberry (調's own stand-in is [[調整]], 査's own stand-in is this exact compound). Pronunciation fields (juoja/줏자/ㄐㄨㄛㄐㄚ) already matched the straightforward concatenation — no bug. **Added missing `kwin`** (false, AND-rule). Filled blank korean (조사) and vietnamese (điều tra, real standard term). Fixed cantonese stray space. Removed blank hsk_level/swadesh. Added genuine simplified alias 调查. homophone_check.py found no independent homophones.

**Correction to iteration 3326 ([[調整]])**: while verifying 調査's own reading, discovered that 調整's `注音` had been left ㄐㄨㄐㄝㄫ (missing 調's own ㄛ) — corrected to ㄐㄨㄛㄐㄝㄫ, fixed also on `characters/調.md` and `characters/整 (char).md`'s citations. The same bug independently affected [[酒精]] (a genuine coincidental homophone of 調整 — 酒 shares 調's exact own reading juo/줏/ㄐㄨㄛ) — fixed there too, plus citations on `characters/酒.md` and `characters/精.md`. The homophone relationship between 調整 and 酒精 survives the correction.

### 2026-09-06, iteration 3328 — [[words/諂|諂]]
Single-character stand-in word (諂's own stand-in is 諂 itself). Pronunciation fields (cem/첨/ㄑㄝㄇ) already matched the character's own stored reading — no bug. Added missing pos/japanese. **Found and fixed a real bug**: vietnamese held the literal string "null" — corrected to siểm. **Found a genuine, previously undocumented homophone** with [[鹸]] ("base, alkali") — added reciprocal callouts to both pages. homophone_check.py found no other homophones.

### 2026-09-06, iteration 3329 — [[words/談判|談判]]
No cranberry (談's own stand-in is [[談話]], 判's own stand-in is [[判断]]). Pronunciation fields (dampan/담판/ㄉㄚㄇㄆㄚㄋ) already matched the straightforward concatenation — no bug. kwin true already correct (AND-rule). Fixed cantonese stray space, quoted hsk_level, filled blank aliases (谈判). Removed blank swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3330 — [[words/請|請]]
Single-character stand-in word (請's own stand-in is 請 itself). Pronunciation fields (cing/칭/ㄑㄧㄫ) already matched the character's own stored reading — no bug. Added missing pos/japanese/kwin. **Found and fixed a real bug**: vietnamese held the literal string "null" — corrected to thỉnh. **Found a genuine, previously undocumented homophone** with [[逞]] ("indulge, brag") — added reciprocal callouts to both pages, plus a missing "(stand-in for 請 (char))" citation entirely absent from the character page's own Words list. Checked five other candidates (情/懲/晴/清/称), none independently legitimized.

### 2026-09-06, iteration 3331 — [[words/諒解|諒解]]
No cranberry (諒's own stand-in is this exact compound, 解's own stand-in is [[解]] itself). Pronunciation fields (lyanggyai/량걔/ㄌ⼘ㄫㄍ⼘ㄧ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Fixed cantonese stray space, filled blank aliases (谅解). Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3332 — [[words/論争|論争]]
No cranberry (論's own stand-in is [[理論]], 争's own stand-in is [[抗争]]). Pronunciation fields (lonjang/론장/ㄌㄛㄋㄐㄚㄫ) already matched the straightforward concatenation — no bug. **Added missing `kwin`** (false, AND-rule). **Found and fixed real bugs**: korean was a comma-joined mixed-form string (논쟁,쟁론) — reformatted to a list and corrected the first value's 두음법칙-shifted 논 to the vault's standing North Korean 론 (론쟁), kept 쟁론 as a genuine reversed-order alternate reading; aliases wrongly listed 爭論/争论 (would be a distinct compound with a different reading, janglon not lonjang) — kept only genuine 論爭, same false-alias pattern as [[言語]]'s earlier fix. Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3333 — [[words/諦|諦]]
Single-character stand-in word (諦's own stand-in is 諦 itself). Pronunciation fields (tei/테/ㄊㄝㄧ) already matched the character's own stored reading — no bug. Added missing japanese/kwin. Confirmed existing [[締]]/[[剃]] homophone callouts complete. Fixed a malformed non-ruby, unannotated Words-list citation on the character page. homophone_check.py confirmed no other homophones.

### 2026-09-06, iteration 3334 — [[words/諭示|諭示]]
No cranberry (諭's own stand-in is this exact compound, 示's own stand-in is [[開示]]). **Found and fixed a real bug**: 羅馬字/諺文 had 'yuge/유거 instead of 諭's own 'yumge/윰거 (注音 already correct — missing final -m, same class as the福/覆蓋/解放/訪問/語法-family bugs). kwin false already correct (AND-rule). Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3335 — [[words/諱|諱]]
Single-character stand-in word (諱's own stand-in is 諱 itself). Pronunciation fields (hui/휘/ㄏㄨㄧ) already matched the character's own stored reading — no bug. Fixed bare-string characters format. Checked seven candidates sharing this syllable (卉/徽/戯/揮/犠/葦/輝), none independently legitimized. Fixed a malformed non-ruby citation on the character page. homophone_check.py found no genuine homophones.

### 2026-09-06, iteration 3336 — [[words/諸語|諸語]]
No cranberry (諸's own stand-in is [[諸]] itself, 語's own stand-in is [[言語]]). Pronunciation fields (ja'yo/자요/ㄐㄚ⼄) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Fixed cantonese stray space. Filled blank vietnamese (chư ngữ, compositional). Added missing simplified alias 诸语. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3337 — [[words/諺文|諺文]]
No cranberry (諺's own stand-in is this exact compound, 文's own stand-in is [[文化]]). **Found and fixed a major real bug**: 羅馬字/諺文/注音 had nyenmun/년문/ㄋ⼶ㄋㄇㄨㄋ, not matching 諺's own stored 'en/언/ㄝㄋ at all — corrected to 'enmun/언문/ㄝㄋㄇㄨㄋ, fixed also on `characters/文.md`'s citation. Fixed cantonese stray space. Filled blank vietnamese (ngạn văn). **Found and removed a false alias**: 韩文/韓文 represent a rejected alternative naming (a different character 韓), not orthographic variants, as the body text itself already explained. Flagged `characters/諺.md` as badly under-filled (no Words section despite its own stand_in, stub Notes, likely wrong english gloss) — added the missing stand-in citation, left the rest for a dedicated cleanup pass. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3338 — [[words/諾|諾]]
Single-character stand-in word (諾's own stand-in is 諾 itself). Pronunciation fields (nag/낙/ㄋㄚㄎ) already matched the character's own stored reading — no bug. Added missing pos/japanese/kwin. **Found and fixed a real bug**: vietnamese held the literal string "null" — corrected to nặc. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3339 — [[words/謀求|謀求]]
No cranberry (謀's own stand-in is [[謀]] itself, 求's own stand-in is [[要求]]). Pronunciation fields (muogyuo/뭇귯/ㄇㄨㄛㄍ⼜ㄛ) already matched the straightforward concatenation — no bug. **Added missing `kwin`** (false, AND-rule). Filled blank japanese (ぼうきゅう, compositional). **Found and fixed a real bug**: korean held native/mixed verb forms (꾀하다, 도모하다) instead of compositional 모구 — corrected, kept the originals as prose equivalents. Fixed cantonese stray space. Added missing simplified alias 谋求. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3340 — [[words/謁|謁]]
Single-character stand-in word (謁's own stand-in is 謁 itself). **Found and fixed a real bug**: 羅馬字 was missing the character's own leading null-onset apostrophe (ed→'ed; 諺文/注音 already correct). Added missing japanese/kwin. In passing, fixed an empty-string `hsk_level: ""` bug on `characters/謁 (char).md` and added it to `lookup/HSK/HSK No.md`. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3341 — [[words/謂之|謂之]]
No cranberry (謂's own stand-in is [[所謂]], 之's own stand-in is [[之]] itself). Pronunciation fields (witi/위티/ㄨㄧㄊㄧ) already matched the straightforward concatenation — no bug. **Added missing `kwin`** (false, AND-rule). Filled blank cantonese/korean/japanese/vietnamese, all compositional. Removed redundant duplicate 品詞, fixed mandarin's stray space. Fixed a missing citation on `characters/之 (char).md`'s own Words list. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3342 — [[words/謄録|謄録]]
No cranberry (謄's own stand-in is this exact compound, 録's own stand-in is [[抄録]]). Pronunciation fields (dǝnglog/등록/ㄉㄜㄫㄌㄛㄎ) already matched the straightforward concatenation — no bug. kwin true already correct (AND-rule). Filled blank vietnamese (đằng lục, compositional). Fixed a missing "(stand-in for 謄)" annotation on `characters/謄.md`'s own Words list. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3343 — [[words/謎|謎]]
Single-character stand-in word (謎's own stand-in is 謎 itself). Pronunciation fields (mei/메/ㄇㄝㄧ) already matched the character's own stored reading — no bug. Added missing japanese/kwin. Confirmed existing [[米]]/[[迷]] homophone callouts complete. Fixed a missing "(stand-in for 謎 (char))" annotation on the character page's own Words list. homophone_check.py found no other homophones.

### 2026-09-06, iteration 3344 — [[words/謹慎|謹慎]]
**Genuine `#cranberry`** (both 謹's and 慎's own stand-ins point here — full transitivity, already correctly tagged). Pronunciation fields (ginsin/긴신/ㄍㄧㄋㄙㄧㄋ) already matched the straightforward concatenation — no bug. **Added missing `kwin`** (false, AND-rule) and **found and fixed a real bug**: cantonese had sen6, not matching 慎's own stored san6 — corrected to gan2san6. Filled blank korean (근신) and vietnamese (cẩn thận). Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3345 — [[words/識字|識字]]
No cranberry (識's own stand-in is [[認識]], 字's own stand-in is [[字]] itself). **Found and fixed a real bug**: 羅馬字 had sikji instead of 識's own sigji (諺文/注音 already correct — Hangul batchim doesn't distinguish g/k). kwin false already correct (AND-rule). Converted two real mandarin readings into a list. Filled blank pos (名詞) and vietnamese (thức tự). Fixed cantonese stray space, removed redundant duplicate 品詞. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3346 — [[words/議員|議員]]
No cranberry (議's own stand-in is [[議論]], 員's own stand-in is [[人員]]). **Found and fixed a real bug**: 羅馬字/諺文 had 'wi'un/위운 instead of 議's own 'ǝi'un/읫운 (注音 already correct — 議 carries 義 as phonetic component and inherited the same historical misreading bug fixed 7 times earlier this session for 義-final compounds). Added missing kwin (true, AND-rule). Fixed cantonese stray space. Removed blank swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3347 — [[words/議定|議定]]
No cranberry (議's own stand-in is [[議論]], 定's own stand-in is [[決定]]). Found and fixed a real bug: 羅馬字/諺文 had 'wijeng/위정 instead of 議's own 'ǝijeng/읫정 (注音 already correct — same 議/義-family misreading bug as [[議員]]). Added missing kwin (true, AND-rule). Filled blank pos (動詞) and vietnamese (nghị định). Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3348 — [[words/議論|議論]]
No cranberry (議's own stand-in is this exact compound, 論's own stand-in is [[理論]]). Pronunciation fields already correctly used 議's own 'ǝi form (no bug here, unlike the sibling compounds). Added missing kwin (false, AND-rule). Filled blank vietnamese (nghị luận). Fixed cantonese stray space. Added missing simplified alias 议论. **Out-of-sequence fix**: while checking for other instances of the 議-misreading bug, found and fixed the same bug on still-unperfected `words/会議.md` (hwe'wi→hwe'ǝi) — confirmed all other 議-compounds (協議/衆議/衆議院/思議/諌議) were already correctly stamped with 'ǝi from their own original perfecting passes. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3349 — [[words/護金|護金]]
No cranberry (護's own stand-in is [[守護]], 金's own stand-in is [[金]] itself). Pronunciation fields (hogim/호김/ㄏㄛㄍㄧㄇ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Periodic-table neologism (palladium); cantonese paa4 confirmed to legitimately track the real element name 钯. **Found and fixed a real bug**: mandarin had the wrong tone (bā→bǎ, matching 钯's real reading). Removed redundant duplicate 品詞, simplified single-item lists to scalars. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3350 — [[words/豆腐|豆腐]]
No cranberry (豆's own stand-in is [[豆]] itself, 腐's own stand-in is [[腐敗]]). Pronunciation fields (doupu/돗푸/ㄉㄛㄨㄆㄨ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Converted comma-joined mandarin and vietnamese into proper YAML lists. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3351 — [[words/豊富|豊富]]
**Genuine `#cranberry`** (both 豊's and 富's own stand-ins point here — full transitivity, tag added). **Found and fixed a real bug**: 羅馬字/諺文 had pungbuo/푼붓 instead of the correct pungfuo/풍뿟 (注音 already correct throughout). kwin false already correct (AND-rule). Filled blank vietnamese (phong phú, real standard term). Quoted hsk_level. Both character-page citations already correctly annotated. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3352 — [[words/豊尭|豊尭]]
Not a literal cranberry (豊's own stand-in is [[豊富]]; 尭's own stand_in field is the forbidden-character placeholder 名専字, so its use here as a borrowed stand-in for its alias 饒 is a documented special case, not a normal cranberry). Pronunciation fields (pung'yau/풍얏/ㄆㄨㄫ⼘ㄨ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Filled blank vietnamese (phong nhiêu, using 饒's own real reading). Fixed cantonese stray space. Confirmed stored aliases (豊饒/豐饒/丰饶) are the genuine real spellings using 饒 itself. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3353 — [[words/豚肉|豚肉]]
No cranberry (豚's own stand-in is [[豚]] itself, 肉's own stand-in is [[肉]] itself). Found and fixed a real bug: 羅馬字 had donnug instead of 豚's own tunnug (諺文/注音 already correct). Mandarin/cantonese/korean/vietnamese legitimately cite the real common words for pork (built on unrelated 豬/猪, matching the [[詞彙]] precedent, not a bug). Found and removed a false alias (豬肉 — a distinct compound on 猪 with its own different reading). Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3354 — [[words/象形|象形]]
No cranberry (象's own stand-in is [[大象]], 形's own stand-in is [[形]] itself). Pronunciation fields (syangheng/샹헝/ㄙ⼘ㄫㄏㄝㄫ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Fixed cantonese stray space, removed redundant duplicate 品詞. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3355 — [[words/豪傑|豪傑]]
No cranberry (豪's own stand-in is [[豪華]], 傑's own stand-in is [[傑出]]). Pronunciation fields (hauged/핫걷/ㄏㄚㄨㄍㄝㄊ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Removed blank hsk_level/swadesh. Added missing simplified alias 豪杰. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3356 — [[words/豪洲|豪洲]]
No cranberry (豪's own stand-in is [[豪華]], 洲's own stand-in is [[洲]] itself). Pronunciation fields (haujuo/핫줏/ㄏㄚㄨㄐㄨㄛ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Mandarin/cantonese/japanese legitimately cite the real (more common) names for Australia, matching the [[詞彙]]/[[豚肉]] precedent. Filled blank vietnamese (Úc). Fixed cantonese stray space. **Found and removed a false alias**: 澳洲 (unrelated character 澳, no vault presence) — kept 豪州 (valid, 州 shares 洲's exact reading) and 濠洲/濠州 (valid, 濠 is 豪's own alias). Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3357 — [[words/豪華|豪華]]
No cranberry (豪's own stand-in is this exact compound, 華's own stand-in is [[華美]]). Pronunciation fields (hauhwa/핫화/ㄏㄚㄨㄏ⺢) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Filled blank vietnamese (hào hoa, real standard term). Fixed cantonese stray space, quoted hsk_level, added missing simplified alias 豪华. Removed blank swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3358 — [[words/貒|貒]]
Single-character stand-in word (貒's own stand-in is 貒 itself). Pronunciation fields (twan/퇀/ㄊ⺢ㄋ) already matched the character's own stored reading — no bug. Added missing pos/japanese/kwin. **Found and fixed two real bugs**: vietnamese/korean held the literal string "null" — vietnamese removed (genuinely empty ø on the character page), korean corrected to 단. Fixed a malformed non-ruby, unannotated citation on the character page. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3359 — [[words/貝類|貝類]]
No cranberry (貝's own stand-in is this exact compound, 類's own stand-in is [[種類]]). Pronunciation fields (bailui/배뤼/ㄅㄚㄧㄌㄨㄧ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). **Found and fixed three real bugs**: japanese held only かい (missing 類 entirely) → かいるい; korean held 貝's own native gloss 조개 (not compositional) → 배류; vietnamese held ốc ("snail," unrelated) → bối loại (compositional). Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3360 — [[words/貞潔|貞潔]]
No cranberry (貞's own stand-in is this exact compound, 潔's own stand-in is [[清潔]]). Pronunciation fields (tingged/팅걷/ㄊㄧㄫㄍㄝㄊ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule); all other fields already correct and standard. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3361 — [[words/貢献|貢献]]
No cranberry (貢's own stand-in is [[貢品]], 献's own stand-in is [[献上]]). Pronunciation fields (gonghen/공헌/ㄍㄛㄫㄏㄝㄋ) already matched the straightforward concatenation — no bug. **Added missing `kwin`** (true, AND-rule). Split comma-joined korean, keeping compositional 공헌 (native 이바지 moved to prose). Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3362 — [[words/貧乏|貧乏]]
No cranberry (貧's own stand-in is this exact compound, 乏's own stand-in is [[欠乏]]). Pronunciation fields (binbab/빈밥/ㄅㄧㄋㄅㄚㄆ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Filled blank vietnamese (bần phập). Fixed cantonese stray space, added missing simplified alias. In passing, fixed an empty-string `pos: ""` bug and a missing stand-in citation on `characters/乏.md`. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3363 — [[words/貧窮|貧窮]]
No cranberry (貧's own stand-in is [[貧乏]], 窮's own stand-in is this exact compound). Pronunciation fields (bingung/빈궁/ㄅㄧㄋㄍㄨㄫ) already matched the straightforward concatenation — no bug. kwin true already correct (AND-rule). **Found and fixed a real bug**: mandarin pinyin ordering typo (pínqíong→pínqióng). Filled blank vietnamese (bần cùng). Fixed cantonese stray space, added missing simplified alias. Fixed a missing "(stand-in for 窮)" annotation on `characters/窮.md`'s own Words list. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3364 — [[words/貨幣|貨幣]]
No cranberry (貨's own stand-in is [[貨物]], 幣's own stand-in is [[幣]] itself). Pronunciation fields (hwape/화퍼/ㄏ⺢ㄆㄝ) already matched the straightforward concatenation — no bug. **Added missing `kwin`** (false, AND-rule). Split comma-joined korean (native 돈 moved to prose). Filled blank vietnamese (hoá tệ). Fixed cantonese stray space, added missing simplified alias 货币. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3365 — [[words/貨物|貨物]]
No cranberry (貨's own stand-in is this exact compound, 物's own stand-in is [[物]] itself). Found and fixed a real bug: 羅馬字 hwamut→hwamud (諺文/注音 already correct). Added missing kwin (true, AND-rule). Split comma-joined korean, filled blank vietnamese, fixed cantonese stray space, added missing simplified alias. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3366 — [[words/販売|販売]]
**Genuine `#cranberry`** (both 販's and 売's own stand-ins point here — full transitivity, already correctly tagged). Found and fixed a real bug: 羅馬字 bonmai→fonmai (諺文/注音 already correct). Filled blank vietnamese (phán mại) — in passing added 売's own previously-blank vietnamese (mại) to its character page, plus a missing "(stand-in for both 販 and 売)" annotation matching 販's own citation. Fixed cantonese stray space. Confirmed stored aliases are genuine real orthographic variants. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3367 — [[words/貪官|貪官]]
No cranberry (貪's own stand-in is [[貪]] itself, 官's own stand-in is [[官人]]). Pronunciation fields (tamgwan/탐관/ㄊㄚㄇㄍ⺢ㄋ) already matched the straightforward concatenation — no bug. kwin true already correct (AND-rule). Filled blank pos (名詞) and vietnamese (tham quan). Fixed cantonese stray space. **Found and fixed a real bug**: aliases wrongly self-listed the word's own headword (貪官) as its own alias — removed, kept genuine simplified 贪官. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3368 — [[words/貪林|貪林]]
Not a cranberry (貪's own stand-in is [[貪]] itself; 林's own stand_in is 林 itself, so its use here as borrowed stand-in for alias 婪 is a documented special case, not a cranberry). Pronunciation fields (tamlim/탐림/ㄊㄚㄇㄌㄧㄇ) already matched the straightforward concatenation — no bug. kwin true already correct (AND-rule). Confirmed real-language fields legitimately cite 婪's own readings (not 林's), matching the [[豊尭]] precedent. Fixed cantonese stray space, fixed a real spelling typo (avacious→avaricious). Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3369 — [[words/責任|責任]]
**Genuine `#cranberry`** (both 責's and 任's own stand-ins point here — full transitivity, tag added). Pronunciation fields (jagnim/작님/ㄐㄚㄎㄋㄧㄇ) already matched the straightforward concatenation — no bug. Fixed cantonese stray space, added missing simplified alias 责任. Fixed a missing "(stand-in for 責)" annotation on `characters/責.md`'s own Words list. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3370 — [[words/貯蔵|貯蔵]]
No cranberry (貯's own stand-in is this exact compound, 蔵's own stand-in is [[収蔵]]). Pronunciation fields (jocang/조창/ㄐㄛ·ㄑㄚㄫ) already matched the straightforward concatenation, including the separator dot — no bug. Added missing kwin (false, AND-rule). **Found and fixed a real bug**: `characters/蔵.md`'s own mandarin had zāng, matching neither of 藏's real readings — corrected to cáng (verb sense); the word's own mandarin inherited the same error, also fixed. Filled blank vietnamese (trữ tàng). Fixed cantonese stray space. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3371 — [[words/貴族|貴族]]
No cranberry (貴's own stand-in is [[貴重]], 族's own stand-in is [[家族]]). Pronunciation fields (guijog/귀족/ㄍㄨㄧㄐㄛㄎ) already matched the straightforward concatenation — no bug. kwin true already correct (AND-rule). Fixed cantonese stray space, added missing simplified alias. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3372 — [[words/貴重|貴重]]
No cranberry (貴's own stand-in is this exact compound, 重's own stand-in is [[重]] itself). Pronunciation fields (guicong/귀총/ㄍㄨㄧㄑㄛㄫ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). **Found and fixed a real bug**: cantonese had zung6, not matching 重's own stored cung5 — corrected to gwai3cung5. Filled blank vietnamese (quí trọng). Added missing simplified alias. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3373 — [[words/貸出|貸出]]
No cranberry (貸's own stand-in is this exact compound, 出's own stand-in is [[出]] itself). Pronunciation fields (taicud/태춛/ㄊㄚㄧㄑㄨㄊ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule). Japanese かしだし confirmed a real, common native reading, kept as-is. Filled blank pos (動詞) and vietnamese (thải xuất). Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3374 — [[words/費|費]]
Single-character stand-in word (費's own stand-in is 費 itself). Pronunciation fields (fai/빼/ㄈㄚㄧ) already matched the character's own stored reading — no bug. Added missing pos/japanese/kwin. **Found and fixed a real bug**: vietnamese held phía ("direction," unrelated) instead of phí ("expense," matching meaning and also the real common word) — corrected. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3375 — [[words/貼|貼]]
Single-character stand-in word (貼's own stand-in is 貼 itself). Pronunciation fields (teb/텁/ㄊㄝㄆ) already matched the character's own stored reading — no bug. Added missing pos/japanese/kwin. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3376 — [[words/資本|資本]]
No cranberry (資's own stand-in is this exact compound, 本's own stand-in is [[本]] itself). Pronunciation fields (jiǝbon/즤본/ㄐㄧㄜㄅㄛㄋ) already matched the straightforward concatenation — no bug. kwin false already correct (AND-rule); all other fields already correct and standard. Fixed cantonese stray space. Removed blank hsk_level/swadesh. homophone_check.py found no independent homophones.

### 2026-09-06, iteration 3377 — [[words/賞|賞]]
Single-character stand-in word (賞's own stand-in is 賞 itself). Pronunciation fields (syang/샹/ㄙ⼘ㄫ) already matched the character's own stored reading — no bug. Added missing pos/japanese/kwin. **Found and fixed a real bug**: vietnamese held the literal string "null" — corrected to thưởng. Confirmed existing [[尚]]/[[上]] homophone callouts complete. Fixed a missing "(stand-in for 賞 (char))" citation entirely absent from the character page's own Words list. homophone_check.py found no other homophones.

Next: 賢明.

**[Milestone: 3,200th logged iteration.]**

**[Milestone: 3,170th logged iteration.]**

### 2026-09-06, iteration 3378 — [[words/賢明|賢明]]
No cranberry (賢's own stand-in is this exact compound, 明's own stand-in is [[明]] itself). Pronunciation fields (henmyeng/헌명/ㄏㄝㄋㄇ⼶ㄫ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule: 賢 false, 明 true). Added missing cantonese (jin4ming4) and vietnamese (hiền minh). **Found and fixed a real bug**: japanese held a stray trailing quotation mark ("けんめい\"") — corrected to けんめい. Added simplified alias 贤明. homophone_check.py found no independent homophones.

Next: 質問.

### 2026-09-06, iteration 3379 — [[words/質問|質問]]
No cranberry (問's own stand-in is this exact compound, but 質's own is [[質素]]) — transitivity fails, though 問 is legitimized as an independent Dan'a'yo entry by this word. **Found and fixed two real bugs**: `羅馬字` had jitmun (t-final), mismatching 質's real d-final reading (jid) — `諺文`/`注音` had already stayed correct; `cantonese` held "zhíwèn," garbled Mandarin-pinyin-like text rather than a real Cantonese reading — corrected to zat1man6. Filled blank vietnamese (chất vấn, standard attested term). Removed blank hsk_level/swadesh/aliases, added simplified alias 质问. homophone_check.py found no independent homophones.

Next: 質素.

### 2026-09-06, iteration 3380 — [[words/質素|質素]]
No cranberry (質's own stand-in is this exact compound, but 素's own is [[要素]]) — transitivity fails, though 質 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (jidso/짇소/ㄐㄧㄊㄙㄛ) already matched the straightforward concatenation — no bug. Added missing `kwin: true` (AND-rule). **Found and fixed a real bug**: mandarin held a spurious comma-joined second reading "zhísù" (質 has no zhí reading) — corrected to the single real zhìsù. Fixed cantonese stray space. Japanese しっそ confirmed a real attested word, kept as-is. Filled blank korean (질소) and vietnamese (chất tố). Removed blank hsk_level/swadesh/aliases. homophone_check.py found no independent homophones.

Next: 賭博.

### 2026-09-06, iteration 3381 — [[words/賭博|賭博]]
No cranberry (賭's own stand-in is this exact compound, but 博's own is [[博大]]) — transitivity fails, though 賭 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (dobag/도박/ㄉㄛㄅㄚㄎ) already matched the straightforward concatenation — no bug; kwin true already correct (AND-rule). **Found and fixed a real bug**: pos was 性詞, mismatching the word's verbal sense and 賭's own 事詞 — corrected to 事詞. Fixed cantonese stray space. Filled blank vietnamese (đổ bác). Added simplified alias 赌博. homophone_check.py found no independent homophones.

Next: 購入.

### 2026-09-06, iteration 3382 — [[words/購入|購入]]
No cranberry (neither 購's own stand-in [[購買]] nor 入's own stand-in [[入]] points here). Pronunciation fields (gounib/곳닙/ㄍㄛㄨㄋㄧㄆ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule). **Found and fixed two real bugs**: cantonese had "kau3" (k-initial), mismatching 購's real g-initial reading (gau3); japanese had こうにふ, an unattested spelling — corrected to こうにゅう. Fixed cantonese stray space. Filled blank vietnamese (cấu nhập). Added simplified alias 购入. **In passing**, fully repaired `characters/入 (char).md`'s malformed Words/Chengyu structure: moved orphaned CC-lookup wikilinks into Notes prose, split the mislabeled "## Chengyu" section (which held ordinary compound words) into proper "## Words" (adding the missing 購入 citation and ruby-formatting two bare-link entries, 入籍/入口/入場) and "## Chengyu" (単刀直入 only). homophone_check.py found no independent homophones.

Next: 購買.

### 2026-09-06, iteration 3383 — [[words/購買|購買]]
Genuine `#cranberry` case (both 購's and 買's own stand-in point to this exact compound, already correctly annotated on both character pages). Pronunciation fields (goumai/곳매/ㄍㄛㄨㄇㄚㄧ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule). **Found and fixed a real bug**: cantonese had "kau3" (k-initial), mismatching 購's real g-initial reading (gau3) — same bug as [[購入]]. Fixed stray space. **In passing**, fixed a real bug on `characters/買.md`: its own vietnamese field held four unrelated syllables instead of the real Sino-Vietnamese reading "mãi" — corrected. Filled blank vietnamese (cấu mãi). Quoted previously-unquoted mandarin/korean. Added simplified alias 购买. homophone_check.py found no independent homophones.

Next: 贈与.

### 2026-09-06, iteration 3384 — [[words/贈与|贈与]]
No cranberry (贈's own stand-in is this exact compound, but 与's own is [[与]] itself) — transitivity fails, though 贈 is legitimized as an independent Dan'a'yo entry by this word. Pronunciation fields (jǝng'yo/증요/ㄐㄜㄫ·⼄) already matched the straightforward concatenation — no bug. Added missing `kwin: false` (AND-rule). Fixed a typo in english ("bestor"→bestow). Filled blank cantonese/korean. **In passing**, found and fixed a real bug on `characters/与 (char).md`: vietnamese held native glosses (và/với) instead of the real Sino-Vietnamese reading — corrected to dữ/dự, confirmed via the real compound this word forms (tặng dữ). Filled this word's blank vietnamese accordingly. Also added a missing citation of 贈与 and folded orphaned CC-lookup wikilinks into Notes prose on `与 (char).md`. homophone_check.py found no independent homophones.

Next: 赤道.

### 2026-09-06, iteration 3385 — [[words/赤道|赤道]]
No cranberry (both 赤's and 道's own stand-in point to themselves). Pronunciation fields (cegdau/척닷/ㄑㄝㄎㄉㄚㄨ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule). All other-language fields already correctly filled and standard. Fixed the `characters:` list citing bare "赤"/"道" (redlinks, actual pages are "赤 (char).md"/"道 (char).md"). Fixed cantonese stray space. Removed blank hsk_level/swadesh/aliases. **In passing**, fixed `characters/赤 (char).md`'s bare, gloss-less Words citation of 赤道 and folded orphaned CC-lookup wikilinks into Notes prose. homophone_check.py found no independent homophones.

Next: 赴.

### 2026-09-06, iteration 3386 — [[words/赴|赴]]
Single-character stand-in word (赴's own stand-in is 赴 itself). Pronunciation fields (fuo/뿟/ㄈㄨㄛ) already matched the character's own stored reading — no bug. Added missing pos/japanese. Fixed the unquoted, non-list `characters:` field. homophone_check.py found 富/訃 sharing this syllable at the character level only (neither independently legitimized) — no genuine collision.

Next: 起伏.

### 2026-09-06, iteration 3387 — [[words/起伏|起伏]]
No cranberry (both 起's and 伏's own stand-in point to themselves). Pronunciation fields (kibug/키북/ㄎㄧㄅㄨㄎ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule). **Found and fixed a real bug**: pos was 性詞, mismatching the word's verbal gloss and 起's own 事詞 — corrected to 事詞. Fixed cantonese stray space. Filled blank vietnamese (khởi phục). Fixed the `characters:` list citing bare "起"/"伏" redlinks. homophone_check.py found no independent homophones.

Next: 起床.

### 2026-09-06, iteration 3388 — [[words/起床|起床]]
No cranberry (both 起's and 床's own stand-in point to themselves). Pronunciation fields (kisyam/키샴/ㄎㄧㄙ⼘ㄇ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule). **Found and fixed a real bug**: pos was 性詞, mismatching the word's verbal gloss and 起's own 事詞 — corrected to 事詞. Fixed cantonese stray space, quoted bare hsk_level. Filled blank vietnamese (khởi sàng). Fixed the `characters:` list citing bare "起"/"床" redlinks. homophone_check.py found no independent homophones.

Next: 起死.

### 2026-09-06, iteration 3389 — [[words/起死|起死]]
No cranberry (起's own stand_in is 起 itself, 死's own is [[死亡]]) — neither constituent legitimized by this word. Pronunciation fields (kisiǝ/키싀/ㄎㄧㄙㄧㄜ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule). **Found and fixed a real bug**: pos was 性詞, mismatching the word's clearly verbal English gloss ("bring the dead back to life") and 起's own 事詞 — corrected to 事詞 (same bug shape as [[起伏]]/[[起床]]). Filled blank cantonese (hei2sei2, compositional) and vietnamese (khởi tử, attested in khởi tử hồi sinh = [[起死回生]]). Fixed the `characters:` list citing a bare "起" redlink. Removed blank hsk_level/swadesh/aliases. Built the `## Notes` section ahead of the existing `## Etymology`. Both character pages already cite the word with correct ruby/gloss; their [[起死回生]] citations resolve to the existing `chengyu/起死回生.md` — no in-passing fixes needed. Exact-match homophone check (scratchpad script absent from this vault; run as equivalent direct greps on 羅馬字/諺文/注音 across words/ and characters/) found no independent homophones. Stamped `date-last-perfect: 2026-09-06`.

Next: 釈珈文尼.

### 2026-09-06, iteration 3390 — [[words/釈珈文尼|釈珈文尼]]
No cranberry (釈's own stand_in is [[解釈]], 珈's is [[珈啡]], 文's is [[文化]], 尼's is [[尼僧]]) — no constituent legitimized by this word. **Found and fixed a real bug spanning all three pronunciation fields**: 羅馬字/諺文/注音 (segkamunni/석카문니/ㄙㄝㄎㄎㄚㄇㄨㄋㄋㄧ) had all dropped 尼's final schwa (niǝ/늬/ㄋㄧㄜ) — corrected to the exact concatenation segkamunniǝ/석카문늬/ㄙㄝㄎㄎㄚㄇㄨㄋㄋㄧㄜ (a consistent-truncation variant of the internal-reading bug class). kwin false already correct (AND-rule — 珈 and 尼 both false). Fixed cantonese's stray spacing (sik1gaa1mau4nei4). mandarin (Shìjiāmóuní)/japanese (しゃかむに)/korean (석가모니)/vietnamese (Thích-ca Mâu-ni) all confirmed as the attested Buddhist-name readings. Removed blank hsk_level/swadesh; aliases (釋迦牟尼/释迦牟尼/釈迦牟尼) confirmed real orthographic variants. Built the missing `## Notes` and `## Etymology` sections. **In passing**: fixed the same truncated zhuyin in the ruby citations on `characters/釈.md`, `characters/珈.md`, `characters/文.md`, and added the missing 釈珈文尼 citation to `characters/尼.md`'s Words list — re-stamped all four character pages. Exact-match homophone check (direct greps on the corrected 羅馬字/諺文/注音 across words/ and characters/) found no independent homophones. Stamped `date-last-perfect: 2026-09-06`.

Next: 金髪碧眼.

### 2026-09-06, iteration 3391 — [[words/金髪碧眼|金髪碧眼]]
No cranberry (金's own stand_in is 金 itself, 髪's is [[頭髪]], 碧's is [[碧色]], 眼's is [[眼球]]) — no constituent legitimized by this word. Pronunciation fields (gimfadbyeg'an/김빧벽안/ㄍㄧㄇㄈㄚㄊㄅ⼶ㄎ·ㄚㄋ, including the null-onset syllable break before 眼) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 髪 is false). pos 性詞 confirmed correct (descriptive idiom). **Found and fixed real bugs**: mandarin held two comma-joined readings in one string — split into a proper YAML list; cantonese had stray spaces — fixed to gam1faat3bik1ngaan5; the Etymology bullet's links were missing the `../` prefix. japanese きんぱつへきがん and korean 금발벽안 confirmed attested; vietnamese kim phát bích nhãn compositional. Built the missing `## Notes` section. **In passing**: fixed wrong 金髪碧眼 ruby zhuyin on `characters/髪.md` and `characters/眼.md` (ㄍㄧㄇㄅㄚㄊㄅㄝㄎ·ㄚㄋ — mis-derived initials, vs. 碧's already-correct one) and rebuilt `characters/金 (char).md`'s malformed old-batch `## Words` section — bare entries and `/words/`-path markdown links normalized to ruby format, "umquat" typo corrected to kumquat, orphaned CC-lookup wikilinks folded into a proper MC bullet in `## Notes` (244th most used, 聲 見 k + 韻 侵B ɣiɪm), prose surname note moved to Notes. Re-stamped all three touched character pages. Exact-match homophone check (direct greps across words/ and characters/) found no independent homophones. Stamped `date-last-perfect: 2026-09-06`.

Next: 針.

### 2026-09-06, iteration 3392 — [[words/針|針]]
Single-character stand-in word (針's own stand_in is 針 itself). Pronunciation fields (jim/짐/ㄐㄧㄇ) already matched the character's own stored reading — no bug. **Found and fixed real bugs**: `vietnamese` held the literal string "null" — filled with the real Sino-Vietnamese reading châm; `characters:` was an unquoted, non-list scalar — fixed to `["針 (char)"]`; missing `pos` (名詞, matching the character's own), `kwin` (false), and `japanese` (しん) all added; the empty single-hash `# Notes` heading rebuilt as a proper `## Notes` section. Exact-match homophone check found 斟/枕 sharing this syllable at the character level only (stand-ins [[斟酌]]/[[枕頭]]; neither independently legitimized as a standalone word) — no genuine collision, same shape as 赴's 富/訃. Stamped `date-last-perfect: 2026-09-06`.

Next: 釣漁.

### 2026-09-06, iteration 3393 — [[words/釣漁|釣漁]]
**Genuine `#cranberry` case**: both 釣's and 漁's own stand_in point to this exact compound (already correctly annotated on both character pages) — added the cranberry tag. Pronunciation fields (cou'yo/촛요/ㄑㄛㄨ·⼄, including the null-onset syllable break before 漁) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule). Quoted the bare mandarin string; fixed cantonese's stray space (diu3jyu4-2, keeping the attested changed-tone mark). japanese つる, korean 낚시하다, vietnamese câu cá all confirmed as genuine attested native terms (not bugs), per the 良月 precedent. Removed blank hsk_level/swadesh. Aliases 釣魚/漁釣 confirmed real variants. Built the missing `## Notes` and `## Etymology` sections. Both character pages already clean — no in-passing fixes needed. Exact-match homophone check (direct greps across words/ and characters/) found no independent homophones. Stamped `date-last-perfect: 2026-09-06`.

Next: 釣竿.

### 2026-09-06, iteration 3394 — [[words/釣竿|釣竿]]
No cranberry (釣's own stand_in is [[釣漁]], 竿's own is [[竿竹]]) — neither constituent legitimized by this word. Pronunciation fields (cougan/촛간/ㄑㄛㄨㄍㄚㄋ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 釣 false, 竿 true). Fixed cantonese's stray space (diu3gon1). japanese ちょうかん and korean 조간 confirmed attested readings. Filled blank vietnamese (cần câu, the attested modern term), added simplified alias 钓竿. Removed blank hsk_level/swadesh. Built the missing `## Notes` section. **In passing**, fixed three bugs on `characters/竿.md`: a duplicated `japanese_native` (scalar さお plus a stray `  - さお` list item — invalid YAML), a comma-joined `vietnamese` string (split into a proper list), and a missing 釣竿 citation in its Words list — re-stamped. Exact-match homophone check (direct greps across words/ and characters/) found no independent homophones. Stamped `date-last-perfect: 2026-09-06`.

Next: 釩金.

### 2026-09-06, iteration 3395 — [[words/釩金|釩金]]
No cranberry (釩's own stand_in is this exact compound, but 金's own is 金 itself) — transitivity fails, though 釩 is legitimized as an independent Dan'a'yo entry by this word (stand-in note added to the opening Notes bullet per feedback_standin_note). Pronunciation fields (vangim/반김/ㄪㄚㄋㄍㄧㄇ) deliberately deviate from the plain concatenation — the v/ㄪ-initial swap with 礬 is a documented intentional design choice on 釩's own page ("meant to resemble international vanadium"; the page's own Notes sanction the b-initial hangul approximation), so verified as intentional, not a drift bug; kwin false already correct (AND-rule — 釩 false). **Found and fixed real bugs**: japanese list item had a trailing non-breaking space (U+00A0); a redundant `品詞: 固有名詞` duplicated `pos` — removed. mandarin fán/cantonese faan4/korean 바나듐/japanese バナジウム/vietnamese vanađi all confirmed as the attested element names (single-syllable zh forms intentional — 金 is the Dan'a'yo disambiguator). Added the missing opening character-link bullet to `## Notes`. **In passing** on `characters/釩.md`: fixed the same scalar-plus-stray-list-item `japanese_native` YAML bug as 竿 (はら + はらう now a proper list), and folded orphaned CC-lookup wikilinks into a proper MC bullet (聲 敷 fʰ + 韻 凡 ɨɐm). **Notable discovery**: 釩's `date-last-perfect:` was present but BLANK — invisible to the char sweep's `grep -L "^date-last-perfect"` discovery, which is how it survived the completed character loop unperfected; 13 character pages total carry this blank-stamp pattern (憑 (char), 俟, 吠, 嗇, 址, 嬴, 狡, 疆, 紐, 舅, + 3 more). Removed the blank line on 釩 so the standard discovery finds it again; left the char page unstamped (char-checklist completion is the char sweep's call). Exact-match homophone check found no independent homophones. Stamped `date-last-perfect: 2026-09-06` on the word page.

Next: 鈴.

### 2026-09-06, iteration 3396 — [[words/鈴|鈴]]
Single-character stand-in word (鈴's own stand_in is 鈴 itself). Pronunciation fields (leng/렁/ㄌㄝㄫ) already matched the character's own stored reading — no bug. **Found and fixed real bugs** (same bug cluster as [[針]]): `vietnamese` held the literal string "null" — filled with the real Sino-Vietnamese reading linh; `characters:` was an unquoted, non-list scalar — fixed to `["鈴 (char)"]`; missing `pos` (名詞, matching the character's own), `kwin` (false), and `japanese` (れい/りん/りょう, from the character's own REI/RIN/RYOU) all added; the empty single-hash `# Notes` heading rebuilt as a proper `## Notes` section. **Homophone callout added**: leng/렁/ㄌㄝㄫ is shared with the independently-legitimized stand-in words [[令]] ("cause") and [[零]] ("zero") — both already carried callouts listing 鈴 (令's Notes even flagged 鈴 as "still awaiting its own turn"), so this completes the three-way cross-link; 令/零 needed no changes. Stamped `date-last-perfect: 2026-09-06`.

Next: 鉄板.

### 2026-09-06, iteration 3397 — [[words/鉄板|鉄板]]
No cranberry (鉄's own stand_in is 鉄 itself, 板's own is [[木板]]) — neither constituent legitimized by this word. Pronunciation fields (tedpan/터판/ㄊㄝㄊㄆㄚㄋ) already matched the straightforward concatenation — no bug. **Found and fixed**: `kwin` was missing entirely — added false (AND-rule: 鉄 false, 板 true); cantonese stray space fixed (tit3baan2); missing korean (철판, attested) and vietnamese (thiết bản, attested) filled. japanese てっぱん confirmed attested. Added 鉄's missing gloss to the Etymology bullet, built the missing `## Notes` section. Both character pages already cite the word with correct ruby — no in-passing fixes. Exact-match homophone check (direct greps across words/ and characters/) found no independent homophones. Stamped `date-last-perfect: 2026-09-06`.

Next: 鉄砧.

### 2026-09-06, iteration 3398 — [[words/鉄砧|鉄砧]]
No cranberry (鉄's own stand_in is 鉄 itself; 砧's own is this exact compound) — transitivity fails, though 砧 is legitimized as an independent Dan'a'yo entry by this word (stand-in note added to the Etymology bullet). Pronunciation fields (teddum/턷둠/ㄊㄝㄊㄉㄨㄇ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule). Fixed cantonese's stray space (tit3zam1). japanese かなとこ and korean 모루 confirmed as genuine attested native terms. Filled blank vietnamese (đe, the attested native term). Removed blank hsk_level/swadesh. Aliases 金床/鉄床/鐵砧/铁砧 confirmed real variants. Built the missing `## Notes` and `## Etymology` sections. Both character pages already cite the word with correct ruby (砧's annotated as its stand-in) — no in-passing fixes. Exact-match homophone check (direct greps across words/ and characters/) found no independent homophones. Stamped `date-last-perfect: 2026-09-06`.

Next: 鉄道.

### 2026-09-06, iteration 3399 — [[words/鉄道|鉄道]]
No cranberry (both 鉄's and 道's own stand_in point to themselves). Pronunciation fields (teddau/턷닷/ㄊㄝㄊㄉㄚㄨ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule). Fixed cantonese's stray space (tit3dou6). Filled blank vietnamese (thiết đạo, compositional). Removed blank swadesh and empty `aliases: []`. japanese てつどう/korean 철도 confirmed attested; hsk_level "4" already quoted. Built the missing `## Notes` and `## Etymology` sections. Both character pages already cite the word with correct ruby — no in-passing fixes. Exact-match homophone check (direct greps across words/ and characters/) found no independent homophones. Stamped `date-last-perfect: 2026-09-06`.

Next: 鉗.

### 2026-09-06, iteration 3400 — [[words/鉗|鉗]]
Single-character stand-in word (鉗's own stand_in is 鉗 itself). Pronunciation fields (gem/검/ㄍㄝㄇ) already matched the character's own stored reading — no bug; vietnamese kiềm already correct. **Found and fixed** (lighter variant of the 針/鈴 cluster): `characters:` unquoted non-list scalar → `["鉗 (char)"]`; missing `kwin` (false) and `japanese` (かん/けん, from the character's own KAN/KEN) added; empty single-hash `# Notes` heading rebuilt as a proper `## Notes` section. **Homophone callout added**: gem/검/ㄍㄝㄇ is shared with the independently-legitimized stand-in word [[兼]] ("double as"), which already carried its half of the callout explicitly awaiting 鉗's turn — pair completed; 兼 needed no changes. 倹/検/瞼 share the syllable at the character level only (stand-ins 倹素/検査/眼瞼) — no genuine collision. Stamped `date-last-perfect: 2026-09-06`.

Next: 鉛筆.

### 2026-09-06, iteration 3401 — [[words/鉛筆|鉛筆]]
No cranberry (both 鉛's and 筆's own stand_in point to themselves). 羅馬字 ('yenpud) and 諺文 (연푿) already matched the straightforward concatenation — but **found and fixed a real bug**: 注音 was ⼶ㄇㄅㄧㄊ, drifting from both constituents' own stored values (鉛 ⼶ㄋ + 筆 ㄆㄨㄊ = ⼶ㄋㄆㄨㄊ — n→m, p→b, u→i, the classic voicing/place-of-articulation confusion shape) — corrected; the same buggy zhuyin was baked into the ruby citations on both character pages, fixed in passing. **Also fixed**: cantonese held "yuan2 bi2" — not valid jyutping and contradicting 鉛's own jyun4 — corrected to the attested jyun4bat1. kwin false already correct (AND-rule — 筆 false). japanese えんぴつ/korean 연필/vietnamese bút chì all confirmed attested. Removed blank swadesh. Built the missing `## Notes` section. Exact-match homophone check found no independent homophones. Stamped `date-last-perfect: 2026-09-06` on all three files.

Next: 鉢.

### 2026-09-06, iteration 3402 — [[words/鉢|鉢]]
Single-character stand-in word (鉢's own stand_in is 鉢 itself). Pronunciation fields (bad/받/ㄅㄚㄊ) already matched the character's own stored reading — no bug; vietnamese bát already correct. **Found and fixed**: redundant `品詞: 名詞` duplicating `pos` — removed; `characters:` unquoted non-list scalar → `["鉢 (char)"]`; missing `kwin` added as **true** (the character's own kwin is true); missing `japanese` filled (はち/はつ, from the character's own HACHI/HATSU); previously-unquoted mandarin/cantonese/korean quoted. **Homophone callout added**: bad/받/ㄅㄚㄊ is genuinely shared with the independently-legitimized stand-in word [[八]] ("eight") — reciprocal callout added to 八's page. 叭/抜/跋 share the syllable at the character level only (stand-ins 喇叭/選抜/跋扈) — no genuine collision. **Noted but left for its own iteration**: words/八.md (stamped 2026-02-21, pre-checklist) has an empty `## Notes` section, its own redundant `品詞`, and a questionable japanese value (はちけ) — only the callout was added; its stamp was left alone. Stamped `date-last-perfect: 2026-09-06` on 鉢.

Next: 鉱物学.

### 2026-09-06, iteration 3403 — [[words/鉱物学|鉱物学]]
No cranberry (鉱's own stand_in is [[鉱石]], 物's is 物 itself, 学's is [[学習]]). Pronunciation fields (gwangmudhag/광묻학/ㄍ⺢ㄫㄇㄨㄊㄏㄚㄎ) already matched the straightforward concatenation — no bug; kwin **true** already correct (AND-rule — all three constituents true). **Found and fixed**: cantonese stray spaces → kwong3mat6hok6; japanese held historical kana orthography くわうぶつがく — modernized to こうぶつがく per the vault's modern-kana convention (cf. てつどう, not てつだう). korean 광물학/vietnamese khoáng vật học confirmed attested. Removed blank hsk_level/swadesh. Built the missing `## Notes` and `## Etymology` sections. All three character pages already cite the word with correct ruby — no in-passing fixes. Exact-match homophone check (direct greps across words/ and characters/) found no independent homophones. Stamped `date-last-perfect: 2026-09-06`.

Next: 鉱石.

### 2026-09-06, iteration 3404 — [[words/鉱石|鉱石]]
No cranberry (鉱's own stand_in is this exact compound, but 石's own is 石 itself) — transitivity fails, though 鉱 is legitimized as an independent Dan'a'yo entry by this word (stand-in note added to the Etymology bullet). Pronunciation fields (gwangseg/광석/ㄍ⺢ㄫㄙㄝㄎ) already matched the straightforward concatenation — no bug; kwin **true** already correct (AND-rule — both constituents true). cantonese kong3sek6 already correct (kong3, matching 鉱's own stored reading). japanese こうせき/korean 광석 confirmed attested; vietnamese quặng confirmed as the living Vietnamese word for ore. Removed blank hsk_level/swadesh. Built the missing `## Notes` and `## Etymology` sections. **Correction to iteration 3403**: 鉱物学's cantonese had been de-spaced to kwong3mat6hok6, but 鉱's own stored cantonese is kong3 — corrected to kong3mat6hok6 (caught via this word's own correct value). Both character pages already cite 鉱石 with correct ruby — no in-passing fixes. Exact-match homophone check found no independent homophones. Stamped `date-last-perfect: 2026-09-06`.

Next: 銀.

### 2026-09-06, iteration 3405 — [[words/銀|銀]]
Single-character stand-in word (銀's own stand_in is 銀 itself). Pronunciation fields ('in/인/ㄧㄋ) already matched the character's own stored reading — no bug; kwin false already correct. **Found and fixed real bugs**: `japanese` held the romaji string "gin" instead of kana — replaced with ぎん/ごん from the character's own GIN/GON; redundant `品詞: 固有名詞` duplicating `pos` — removed (pos 固有名詞 kept, matching the periodictable-word convention of [[銅]]/[[鉄]]); `characters:` unquoted non-list scalar → `["銀 (char)"]`; the `## Notes` section was present but empty — filled. vietnamese ngân confirmed correct. The homophone callout for [[引]] ("pull; tug") was already present and 引's page already carries the reciprocal — pair complete. Stamped `date-last-perfect: 2026-09-06`.

Next: 銀河系.

### 2026-09-06, iteration 3406 — [[words/銀河系|銀河系]]
No cranberry (銀's own stand_in is 銀 itself, 河's is [[小河]], 系's is [[系統]]). Pronunciation fields ('inhahei/인하헤/ㄧㄋㄏㄚㄏㄝㄧ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 銀 and 系 false). Fixed cantonese's stray spaces (ngan4ho4hai6). vietnamese "Ngân Hà" confirmed as the standard attested Vietnamese term for the Milky Way galaxy (not a missing-系 truncation). Removed blank hsk_level/swadesh and empty `aliases: []`. Built the missing `## Notes` and `## Etymology` sections. **In passing**: added the missing 銀河系 citation to `characters/系.md`'s Words list (銀/河 already cited it correctly) — re-stamped. Exact-match homophone check found no independent homophones. Stamped `date-last-perfect: 2026-09-06`.

Next: 銀行.

### 2026-09-06, iteration 3407 — [[words/銀行|銀行]]
No cranberry (both 銀's and 行's own stand_in point to themselves). Pronunciation fields ('inhang/인항/ㄧㄋㄏㄚㄫ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule). Fixed cantonese's stray space (ngan4hong4). japanese ぎんこう/korean 은행/vietnamese ngân hàng all confirmed attested. Removed blank hsk_level/swadesh and empty `aliases: []`. Built the missing `## Notes` section. Both character pages already cite the word with correct ruby — no in-passing fixes. Homophone check: [[進行]] (jinhang/진항) surfaced as a substring false positive only — no genuine homophones. Stamped `date-last-perfect: 2026-09-06`.

Next: 銃.

### 2026-09-06, iteration 3408 — [[words/銃|銃]]
Single-character stand-in word (銃's own stand_in is 銃 itself). Pronunciation fields (cung/충/ㄑㄨㄫ) already matched the character's own stored reading — no bug; vietnamese súng/korean 총 confirmed attested. **Found and fixed** (the 針/鈴/鉗 cluster): `characters:` unquoted non-list scalar → `["銃 (char)"]`; missing `kwin` (false) and `japanese` (じゅう/しゅう, from the character's own JUU/SHUU) added; empty single-hash `# Notes` heading rebuilt as a proper `## Notes` section. Exact-match homophone check found 充/噌/沖 sharing the syllable at the character level only (stand-ins 充填/噌噌/沖積; none independently legitimized) — no genuine collision. Stamped `date-last-perfect: 2026-09-06`.

Next: 銅鑼.

### 2026-09-06, iteration 3409 — [[words/銅鑼|銅鑼]]
No cranberry (銅's own stand_in is 銅 itself; 鑼's own is this exact compound) — transitivity fails, though 鑼 is legitimized by this word (stand-in note added to the Etymology bullet). Pronunciation fields (dongla/동라/ㄉㄛㄫㄌㄚ) already matched the straightforward concatenation — no bug. **Found and fixed**: `kwin` was missing — added **true** (AND-rule — both 銅 and 鑼 are true); cantonese stray space fixed (tung4lo4); previously-unquoted korean quoted. Filled blank vietnamese (đồng la, compositional — matching 鑼's own stored la). japanese どら confirmed attested native term. Built the missing `## Notes` and `## Etymology` sections. Both character pages already cite the word with correct ruby (鑼's annotated as its stand-in) — no in-passing fixes. Exact-match homophone check found no independent homophones. Stamped `date-last-perfect: 2026-09-06`.

Next: 銘文.

### 2026-09-06, iteration 3410 — [[words/銘文|銘文]]
No cranberry (銘's own stand_in is this exact compound, but 文's own is [[文化]]) — transitivity fails, though 銘 is legitimized by this word (stand-in note already present in the page's substantive Notes). Pronunciation fields (mengmun/멍문/ㄇㄝㄫㄇㄨㄋ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 銘 false). This page was already in good shape (proper opening bullet + substantive prose). Fixed: quoted the bare mandarin (míngwén) and korean (명문) strings; cantonese stray space → ming4man4; filled missing vietnamese (minh văn, compositional Sino-Vietnamese). **In passing**: 銘's own Words citation of 銘文 lacked the "(stand-in for 銘)" annotation (cf. 竿竹/銅鑼 convention) — added and re-stamped. Exact-match homophone check found no independent homophones. Stamped `date-last-perfect: 2026-09-06`.

Next: 銹.

### 2026-09-06, iteration 3411 — [[words/銹|銹]]
Single-character stand-in word (銹's own stand_in is 銹 itself). Pronunciation fields (syu/슈/ㄙ⼜) already matched the character's own stored reading — no bug; vietnamese tú already correct. **Found and fixed** (the 針/鈴/鉗/銃 cluster): `characters:` unquoted non-list scalar → `["銹 (char)"]`; missing `kwin` (false) and `japanese` (しゅう/しゅ, from the character's own SHUU/SHU) added; empty single-hash `# Notes` heading rebuilt as a proper `## Notes` section. The homophone callout for [[手]]/[[痩]] was already present and both pages already carry the reciprocal — the three-way cross-link (adjudicated in the 手/痩 iterations) is complete; remaining syu-syllable characters (受/守/寿/授/狩/獣/繍/首) are character-level only. Stamped `date-last-perfect: 2026-09-06`.

Next: 鋏.

### 2026-09-07, iteration 3412 — [[words/鋏|鋏]]
Single-character stand-in word (鋏's own stand_in is 鋏 itself). Pronunciation fields (geb/겁/ㄍㄝㄆ) already matched the character's own stored reading — no bug; vietnamese kiệp already correct. **Found and fixed** (the 針/鈴/鉗/銃 cluster): `characters:` unquoted non-list scalar → `["鋏 (char)"]`; missing `pos` (名詞), `kwin` (false), `japanese` (きょう, from the character's own KYOU) added; empty `# Notes` rebuilt as `## Notes`. **Homophone found via a cross-page bug**: 頬 ("cheek") had identical hangul/zhuyin but romaji "gep" — the vault's coda convention (十 sib, 鉢 bad) romanizes the ㅂ-coda as -b, so 頬's gep was the typo; corrected to geb on both words/頬.md and characters/頬 (char).md, making 鋏/頬 genuine homophones — reciprocal callouts added to both word pages. 頬's page is itself still unperfected (null vietnamese, scalar characters, empty Notes) — left for its own sweep iteration; only the romaji fix and callout were applied. **In passing**, fixed a real bug on `characters/鋏 (char).md`: `japanese_native` held つるぎ ("sword," copy-paste contamination from 剣, confirmed against 剣's own page) — corrected to はさみ. Re-stamped both touched character pages. Stamped `date-last-perfect: 2026-09-07`.

Next: 鋳造.

### 2026-09-07, iteration 3413 — [[words/鋳造|鋳造]]
No cranberry (鋳's own stand_in is this exact compound, but 造's own is [[創造]]) — transitivity fails, though 鋳 is legitimized by this word (stand-in note already present). 羅馬字 (jucau) and 諺文 (주찻) already matched the straightforward concatenation — but **found and fixed a real bug**: 注音 held "ㄐㄨ·ㄑㄚㄨ" with a spurious syllable-break mark — the · convention applies only before null-onset syllables (cf. 良月, 金髪碧眼), and 造 has a ㄑ onset — corrected to ㄐㄨㄑㄚㄨ (also unquoted). The same spurious-· zhuyin was baked into the ruby citations on both character pages — fixed in passing. **Also fixed**: missing `kwin` added (false — AND-rule, 造 false); bare mandarin (zhùzào) and korean (주조) quoted; cantonese stray space → zyu3zou6; filled missing vietnamese (chú tạo, compositional). japanese ちゅうぞう confirmed attested. The existing Notes (opening bullet + stand-in bullet) were already well-formed. Exact-match homophone check found no independent homophones. Stamped `date-last-perfect: 2026-09-07` on all three files.

Next: 鋼鉄.

### 2026-09-07, iteration 3414 — [[words/鋼鉄|鋼鉄]]
No cranberry (鋼's own stand_in is this exact compound, but 鉄's own is 鉄 itself) — transitivity fails, though 鋼 is legitimized by this word (stand-in note added to the Etymology bullet). Pronunciation fields (gangted/강턷/ㄍㄚㄫㄊㄝㄊ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 鉄 false). All cross-linguistic fields already correct (cantonese gong3tit3 already space-free; vietnamese thép confirmed as the living Vietnamese term; japanese こうてつ/korean 강철 attested). Built the missing `## Notes` and `## Etymology` sections — the page's only real gap. Both character pages already cite the word with correct ruby (鋼's annotated as its stand-in) — no in-passing fixes. Exact-match homophone check found no independent homophones. Stamped `date-last-perfect: 2026-09-07`.

Next: 錦繍.

### 2026-09-07, iteration 3415 — [[words/錦繍|錦繍]]
**Genuine `#cranberry` case** (tag already present): both 錦's and 繍's own stand_in point to this exact compound, and both character pages already carry the "(stand-in for …)" annotation — no in-passing fixes needed. Pronunciation fields (komsyu/콤슈/ㄎㄛㄇㄙ⼜) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — both false). Fixed: quoted the bare mandarin (jǐnxiù) and korean (금수) strings; cantonese stray space → gam2sau3; filled blank vietnamese (cẩm tú, compositional/attested); removed blank hsk_level/swadesh. japanese きんしゅう confirmed attested. Added the verification summary bullet to the existing Notes. Exact-match homophone check found no independent homophones. Stamped `date-last-perfect: 2026-09-07`.

Next: 錦鯉.

### 2026-09-07, iteration 3416 — [[words/錦鯉|錦鯉]]
No cranberry (錦's own stand_in is [[錦繍]]; 鯉's own is this exact compound) — transitivity fails, though 鯉 is legitimized by this word (stand-in note added to the Etymology bullet). Pronunciation fields (komli/콤리/ㄎㄛㄇㄌㄧ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 錦 false). Fixed cantonese's stray space (gam2lei5). **Found and fixed a real bug**: vietnamese held "cá chép" — plain "carp" (鯉's equivalent), not the ornamental brocade carp this word names — replaced with cá koi, the attested modern Vietnamese term (narrower-term bug shape). japanese にしきごい/korean 비단잉어 confirmed attested. Removed blank hsk_level/swadesh/aliases. Built the missing `## Notes` and `## Etymology` sections. **In passing**: added the missing 錦鯉 citation to `characters/錦.md`'s Words list (鯉's was already present and annotated) — re-stamped. Exact-match homophone check found no independent homophones. Stamped `date-last-perfect: 2026-09-07`.

Next: 錮.

### 2026-09-07, iteration 3417 — [[words/錮|錮]]
Single-character stand-in word (錮's own stand_in is 錮 itself) — a newer-batch page already in good shape (block-list characters, pos 事詞, kwin true correct, vietnamese cố correct, homophone callout present). Pronunciation fields (go/고/ㄍㄛ) already matched the character's own stored reading — no bug. **Fixed**: missing `japanese` filled (こ/く, from the character's own KO/KU); the Notes bullet's link was missing the `../` prefix ((characters/錮%20(char).md) → (../characters/錮%20(char).md)). Homophone group already fully adjudicated and cross-linked in 鼓's perfecting pass (鼓/股/錮 three-way; the other ㄍㄛ-reading characters — 孤/顧/故/固/姑/古 — confirmed character-level only). Stamped `date-last-perfect: 2026-09-07`.

Next: 錯誤.

### 2026-09-07, iteration 3418 — [[words/錯誤|錯誤]]
**Genuine `#cranberry` case**: both 錯's and 誤's own stand_in point to this exact compound (both character pages already annotated) — added the missing cranberry tag. 羅馬字 (cag'o) and 諺文 (착오) already matched the straightforward concatenation — but **found and fixed a real bug**: 注音 held ㄑㄚㄎㄛ, missing the null-onset syllable break before 誤's vowel-only ㄛ (the · convention, cf. 良月/金髪碧眼 — and ㄑㄚㄎㄛ is genuinely ambiguous, parseable as ㄑㄚ+ㄎㄛ) — corrected to ㄑㄚㄎ·ㄛ; the same unbroken form was baked into the 錯誤 and 時代錯誤 ruby citations on both character pages — all four fixed in passing. **Also fixed**: pos 性詞 → 事詞 (verbal gloss, same bug shape as 起伏/起床/起死); cantonese stray space → co3ng6; bare `hsk_level: 1` → quoted "1"; filled blank vietnamese (sai lầm, the attested living term); removed blank swadesh. japanese さくご/korean 착오 confirmed attested; kwin true already correct (both constituents true). Built the missing `## Notes` and `## Etymology` sections. Exact-match homophone check found no independent homophones. Stamped `date-last-perfect: 2026-09-07` on all three files.

Next: 録音.

### 2026-09-07, iteration 3419 — [[words/録音|録音]]
No cranberry (録's own stand_in is [[抄録]], 音's own is [[音楽]]). 羅馬字 (log'um) and 諺文 (록움) already matched the straightforward concatenation, including the null-onset apostrophe — but **found and fixed a real bug**: 注音 held ㄌㄛㄎㄨㄇ, missing the null-onset syllable break before 音's vowel-initial ㄨㄇ (genuinely ambiguous — parseable as ㄌㄛ+ㄎㄨㄇ) — corrected to ㄌㄛㄎ·ㄨㄇ, matching the 羅馬字 apostrophe; the same unbroken form was baked into the ruby citations on both character pages — fixed in passing. **Also fixed**: cantonese stray space → luk6jam1; bare `hsk_level: 1` → quoted "1"; filled blank vietnamese (ghi âm, the attested living term); removed blank swadesh. japanese ろくおん/korean 녹음 confirmed attested; kwin false already correct (AND-rule — 音 false). Built the missing `## Notes` section. Exact-match homophone check found no independent homophones. Stamped `date-last-perfect: 2026-09-07` on all three files.

Next: 鍋.

### 2026-09-07, iteration 3420 — [[words/鍋|鍋]]
Single-character stand-in word (鍋's own stand_in is 鍋 itself). Pronunciation fields (gwa/과/ㄍ⺢) already matched the character's own stored reading — no bug; vietnamese oa already correct. **Found and fixed** (the 針/鈴/鉗/銃/鋏 cluster): `characters:` unquoted non-list scalar → `["鍋 (char)"]`; missing `pos` (名詞), `kwin` (**true** — the character's own is true), `japanese` (か, from KA) added; empty `# Notes` rebuilt as `## Notes`. **Homophone callout added**: gwa/과/ㄍ⺢ is shared with the independently-legitimized stand-in word [[過]] ("than; too") — reciprocal callout added to 過's page (itself still unperfected — null vietnamese, scalar characters, empty Notes — left for its own iteration). Other ㄍ⺢-reading characters (寡/戈/果/渦/瓜/窩/蝸) are compound/名専字 stand-ins — no further collisions. **Sweep-integrity finding**: a large backlog of ~400 unperfected words sorts BEFORE the current pointer (everything from 䦧神星 up to 鍋) — part pre-existing (the archived logs jumped across regions), part from this session's own locale-collation comm bug at iterations 3389–3390 (fixed at 3391), which skipped the 起死…金髪碧眼 range including 過. The forward sweep will never reach these; they need a wrap-around pass or a dedicated backlog sweep — flagged for the user. Stamped `date-last-perfect: 2026-09-07`.

Next: 鍵.

### 2026-09-07, iteration 3421 — [[words/鍵|鍵]]
Single-character stand-in word (鍵's own stand_in is 鍵 itself). Pronunciation fields (gyen/견/ㄍ⼶ㄋ) already matched the character's own stored reading — no bug; vietnamese kiện already correct. **Found and fixed** (the 針/鈴/鉗/銃/鋏/鍋 cluster): `characters:` unquoted non-list scalar → `["鍵 (char)"]`; missing `pos` (名詞), `kwin` (false), `japanese` (けん, from the character's own KEN) added; empty `# Notes` rebuilt as `## Notes`. The homophone callout for [[見]]/[[乾]] was already present and both pages already carry the reciprocal (乾's Notes explicitly flagged 鍵 as "still awaiting its own turn") — three-way cross-link complete. 件/甄 share the syllable at the character level only — no further collision. Stamped `date-last-perfect: 2026-09-07`.

Next: 鍵盤.

### 2026-09-07, iteration 3422 — [[words/鍵盤|鍵盤]]
No cranberry (both 鍵's and 盤's own stand_in point to themselves). Pronunciation fields (gyenban/견반/ㄍ⼶ㄋㄅㄚㄋ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 鍵 false). **Found and fixed**: `characters:` cited bare "鍵"/"盤" redlinks (actual files are 鍵 (char).md/盤 (char).md) — fixed; cantonese stray space → gin6pun4; filled blank vietnamese (bàn phím, attested modern term); removed blank hsk_level/swadesh/aliases; an orphaned headingless prose line ("musical keyboard, computer keyboard") folded into the new `## Notes` section. Built the missing `## Etymology` section. Both character pages already cite the word with correct ruby — no in-passing fixes. Exact-match homophone check found no independent homophones. Stamped `date-last-perfect: 2026-09-07`.

Next: 鎌.

### 2026-09-07, iteration 3423 — [[words/鎌|鎌]]
Single-character stand-in word (鎌's own stand_in is 鎌 itself). Pronunciation fields (lem/럼/ㄌㄝㄇ) already matched the character's own stored reading — no bug; vietnamese liêm already correct; pos 名詞 already present. **Found and fixed** (the 針/鈴/鉗/銃/鋏/鍋/鍵 cluster): `characters:` unquoted non-list scalar → `["鎌 (char)"]`; missing `kwin` (false) and `japanese` (れん, from the character's own REN) added; empty `# Notes` rebuilt as `## Notes`. Exact-match homophone check found 簾 sharing the syllable at the character level only (stand-in 暖簾 — not independently legitimized) — no genuine collision. Stamped `date-last-perfect: 2026-09-07`.

Next: 鎖.

### 2026-09-07, iteration 3424 — [[words/鎖|鎖]]
Single-character stand-in word (鎖's own stand_in is 鎖 itself). Pronunciation fields (swa/솨/ㄙ⺢) already matched the character's own stored reading — no bug. **Found and fixed** (the 針/鈴/鉗/銃/鋏/鍋/鍵/鎌 cluster): `vietnamese` held the literal string "null" — filled with the real Sino-Vietnamese reading toả; `characters:` unquoted non-list scalar → `["鎖 (char)"]`; missing `pos` (名詞), `kwin` (false), `japanese` (さ, from the character's own SA) added; empty `# Notes` rebuilt as `## Notes`. Exact-match homophone check found 唆 sharing the syllable at the character level only (stand-in 教唆) — no genuine collision. Stamped `date-last-perfect: 2026-09-07`.

Next: 鎧球.

### 2026-09-07, iteration 3425 — [[words/鎧球|鎧球]]
No cranberry (鎧's own stand_in is this exact compound, but 球's own is 球 itself) — transitivity fails, though 鎧 is legitimized by this word (stand-in note added to the Etymology bullet). Pronunciation fields (kaigyu/캐규/ㄎㄚㄧㄍ⼜) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule). Fixed cantonese's stray spaces (mei5sik1zuk1kau4 — the reading of the alias 美式足球, the attested CJK term, since 鎧球 is a Dan'a'yo calque "armor ball"). Filled blank vietnamese (bóng bầu dục Mỹ, attested modern term). korean 미식축구 confirmed attested; japanese がいきゅう kept as the compositional on'yomi reading (Japanese otherwise uses アメフト). Removed blank hsk_level/swadesh. Folded the orphaned headingless line "橄欖球 = rugby" into Notes as a linked disambiguation bullet. Built the missing `## Notes` section. Both character pages already cite the word with correct ruby (鎧's annotated as its stand-in) — no in-passing fixes. Exact-match homophone check found no independent homophones. Stamped `date-last-perfect: 2026-09-07`.

Next: 鏡鑑.

### 2026-09-07, iteration 3426 — [[words/鏡鑑|鏡鑑]]
No cranberry (鏡's own stand_in is 鏡 itself; 鑑's own is this exact compound) — transitivity fails, though 鑑 is legitimized by this word (stand-in note added to the Etymology bullet). Pronunciation fields (gyenggam/경감/ㄍ⼶ㄫㄍㄚㄇ) already matched the straightforward concatenation — no bug; kwin **true** already correct (both constituents true). Filled blank cantonese (geng3gaam3, compositional) and vietnamese (gương, the attested living term). mandarin "jìngzi" confirmed as the reading of the alias 鏡子 (鏡鑑 is not a living Mandarin compound). Removed blank hsk_level/swadesh. Built the missing `## Notes` and `## Etymology` sections. Both character pages already cite the word with correct ruby (鑑's annotated as its stand-in) — no in-passing fixes. Exact-match homophone check found no independent homophones. Stamped `date-last-perfect: 2026-09-07`.

Next: 鑽石.

### 2026-09-07, iteration 3427 — [[words/鑽石|鑽石]]
No cranberry (鑽's own stand_in is this exact compound, but 石's own is 石 itself) — transitivity fails, though 鑽 is legitimized by this word (stand-in note added to the Etymology bullet). Pronunciation fields (janseg/잔석/ㄐㄚㄋㄙㄝㄎ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule). Fixed cantonese's stray space (zyun3sek6). Filled blank vietnamese (kim cương, the attested living term). japanese ダイヤモンド/korean 다이아몬드 confirmed as the attested loanword forms. Removed blank hsk_level/swadesh/aliases. Built the missing `## Notes` section, noting 鑽's own page's pointer to [[金剛石]] for the carbon-crystal mineral specifically. Both character pages already cite the word with correct ruby — no in-passing fixes. Exact-match homophone check found no independent homophones. Stamped `date-last-perfect: 2026-09-07`.

Next: 長期.

### 2026-09-07, iteration 3428 — [[words/長期|長期]]
No cranberry (both 長's and 期's own stand_in point to themselves). Pronunciation fields (jangki/장키/ㄐㄚㄫㄎㄧ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 期 false). **Found and fixed**: mandarin held two comma-joined readings in one string — split into a proper YAML list (chángqī/chángqí both attested); cantonese stray space → coeng4kei4; japanese held historical kana ちやうき — modernized to ちょうき (cf. こうぶつがく, iteration 3403); filled blank vietnamese (trường kỳ, attested). Removed blank hsk_level/swadesh and empty `aliases: []`. Built the missing `## Notes` section. **In passing**: rebuilt `characters/長 (char).md`'s malformed old-batch structure — `# Notes` heading level fixed to `##`, orphaned CC-lookup wikilinks folded into a proper MC bullet (95th most used, 聲 澄 ɖ + 韻 陽開 ɨɐŋ), missing `## Words` heading added, bare 長期/長上 entries given ruby — re-stamped. Exact-match homophone check found no independent homophones. Stamped `date-last-perfect: 2026-09-07`.

Next: 長短.

### 2026-09-07, iteration 3429 — [[words/長短|長短]]
No cranberry (both 長's and 短's own stand_in point to themselves). Pronunciation fields (jangdwan/장돤/ㄐㄚㄫㄉ⺢ㄋ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 短 false). Fixed: quoted the bare mandarin (chángduǎn) and korean (장단) strings; cantonese stray space → coeng4dyun2. The existing Notes (opening bullet + substantive prose) were already well-formed. **Genuine homophone found**: [[争端]] ("dispute, conflict") shares the exact reading on all three systems (争 homophonous with 長, 端 with 短) — reciprocal callouts added to both pages; 争端 is itself still unperfected (in the pre-pointer backlog) and awaits its own iteration. Both character pages already cite 長短 with correct ruby — no in-passing fixes. Stamped `date-last-perfect: 2026-09-07`.

Next: 門戸.

### 2026-09-07, iteration 3430 — [[words/門戸|門戸]]
No cranberry (戸's own stand_in is this exact compound, but 門's own is [[大門]]) — transitivity fails, though 戸 is legitimized by this word (stand-in note added to the Notes opening bullet). Pronunciation fields (monho/몬호/ㄇㄛㄋㄏㄛ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 門 false). Body was completely empty beyond the meta-bind-embed (no Notes section at all). Filled blank vietnamese (môn hộ, confirmed via web search as the attested literal "door" reading, now largely supplanted by native cửa nẻo); converted flow-style `aliases: [門戶, 门户]` to block list; removed blank hsk_level/swadesh. Built the missing `## Notes` section covering the figurative "faction"/"family status" extensions in Mandarin/Cantonese (門戶之見, 門當戶對) and the "access/opportunity" extension in Japanese/Korean (門戸開放/문호개방). Both character pages already cite 門戸 with correct ruby (戸's annotated as its stand-in) — no in-passing fixes. Exact-match homophone check (script hung on this environment's grep with these glyphs — backgrounded plain grep instead, same idiom) found no independent homophones. Stamped `date-last-perfect: 2026-09-07`.

Next: 開始.

### 2026-09-07, iteration 3431 — [[words/開始|開始]]
No cranberry (開's own stand_in is [[開放]], 始's own is [[始作]] — neither points here). Pronunciation fields (kaisi/캐시/ㄎㄚㄧㄙㄧ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 開 false). **Found and fixed a real bug**: `vietnamese` held khởi sự, an unrelated real native-feeling word ("to start an undertaking") that doesn't decompose from either constituent's own stored readings — corrected to the attested compositional Sino-Vietnamese khai thuỷ (confirmed via web search: hvdic.thivien.net entries for 開/始). Quoted `hsk_level` (bare `1`→`"1"`), removed blank swadesh/aliases, normalized `characters:` indentation, renamed `## Etymology`→`## Notes`. Wrote substantive Notes prose on the Chinese-everyday vs. Japanese/Korean-formal register split. Both character pages already cite 開始 with correct ruby (no stand-in annotation needed, since it isn't either's legitimizer) — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-07`.

Next: 開学.

### 2026-09-07, iteration 3432 — [[words/開学|開学]]
No cranberry (開's own stand_in is [[開放]], 学's own is [[学習]] — neither points here). Pronunciation fields (kaihag/캐학/ㄎㄚㄧㄏㄚㄎ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 開 false). Filled blank `japanese` (かいがく, confirmed attested — but Japanese has narrowed the sense specifically to "founding a university," per kotobank/weblio, unlike the broader everyday "start of term" sense in the other languages) and blank `vietnamese` (khai học, confirmed attested/interchangeable with khai giảng). Quoted `hsk_level`, converted flow-style `characters:`/`aliases:` to block lists. Wrote a full `## Notes` section documenting the Japanese semantic narrowing as the cross-linguistic highlight. Both character pages already cite 開学 with correct ruby (not either's stand-in, no annotation needed) — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-07`.

Next: 開張.

### 2026-09-07, iteration 3433 — [[words/開張|開張]]
No cranberry (開's own stand_in is [[開放]], 張's own is [[拡張]] — neither points here). Pronunciation fields (kaicang/캐창/ㄎㄚㄧㄑㄚㄫ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — both false). vietnamese (khai trương) already correct. **Filled blank `japanese`** (かいちょう) but found a genuine cross-linguistic divergence in the process: unlike Mandarin/Cantonese/Korean/Vietnamese's shared "grand opening of a business" sense, Japanese 開張 doesn't carry that meaning at all — real attested senses are "spread wide/wingspan" and a variant of 開帳 (unveiling a Buddhist icon; historically also opening an illegal gambling table); Japanese instead uses 開業/開幕 for "grand opening," which explains the page's pre-existing stray editorial note "prefer 開幕 or 開業" — folded that note into proper Notes prose rather than deleting it. Removed blank hsk_level/swadesh/empty `aliases: []`, reordered 羅馬字/諺文. **In passing**, fixed a non-standard Words-list citation (markdown link + absolute path + unquoted gloss) on `characters/張.md`'s own entry for this word. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-07`.

Next: 開拓.

### 2026-09-07, iteration 3434 — [[words/開拓|開拓]]
No cranberry (開's own stand_in is [[開放]], 拓's own is this exact compound — transitivity fails; stand-in note already present on 拓's own page, not this word's, so nothing to add here). Pronunciation fields (kaitag/캐탁/ㄎㄚㄧㄊㄚㄎ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 開 false). mandarin/korean were **already correctly using the *tuò/개척 reading-split documented on `characters/拓.md`** rather than a naive concatenation — verified against that page's existing Notes rather than mistakenly "fixing" them to match 拓's own stored 탁/tà-derived fields. Filled blank vietnamese (khai thác, confirmed attested — "open up," semantically extended in modern use to "exploit/extract"). Removed blank hsk_level/swadesh/empty aliases, renamed `## Etymology`→`## Notes`, wrote substantive Notes explaining the reading-split for future readers. Both character pages already cite 開拓 correctly (拓's with its stand-in annotation) — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-07`.

Next: 開放.

### 2026-09-07, iteration 3435 — [[words/開放|開放]]
開's own stand_in is this exact compound, but 放's own is [[釈放]] — transitivity fails, though 開 is legitimized by this word (stand-in note added to the Notes opening bullet). Pronunciation fields (kaibang/캐빵/ㄎㄚㄧㄈㄚㄫ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — both false). **Found and fixed a real bug**: `vietnamese` held đóng, which actually means "close/shut" — the literal *antonym* of this word's own meaning — corrected to the attested compositional khai phóng (confirmed via web search). Quoted `hsk_level`, removed blank swadesh/aliases, renamed `## Etymology`→`## Notes`. Wrote Notes covering the shared cross-CJK "open/liberalize" sense (改革開放) and Vietnamese khai phóng's distinctive modern intellectual/educational coloring. Both character pages already cite 開放 correctly (開's with its stand-in annotation) — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-07`.

Next: 開示.

### 2026-09-07, iteration 3436 — [[words/開示|開示]]
示's own stand_in is this exact compound, but 開's own is [[開放]] — transitivity fails, though 示 is legitimized by this word (stand-in note moved from a stray body line into the Notes opening bullet). Pronunciation fields (kaige/캐거/ㄎㄚㄧㄍㄝ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — both false). **Verified, not fixed**: korean 개시 exactly matches [[開始]]'s own Korean reading, but confirmed this is a genuine coincidental Korean-only homograph (示's real Sino-Korean reading is 시, giving 개+시), not a copy-paste bug — the two words' own 注音/羅馬字/諺文 differ entirely, so no Dan'a'yo homophone callout needed. Filled blank cantonese (hoi1 si6, compositional) and vietnamese (khai thị, confirmed attested — the Buddhist 開示悟入 "khai, thị, ngộ, nhập" formula from the Lotus Sutra). Removed blank hsk_level/swadesh/empty aliases, renamed `## Etymology`→`## Notes`. Both character pages already cite 開示 correctly (示's with its stand-in annotation) — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-07`.

Next: 閑暇.

### 2026-09-07, iteration 3437 — [[words/閑暇|閑暇]]
**Genuine `#cranberry`**: both 閑's and 暇's own stand_in point here (full transitivity), already correctly tagged on the word and both character pages. Pronunciation fields (hanha/한하/ㄏㄚㄋㄏㄚ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 暇 false). Filled blank vietnamese (nhàn hạ, the common everyday compositional term — using 閑's "nhàn" reading and 暇's "hạ" reading specifically, out of each character's several stored alternates). Quoted bare mandarin/korean strings, removed blank hsk_level/swadesh, renamed `## Etymology`→`## Notes`. **In passing**: added the missing `#cranberry` tag to `characters/閑.md`'s own Words-list citation of this word (暇's side already had it). Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-07`.

Next: 間或.

### 2026-09-07, iteration 3438 — [[words/間或|間或]]
No cranberry (間's own stand_in is [[之間]], 或's own is [[或]] itself). Pronunciation fields (ganhog/간혹/ㄍㄚㄋㄏㄛㄎ) already matched the straightforward concatenation — no bug; **added entirely missing `kwin: true`** (AND-rule — both constituents true). **New reading-split pattern found** (2nd instance after [[拓]]): 間 takes a distinct minority reading in the "interval/occasionally" sense (jiàn/gaan3/gián) versus its own stored default "between" reading (jiān/gaan1/gian) — confirmed via web search that mandarin jiànhuò and a corrected cantonese gaan3 waak6 (was blank; naive concatenation would have wrongly given gaan1) both reflect this split, matching 間諜/間中's real-world precedent. Filled blank vietnamese (gián hoặc, same reading-split, confirmed attested) and japanese (かんわく, compositional only — confirmed via web search that Japanese doesn't actually use this compound, uses 時折/時々 instead; documented in Notes). Split comma-joined korean (간혹,이따금 → 간혹, moved the native synonym 이따금 to prose). Fixed missing `(char)` suffix on 或 in `characters:`. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-07`.

Next: 間隔.

### 2026-09-07, iteration 3439 — [[words/間隔|間隔]]
No cranberry (隔's own stand_in is [[隔]] itself, 間's is [[之間]]). Pronunciation fields (gangag/간각/ㄍㄚㄋㄍㄚㄎ) already matched the straightforward concatenation — no bug; **added entirely missing `kwin: false`** (AND-rule — 隔 false). mandarin/cantonese were **already correctly using 間's minority "interval" reading** (jiàngé/gaan3gaak6, same split as [[間或]]) — verified rather than "fixed." **Found and fixed a real bug**: `vietnamese` held chia, an unrelated native verb ("to divide") — corrected to the attested compositional gián cách (confirmed via web search). Split comma-joined korean (간격, 사이, 틈 → 간격, moved the two native synonyms to prose). Wrote a full `## Notes` section (body had none), noting Japanese かんかく is the ordinary everyday word here — unlike [[間或]], where Japanese lacked a real cognate. Both character pages already cite 間隔 correctly — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-07`.

Next: 関係.

### 2026-09-07, iteration 3440 — [[words/関係|関係]]
係's own stand_in is this exact compound, but 関's own is [[関]] itself — transitivity fails, though 係 is legitimized by this word (stand-in note added to the Notes opening bullet). Pronunciation fields (gwamgei/괌게/ㄍ⺢ㄇㄍㄝㄧ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — both false). **Found and fixed a real bug**: `mandarin` held a comma-joined "guānxì, guānxī" — the second variant's tone (guānxī, 1st tone) doesn't exist for this word; confirmed via web search the correct/only reading is guānxì (4th tone, matching 係's own stored xì) — trimmed to the single correct value. Quoted `hsk_level`. Wrote a full `## Notes` section (body had none), noting the *guanxi* sociological concept as the cross-linguistic highlight. Both character pages already cite 関係 correctly (係's with its stand-in annotation) — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-07`.

Next: 関島.

### 2026-09-07, iteration 3441 — [[words/関島|関島]]
No cranberry (both 関's and 島's own stand_in point to themselves). Pronunciation fields (gwamtau/괌탓/ㄍ⺢ㄇㄊㄚㄨ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — both false). Filled blank cantonese (gwaan1 dou2, compositional, matches the Chinese "closed island" calque used as the standard place name). **Found and fixed a real typo**: `english` had "Gwam (island)" — Gwam is the Dan'a'yo romanisation, not the English name Guam — fixed here and on `characters/関 (char).md`'s own Words-list citation (island's own citation already said "Guam" correctly). Wrote a full `## Notes` section explaining why japanese/korean hold English transliterations (グアム/괌) rather than on'yomi/Sino-Korean readings, unlike Chinese's calque approach. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-07`.

Next: 関心.

### 2026-09-07, iteration 3442 — [[words/関心|関心]]
No cranberry (both 関's and 心's own stand_in point to themselves). Pronunciation fields (gwamsim/괌심/ㄍ⺢ㄇㄙㄧㄇ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 関 false). vietnamese (quan tâm) already correct/compositional. Quoted `hsk_level`. Wrote a full `## Notes` section (body had none), noting Japanese's real-world near-homophone confusion between 関心 and 感心 (both かんしん, distinct meanings) as an interesting aside. Both character pages already cite 関心 correctly — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-07`.

Next: 関数.

### 2026-09-08, iteration 3443 — [[words/関数|関数]]
No cranberry (関's own stand_in is [[関]] itself, 数's own is [[計数]]). Pronunciation fields (gwamsu/괌수/ㄍ⺢ㄇㄙㄨ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 関 false). **Genuine cross-CJKV orthographic split found**: Mandarin/Cantonese/Korean/Vietnamese all write "function" with an entirely different first character 函 ("box," a 19th-c. Chinese coinage) rather than 関 — hánshù/haam4sou3/함수/hàm số — while Japan alone standardized on 関数; mandarin/cantonese/korean fields were already correctly using the real 函-based readings (not a bug), filled the previously-blank vietnamese with hàm số to match. **Modernized `japanese`**: old-kana くわんすう → modern かんすう (same class of fix as 競走/長期's historical-kana normalization). Wrote a full `## Notes` section explaining the 関/函 split as the cross-linguistic highlight. Both character pages already cite 関数 correctly — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 閨房.

### 2026-09-08, iteration 3444 — [[words/閨房|閨房]]
閨's own stand_in is this exact compound, but 房's own is [[房]] itself — transitivity fails, though 閨 is legitimized by this word (stand-in note added to the Notes opening bullet). Pronunciation fields (guibang/귀방/ㄍㄨㄧㄅㄚㄫ) already matched the straightforward concatenation — no bug; **added entirely missing `kwin: false`** (AND-rule — 閨 false). Filled blank cantonese (gwai1 fong4, compositional) and japanese (けいぼう, confirmed attested via web search — a classical/archaic Japanese term, not everyday vocabulary). Fixed missing `(char)` suffix on 房 in `characters:`. Wrote a full `## Notes` section on the shared classical-register "women's private chamber" connotation across Mandarin/Korean/Vietnamese/Japanese. **In passing**, fixed a missing "(stand-in for 閨)" annotation on `characters/閨.md`'s own Words-list citation. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 閲読.

### 2026-09-08, iteration 3445 — [[words/閲読|閲読]]
読's own stand_in is this exact compound, but 閲's own is [[検閲]] — transitivity fails, though 読 is legitimized by this word (stand-in note added to the Notes opening bullet). Pronunciation fields ('yeddog/엳독/⼶ㄊㄉㄛㄎ) already matched the straightforward concatenation — no bug; kwin true already correct (AND-rule — both true). **Found and fixed two real bugs**: `japanese` held よむ, which is just 読's own bare kun'yomi verb (copy-paste contamination) — corrected to the attested compositional on'yomi えつどく (confirmed via web search — a real, narrower/more formal word meaning "to read while examining/investigating"); `vietnamese` held đọc, likewise just 読's own bare reading — corrected to the attested compositional duyệt đọc. mandarin/cantonese/korean were already correct. Wrote a full `## Notes` section covering the Japanese semantic narrowing (vs. 閲覧/校閲) as the cross-linguistic highlight. Both character pages already cite 閲読 correctly (読's with its stand-in annotation) — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 闊.

### 2026-09-08, iteration 3446 — [[words/闊|闊]]
Single-character stand-in word (闊's own stand_in is 闊 itself). **Found and fixed a real bug affecting both this word's and the character page's own frontmatter**: `諺文` was stored as two *different, both-wrong* values (word: 쾉 = ㅋ+ㅘ+ㅌ; character: 괃 = ㄱ+ㅘ+ㄷ) — decomposed both with a Hangul-jamo script and confirmed via Unicode composition that the correct rendering of 羅馬字 kwad / 注音 ㄎ⺢ㄊ is 콷 (ㅋ+ㅘ+ㄷ), independently cross-checked against two other characters sharing this exact syllable (`characters/闕.md`, `characters/蛞.md`, both already correctly stored as 콷) — fixed both pages to 콷. Rewrote the whole frontmatter into current template order (was scrambled/missing kwin, japanese, date-last-perfect). Added missing `kwin: false` and `japanese` (かつ, from the character's own KATSU on'yomi — confirmed real but comparatively rare standalone, mostly bound in 闊達/闊歩). Wrote a full `## Notes` section, noting the 闊/闕/蛞 syllable-sharing is coincidental rather than a genuine word-level homophone (闕 has no standalone word; 蛞's own word 蛞蝓 is two syllables). Stamped `date-last-perfect: 2026-09-08` on both.

Next: 闊葉.

### 2026-09-08, iteration 3447 — [[words/闊葉|闊葉]]
No cranberry (both 闊's and 葉's own stand_in point to themselves). Pronunciation fields' 羅馬字/注音 already matched the straightforward concatenation, but **found the same 諺文 bug just fixed on [[闊]]'s own pages, propagated here**: 괃욥 → corrected to 콷욥 (콷 for 闊's syllable, matching 闕/蛞's independently-verified-correct value). kwin false already correct (AND-rule — both false). Removed the space from `mandarin` (kuò yè → kuòyè, matching compound-word convention). Filled blank cantonese (fut3 jip6) and vietnamese (khoát diệp, confirmed attested via web search). Fixed missing `(char)` suffixes on both `characters:` entries, converted flow-style list to block. Wrote a full `## Notes` section, noting Japanese 闊葉樹 is now the superseded older term for 広葉樹 (built on a different character, 広). Both character pages already cite 闊葉 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 闖入.

### 2026-09-08, iteration 3448 — [[words/闖入|闖入]]
Stand-in word for [[闖]] (already documented in its own pre-existing Notes bullet, not a genuine `#cranberry` since 入's own stand_in is [[入]] itself). Pronunciation fields (tumnib/툼닙/ㄊㄨㄇㄋㄧㄆ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — both false). Quoted bare mandarin/cantonese/korean fields, added a space to cantonese (cong2jap6→cong2 jap6). **Filled entirely missing `vietnamese`** (sấm nhập, compositional from 闖's own sole listed reading "sấm" — a rare/literary compound, left as compositional best-effort since no independent attestation was found). Wrote substantive Notes prose noting Korean 틈입 is comparatively dated, with 침입 now the more common near-synonym. Both character pages already cite 闖入 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 闘争.

### 2026-09-08, iteration 3449 — [[words/闘争|闘争]]
闘's own stand_in is this exact compound, but 争's own is [[抗争]] — transitivity fails, though 闘 is legitimized by this word (stand-in note added to the Notes opening bullet). Pronunciation fields (doujang/돗장/ㄉㄛㄨㄐㄚㄫ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — both false). **Modernized `japanese`**: old-kana とうさう → modern とうそう (same class of fix as 開学/闘争's siblings 競走/長期). Filled blank vietnamese (đấu tranh, a well-known common term, e.g. đấu tranh giai cấp "class struggle" — no web search needed given how well-established). Converted flow-style aliases to block list. Wrote Notes noting the shared Marxist/political-struggle register across all five languages. Both character pages already cite 闘争 correctly (闘's with its stand-in annotation) — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 防御.

### 2026-09-08, iteration 3450 — [[words/防御|防御]]
御's own stand_in is this exact compound, but 防's own is [[防護]] — transitivity fails, though 御 is legitimized by this word (stand-in note added to the Notes opening bullet). Pronunciation fields (bang'yo/방요/ㄅㄚㄫ·⼄) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 御 false). **Found and fixed a real corruption bug**: `japanese` held "ぼう御ぎょ" — a stray kanji 御 embedded mid-string inside what should be pure kana — corrected to ぼうぎょ. Quoted `hsk_level`. Wrote a full `## Notes` section, noting 防禦/防護 as a Chinese near-synonym doublet and the 防御↔攻撃 antonym pairing shared across all four languages. Both character pages already cite 防御 correctly (御's with its stand-in annotation) — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 防疫.

### 2026-09-08, iteration 3451 — [[words/防疫|防疫]]
No cranberry (防's own stand_in is [[防護]], 疫's own is [[疫病]]). Pronunciation fields' 羅馬字/注音 already matched the straightforward concatenation, but **found and fixed a real 諺文 typo**: 방영 (final ㅇ) → corrected to 방역 (final ㄱ, matching 'yeg and the word's own already-correct `korean` field) — confirmed via Hangul-jamo decomposition. Quoted `hsk_level`, converted flow-style `characters:` to block list, removed empty `aliases: []`. Wrote a full `## Notes` section (body had none). Both character pages already cite 防疫 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 防護.

### 2026-09-08, iteration 3452 — [[words/防護|防護]]
防's own stand_in is this exact compound, but 護's own is [[守護]] — transitivity fails, though 防 is legitimized by this word (stand-in note added to the Notes opening bullet). Pronunciation fields (bangho/방호/ㄅㄚㄫㄏㄛ) already matched the straightforward concatenation — no bug; kwin true already correct (AND-rule — both true). Added a missing space to cantonese (fong4wu6→fong4 wu6). Filled entirely blank `vietnamese` (phòng hộ, confirmed attested via web search — "protective covering," also extends to labor-safety contexts). Wrote a full `## Notes` section (body had none). Both character pages already cite 防護 correctly (防's with its stand-in annotation) — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 阻止.

### 2026-09-08, iteration 3453 — [[words/阻止|阻止]]
阻's own stand_in is this exact compound, but 止's own is [[中止]] — transitivity fails, though 阻 is legitimized by this word (stand-in note added to the Notes opening bullet). Pronunciation fields (joji/조지/ㄐㄛㄐㄧ) already matched the straightforward concatenation — no bug; **added entirely missing `kwin: true`** (AND-rule — both true). **Genuine cross-character substitution found**: filled blank korean with the real attested word 저지 (jeoji), which uses a *different* character 沮 (jeo, "hinder") rather than 阻 (jo) itself — confirmed via web search — same class of divergence as [[関数]]'s 関/函 split. Filled blank vietnamese (trở chỉ, confirmed attested, genuinely compositional from 阻's own "trở" reading). Wrote a full `## Notes` section. Both character pages already cite 阻止 correctly (阻's with its stand-in annotation) — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 阿鼻.

### 2026-09-08, iteration 3454 — [[words/阿鼻|阿鼻]]
No cranberry (both 阿's and 鼻's own stand_in point to themselves). Pronunciation fields ('abi/아비/ㄚㄅㄧ) already matched the straightforward concatenation — no bug. **Found and fixed a real bug**: `kwin` was stored false despite both constituents being individually true — corrected to true. Trimmed `korean` from 아비지옥 to the bare 아비 (matching the other three languages' bare transliteration form; confirmed via web search that 아비 alone is independently attested, not just the fuller compound) — noted the trimmed fuller form and a real coincidental Korean-only homograph with native 아비 ("father") in prose instead. Filled blank vietnamese (A Tỳ, confirmed attested Buddhist transliteration). Folded the stray body line "fully 阿鼻地獄" into proper Notes prose. Removed empty `aliases: []`. Both character pages already cite 阿鼻 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 附近.

### 2026-09-08, iteration 3455 — [[words/附近|附近]]
No cranberry (both 附's and 近's own stand_in point to themselves). Pronunciation fields (bugin/부긴/ㄅㄨㄍㄧㄋ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 近 false). All real-language fields already correct, no bugs found. Quoted `hsk_level`, fixed missing `(char)` suffixes on both `characters:` entries, renamed `## Etymology`→`## Notes`, wrote substantive Notes prose. Both character pages already cite 附近 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 降臨.

### 2026-09-08, iteration 3456 — [[words/降臨|降臨]]
No cranberry (降's own stand_in is [[下降]], 臨's own is [[来臨]]). Pronunciation fields (ganglim/강림/ㄍㄚㄫㄌㄧㄇ) already matched the straightforward concatenation, correctly using 림 (North Korean/문화어 form, per [[feedback_korean_reading_north]]) — no bug; kwin true already correct (AND-rule — both true). All real-language fields already correct. Quoted `hsk_level`, added missing space to cantonese (gong3lam4→gong3 lam4), renamed `## Etymology`→`## Notes`, wrote substantive Notes on the religious-descent register and its modern hyperbolic extension. Both character pages already cite 降臨 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 限定.

### 2026-09-08, iteration 3457 — [[words/限定|限定]]
No cranberry (限's own stand_in is [[限度]], 定's own is [[決定]]). Pronunciation fields (hanjeng/한정/ㄏㄚㄋㄐㄝㄫ) already matched the straightforward concatenation, all real-language fields already correct — no bug; kwin true already correct (AND-rule — both true). Removed blank hsk_level/aliases, renamed `## Etymology`→`## Notes`, wrote substantive Notes noting the "limited edition" commercial usage. Both character pages already cite 限定 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 限定詞.

### 2026-09-08, iteration 3458 — [[words/限定詞|限定詞]]
No cranberry (none of the three constituents' own stand_in point here — 限→限度, 定→決定, 詞→単詞). Pronunciation fields (hanjengsa/한정사/ㄏㄚㄋㄐㄝㄫㄙㄚ) already matched the straightforward concatenation — no bug; kwin true already correct (AND-rule — all three true). **Found and fixed a real mistake**: `aliases` wrongly listed [[限定]] — a completely distinct, independently perfected headword ("to restrict"), not an orthographic variant of this compound — removed it, keeping only the genuine simplified-character alias 限定词; flagged the distinction explicitly in Notes to prevent recurrence. Filled blank cantonese (haan6 deng6 ci4) and vietnamese (từ hạn định, confirmed attested — noting the reversed word order vs. the Chinese-order calque, a native Vietnamese noun-then-modifier pattern). All three character pages already cite 限定詞 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 限度.

### 2026-09-08, iteration 3459 — [[words/限度|限度]]
限's own stand_in is this exact compound, but 度's own is [[程度]] — transitivity fails, though 限 is legitimized by this word (stand-in note added to the Notes opening bullet). Pronunciation fields (hando/한도/ㄏㄚㄋㄉㄛ) already matched the straightforward concatenation, all real-language fields already correct — no bug; kwin true already correct (AND-rule — both true). Renamed `## Etymology`→`## Notes`, wrote substantive Notes with concrete/abstract usage examples. Both character pages already cite 限度 correctly (限's with its stand-in annotation) — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 陛下.

### 2026-09-08, iteration 3460 — [[words/陛下|陛下]]
陛's own stand_in is this exact compound, but 下's own is [[下]] itself — transitivity fails, though 陛 is legitimized by this word (stand-in note added to the Notes opening bullet). Pronunciation fields (beiha/베하/ㄅㄝㄧㄏㄚ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 陛 false). **Verified, not fixed**: `korean` 폐하 correctly uses 陛's own real Sino-Korean reading 폐 (stored on `characters/陛.md`) rather than the Dan'a'yo-derived 베 seen in `諺文` — these are two intentionally distinct fields, not a mismatch. Added missing space to cantonese (bai6haa6→bai6 haa6). Wrote a full `## Notes` section on the honorific "below the steps" etymology and the related lower-ranking 殿下. **In passing**, fixed a missing "(stand-in for 陛)" annotation on `characters/陛.md`'s own Words-list citation. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 院落.

### 2026-09-08, iteration 3461 — [[words/院落|院落]]
Stand-in word for [[院]] (already documented in its own pre-existing Notes bullet; not a genuine `#cranberry` since 落's own stand_in is [[落下]]). Pronunciation fields ('wenlag/원락/⼔ㄋㄌㄚㄎ) already matched the straightforward concatenation — no bug; kwin true already correct (AND-rule — both true). Quoted bare mandarin/cantonese/korean fields. **Filled entirely missing `vietnamese`** (viện lạc, confirmed attested via web search, though comparatively rare — everyday Vietnamese favors sân/đình viện instead). Wrote substantive Notes prose noting the same rarity pattern in Japanese (いんらく, favoring 庭/中庭 instead). Both character pages already cite 院落 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 陣営.

### 2026-09-08, iteration 3462 — [[words/陣営|陣営]]
陣's own stand_in is this exact compound, but 営's own is [[経営]] — transitivity fails, though 陣 is legitimized by this word (stand-in note added to the Notes opening bullet). Pronunciation fields (cin'yeng/친영/ㄑㄧㄋ⼶ㄫ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 陣 false). Filled blank cantonese (zan6 jing4) and vietnamese (trận doanh, confirmed attested via web search — shares both the literal-camp and figurative-faction senses). Converted flow-style aliases to block list. Wrote Notes noting the shared literal/figurative dual sense across all five languages. Both character pages already cite 陣営 correctly (陣's with its stand-in annotation) — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 陣地.

### 2026-09-08, iteration 3463 — [[words/陣地|陣地]]
No cranberry (地's own stand_in matches, 陣's is [[陣営]]). Pronunciation fields (cindiǝ/친듸/ㄑㄧㄋㄉㄧㄜ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — both false). Added missing space to cantonese (zan6dei6→zan6 dei6). Filled blank vietnamese (trận địa, a well-known common term — no web search needed). Fixed missing `(char)` suffix on 地. Wrote a full `## Notes` section (body had none), noting the figurative "position held in a broader contest" extension shared across all five languages. Both character pages already cite 陣地 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 除外.

### 2026-09-08, iteration 3464 — [[words/除外|除外]]
除's own stand_in is this exact compound, but 外's own is [[外部]] — transitivity fails, though 除 is legitimized by this word (stand-in note added to the Notes opening bullet). Pronunciation fields (jei'wai/제왜/ㄐㄝㄧ⺢ㄧ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 外 false). Filled blank vietnamese (ngoại trừ, confirmed attested — **2nd instance of the Vietnamese word-order-reversal pattern**, after [[限定詞]]'s từ hạn định). Both character pages already cite 除外 correctly (除's with its stand-in annotation) — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 除湿.

### 2026-09-08, iteration 3465 — [[words/除湿|除湿]]
No cranberry (除's own stand_in is [[除外]], 湿's own is [[湿]] itself). Pronunciation fields' 羅馬字/諺文 were already fixed, but **closed out a bug pre-flagged by `characters/湿 (char).md`'s own Notes**: this word's `注音` still carried the old buggy ㄙㄜㄆ syllable for 湿 (already corrected to ㄙㄧㄆ on the character page itself) — fixed to ㄐㄝㄧㄙㄧㄆ. kwin false already correct (AND-rule — 湿 false). Filled blank vietnamese (trừ thấp, confirmed attested but less common than native hút ẩm/khử ẩm in casual speech). Fixed missing `(char)` suffix, converted flow-style characters to block, removed empty `aliases: []`. **In passing**, fixed the matching stale ruby annotation on `characters/除.md`'s own Words-list citation (ㄙㄜㄆ→ㄙㄧㄆ) — 湿's own citation had already been fixed. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 除籍.

### 2026-09-08, iteration 3466 — [[words/除籍|除籍]]
No cranberry (籍's own stand_in is [[書籍]], 除's is [[除外]]). Pronunciation fields (jeijeg/제적/ㄐㄝㄧㄐㄝㄎ) already matched the straightforward concatenation — no bug; kwin true already correct (AND-rule — both true). **Filled blank vietnamese with a caution flag**: the compositional trừ tịch is spelled identically to the well-known unrelated word trừ tịch (除夕, "New Year's Eve," a different character pair) — filled the field but documented the collision explicitly in Notes, noting modern Vietnamese prefers the native phrase xóa tên khỏi danh sách to avoid ambiguity. Fixed missing indentation/flow-style `characters:`, removed empty `aliases: []`. Both character pages already cite 除籍 correctly. Exact-match homophone check found none (Dan'a'yo-level; the Vietnamese collision is a real-language-only coincidence, not a Dan'a'yo homophone). Stamped `date-last-perfect: 2026-09-08`.

Next: 陥.

### 2026-09-08, iteration 3467 — [[words/陥|陥]]
Single-character stand-in word (陥's own stand_in is 陥 (char) itself). **Found and fixed the literal-`"null"`-string bug** (2nd known class this session) on both `vietnamese` and `korean`: corrected to hãm (confirmed attested via web search) and 함 (matching the character's own already-correct field) respectively. Rewrote the whole scrambled frontmatter into current template order — added missing `kwin: true` and `japanese` (かん, bound almost exclusively in compounds like 陥没/欠陥; the native verb 陥る carries the everyday standalone sense instead). Built the missing `## Notes` section (was just a bare heading). **Notable syllable cluster**: ham/함/ㄏㄚㄇ is shared by six other characters (艦/憾/含/喊/函/咸), but none stand alone as their own word, so no genuine word-level homophone exists — documented this explicitly rather than leaving it unchecked. Stamped `date-last-perfect: 2026-09-08`.

Next: 陰影.

### 2026-09-08, iteration 3468 — [[words/陰影|陰影]]
影's own stand_in is this exact compound, but 陰's own is [[陰]] itself — transitivity fails, though 影 is legitimized by this word (stand-in note added to the Notes opening bullet). Pronunciation fields ('im'yeng/임영/ㄧㄇ⼶ㄫ) already matched the straightforward concatenation — no bug; **added entirely missing `kwin: false`** (AND-rule — 陰 false). Split comma-joined korean (음영, 그늘, 그림자 → 음영, moved both native synonyms to prose, tracing them to each constituent's own native gloss). Filled blank vietnamese (âm ảnh — compositional best-effort; couldn't independently confirm it as a live everyday term, flagged as literary/rare in Notes since everyday Vietnamese favors native bóng). Converted flow-style characters/aliases to block lists. Both character pages already cite 陰影 correctly (影's with its stand-in annotation) — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 陰性.

### 2026-09-08, iteration 3469 — [[words/陰性|陰性]]
No cranberry (陰's own stand_in is [[陰]] itself, 性's is [[性別]]). Pronunciation fields ('imsing/임싱/ㄧㄇㄙㄧㄫ) already matched the straightforward concatenation, all real-language fields already correct — no bug; kwin false already correct (AND-rule — both false). Removed blank hsk_level/empty aliases. Wrote a full `## Notes` section (body had none), distinguishing the yin-yang/gender sense from the now much more common modern medical "negative test result" sense. **In passing**, fixed a non-standard markdown-link citation (should be a wikilink) on `characters/陰 (char).md`'s own Words-list entry for this word. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 陰核.

### 2026-09-08, iteration 3470 — [[words/陰核|陰核]]
No cranberry (both 陰's and 核's own stand_in point to themselves). Pronunciation fields ('imhag/임학/ㄧㄇㄏㄚㄎ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — both false). **Found and fixed a real typo**: `cantonese` had wat6 instead of 核's own correct hat6 (single-letter substitution). vietnamese âm vật was already correct — a genuine native-Vietnamese medical euphemism (vật, "object," not a reading of 核 itself), documented the divergence in Notes rather than mistaking it for a bug. Converted flow-style `characters:`/`aliases:` to block lists, removed blank hsk_level. Both character pages already cite 陰核 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 陰極.

### 2026-09-08, iteration 3471 — [[words/陰極|陰極]]
No cranberry (both 陰's and 極's own stand_in point to themselves). Pronunciation fields ('imgig/임긱/ㄧㄇㄍㄧㄎ) already matched the straightforward concatenation, all real-language fields already correct — no bug; kwin false already correct (AND-rule — both false). Converted flow-style characters/aliases to block lists, removed blank hsk_level. Wrote a full `## Notes` section (body had none). Both character pages already cite 陰極 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 陰茎.

### 2026-09-08, iteration 3472 — [[words/陰茎|陰茎]]
No cranberry (both 陰's and 茎's own stand_in point to themselves). Pronunciation fields ('imking/임킹/ㄧㄇㄎㄧㄫ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — both false). **Verified, not fixed**: cantonese jam1ging3 correctly uses a minority reading of 茎 distinct from its own stored default hang1 (confirmed via web search) — another instance of the sense-conditioned reading-split pattern. Filled blank vietnamese (âm hành, confirmed attested but rare) and flagged a genuinely striking cross-linguistic fact: everyday Vietnamese instead uses dương vật ("yang object"), built on the *opposite* polarity character from Mandarin/Japanese/Korean's shared 陰-based term. Converted flow-style characters/aliases to block lists. Both character pages already cite 陰茎 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 陰道.

### 2026-09-08, iteration 3473 — [[words/陰道|陰道]]
No cranberry (both 陰's and 道's own stand_in point to themselves). Pronunciation fields ('imdau/임닷/ㄧㄇㄉㄚㄨ) already matched the straightforward concatenation, all real-language fields already correct — no bug; kwin false already correct (AND-rule — both false). Converted flow-style characters/aliases to block lists, removed blank hsk_level. Wrote a full `## Notes` section (body had none). **In passing**, fixed a real gap: `characters/道 (char).md`'s own Words list was entirely missing a citation for this word (道's own side of the pair) — added it; 陰's own side already had it. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 陰陽.

### 2026-09-08, iteration 3474 — [[words/陰陽|陰陽]]
No cranberry (both 陰's and 陽's own stand_in point to themselves). Pronunciation fields ('im'yang/임양/ㄧㄇ⼘ㄫ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 陰 false). **Found and fixed a real bug**: `cantonese` held yin1 yang2 — Mandarin-pinyin-style romanization, not real Jyutping at all — corrected to jam1 joeng4 (matching 陽's own stored jyutping). Converted flow-style characters/aliases to block lists, removed blank hsk_level. Wrote a full `## Notes` section, noting Japanese's alternate おんみょう reading in the 陰陽道 (onmyōdō) esoteric-tradition context. Both character pages already cite 陰陽 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 陳列.

### 2026-09-08, iteration 3475 — [[words/陳列|陳列]]
陳's own stand_in is this exact compound, but 列's own is [[配列]] — transitivity fails, though 陳 is legitimized by this word (stand-in note added to the Notes opening bullet). Pronunciation fields (jinled/진럳/ㄐㄧㄋㄌㄝㄊ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 列 false). **Verified, not fixed**: korean 진열 correctly applies a real, mandatory Korean orthographic rule (렬/률→열/율 after a vowel or ㄴ-final syllable) rather than naively concatenating 列's own stored 렬 reading — confirmed this is standard Korean spelling (cf. 나열/분열), not a bug. vietnamese trần liệt confirmed attested via web search. Both character pages already cite 陳列 correctly (陳's with its stand-in annotation) — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 陵墓.

### 2026-09-08, iteration 3476 — [[words/陵墓|陵墓]]
陵's own stand_in is this exact compound, but 墓's own is [[墓穴]] — transitivity fails, though 陵 is legitimized by this word (stand-in note added to the Notes opening bullet). Pronunciation fields (lingmo/릉모/ㄌㄜㄫㄇㄛ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — both false). **Found and fixed a real bug**: `korean` held 무덤, 墓's own *native* Korean gloss (not even Sino-Korean) — corrected to 릉묘, the compositional North Korean/문화어 form per this vault's standing policy (South Korean 두음법칙 would instead give 능묘, confirmed via web search). **Also removed a wrongly-listed `aliases` pair**: 霊廟/靈廟 is a completely different word (a different second character, 廟 not 墓; different pronunciation in every language) — not an orthographic variant of 陵墓, the same class of mistake found earlier on [[限定詞]]. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 陶器.

### 2026-09-08, iteration 3477 — [[words/陶器|陶器]]
陶's own stand_in is this exact compound, but 器's own is [[容器]] — transitivity fails, though 陶 is legitimized by this word (stand-in note added to the Notes opening bullet). Pronunciation fields (daukiǝ/닷킈/ㄉㄚㄨㄎㄧㄜ) already matched the straightforward concatenation — no bug; **added entirely missing `kwin: false`** (AND-rule — both false). Split comma-joined korean (도기, 질그릇 → 도기, moved the native synonym — traced to 陶's own korean_native gloss — to prose). Filled blank vietnamese (đào khí, confirmed attested via web search; native đồ gốm is more common in casual speech). Removed empty `aliases: []`. Both character pages already cite 陶器 correctly (陶's with its stand-in annotation) — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 陶汰.

### 2026-09-08, iteration 3478 — [[words/陶汰|陶汰]]
汰's own stand_in is this exact compound, but 陶's own is [[陶器]] — transitivity fails, though 汰 is legitimized by this word (stand-in note added to the Notes opening bullet). Pronunciation fields (dautai/닷태/ㄉㄚㄨㄊㄚㄧ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 陶 false). **Modernized `japanese`**: old-kana たうた → modern とうた (same class of fix as 開学/闘争/競走/長期). mandarin/cantonese/korean/vietnamese were all already correct, all real attestations of the common word usually written 淘汰 (natural selection etc.). Wrote a full `## Notes` section. Both character pages already cite 陶汰 correctly (汰's with its stand-in annotation) — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 陶瓷.

### 2026-09-08, iteration 3479 — [[words/陶瓷|陶瓷]]
瓷's own stand_in is this exact compound, but 陶's own is [[陶器]] — transitivity fails, though 瓷 is legitimized by this word (stand-in note added). Pronunciation fields (dauci/닷치/ㄉㄚㄨㄑㄧ) already matched the straightforward concatenation — no bug; **added entirely missing `kwin: false`** (AND-rule — both false). The page already had excellent pre-existing Notes on the 磁/瓷 real-vs-Dan'a'yo spelling divergence — kept it, added the stand-in legitimization line and a short comparative paragraph on Vietnamese's less-common đào sứ vs. everyday gốm sứ. Added missing cantonese space, converted flow-style characters/aliases to block lists. **In passing**, fixed a missing "(stand-in for 瓷)" annotation on `characters/瓷.md`'s own Words-list citation. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 陶瓷器.

### 2026-09-08, iteration 3480 — [[words/陶瓷器|陶瓷器]]
No cranberry (none of 陶/瓷/器's own stand_in point here). Pronunciation fields (daucikiǝ/닷치킈/ㄉㄚㄨㄑㄧㄎㄧㄜ) already matched the straightforward concatenation — no bug; **added entirely missing `kwin: false`** (AND-rule — all three false). Split comma-joined korean (도자기, 질그릇 → 도자기, moved native synonym to prose). Filled blank cantonese (tou4 ci4 hei3) and vietnamese (đào sứ khí — rare compositional, everyday Vietnamese uses đồ gốm sứ instead). Kept the page's good pre-existing 磁/瓷 divergence note, added a short paragraph distinguishing this word (the finished ware) from [[陶瓷]] (the material/craft). All three character pages already cite 陶瓷器 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 陽傘.

### 2026-09-08, iteration 3481 — [[words/陽傘|陽傘]]
No cranberry (陽's own stand_in is [[陽]] itself, 傘's is [[雨傘]]). Pronunciation fields ('yangsan/양산/⼘ㄫㄙㄚㄋ) already matched the straightforward concatenation — no bug; **fixed a wrong `kwin`** (was false, should be true — AND-rule, both constituents true). **Found and fixed a real bug affecting four fields at once**: `mandarin`/`cantonese` held the reading for the related synonym 太陽傘 (3 syllables, extra 太), and `japanese`/`korean` held 日傘/일산 (using 日 "sun" instead of 陽 "yang" as the first character) — all four corrected to proper 陽傘-based compositional readings (confirmed via web search that Japanese ようさん is itself marginal/rare, real Japanese uses 日傘). Fixed vietnamese from the native ô dù to the classical Sino-Vietnamese dương tán. **Trimmed `aliases`** from a list of six near-synonyms with different characters (遮陽傘/太陽傘/日傘 family) down to the one genuine orthographic variant (阳伞, simplified) — the same over-broad-aliasing mistake found on [[限定詞]]/[[陵墓]], and very likely the actual source of this word's reading contamination. Both character pages already cite 陽傘 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 陽光.

### 2026-09-08, iteration 3482 — [[words/陽光|陽光]]
No cranberry (both 陽's and 光's own stand_in point to themselves). Pronunciation fields ('yangkwang/양쾅/⼘ㄫㄎ⺢ㄫ) already matched the straightforward concatenation, all real-language fields already correct — no bug; kwin false already correct (AND-rule — 光 false). Filled blank vietnamese (dương quang, confirmed attested via web search — shares Mandarin's literal-and-figurative "cheerful" range). Wrote a full `## Notes` section noting the shared figurative "sunny disposition" extension and each language's everyday-vs-literary register split. Both character pages already cite 陽光 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 陽性.

### 2026-09-08, iteration 3483 — [[words/陽性|陽性]]
No cranberry (陽's own stand_in is [[陽]] itself, 性's is [[性別]]). Pronunciation fields ('yangsing/양싱/⼘ㄫㄙㄧㄫ) already matched the straightforward concatenation, all real-language fields already correct — no bug; kwin false already correct (AND-rule — 性 false). **Fixed a malformed homophone callout**: genuine Dan'a'yo homophone with [[養成]] (both 양싱/⼘ㄫㄙㄧㄫ) was already correctly identified but written as `>[!warn] Homophones: [[養成]] cultivate` before the meta-bind-embed instead of the proper `>[!warning] Homophones` block after it — fixed on both sides (養成's own side was just a bare text line, not a callout at all). Wrote a full `## Notes` section distinguishing the yin-yang/gender sense from the modern medical "positive result" sense. Both character pages already cite 陽性 correctly. Stamped `date-last-perfect: 2026-09-08`.

Next: 陽極.

### 2026-09-08, iteration 3484 — [[words/陽極|陽極]]
No cranberry (both 陽's and 極's own stand_in point to themselves). Pronunciation fields ('yanggig/양긱/⼘ㄫㄍㄧㄎ) already matched the straightforward concatenation, all real-language fields already correct — no bug; kwin false already correct (AND-rule — 極 false). Filled blank vietnamese (dương cực, the exact parallel of [[陰極]]'s already-confirmed âm cực). Converted flow-style characters/aliases to block lists, removed blank hsk_level. Wrote a full `## Notes` section. Both character pages already cite 陽極 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 陽炎.

### 2026-09-08, iteration 3485 — [[words/陽炎|陽炎]]
No cranberry (陽's own stand_in is [[陽]] itself, 炎's is [[炎症]]). Pronunciation fields ('yang'em/양엄/⼘ㄫㄝㄇ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 炎 false). Fixed a typo (english "sunligh"→"sunlight"). Filled blank vietnamese (dương viêm, confirmed attested in a Buddhist-dictionary context via web search). Confirmed korean 양염 is a real Sino-Korean term (native 아지랑이 is more common). Wrote a full `## Notes` section covering Japanese's three attested readings (archaic かぎろい, everyday かげろう, compositional ようえん) and the Buddhist "mirage as illusion" metaphor. Both character pages already cite 陽炎 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 隅.

### 2026-09-08, iteration 3486 — [[words/隅|隅]]
Single-character stand-in word. **Completed a homophone callout already anticipated by [[又]]'s own page** (both 'uo/웃/ㄨㄛ) — added the reciprocal `>[!warning] Homophones` block here. Pronunciation fields already matched the character's own stored reading — no bug. Rewrote the whole scrambled frontmatter into current template order (bare unquoted `characters:` string → proper list); added missing `japanese` (ぐう, on'yomi — everyday Japanese uses native すみ instead). Built the missing `## Notes` section, noting this word survives mainly bound in compounds (四隅) rather than as a fully free-standing word in most of these languages. Stamped `date-last-perfect: 2026-09-08`.

Next: 隊.

### 2026-09-08, iteration 3487 — [[words/隊|隊]]
Single-character stand-in word. **Fixed the literal-`"null"`-string bug** on `vietnamese`: corrected to đội (a fully everyday, free-standing Vietnamese word — "team," e.g. đội bóng đá). Rewrote the whole scrambled frontmatter into template order; added missing `kwin: false` and `japanese` (たい, as in 兵隊/一隊). Built the missing `## Notes` section. **Notable syllable cluster**: doi/되/ㄉㄛㄧ is shared by four other characters (殆/対/隹/堆), but none stand alone as their own word, so no genuine word-level homophone exists — checked and documented explicitly. Stamped `date-last-perfect: 2026-09-08`.

Next: 隊伍.

### 2026-09-08, iteration 3488 — [[words/隊伍|隊伍]]
No cranberry (both 隊's and 伍's own stand_in point to themselves). Pronunciation fields (doi'o/되오/ㄉㄛㄧㄛ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 隊 false). Filled blank vietnamese (đội ngũ, an extremely common everyday Vietnamese term extending well beyond the literal military sense). Fixed missing `(char)` suffix, added missing cantonese space. **In passing**, fixed a real gap: `characters/伍 (char).md`'s own Words list was entirely missing a citation for this word — added it. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 階段.

### 2026-09-08, iteration 3489 — [[words/階段|階段]]
階's own stand_in is this exact compound, but 段's own is [[段]] itself — transitivity fails, though 階 is legitimized by this word (stand-in note added). Pronunciation fields (gyedwan/계돤/ㄍ⼶ㄧㄉ⺢ㄋ) already matched the straightforward concatenation, all real-language fields already correct — no bug; kwin false already correct (AND-rule — 段 false). Wrote a full `## Notes` section on a genuine semantic split: Japanese/Korean keep the literal "staircase" sense, while Mandarin/Vietnamese have generalized to the abstract "stage, phase" sense (Mandarin's everyday word for physical stairs is instead 樓梯). Both character pages already cite 階段 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 随性.

### 2026-09-08, iteration 3490 — [[words/随性|随性]]
No cranberry (随's own stand_in is [[随行]], 性's is [[性別]]). Pronunciation fields (suising/쉬싱/ㄙㄨㄧㄙㄧㄫ) already matched the straightforward concatenation — no bug; **added entirely missing `kwin: false`** (AND-rule — both false). **Modernized `japanese`**: old-kana ずいしやう → ずいしょう. Filled blank cantonese (ceoi4 sing3), korean (수성 — flagged as a coincidental homograph with the unrelated common word 水星 "Mercury"), and vietnamese (tuỳ tính, confirmed attested via web search). Both character pages already cite 随性 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 随意.

### 2026-09-08, iteration 3491 — [[words/随意|随意]]
No cranberry (随's own stand_in is [[随行]], 意's is [[意味]]). Pronunciation fields (sui'ǝ/쉬으/ㄙㄨㄧ·ㄜ) already matched the straightforward concatenation — no bug; **added entirely missing `kwin: false`** (AND-rule — both false). Filled blank vietnamese (tuỳ ý — an extremely common, everyday Vietnamese phrase, "as you like"). Wrote a full `## Notes` section. Both character pages already cite 随意 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 随行.

### 2026-09-08, iteration 3492 — [[words/随行|随行]]
随's own stand_in is this exact compound, but 行's own is [[行]] itself — transitivity fails, though 随 is legitimized by this word (stand-in note added). Pronunciation fields (suihang/쉬항/ㄙㄨㄧㄏㄚㄫ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — both false). Filled blank vietnamese (tuỳ hành, confirmed attested via web search). Removed empty `aliases: []`. Both character pages already cite 随行 correctly (随's with its stand-in annotation) — no in-passing fixes. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 隔世紀.

### 2026-09-08, iteration 3493 — [[words/隔世紀|隔世紀]]
No cranberry (none of 隔/世/紀's own stand_in point here). Pronunciation fields (gagsegi/각서기/ㄍㄚㄎㄙㄝㄍㄧ) already matched the straightforward concatenation, all real-language fields already correct — no bug; kwin false already correct (AND-rule — 隔/世 false). Filled blank vietnamese (cách thế kỷ, confirmed attested via web search). Applied the checklist's nested-compound rule (this word's own example case): opening bullet now also links [世紀](世紀.md) as the meaningful sub-compound formed by 世+紀. Wrote a full `## Notes` section noting the 隔-prefix pattern shared with 隔年/隔月/隔日. All three character pages already cite 隔世紀 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 隔年.

### 2026-09-08, iteration 3494 — [[words/隔年|隔年]]
No cranberry (both 隔's and 年's own stand_in point to themselves). Pronunciation fields (gagnen/각넌/ㄍㄚㄎㄋㄝㄋ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — both false). Filled blank vietnamese (cách năm, plausible common phrase per web search — native "cách" + native "năm," the everyday word for year rather than the Sino "niên"). Wrote a full `## Notes` section noting the shared 隔-prefix pattern (隔世紀/隔月/隔日). Both character pages already cite 隔年 correctly. Exact-match homophone check: all three fields (羅馬字/諺文/注音) confirmed self-only match — the 注音 grep initially hung (known glyph issue) but the delayed background result later confirmed no collision. Stamped `date-last-perfect: 2026-09-08`.

Next: 隔日.

### 2026-09-08, iteration 3495 — [[words/隔日|隔日]]
No cranberry (both 隔's and 日's own stand_in point to themselves). Pronunciation fields (gagnid/각닏/ㄍㄚㄎㄋㄧㄊ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — both false). Filled blank vietnamese (cách nhật, a standard traditional-medicine term — "sốt cách nhật," intermittent fever). Removed redundant `品詞` duplicate of `pos`, converted japanese from a single-item list to a plain string. Wrote a full `## Notes` section. Both character pages already cite 隔日 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 隔月.

### 2026-09-08, iteration 3496 — [[words/隔月|隔月]]
No cranberry (both 隔's and 月's own stand_in point to themselves). Pronunciation fields (gag'wed/각웓/ㄍㄚㄎ⼔ㄊ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — both false). Filled blank vietnamese (cách nguyệt, confirmed attested via web search). Wrote a full `## Notes` section, closing out the four-member 隔- "every other" set (隔世紀/隔年/隔日/隔月). Both character pages already cite 隔月 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 隔週.

### 2026-09-08, iteration 3497 — [[words/隔週|隔週]]
No cranberry (隔's own stand_in is [[隔]] itself, 週's is [[週日]]). Pronunciation fields (gagjuo/각줏/ㄍㄚㄎㄐㄨㄛ) already matched the straightforward concatenation, all real-language fields already correct — no bug; kwin false already correct (AND-rule — both false). Filled blank vietnamese (cách chu — compositional but rare; everyday Vietnamese uses the native periphrastic cứ hai tuần một lần instead, since 週's own SV readings never became the everyday word for "week" the way native tuần did). Wrote a full `## Notes` section. Both character pages already cite 隔週 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 隙.

### 2026-09-08, iteration 3498 — [[words/隙|隙]]
Single-character stand-in word. **Fixed the literal-`"null"`-string bug** on `vietnamese`: corrected to khích (matching the character's own stored reading). **Completed a homophone callout already anticipated by [[喫]]'s own page** (both keg/컥/ㄎㄝㄎ) — added the reciprocal `>[!warning] Homophones` block here. Rewrote the whole scrambled frontmatter into current template order; added missing `kwin: false` and `japanese` (げき, on'yomi; native すき also documented in Notes). Built the missing `## Notes` section. Stamped `date-last-perfect: 2026-09-08`.

Next: 障碍.

### 2026-09-08, iteration 3499 — [[words/障碍|障碍]]
障's own stand_in is this exact compound, but 碍's own is [[妨碍]] — transitivity fails, though 障 is legitimized by this word (stand-in note added). Pronunciation fields (jang'ai/장애/ㄐㄚㄫㄚㄧ) already matched the straightforward concatenation — no bug; kwin true already correct (AND-rule — both true). **Verified, not fixed**: japanese しょうげ is a real, historically-doubled reading (Go-on しょうげ, originally a Buddhist term, vs. Kan-on しょうがい, which migrated to the now-standard spelling 障害 postwar) — confirmed via web search rather than assumed a bug. Filled blank vietnamese (chướng ngại, an extremely common everyday term). Converted flow-style aliases to block list. **In passing**, fixed a malformed citation on `characters/碍.md`'s own Words list (bare `[[障碍]]` with no ruby/gloss). Also verified 碍's own `#cranberry` tag is legitimately about its transitivity with [[妨碍]] (not this word) — no error there. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 隠形.

### 2026-09-08, iteration 3500 — [[words/隠形|隠形]]
No cranberry (隠's own stand_in is [[隠蔵]], 形's is [[形]] itself). **Found and fixed a real bug**: `羅馬字`/`諺文` had drifted to 'inheng/인헝, inconsistent with 隠's own correctly-stored 'ǝn/은 (注音 ㄜㄋ was already correct) — corrected to 'ǝnheng/은헝, the same "wrong 羅馬字/諺文, correct 注音" bug class documented repeatedly earlier in this sweep. **Added entirely missing `kwin: false`** (AND-rule — 形 false) and `korean` (은형). **Modernized `japanese`**: old-kana おんぎやう → おんぎょう (confirmed via web search as a real term, historically tied to ninjutsu/esoteric concealment technique). Filled blank vietnamese (tàng hình — the real modern term, confirmed via web search, substituting a different character morpheme for 隠's own literal "ẩn," parallel to the modern "stealth aircraft" sense). Both character pages already cite 隠形 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 隠蔵.

### 2026-09-08, iteration 3501 — [[words/隠蔵|隠蔵]]
隠's own stand_in is this exact compound, but 蔵's own is [[収蔵]] — transitivity fails, though 隠 is legitimized by this word (stand-in note added). **Found and fixed the same recurring bug as [[隠形]] one iteration ago**: `羅馬字`/`諺文` had drifted to 'incang/인창, inconsistent with 隠's own correctly-stored 'ǝn/은 (注音 ㄜㄋ already correct) — corrected to 'ǝncang/은창. **Added entirely missing `kwin: false`, `japanese`** (いんぞう, confirmed real via web search — distinct from the related 秘蔵 hizō), **`korean`** (은장), **and `vietnamese`** (ẩn tàng, confirmed real). **In passing**, fixed a typo on `characters/隠.md`'s own vietnamese field (ẩng→ẩn) discovered while sourcing this word's reading. Removed a stray body line ("a very C word"). Converted flow-style characters/aliases to block lists. Both character pages already cite 隠蔵 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 隠蔽.

### 2026-09-08, iteration 3502 — [[words/隠蔽|隠蔽]]
蔽's own stand_in is this exact compound, but 隠's own is [[隠蔵]] — transitivity fails, though 蔽 is legitimized by this word (stand-in note added). **Found and fixed the same recurring bug, 3rd instance now** (after [[隠形]], [[隠蔵]]): `羅馬字`/`諺文` had drifted to 'inpe/인퍼, inconsistent with 隠's own correctly-stored 'ǝn/은 (注音 ㄜㄋ already correct) — corrected to 'ǝnpe/은퍼. Removed empty-string `vietnamese: ""` and redundant `品詞`. Filled vietnamese (ẩn tế — rare/compositional; everyday Vietnamese uses native che giấu/che đậy instead). japanese/korean/mandarin/cantonese were already correct. Both character pages already cite 隠蔽 correctly (蔽's with its stand-in annotation). Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 隠金.

### 2026-09-08, iteration 3503 — [[words/隠金|隠金]]
Periodic-table neologism (lanthanum); pronunciation fields already correct (confirmed clean during the proactive 隠-prefix check two iterations ago), no cranberry (金's own stand_in is [[金]] itself, 隠's is [[隠蔵]]). Real-element-reading fields (mandarin/cantonese/korean/japanese/vietnamese all phonetic loanwords for the international name) legitimately non-compositional per established convention — page already carried an unusually thorough etymology essay, kept as-is. Removed redundant `品詞` duplicate of `pos`. **In passing**, fixed a real gap: `characters/金 (char).md`'s own Words list was entirely missing a citation for this word — added it with the periodic-table-neologism annotation matching its sibling [[蛍金]]. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 隣人.

### 2026-09-08, iteration 3504 — [[words/隣人|隣人]]
No cranberry (隣's own stand_in is [[隣]] itself, 人's is [[人]] itself). Pronunciation fields (linnin/린닌/ㄌㄧㄋㄋㄧㄋ) already matched the straightforward concatenation — no bug. **Verified, not fixed**: korean 이웃 (native, matching 隣's own korean_native gloss) confirmed via web search as a deliberate real-word choice — 隣's own hanja reading 린 does appear in real compounds (근린/인접/선린), but 隣人 itself isn't established as a standalone Sino-Korean word. Filled blank cantonese and vietnamese (lân nhân, confirmed attested though less common than native láng giềng/hàng xóm). **Flagged, not fixed** (out of scope for one iteration): `characters/人 (char).md`'s own Words section is in poor shape — a long stretch of bare numbered-list citations with no ruby annotations at all, mixed with markdown-link-style entries elsewhere in the same list; needs a dedicated cleanup pass someday, similar to the previously-flagged `一 (char).md`. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 隣国.

### 2026-09-08, iteration 3505 — [[words/隣国|隣国]]
No cranberry (隣's own stand_in is [[隣]] itself, 国's is presumably itself). Pronunciation fields (lingog/린곡/ㄌㄧㄋㄍㄛㄎ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 隣 false). **Found and fixed a real typo**: cantonese had leun4 instead of 隣's own correct leon4 (u/o transposition). **Verified, not fixed**: korean 인국 confirmed real via web search, using 隣/鄰's alternate Sino-Korean reading 인 (distinct from 린, seen on [[隣人]]) — a genuine dual-reading character, not a bug. Filled blank vietnamese (lân quốc, a well-known common term). Converted flow-style characters/aliases to block lists. Both character pages already cite 隣国 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 隼.

### 2026-09-08, iteration 3506 — [[words/隼|隼]]
Single-character stand-in word. Pronunciation fields already matched the character's own stored reading — no bug. Filled blank `pos` (名詞, character's own) and `vietnamese` (chuẩn). **In passing**, fixed a missing "(stand-in for 隼)" annotation on the character page's own Words-list citation. Wrote a full `## Notes` section, noting the native はやぶさ (famous as Japan's asteroid-probe name) is far more common than the on'yomi じゅん in Japanese. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 雅楽.

### 2026-09-08, iteration 3507 — [[words/雅楽|雅楽]]
No cranberry (雅's own stand_in is [[典雅]], 楽's is [[快楽]]). Pronunciation fields ('alag/아락/ㄚㄌㄚㄎ) already matched the straightforward concatenation, all real-language fields already correct — no bug. **Found and fixed a real bug**: `kwin` was stored false despite both constituents being individually true — corrected to true. Converted flow-style characters/aliases to block lists, removed blank hsk_level. Wrote a full `## Notes` section on the shared "each country's own living court-music tradition" theme. Both character pages already cite 雅楽 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 集合.

### 2026-09-08, iteration 3508 — [[words/集合|集合]]
集's own stand_in is this exact compound, but 合's own is [[合]] itself — transitivity fails, though 集 is legitimized by this word (stand-in note added). **Found and fixed a real bug**: `羅馬字` had jibkab, mismatched with 合's own correctly-stored gob (諺文 곱 and 注音 ㄍㄛㄆ were both already correct) — corrected to jibgob. Quoted bare mandarin/cantonese/korean fields. Wrote a full `## Notes` section noting both the everyday and mathematical "set" senses. Both character pages already cite 集合 correctly (集's with its stand-in annotation). Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 雇員.

### 2026-09-08, iteration 3509 — [[words/雇員|雇員]]
No cranberry (雇's own stand_in is [[雇用]], 員's is [[人員]]). Pronunciation fields (ko'un/코운/ㄎㄛㄨㄋ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 雇 false). **Verified, not fixed**: vietnamese nhân viên confirmed as the standard everyday word (built on the unrelated 人員, not this word's own 雇員) — a deliberate real-word choice, not contamination, given no evidence a literal "cố viên" compound exists. **Fixed a self-referential alias mistake**: `aliases` wrongly listed the headword 雇員 as its own alias — removed, keeping only the genuine variants 雇员/僱員. Quoted `hsk_level`. Both character pages already cite 雇員 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 雉.

### 2026-09-08, iteration 3510 — [[words/雉|雉]]
Single-character stand-in word. **Fixed the literal-`"null"`-string bug** on `vietnamese`: corrected to trĩ. **Completed a homophone callout already anticipated by [[地]]'s own page** (both diǝ/듸/ㄉㄧㄜ) — added the reciprocal callout here. Rewrote the whole scrambled frontmatter into template order; added missing `kwin: false` and `japanese` (ち, on'yomi; native きじ, Japan's national bird and a Momotarō folktale character, is far more common — documented in Notes). **In passing**, added an entirely missing `## Words` section to the character page (it had none at all, not even its own stand-in citation). Exact-match homophone check confirmed 緻/稚 (sharing the same syllable) don't stand alone as their own words, so no further collision. Stamped `date-last-perfect: 2026-09-08`.

Next: 雍雍.

### 2026-09-08, iteration 3511 — [[words/雍雍|雍雍]]
**Genuine `#cranberry`**: 雍's own stand_in points to this exact reduplicated compound (both halves the same character, transitivity trivially holds) — newly tagged on both the word and `characters/雍.md` (which previously lacked the tag). **Found and fixed two real bugs**: `諺文` had drifted to 오옹, inconsistent with both halves of 雍's own correctly-stored 옹 (注音 ㄛㄫㄛㄫ already correct) — corrected to 옹옹; `japanese` held an unrelated katakana string ヨンヨン — corrected to ようよう (confirmed via web search, referencing the 詩經 "harmonious geese" image). Filled blank vietnamese (ung ung, confirmed attested). Converted flow-style characters/aliases to block lists, removed a stray body line ("admittedly very C"). Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 雑.

### 2026-09-08, iteration 3512 — [[words/雑|雑]]
Single-character stand-in word. **Fixed the literal-`"null"`-string bug** on both `vietnamese` and `korean`: corrected to tạp (previously entirely undocumented on the character page too — added there as well) and 잡 (matching the character's own stored reading) respectively. Rewrote the whole scrambled frontmatter into template order; added missing `kwin: true` (AND-rule — character's own kwin true, matching) and `japanese` (ざつ). Built the missing `## Notes` section. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 雑交.

### 2026-09-08, iteration 3513 — [[words/雑交|雑交]]
No cranberry (both 雑's and 交's own stand_in point to themselves). **Found and fixed a real bug**: `羅馬字` had jabgyau, mismatched with 交's own correctly-stored gyou (諺文 굣 and 注音 ㄍ⼄ㄨ were both already correct) — corrected to jabgyou. Filled blank cantonese and vietnamese (tạp giao, confirmed attested biology term). **In passing**, fixed the long-flagged empty-string `pos: ""` bug on `characters/交 (char).md` (matching the memory-documented recurring bug class) and added a missing ruby annotation to that page's own 雑交 citation — the rest of that character's large, messy Words list (many bare wikilinks without ruby) is still out of scope for one iteration and remains flagged for a future dedicated pass. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 雛鳥.

### 2026-09-08, iteration 3514 — [[words/雛鳥|雛鳥]]
雛's own stand_in is this exact compound, but 鳥's own is [[鳥]] itself — transitivity fails, though 雛 is legitimized by this word (stand-in note added). **Found and fixed a real cluster of bugs**: `羅馬字` had jucou, mismatched with 雛's own correctly-stored cuo (諺文/注音 already correct) — corrected to cuocou; `cantonese` had a wrong tone plus a letter transposition (co4 nui5 → co1 niu5); `japanese` held ひよこ, the reading of a distinct related word specifically meaning "baby chicken," not this compound — corrected to ひなどり (confirmed via web search); `korean` held 병아리, 雛's own native gloss rather than a Sino-Korean reading — corrected to compositional 추조. Filled blank vietnamese (sồ điểu, compositional best-effort). Both character pages already cite 雛鳥 correctly (雛's with its stand-in annotation). Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 離別.

### 2026-09-08, iteration 3515 — [[words/離別|離別]]
離's own stand_in is this exact compound, but 別's own is [[別]] itself — transitivity fails, though 離 is legitimized by this word (stand-in note added). Pronunciation fields (leibed/레벋/ㄌㄝㄧㄅㄝㄊ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — both false). **Found and fixed a real bug**: `korean` had 이별, the South Korean 두음법칙-shifted form — corrected to 리별, this vault's standing North Korean/문화어 pronunciation policy (matching 離's own correctly-stored 리). Filled blank vietnamese (ly biệt, a well-known literary term). Removed empty `aliases: []`. Both character pages already cite 離別 correctly (離's with its stand-in annotation). Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 離婚.

### 2026-09-08, iteration 3516 — [[words/離婚|離婚]]
No cranberry (離's own stand_in is [[離別]], 婚's is [[結婚]]). Pronunciation fields (leihon/레혼/ㄌㄝㄧㄏㄛㄋ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 離 false). **Found and fixed a real bug**: `korean` had 이혼, the South Korean 두음법칙-shifted form — corrected to 리혼, matching the vault's standing North Korean/문화어 policy (same fix as [[離別]] one iteration ago). Converted flow-style characters/aliases to block lists, removed blank hsk_level. Both character pages already cite 離婚 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 離心率.

### 2026-09-08, iteration 3517 — [[words/離心率|離心率]]
No cranberry (none of 離/心/率's own stand_in point here). Pronunciation fields (leisimlud/레심룯/ㄌㄝㄧㄙㄧㄇㄌㄨㄊ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 離/率 false). Korean 리심률 was already correctly using the vault's North Korean form (no drift this time, unlike [[離別]]/[[離婚]]). Normalized a non-standard Cantonese tone-change notation (leot6-2 → leot6, matching the character's own stored base reading). Fixed capitalization on vietnamese (Độ lệch tâm → độ lệch tâm), noting it's a native calque phrase rather than a Sino-Vietnamese compound. All three character pages already cite 離心率 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 離枝.

### 2026-09-08, iteration 3518 — [[words/離枝|離枝]]
No cranberry (離's own stand_in is [[離別]], 枝's is [[枝葉]]). Pronunciation fields (leije/레저/ㄌㄝㄧㄐㄝ) already matched the straightforward concatenation — no bug. **Verified, not fixed**: all five real-language fields (mandarin/cantonese/japanese/korean already stored, vietnamese vải) correctly reflect the standardized alias spelling 荔枝's real readings rather than a naive concatenation of 離/枝's own fields — 離枝 is a genuine early/alternate written form of "lychee" per its own pre-existing english gloss ("kingdom of Lizhi"), confirmed rather than assumed a bug. Wrote a full `## Notes` section explaining this substitution. **In passing**, fixed a real gap: `characters/枝.md`'s own Words list was entirely missing a citation for this word — added it. Also fixed a self-inflicted duplicate-field slip from this iteration's own editing (doubled `kwin`/`tags`, stray blank `swadesh:`) before finalizing. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 難金.

### 2026-09-08, iteration 3519 — [[words/難金|難金]]
Periodic-table neologism (dysprosium); pronunciation fields already correct, no cranberry (難's own stand_in is [[困難]], 金's is [[金]] itself). **Found and fixed a real bug**: `kwin` was stored false despite both constituents being individually true — corrected to true. Removed redundant `品詞` duplicate of `pos`. Real-element-reading fields already correct per established convention; page's thorough etymology essay kept as-is. **In passing**, fixed a real gap (same class as [[隠金]] two iterations ago): `characters/金 (char).md`'s own Words list was missing a citation for this word — added it. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 雨中.

### 2026-09-08, iteration 3520 — [[words/雨中|雨中]]
No cranberry (both 雨's and 中's own stand_in point to themselves). Pronunciation fields ('ujung/우중/ㄨㄐㄨㄫ) already matched the straightforward concatenation — no bug; **added entirely missing `kwin: true`** (AND-rule — both true). Split comma-joined korean (우중, 빗속 → 우중, moved native synonym to prose). Filled blank cantonese, japanese (うちゅう, confirmed attested via web search — more formal than 雨の中), and vietnamese (vũ trung, confirmed attested, poetic register). **In passing**, fixed a real gap: `characters/中 (char).md`'s own large Words list was missing a citation for this word — added it. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 雨傘.

### 2026-09-08, iteration 3521 — [[words/雨傘|雨傘]]
傘's own stand_in is this exact compound, but 雨's own is [[雨]] itself — transitivity fails, though 傘 is legitimized by this word (stand-in note added). Pronunciation fields ('usan/우산/ㄨㄙㄚㄋ) already matched the straightforward concatenation — no bug; kwin true already correct (AND-rule — both true). **Found and fixed a real bug**: `japanese` held かさ, the bare ambiguous general word for "umbrella" — corrected to あまがさ, the real word specifically distinguishing rain umbrellas from [[陽傘]]'s 日傘 (confirmed via web search). Both character pages already cite 雨傘 correctly (傘's with its stand-in annotation). Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 雪.

### 2026-09-08, iteration 3522 — [[words/雪|雪]]
Single-character stand-in word. Pronunciation fields already matched the character's own stored reading — no bug. Removed redundant `品詞` duplicate of `pos`. Wrote a full `## Notes` section, noting the native ゆき is the everyday Japanese word (せつ appears mainly in compounds like 積雪/除雪). Exact-match homophone check found 説 sharing the same syllable at the character level only (stand-in 学説) — no genuine collision, documented explicitly. Stamped `date-last-perfect: 2026-09-08`.

Next: 雪崩.

### 2026-09-08, iteration 3523 — [[words/雪崩|雪崩]]
No cranberry (both 雪's and 崩's own stand_in point to themselves). Pronunciation fields (swedbung/숻붕/ㄙ⼔ㄊㄅㄨㄫ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 雪 false). **Verified, not fixed**: japanese なだれ is a genuine 熟字訓 (jukujikun) — the whole compound has a dedicated native reading with no everyday on'yomi alternative, confirmed rather than assumed a bug. **Found and fixed a real bug**: `korean` held 눈사태, a native/mixed term, when a real attested Sino-Korean compositional form 설붕 exists (confirmed via web search) — corrected to 설붕, noting 눈사태's greater everyday frequency in Notes. Both character pages already cite 雪崩 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 雪魚.

### 2026-09-08, iteration 3524 — [[words/雪魚|雪魚]]
No cranberry (both 雪's and 魚's own stand_in point to themselves). Pronunciation fields (swed'yo/숻요/ㄙ⼔ㄊ·⼄) already matched the straightforward concatenation — no bug. **Verified, not fixed**: mandarin/japanese/korean already correctly reflect the real standardized name for this fish (牙鱈/鱈, an entirely different character), matching the same divergence class documented on [[離枝]]. Filled blank vietnamese (tuyết ngư, compositional; everyday Vietnamese uses cá tuyết instead). Both character pages already cite 雪魚 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 雰囲.

### 2026-09-08, iteration 3525 — [[words/雰囲|雰囲]]
No cranberry (雰's own stand_in is [[雰囲気]], 囲's is [[包囲]]). Pronunciation fields (pun'wi/푼위/ㄈㄨㄋㄨㄧ) already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — 雰 false). **Found and fixed real contamination on both `japanese` and `korean`**: both had drifted to the readings of the far more common three-character compound 雰囲気/분위기 (with an extra 気/기 syllable) rather than this word's own two-character form — corrected to ふんい/분위. Trimmed a spurious second mandarin tone variant (fènwéi, unsupported by 雰's own stored single reading). Filled blank vietnamese (phân vi, compositional/rare; everyday Vietnamese uses bầu không khí). Both character pages already cite 雰囲 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 雴霫.

### 2026-09-08, iteration 3526 — [[words/雴霫|雴霫]]
**Genuine `#cranberry`**: both 雴's and 霫's own stand_in point to this exact compound (already correctly tagged on all three pages). Pronunciation fields already matched the straightforward concatenation — no bug; kwin false already correct (AND-rule — both false). Quoted bare mandarin/cantonese/korean fields, added a missing cantonese space. Filled entirely missing `vietnamese` (lụp tập, compositional best-effort given the extreme rarity — both constituents are hapax-tagged characters with no independent attestation for this compound in any language). **In passing**, fixed a duplicated `cranberry` tag on `characters/雴.md`. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 雷.

### 2026-09-08, iteration 3527 — [[words/雷|雷]]
Single-character stand-in word. Pronunciation fields already matched the character's own stored reading, korean 뢰 already correctly using this vault's North Korean/문화어 policy — no bug. Filled blank pos/vietnamese, rewrote frontmatter into template order. **In passing**, fixed a non-standard markdown-link citation (should be a wikilink) on the character page's own Words-list entry. Exact-match homophone check confirmed 磊/儡 (sharing the same syllable) don't stand alone as their own words, so no genuine collision. Stamped `date-last-perfect: 2026-09-08`.

Next: 雷金.

### 2026-09-08, iteration 3528 — [[words/雷金|雷金]]
Periodic-table neologism (thorium); pronunciation fields already correct, no cranberry (both 雷's and 金's own stand_in point to themselves). **Found and fixed a real bug**: `kwin` was stored false despite both constituents being individually true — corrected to true. Removed redundant `品詞`. Real-element-reading fields already correct per established convention; page's thorough mythological-calque essay kept as-is. **In passing**, fixed a real gap (3rd instance of this exact pattern this session): `characters/金 (char).md`'s own Words list was missing a citation for this word — added it. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 電子.

### 2026-09-08, iteration 3529 — [[words/電子|電子]]
No cranberry (電's own stand_in is [[電気]], 子's is [[児子]]). **Found and fixed a real bug**: `羅馬字`/`諺文` had drifted to denji/던지, inconsistent with 子's own correctly-stored jǝ/즈 (注音 ㄐㄜ already correct) — corrected to denjǝ/던즈, the same recurring bug class fixed many times earlier in this sweep. All real-language fields already correct. Converted flow-style characters to block list, removed blank hsk_level/empty aliases. **In passing**, fixed the specific 電子 citation on `characters/子.md`'s own Words list (bare wikilink, no ruby) — that page is otherwise extremely messy (dozens of bare-wikilink entries, at least one wrong 注音 shown elsewhere on the page) and needs its own dedicated cleanup pass someday, flagged rather than fully fixed now. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 電子版.

### 2026-09-08, iteration 3530 — [[words/電子版|電子版]]
No cranberry (none of 電/子/版's own stand_in point here). **Found and fixed the same recurring bug just fixed on [[電子]] one iteration ago**: `羅馬字`/`諺文` had drifted to denjipan/던지판 — corrected to denjǝban/던즈판 (注音 already correct). Added missing `kwin: false`, `korean` (전자판), and `vietnamese` (bản điện tử, confirmed attested — 2nd instance of the Vietnamese word-order-reversal pattern this word specifically, after [[限定詞]]/[[除外]]). Consolidated a duplicated Notes/Etymology heading pair into one proper `## Notes` section. **In passing**, added a missing citation to `characters/子.md`'s own (still generally messy) Words list. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

**Out-of-sequence fix (before 3531)**: chasing down the ji/지-vs-jǝ/즈 bug found on [[電子]]/[[電子版]], grepped all `words/*子*.md` for the same drift. Found and fixed six more instances, all `羅馬字`-only except two: [[卵子]] (lanji→lanjǝ), [[子子]] (jiji→jǝjǝ, both syllables), [[子宮]] (jigung→jǝgung), [[庵子]] (both 羅馬字 'amji→'amjǝ AND 諺文 암지→암즈), [[種子]] (both 羅馬字 jongji→jongjǝ AND 諺文 종지→종즈), [[中性子]] (jungsingji→jungsingjǝ, also removed a redundant 品詞 in passing). [[分子]] (not yet reached by the sweep, no date-last-perfect) got the same 羅馬字 fix without a stamp. [[振子]] and [[親子井]] were already correct (already documented fixes/notes). All six already-stamped words re-stamped `date-last-perfect: 2026-09-08` since a genuine bug was corrected on each.

Next: 電影.

### 2026-09-08, iteration 3531 — [[words/電影|電影]]
No cranberry (電's own stand_in is [[電気]], 影's is [[陰影]]). Pronunciation fields (den'yeng/던영/ㄉㄝㄋ⼶ㄫ) already matched the straightforward concatenation — no bug; **added entirely missing `kwin: false`** (AND-rule — 電 false). Filled blank japanese/korean with compositional readings (でんえい/전영), documenting in Notes that neither is an independently attested real word — both Japanese and Korean use an entirely different compound (映画/영화, built on 映 not 電) for "movie," which the page's own pre-existing stray note had already flagged. Quoted `hsk_level`. Both character pages already cite 電影 correctly. Exact-match homophone check found none. Stamped `date-last-perfect: 2026-09-08`.

Next: 電気.

### 2026-09-08, iteration 3532 — [[words/電気|電気]]
Legitimizing note added (電's own `stand_in` is [[電気]] itself; 気's own `stand_in` remains 気, so transitivity fails — no `#cranberry`). Pronunciation fields (denkiǝ/던킈/ㄉㄝㄋㄎㄧㄜ) already matched constituents exactly — no bug. `kwin: false` already correct (AND-rule, both constituents false). Both character pages already cited 電気 correctly, 電's side with the `(stand-in for 電)` annotation — no in-passing fixes needed. Researched and filled blank `vietnamese: điện khí` — real, compositionally exact Sino-Vietnamese term, but noted in Notes that it has narrowed in modern technical usage toward "gas-fired electricity" specifically, with điện năng now the standard plain word for electricity in general; Dan'a'yo follows the older/broader sense shared with Mandarin/Cantonese/Korean. Converted flow-style `characters`/`aliases` to block-list style, removed blank `hsk_level`/`swadesh`. Stamped `date-last-perfect: 2026-09-08`. Exact-match homophone check (denkiǝ/던킈/ㄉㄝㄋㄎㄧㄜ) found only this file — no collision.

Next: 電灯.

### 2026-09-08, iteration 3533 — [[words/電灯|電灯]]
No cranberry (neither constituent's own `stand_in` points here — 電's is [[電気]], 灯's is 灯 itself). Pronunciation fields (dendung/던둥/ㄉㄝㄋㄉㄨㄫ) and `kwin: false` already matched constituents exactly — no bug. Both character pages already cited 電灯 correctly. Researched and filled blank `vietnamese: đèn điện` — the Sino-order **điện đăng** is not an attested live Vietnamese compound (đăng now reads mainly as "post/publish" outside fixed compounds); Vietnamese instead uses the native word-order-reversed đèn điện, a **third confirmed instance** of the word-order-reversal pattern (alongside [[限定詞]]→từ hạn định, [[除外]]→ngoại trừ). Quoted `hsk_level`, converted flow-style `characters`/`aliases` to block-list. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 電脳.

### 2026-09-08, iteration 3534 — [[words/電脳|電脳]]
No cranberry (neither constituent's own `stand_in` points here — 電's is [[電気]], 脳's is 脳 itself). Pronunciation fields (dennau/던낫/ㄉㄝㄋㄋㄚㄨ) already matched constituents exactly — **added entirely missing `kwin: false`** (AND-rule, both constituents false). Fixed comma-joined native-synonym contamination in `japanese`/`korean` (でんのう, コンピュータ → でんのう only; 컴퓨터, 전자계산기 → 전뇌 only), documenting in Notes that 電脳/でんのう is real but niche/hobbyist register in Japan (コンピュータ is the ordinary word), and that Korean 전뇌 is not standard vocabulary at all — it exists only in the same sci-fi "cyberbrain" register borrowed from Japanese pop culture (via Ghost in the Shell), with 컴퓨터 as the only ordinary Korean word. Filled blank `vietnamese: điện não`, noting it's an etymological gloss rather than live vocabulary — modern Vietnamese uses the native calque máy tính. Both character pages already cited 電脳 correctly. Converted flow-style `characters`/`aliases` to block-list, removed blank `hsk_level`/`swadesh`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 電視.

### 2026-09-08, iteration 3535 — [[words/電視|電視]]
No cranberry (neither constituent's own `stand_in` points here — 電's is [[電気]], 視's is 視 itself). Pronunciation fields (densiǝ/던싀/ㄉㄝㄋㄙㄧㄜ) already matched constituents exactly — **added entirely missing `kwin: false`**. Investigated `japanese: でんし` as a possible cross-character substitution from 電子 (also でんし) but confirmed it's a genuine real-Japanese homophone coincidence (子 and 視 share on'yomi シ), not a vault bug — documented in Notes. Filled blank `korean: 전시` (attested Sino-Korean reading, but not the ordinary word — noting Korean's live 전시 almost always means 展示 "exhibition" instead, and television is 텔레비전/티비) and `vietnamese: điện thị` (dictionary gloss only — modern Vietnamese uses truyền hình or tivi). **Added missing citation** to `characters/視 (char).md`'s `## Words` list (電's side already had it). Quoted `hsk_level`, dropped empty `aliases: []`/`swadesh`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 電話.

### 2026-09-08, iteration 3536 — [[words/電話|電話]]
No cranberry (neither constituent's own `stand_in` points here — 電's is [[電気]], 話's is 話 itself). Pronunciation fields (denhwai/던홰/ㄉㄝㄋㄏ⺢ㄧ) and `kwin: false` already matched constituents exactly — no bug. Both character pages already cited 電話 correctly. All real-language fields (diànhuà/din6waa6-2/でんわ/전화/điện thoại) already correct — a clean case with no substitutions, narrowings, or reorderings across all five languages. Quoted `hsk_level`, converted flow-style `characters`/`aliases` to block-list, dropped blank `swadesh`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 電車.

### 2026-09-08, iteration 3537 — [[words/電車|電車]]
No cranberry (neither constituent's own `stand_in` points here). **Found and fixed a real bug**: `羅馬字`/`諺文` had been contaminated to a naive w-glide-dropped form (denca/던차) instead of 車's own stored reading (cwa/촤) — the glide only drops after a *vowel-final* syllable (cf. [[汽車]], [[火車]]), but 電 ends in a consonant (-n), so the glide should be retained, confirmed against [[自動車]]/[[自転車]] (both also consonant-final before 車, both correctly keep -cwa-). `注音` had already stayed correct (ㄑ⺢ doesn't distinguish the glide). Filled blank `vietnamese: xe điện` — a further instance of the word-order-reversal pattern (native "vehicle-electric" order, no Sino-order **điện xa** attested). Both character pages already cited 電車 correctly. Quoted `hsk_level`, dropped empty `aliases: []`/`swadesh`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 需要.

### 2026-09-08, iteration 3538 — [[words/需要|需要]]
Legitimizing note added (需's own `stand_in` is [[需要]] itself; 要's own `stand_in` is [[重要]], so transitivity fails — no `#cranberry`). Pronunciation fields (su'you/수욧/ㄙㄨ⼄ㄨ) and `kwin: false` (AND-rule: 需's own kwin=true, 要's own kwin=false → false) already matched exactly — no bug. Both character pages already cited 需要 correctly, 需's side with the `(stand-in for 需)` annotation. All real-language fields (xūyào/seoi1jiu3/じゅよう/수요/nhu yếu) already correct standard words for "need/demand" in each language — a clean case. Quoted `hsk_level`, dropped empty `aliases: []`/`swadesh`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 震怒.

### 2026-09-08, iteration 3539 — [[words/震怒|震怒]]
No cranberry (neither constituent's own `stand_in` points here — 震's is [[震動]], 怒's is 怒 itself). Pronunciation fields (jinno/진노/ㄐㄧㄋㄋㄛ) already matched constituents exactly — **added entirely missing `kwin: true`** (AND-rule: both 震's own and 怒's own kwin are true, unlike the more common false case). **Found and fixed a real bug**: `japanese` had いかり, the native reading of 怒 alone ("anger"), instead of the compound's own correct on'yomi しんど — confirmed real and attested (distinct from the unrelated homophone しんど meaning "tiredness"). Filled blank `korean: 진노` and `vietnamese: chấn nộ` — both confirmed real, standard words for this same elevated "wrath of an exalted figure" sense across all five languages. Both character pages already cited 震怒 correctly. Removed blank `hsk_level`/`swadesh`/`aliases`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 霊芝.

### 2026-09-08, iteration 3540 — [[words/霊芝|霊芝]]
No cranberry (neither constituent's own `stand_in` points here — 霊's is [[霊魂]], 芝's is the special "name-only character" marker 名専字, unrelated). Pronunciation fields (lengji/렁지/ㄌㄝㄫㄐㄧ) and `kwin: false` already matched constituents exactly — no bug. Both character pages already cited 霊芝 correctly. `pos: 固有名詞` confirmed consistent with vault convention of treating uniquely-named natural substances/species (cf. chemical elements) as proper nouns. Fixed `vietnamese`: was "Nấm linh chi" (capitalized, native-classifier-expanded) — trimmed to the exact Sino-Vietnamese compound `linh chi` itself, documenting the fuller everyday nấm linh chi form in Notes. Removed blank `hsk_level`/`swadesh`, converted flow-style `characters`/`aliases` to block-list. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 霊長類.

### 2026-09-08, iteration 3541 — [[words/霊長類|霊長類]]
No cranberry (no constituent's own `stand_in` points here — 霊's is [[霊魂]], 長's is 長 itself, 類's is [[種類]]). Pronunciation fields (lengjanglui/렁장뤼/ㄌㄝㄫㄐㄚㄫㄌㄨㄧ) and `kwin: false` already matched constituents exactly — no bug. **Found and fixed a real bug**: `mandarin`/`cantonese` had been contaminated with the taxonomic-rank reading (Língzhǎngmù/muk6, using 目 "order") instead of this word's own 類-based reading (língzhǎnglèi/leoi6) — the two terms are near-synonyms in Chinese (灵长类 = common noun "primates" vs 灵长目 = formal "Order Primates"), but this word's own characters are 霊+長+類, not 霊+長+目. Filled blank `vietnamese: linh trưởng` (real term, though it drops 類 entirely, a 2-morpheme truncation paralleling 中性子→中子). **Added missing citation** to `characters/長 (char).md`'s `## Words` list (霊's and 類's own lists already had it). Removed blank `hsk_level`/`swadesh`, converted flow-style `characters`/`aliases` to block-list. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 霊鬼.

### 2026-09-08, iteration 3542 — [[words/霊鬼|霊鬼]]
No cranberry (neither constituent's own `stand_in` points here — 霊's is [[霊魂]], 鬼's is [[鬼神]]). Pronunciation fields (lenggui/렁귀/ㄌㄝㄫㄍㄨㄧ) already matched constituents exactly — **added entirely missing `kwin: false`** (AND-rule: 霊's own false, 鬼's own true). **Found and fixed a real bug**: `korean` held stray Japanese katakana (れーき, a garbled form of this word's own Japanese reading) instead of a real Korean value. Filled entirely blank `mandarin`/`cantonese`/`japanese`/`vietnamese`/`korean` with confirmed real readings: línggui (attested Daoist "ghost immortal" term), ling4gwai2, れいき (archaic, attested in *Nihon Ryōiki*), 영귀 (attested "eerie/numinous ghost"), and linh quỷ (compositionally straightforward but not independently attested as a fixed dictionary compound, unlike the other four). Both character pages already cited 霊鬼 correctly. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 霓金.

### 2026-09-08, iteration 3543 — [[words/霓金|霓金]]
No cranberry (霓's own `stand_in` is [[虹霓]], 金's is 金 itself — neither points here). Pronunciation fields ('eigim/에김/ㄝㄧㄍㄧㄇ) and `kwin: false` (this series compares the word's own Dan'a'yo/korean fields, not the AND-rule — 에김 vs 이리듐 diverge) already correct. Per this neologism series' established convention (cf. [[丹金]]), `mandarin`/`cantonese` correctly hold the real avoided element character's own reading — **found and fixed a real bug**: cantonese jyutping was `ji2`, corrected to the verified `ji1`. Removed the redundant duplicate `品詞` field (kept `pos`), flattened single-item list fields (`japanese`/`vietnamese`) to scalars. 金 (char).md's citation gap is part of the already-documented ~55-file 金-page backlog, out of scope here. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 霧虹.

### 2026-09-08, iteration 3544 — [[words/霧虹|霧虹]]
No cranberry (霧's own `stand_in` is the word [[霧]] itself, 虹's is [[彩虹]] — neither points here). Pronunciation fields (muhong/무홍/ㄇㄨㄏㄛㄫ) already matched constituents exactly — **added entirely missing `kwin: true`** (AND-rule: both 霧's own and 虹's own kwin are true). Fixed `characters:` list entry 霧→霧 (char) to match the actual disambiguated filename. Filled blank `cantonese: mou6 hung4` (compositional), `korean: 무홍` (confirmed real, attested term) and `vietnamese: vụ hồng` (compositionally exact, though the standard Vietnamese term is instead the native cầu vồng sương mù/cung sương mù). Japanese きりにじ was already correct (confirmed real, native-reading term, not a bug). **Added missing citation** to `characters/虹.md`'s `## Words` list (霧 (char)'s own list already had it). Removed blank `hsk_level`/`swadesh`/`aliases`. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 露.

### 2026-09-08, iteration 3545 — [[words/露|露]]
Legitimizing note added (this bare-character word is 露's own legitimizer, `stand_in` points here). Pronunciation fields (lo/로/ㄌㄛ) and `kwin: true` already matched the character's own stored values exactly — no bug. All real-language fields (lù/lou6/ろ/로/lộ) already correct, with Notes documenting each language's native alternative (이슬, つゆ, sương) where the Sino form isn't the everyday word. **Added missing self-citation** to `characters/露 (char).md`'s `## Words` list (the "(stand-in for 露)" line other single-character word pages have, absent here). Removed redundant duplicate `品詞` field, flattened single-item list fields to scalars, wrote the empty `## Notes` section. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found many syllable-mates (路/炉/盧/羅/鈩/芦/廬/賂/虜, all sharing ㄌㄛ) but none is itself a legitimized single-character word — no genuine collision.

Next: 露国.

### 2026-09-08, iteration 3546 — [[words/露国|露国]]
No cranberry (露's own `stand_in` is the word [[露]] itself, 国's is [[国家]] — neither points here; considered a contraction of [[露斯亜]]). Pronunciation fields (logog/로곡/ㄌㄛㄍㄛㄎ) and `kwin: false` already matched constituents exactly — no bug. **Found and fixed a real bug**: `mandarin`/`cantonese` had been contaminated with the unrelated word [[露語]]/俄语's reading ("Russian language," Éyǔ/ngo4jyu5) instead of this word's own "Russia" reading (Éguó/ngo4gwok3, matching the already-present aliases 俄国/俄國). Filled blank `vietnamese: Lộ quốc` — confirmed real, older alternative Sino-Vietnamese name for Russia paralleling modern 俄国→Nga. **Added missing citation** to `characters/露 (char).md`'s `## Words` list (国's own list already had it). Removed blank `hsk_level`/`swadesh`, converted flow-style `characters` to block-list. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 露斯亜.

### 2026-09-08, iteration 3547 — [[words/露斯亜|露斯亜]]
No cranberry (no constituent's own `stand_in` points here — 露's is the word [[露]] itself, 斯's is the special "name-only character" marker 名専字, 亜's is [[亜細亜]]). **Found and fixed a real bug**: `諺文` had a spurious trailing 요 (로시아요→로시아, matching 羅馬字/注音's already-correct losi'a/ㄌㄛㄙㄧ·ㄚ). Added entirely missing `kwin: false` (AND-rule: 露 true, 斯 false, 亜 true → false). Fixed comma-joined contamination in `korean`: was "로서아,러시아,아라사" (three distinct real names crammed together) — trimmed to 로서아 alone (the one actually built on this word's own 露西亜 form), documenting 러시아 (modern loanword) and 아라사 (from the different base 俄羅斯) in Notes instead. Filled blank `vietnamese: Lộ Tây Á` (compositional rendering, not independently common). Incorporated the file's leftover raw `derrogatory: 魯西亜 (lomsei'a)` line into proper Notes prose — confirmed real history: Japan used 魯 until an 1877 Russian consular objection to its "foolish" connotation prompted the switch to neutral 露. **Added missing citation** to `characters/斯.md`'s `## Words` list (露's and 亜's own lists already had it). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 露斯亜語.

### 2026-09-08, iteration 3548 — [[words/露斯亜語|露斯亜語]]
No cranberry (no constituent's own `stand_in` points here). Pronunciation fields (losi'a'yo/로시아요/ㄌㄛㄙㄧㄚ⼄) and `kwin: false` already matched constituents exactly — no bug (the trailing 요 here is correct, unlike [[露斯亜]]'s spurious one, since 語's own 諺文 genuinely is 요). Confirmed `mandarin`/`cantonese` (Éluósīyǔ/ngo4lo4si1jyu5, just capitalized) are correctly the real Chinese equivalent term, not a compositional-reading bug — this fuller form pairs with the real fuller 俄罗斯语, exactly as the shorter [[露語]] already pairs with real 俄语/俄語. **Added missing citation** to `characters/斯.md`'s `## Words` list (露's/亜's/語's own lists already had it). Filled blank `vietnamese: Nga ngữ` (confirmed real, standard Sino-Vietnamese term, calqued from 俄語 — no separate longer form exists in Vietnamese). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 露語.

### 2026-09-08, iteration 3549 — [[words/露語|露語]]
No cranberry (露's own `stand_in` is the word [[露]] itself, 語's is [[言語]] — neither points here; a contraction of [[露斯亜語]]). Pronunciation fields (lo'yo/로요/ㄌㄛ·⼄) and `kwin: false` already matched constituents exactly — no bug. Confirmed `mandarin`/`cantonese` (Éyǔ, Èyǔ/ngo4jyu5) correctly hold the real Chinese equivalent 俄语/俄語 (both tone variants genuinely attested — Éyǔ mainland-standard, Èyǔ a Taiwan-standard alternate), per the same convention as [[露国]]/[[露斯亜語]], not a bug. Both character pages already cited 露語 correctly. Filled blank `vietnamese: Nga ngữ` (matching [[露斯亜語]]'s own field, Vietnamese not distinguishing the short/long Chinese forms). Confirmed the existing homophone callout with [[盧魚]] is genuine and correctly reciprocal on both pages — background exact-match check found no other collisions. Stamped `date-last-perfect: 2026-09-08`.

Next: 露金.

### 2026-09-08, iteration 3550 — [[words/露金|露金]]
No cranberry (both 露's and 金's own `stand_in` point to themselves, not here). Pronunciation fields (logim/로김/ㄌㄛㄍㄧㄇ) and `kwin: false` already correct. Per this neologism series' established convention (cf. [[丹金]], [[霓金]]), verified `mandarin`/`cantonese` (liǎo/liu5) correctly hold the real avoided element character's (钌/釕) own reading — no bug found. Removed the redundant duplicate `品詞` field (kept `pos`). 金 (char).md's citation gap is part of the already-documented ~55-file backlog, out of scope. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision. All remaining 露-prefixed words are now stamped — sweep jumps to 青.

Next: 青年.

### 2026-09-08, iteration 3551 — [[words/青年|青年]]
No cranberry (neither constituent's own `stand_in` points here). Pronunciation fields (cengnen/청넌/ㄑㄝㄫㄋㄝㄋ) and `kwin: false` already matched constituents exactly — no bug. Both character pages already cited 青年 correctly. Filled blank `vietnamese: thanh niên` — confirmed standard everyday term. Fixed `characters:` disambiguation-suffix mismatch (青→青 (char), 年 (char) already correct). Quoted `hsk_level`, converted flow-style `aliases` to block-list, removed blank `swadesh`. A clean case otherwise — all real-language fields already correct standard words for "youth" in every language. Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 青素.

### 2026-09-08, iteration 3552 — [[words/青素|青素]]
No cranberry (青's own `stand_in` is itself, 素's is [[要素]] — neither points here). Pronunciation fields (cengso/청소/ㄑㄝㄫㄙㄛ) and `kwin: false` already correct. Per this neologism series' established convention (cf. [[丹金]], [[霓金]], [[露金]]), verified `mandarin`/`cantonese` (sè/sik1) correctly hold the real avoided element character's (铯/銫) own reading — no bug found, a clean case. Both character pages already cited 青素 correctly. Removed the redundant duplicate `品詞` field (kept `pos`). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 青色.

### 2026-09-08, iteration 3553 — [[words/青色|青色]]
No cranberry (青's own `stand_in` is itself, 色's is [[色彩]] — neither points here). Pronunciation fields (cengsig/청식/ㄑㄝㄫㄙㄧㄎ) and `kwin: false` already matched constituents exactly — no bug. **Found and fixed a real bug**: `cantonese` had `ceng1` instead of 青's own stored jyutping `cing1`. Cleaned `korean` field format (was "청색 (靑色)" with a stray hanja parenthetical — trimmed to 청색 alone, moved 靑色 to a proper word-level `aliases` entry). Both character pages already cited 青色 correctly. Documented in Notes that Vietnamese màu xanh's own word xanh is thought to be an etymological doublet of 青 itself (an older borrowing layer, vs. the newer Sino-Vietnamese thanh seen in [[青年]]). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 青蛙.

### 2026-09-08, iteration 3554 — [[words/青蛙|青蛙]]
Legitimizing note added (蛙's own `stand_in` is [[青蛙]] itself; 青's own `stand_in` is 青 itself, so transitivity fails — no `#cranberry`). Pronunciation fields (ceng'wa/청와/ㄑㄝㄫ⺢) already matched constituents exactly. **Found and fixed a real bug**: `kwin` was `false`, but the AND-rule gives `true` (both 青's own and 蛙's own kwin are true). Documented a genuine cross-linguistic narrowing: Mandarin/Cantonese 青蛙 is the generic word for "frog," while Japanese あおがえる and Korean 청와/청개구리 refer specifically to green tree frogs — explaining why `korean` already correctly holds generic 개구리 rather than 청와. Filled blank `vietnamese: ếch` (native, generic; no Sino-Vietnamese compound attested). **Added missing "(stand-in for 蛙)" annotation** to `characters/蛙.md`'s existing citation (青's own list already had the plain citation). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 青銅.

### 2026-09-08, iteration 3555 — [[words/青銅|青銅]]
No cranberry (both 青's and 銅's own `stand_in` point to themselves). Pronunciation fields (cengdong/청동/ㄑㄝㄫㄉㄛㄫ) and `kwin: true` already matched constituents exactly — no bug. **Found and fixed a real bug**: `cantonese` had a spurious comma-joined second variant `ceng1 tung4` — the same erroneous alternate reading of 青 already corrected on [[青色]] — trimmed to 青's own stored `cing1` alone. Both character pages already cited 青銅 correctly. Documented a further (5th) instance of the word-order-reversal pattern: Vietnamese has both đồng điếu (the standard technical term, kept as the field value) and a directly cognate but reordered đồng thanh (thanh+đồng vs. 青+銅). Stamped `date-last-perfect: 2026-09-08`. Background exact-match homophone check found no collision.

Next: 静寂.
