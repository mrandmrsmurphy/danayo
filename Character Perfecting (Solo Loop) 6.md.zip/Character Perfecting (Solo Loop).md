# Character Perfecting (Solo Loop)

Running log for the character-perfecting backlog sweep (see [[AIOS/checklists/checklist_characters.md|Checklist: Character Pages]]). The prior logs (iterations 1–464, 465–981, 982–1543, 1544–2049, and 2050–2260) grew large and were archived to `Character Perfecting (Solo Loop).md.zip`, `Character Perfecting (Solo Loop) 2.md.zip`, `Character Perfecting (Solo Loop) 3.md.zip`, `Character Perfecting (Solo Loop) 4.md.zip`, and `Character Perfecting (Solo Loop) 5.md.zip` respectively; this file continues from there. Iteration numbering continues unbroken from the archived logs.

**Process**: one character per iteration. Find the next never-perfected character via `danayo_id` ascending (`grep -L "^date-last-perfect" characters/*.md`, sorted by each file's own `danayo_id` frontmatter value — not alphabetical, unlike the word sweep). Verify/fill all required frontmatter (`graphemic_classification`, `stand_in`, `mc_id`, `danayo_id`, `pos`, level fields), write or correct the four fixed `## Notes` bullets (graphemic → SKIP/Stroke → MC rank+phonology → levels), cross-check `## Words` against every real word citing this character as a constituent, add `## Chengyu`/`## Derived Characters` when real hits exist, then stamp `date-last-perfect`.

Next never-perfected character by `danayo_id`: 爰 (8535; 244 characters remaining).

### 2026-08-23, iteration 2261 — [[characters/爰|爰]]

`graphemic_classification: 會意` reconfirmed correct — en.Wiktionary gives an explicit ideogrammic-compound breakdown (爫 "hand" + 丨 + 又 "hand," two hands holding/pulling); zh.Wiktionary corroborates the reading and sense without detailing components. `radical: 爪` reconfirmed correct — genuine "Used" listing (item 3) on `Lookup/Radicals/Radical 087.md`. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `stand_in: 名専字` reconfirmed correct — zero hits for 爰 anywhere in `words/`, matching its listing (item 267) on `Lookup/名専字.md`. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-4-5.md` (item 10), `Lookup/Stroke/Stroke 09.md`, `Lookup/List of 会意.md`, and `Lookup/Korean/Korean Name ㅇ.md`'s `### 원` section.

**`mc_id` off-by-one bug found and fixed**: stored `1559` was actually 它's rank; correct rank for 爰 is `1560` (`CC 1000.md`: `1559. 它`, `1560. 爰`).

**`cantonese` completeness gap found and fixed**: stored `wun4` only; both en.Wiktionary and zh.Wiktionary independently attest a second genuine jyutping reading, `jyun4`; added, converting the field from scalar to list per the vault's multi-reading convention.

**`vietnamese` typo found and fixed**: stored `vèn` (grave accent) — hvdic.thivien.net's genuine Âm Nôm reading is actually `vén` (acute accent); corrected.

**`japanese`/`japanese_native` bugs found and fixed**: `japanese: [EN]` (kan-on) was missing a second genuine on'yomi, the go-on `ON`; both ja.Wiktionary and weblio.jp independently confirm it; added. `japanese_native: ここ` was a truncated fragment, not the real reading — both ja.Wiktionary and weblio.jp give the genuine kun'yomi as `ここに`; corrected.

**`joyo_level` filled**: was blank. Both ja.Wiktionary and weblio.jp confirm 爰 as 表外字 (outside the Jōyō/Jinmeiyō lists but genuinely read); added as item 536 to `Lookup/Japanese/Hyōgai.md` and filled as `表外字`.

**`pos` filled**: was blank. Filled as `連接詞`, matching the primary classical sense "thereupon; therefore" (a sentence-connecting particle), corroborated by both en.Wiktionary and zh.Wiktionary.

**`english` completeness gap found and fixed**: was `[lead on to]` only, missing the dual-source-attested primary conjunctive sense; added `thereupon`.

**`## Derived Characters` section added**: four real 形声 hits citing 爰 as phonetic component — [[characters/媛|媛]], [[characters/援|援]], [[characters/緩|緩]], [[characters/暖 (char)|暖 (char)]] — cross-checked via each page's own `graphemic_classification` field.

**Cross-reference typo found and fixed**: `Lookup/Radicals/Radical 087.md` glossed item 3 as "lean on to," inconsistent with both the character's own `english` field and its correct gloss ("lead on to") on `Lookup/SKIP/SKIP-2/SKIP-2-4-5.md`; corrected to "lead on to."

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 犀 (8537; 243 characters remaining).

### 2026-08-23, iteration 2262 — [[characters/犀|犀]]

`graphemic_classification: 尾` (dual-source confirmed 形声, semantic 牛 + phonetic 尾, OC \*sliːl) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 牛` reconfirmed correct — genuine listing (item 11, "+8 Strokes") on `Lookup/Radicals/Radical 093.md`. `cantonese: sai1` reconfirmed complete — both sources give only this one reading. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 370, corroborated directly by ja.Wiktionary's own status line. `stand_in: 犀牛` reconfirmed correct — sole genuine `characters:` citer is [[words/犀牛|犀牛]]; the second grep hit, [[words/牛|牛]], is a false-positive prose mention (犀牛 appearing only as an example compound in 牛's own etymology note), not a genuine citation. Already correctly cross-listed on `Lookup/SKIP/SKIP-3/SKIP-3-3-9.md` (item 6), `Lookup/Stroke/Stroke 12.md`, and `Lookup/Korean/Korean Name ㅅ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `1750` was actually 希's rank; correct rank for 犀 is `1751` (`CC 1000.md`: `1750. 希`, `1751. 犀`).

**`japanese_native` bug found and fixed — sentinel used despite genuine kun'yomi**: stored `ø` ("confirmed no kun'yomi"), but both en.Wiktionary and ja.Wiktionary independently attest two genuine kun'yomi tied to the "sharp; hard" sense — `かた-い` and `するど-い`; both added, correcting the sentinel.

**`english` completeness gap found and fixed**: was `[rhinoceros, rhino]` only; both en.Wiktionary and zh.Wiktionary independently attest a second genuine sense, "sharp" (cf. 犀利, 心有靈犀), corroborated by the newly-added kun'yomi; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the primary nominal sense "rhinoceros" (the character's sole bound Chinese usage, in 犀牛).

**`aliases` filled**: was blank. One genuine dual-source variant, [[屖]], cross-listed as 異體字/alternative form by both en.Wiktionary and zh.Wiktionary, with no independent page in this vault; added. A second candidate, the obscure never-adopted second-round-simplification form 𰠨, was left out — consistent with this session's established practice of excluding abolished/unused simplification-scheme forms.

**`## Derived Characters` section added**: one real 形声 hit citing 犀 as phonetic component — [[characters/遅 (char)|遅 (char)]] (traditional 遲; simplified 迟 replaces 犀 with 尺).

**Section-ordering bug found and fixed**: the `## Words` section appeared BEFORE the (malformed, wrong-heading-level) `# Notes` section — reversed from this vault's established Notes→Words→Derived-Characters convention (cf. `characters/丁 (char).md`); reordered, with the pre-existing `## Words` section (citing [[words/犀牛|犀牛]]) left otherwise untouched.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet, wrong section order relative to Words) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 狽 (8539; 242 characters remaining).

### 2026-08-23, iteration 2263 — [[characters/狽|狽]]

`graphemic_classification: 貝` (dual-source confirmed 形声, semantic 犬 + phonetic 貝, OC \*paːds) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 犬` reconfirmed correct — genuine listing (item 15) on `Lookup/Radicals/Radical 094.md`. `japanese: [HAI, BAI]` reconfirmed complete — both sources give only go-on/kan-on はい and the customary ばい. `japanese_native: ø` reconfirmed correct — neither source attests any kun'yomi. `vietnamese: [bái]` reconfirmed complete via hvdic.thivien.net (identical Âm Hán Việt and Âm Nôm). `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 210. `stand_in: 狼狽` reconfirmed correct — sole citer, the word's own independent page. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-3-7.md` (item 59), `Lookup/Stroke/Stroke 10.md`, and `Lookup/Korean/Korean Name ㅍ.md`. `mc_id: 6584` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`hsk_level` bug found and fixed — genuine level hiding under simplified sibling glyph**: stored `無`, matching a listing on `Lookup/HSK/HSK No.md`, but `Old HSK 6.md` has a genuine plain-numbered entry under the simplified sibling glyph 狈 (`432. [狈](../../characters/狽.md)`) — the colon-count entries on `Old HSK 4.md` (both 狈 and 狽) are not genuine and were correctly ignored. Corrected `hsk_level` to `6`, and removed the now-stale entry from `Lookup/HSK/HSK No.md`.

**`english` mistranslation found and fixed**: stored `[werewolf]` — genuinely wrong; both en.Wiktionary and zh.Wiktionary independently identify 狽 as a legendary wolf-like beast with short forelegs and long hind legs (the pair-creature of the idiom 狼狽, not a "werewolf" in any sense). Corrected to `[mythical wolf-like beast, distressed]` (the second sense being the idiom's genuine figurative extension). Propagated the same gloss fix to the two cross-reference pages that had copied the error verbatim — `Lookup/Radicals/Radical 094.md` (item 15) and `Lookup/SKIP/SKIP-1/SKIP-1-3-7.md` (item 59) — both now read "wolf-like beast." Note for the word-perfecting sweep: [[words/狼狽|狼狽]]'s own `english` field (`[werewolf, flustering, confusion]`) carries the same mistranslation and is out of scope for this character-perfecting pass.

**`pos` filled**: was blank. Filled as `名詞`, matching the primary nominal sense (naming the mythical creature).

**`aliases` completeness gap found and fixed**: had `狈` (simplified form) only; zh.Wiktionary's own 異體字 listing gives a second genuine variant, `䟺`, with no independent page in this vault; added.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format; `## Chengyu` (citing [[chengyu/周章狼狽|周章狼狽]], ruby verified against the chengyu's own `注音` field) reconfirmed correct, no changes. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 玲 (8541; 241 characters remaining).

### 2026-08-23, iteration 2264 — [[characters/玲|玲]]

`graphemic_classification: 令` (dual-source confirmed 形声, semantic 玉 + phonetic 令, OC \*reŋ) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 玉` reconfirmed correct — genuine listing (item 5) on `Lookup/Radicals/Radical 096.md`. `cantonese: ling4` reconfirmed complete — both sources give only this one reading. `japanese_native: ø` reconfirmed correct — ja.Wiktionary explicitly states 玲 has no standard kun'yomi, only 名乗り (name-only readings あきら/たま/れ, a distinct category this vault's `japanese_native` field doesn't cover). `korean_native: ""` reconfirmed correct — a purely Sino-Korean name character with no native gloss, consistent with 52 other pages using the same blank-string convention. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 373. `stand_in: 名専字` reconfirmed correct — zero hits for 玲 anywhere in `words/`. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-4-5.md` (item 26), and `Lookup/Korean/Korean Name ㄹ.md`. `mc_id: 6718` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`hsk_level` bug found and fixed**: stored `4`, traced only to a colon-count entry on `Old HSK 4.md` (`[[玲]]: 2`, not genuine) — no plain-numbered entry exists in any `Old HSK N.md` file, and `Lookup/HSK/HSK No.md` itself already correctly lists 玲 among characters confirmed to have no genuine HSK level. Corrected to `hsk_level: 無`.

**`japanese` typo found and fixed**: stored `[REI, ROU]` — `ROU` was a corrupted go-on reading, missing the ⟨y⟩; both ja.Wiktionary and en.Wiktionary give the genuine go-on as リョウ, romanized `RYOU` per this vault's established convention (cf. `characters/涼.md`, `characters/両 (char).md`). Corrected to `[REI, RYOU]`.

**`vietnamese` bug found and fixed — unattested reading**: stored `[lanh, leng, linh, liếng, lẻng]`; hvdic.thivien.net's genuine readings (1 Âm Hán Việt + 3 Âm Nôm) are exactly `linh, lanh, leng, liếng` — `lẻng` appears nowhere in the source and was removed as an unattested/fabricated reading (likely confusion with the unrelated onomatopoeia "leng keng").

**`english` accuracy gap found and fixed**: stored `[jade]` — this names the semantic radical, not the character's own meaning; both en.Wiktionary and zh.Wiktionary agree 玲 denotes the tinkling sound of jade, extended to "clever; exquisite." Corrected to `[tinkling of jade, clever]`. Propagated the same gloss correction to `Lookup/Radicals/Radical 096.md` (item 5) and `Lookup/SKIP/SKIP-1/SKIP-1-4-5.md` (item 26), both of which had copied the old "jade" gloss.

**`pos` filled**: was blank. Filled as `性詞`, matching the dominant adjectival modern sense ("clever, exquisite," as used in given names).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 玳 (8542; 240 characters remaining).

### 2026-08-23, iteration 2265 — [[characters/玳|玳]]

`graphemic_classification: 代` (dual-source confirmed 形声, semantic 玉 + phonetic 代, OC \*l'ɯːɡs) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 玉` reconfirmed correct — genuine listing (item 6) on `Lookup/Radicals/Radical 096.md`. `vietnamese: [đại, đồi]` reconfirmed complete and exact against en.Wiktionary (Hán Việt đại; Chữ Nôm đồi, đại). `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `stand_in: 玳瑁` reconfirmed correct — sole citer, the word's own independent page. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-4-5.md` (item 27) and `Lookup/Korean/Korean Name ㄷ.md`. `mc_id: 4865` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`joyo_level` filled**: was blank. Both ja.Wiktionary and en.Wiktionary confirm 玳 as 表外字; added as item 537 to `Lookup/Japanese/Hyōgai.md` and filled as `表外字`.

**`japanese` completeness gap found and fixed**: was `[TAI]` (kan-on) only; both ja.Wiktionary and en.Wiktionary independently attest a genuine go-on, `DAI`; added. A further candidate pair from en.Wiktionary alone (`どく`/`とく`, DOKU/TOKU) was left out — not corroborated by ja.Wiktionary, the authoritative source for Japanese readings, per this session's established dual-source practice.

**`japanese_native` bug found and fixed — compound reading mistaken for kun'yomi**: stored `たいまい`, but both en.Wiktionary and zh.Wiktionary are explicit that 玳 "is used only in 玳瑁" and has no standalone kun'yomi — たいまい is the reading of the two-character compound 玳瑁, not of 玳 alone (ja.Wiktionary independently lists no kun'yomi at all for this character). Corrected to the `ø` sentinel.

**`pos` filled**: was blank. Filled as `名詞`, matching the sole nominal sense (short form of 玳瑁, "hawksbill sea turtle").

**`aliases` filled**: was blank. One genuine dual-source variant, [[瑇]], cross-listed as 異體字/alternative form by both en.Wiktionary and zh.Wiktionary, with no independent page in this vault; added.

**`## Words` section added**: citing [[words/玳瑁|玳瑁]], ruby verified against the word's own `注音` field.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet, no `## Words` section) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 琥 (8544; 239 characters remaining).

### 2026-08-23, iteration 2266 — [[characters/琥|琥]]

`graphemic_classification: 虎` (dual-source confirmed 形声, semantic 玉 + phonetic 虎, OC \*qʰlaːʔ) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 玉` reconfirmed correct — genuine listing (item 20) on `Lookup/Radicals/Radical 096.md`. `vietnamese: [hổ]` reconfirmed complete and exact against hvdic.thivien.net (identical Âm Hán Việt and Âm Nôm). `japanese_native: ø` reconfirmed correct — ja.Wiktionary lists no kun'yomi. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 377. `english: [amber]` reconfirmed correct and deliberately narrow — zh.Wiktionary also attests historical "jade tally/ritual object" senses, but [[words/琥珀|琥珀]]'s own Notes already establish those senses aren't attested anywhere in this vault's data, so they were correctly left out. `stand_in: 琥珀` and the `cranberry` tag reconfirmed correct — sole citer [[words/琥珀|琥珀]] documents genuine transitivity (neither 琥 nor 珀 has independent life elsewhere, matching `korean_native` glosses). `aliases` (blank) reconfirmed correct — zh.Wiktionary attests no genuine variant forms distinct from 琥 itself. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-4-8.md` (item 26) and `Lookup/Korean/Korean Name ㅎ.md`. `mc_id: 5480` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`japanese` completeness gap found and fixed**: was `[KO]` (kan-on) only; both ja.Wiktionary and en.Wiktionary independently attest a genuine go-on, `KU`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the sole nominal sense (amber).

**`## Words` section added**: citing [[words/琥珀|琥珀]], ruby verified against the word's own `注音` field.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, a stray unlinked-format Words bullet folded into Notes instead of its own section, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 琳 (8545; 238 characters remaining).

### 2026-08-23, iteration 2267 — [[characters/琳|琳]]

`graphemic_classification: 林` (dual-source confirmed 形声, semantic 玉 + phonetic 林) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 玉` reconfirmed correct — genuine listing (item 21) on `Lookup/Radicals/Radical 096.md`. `japanese: [RIN]` reconfirmed complete — both sources give an identical go-on/kan-on りん. `vietnamese: [lam, lâm]` reconfirmed complete against en.Wiktionary's Hán Nôm readings. `korean: 림` reconfirmed correct as the North Korean/문화어 form (not the South Korean 두음법칙-shifted 임 that en.Wiktionary also notes). `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 254. `stand_in: 名専字` reconfirmed correct — zero hits for 琳 anywhere in `words/`. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-4-8.md` (item 27) and `Lookup/Korean/Korean Name ㄹ.md`. `mc_id: 4036` reconfirmed as trusted long-tail (just above the 4000-rank ceiling of `CC 3000.md`, not cross-checked per policy).

**`hsk_level` gap filled — genuinely absent, not just unfilled**: was the empty-string sentinel; thoroughly checked all four `Old HSK N.md` files and `Lookup/HSK/HSK No.md` and found zero hits for 琳 anywhere (unlike the usual bug pattern of a stale/wrong value, this character had simply never been indexed). Filled `hsk_level: 無` and added 琳 to `Lookup/HSK/HSK No.md`'s list.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal senses "jade; gem."

**`aliases` filled**: was blank. One genuine dual-source variant, [[玪]], cross-listed as an alternative form by both en.Wiktionary and zh.Wiktionary, with no independent page in this vault; added.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 琺 (8546; 237 characters remaining).

### 2026-08-23, iteration 2268 — [[characters/琺|琺]]

`graphemic_classification: 法` (dual-source confirmed 形声, semantic 玉 + phonetic 法) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 玉` reconfirmed correct — genuine listing (item 25) on `Lookup/Radicals/Radical 096.md`. `japanese: [HOU]` reconfirmed complete — both en.Wiktionary and ja.Wiktionary give only this one on'yomi. `japanese_native: ø` reconfirmed correct — ja.Wiktionary lists no kun'yomi. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `mc_id: 0` reconfirmed correct — genuinely absent from all four `CC N000.md` files. `pos: 名詞` and `aliases: [珐]` reconfirmed correct (simplified form, matching both sources). `stand_in: 琺瑯` reconfirmed correct — sole citer, the word's own independent page. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-4-8.md` (item 28) and `Lookup/Korean/Korean Name ㅂ.md`.

**`joyo_level` cross-reference gap found and fixed**: the field itself already correctly said `表外字` (confirmed genuine via ja.Wiktionary), but the character was missing from `Lookup/Japanese/Hyōgai.md` itself; added as item 538.

**`cantonese` completeness gap found and fixed**: stored `faat3` only; zh.Wiktionary independently attests a second genuine jyutping reading, `fat3` (also corroborated by en.Wiktionary), converting the field from scalar to list per the vault's multi-reading convention.

**`vietnamese` gap found and fixed — field left entirely empty**: both en.Wiktionary and hvdic.thivien.net attest a genuine Âm Hán Việt reading, `pháp`; added (the field previously had no value at all).

**`## Words` section added**: the pre-existing bare bullet citing [[words/琺瑯|琺瑯]] (ruby verified against the word's own `注音` field) was folded directly into the malformed `# Notes` block instead of its own section; separated out properly.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet, `## Words` content misplaced inside Notes) into the standard `## Notes` four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 瑁 (8547; 236 characters remaining).

### 2026-08-23, iteration 2269 — [[characters/瑁|瑁]]

`graphemic_classification: 冒` (dual-source confirmed 形声, semantic 玉 + phonetic 冒) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 玉` reconfirmed correct — genuine listing (item 27) on `Lookup/Radicals/Radical 096.md`. `cantonese: mou6` reconfirmed correct (the etymology-1 "ceremonial jade" reading; the unrelated etymology-2 mui6 belongs to a different, non-attested sense). `japanese_native: ø` reconfirmed correct — ja.Wiktionary lists no kun'yomi. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `pos: 名詞` reconfirmed correct. `aliases` (blank) reconfirmed correct — zh.Wiktionary's variant-form list (㺺, 𤣽, 𤲰, 蝐, 珼/𫞥, etc.) is entirely obscure/unencodable forms, consistent with this session's practice of excluding such forms. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-4-9.md` (item 22) and `Lookup/Korean/Korean Name ㅁ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `3732` was actually 凋's rank; correct rank for 瑁 is `3733` (`CC 3000.md`: `3732. 凋`, `3733. 瑁`).

**`stand_in` bug found and fixed**: stored `名専字` despite a genuine citer — [[words/玳瑁|玳瑁]]'s own `characters:` field lists both 玳 and 瑁. Corrected to `玳瑁`. Note: unlike the parallel [[characters/琥|琥]]/珀 pair (tagged `#cranberry`), 瑁 genuinely has an independent, non-bound sense (etymology 1, "ceremonial jade of the Son of Heaven") distinct from the compound's meaning, so the cranberry tag does not apply here — transitivity fails (瑁's independent meaning ≠ 玳瑁's meaning).

**`japanese` completeness gap found and fixed**: was `[BOU, MOU, MAI]`, missing a fourth genuine on'yomi; both ja.Wiktionary and en.Wiktionary independently attest go-on/kan-on `バイ` (BAI); added.

**`vietnamese` completeness gap found and fixed**: was `[mao, mùi, mạo, mồi]`; hvdic.thivien.net's genuine readings (2 Âm Hán Việt + 3 Âm Nôm) additionally include `mội`; added. A further candidate from en.Wiktionary alone, `mại`, was left out — not corroborated by hvdic, this vault's Vietnamese authority.

**`joyo_level` cross-reference gap found and fixed**: the field itself already correctly said `表外字` (confirmed genuine via ja.Wiktionary), but the character was missing from `Lookup/Japanese/Hyōgai.md` itself; added as item 539.

**`## Words` section added**: citing [[words/玳瑁|玳瑁]], ruby verified against the word's own `注音` field.

Rebuilt the malformed `## Notes` (missing SKIP/Stroke-format bullet consistency, unlinked bare-glyph references, no mc_id-rank bullet, no four-level-links bullet, two floating unlinked CC wikilinks, no `## Words` section) into the standard four-bullet format plus `## Words`. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 瑛 (8548; 235 characters remaining).

### 2026-08-23, iteration 2270 — [[characters/瑛|瑛]]

`graphemic_classification: 英` (dual-source confirmed 形声, semantic 玉 + phonetic 英) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 玉` reconfirmed correct — genuine listing (item 26) on `Lookup/Radicals/Radical 096.md`. `japanese: [EI, YOU]` reconfirmed complete — both en.Wiktionary and ja.Wiktionary give only kan-on えい and go-on よう. `japanese_native: ø` reconfirmed correct — both sources' kun'yomi are entirely 名乗り (name-only readings), not standard kun'yomi. `vietnamese: [anh]` reconfirmed complete — en.Wiktionary's sole reading. `korean: 영` reconfirmed correct (no 두음법칙 concern — the syllable doesn't begin with ㄹ/ㄴ). `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 238. `stand_in: 名専字` reconfirmed correct — zero hits for 瑛 anywhere in `words/`. `aliases: [瑩]` reconfirmed correct — 瑩 has no independent page and is explicitly redirected to 瑛 on both `Lookup/Korean/Korean Name ㅎ.md` ("瑩-->瑛") and `Korean Name ㅇ.md`. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-4-8.md` (item 29). `mc_id: 7338` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`english` completeness gap found and fixed**: was `[luster]` only; zh.Wiktionary independently attests a second genuine gloss, "crystal," corroborating en.Wiktionary's own "luster of jade; beautiful jade" senses; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal senses.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 甬 (8550; 234 characters remaining).

### 2026-08-23, iteration 2271 — [[characters/甬|甬]]

`graphemic_classification: 用` reconfirmed correct, but with a genuine three-way source conflict investigated and documented: zh.Wiktionary treats 甬 as 形声 with phonetic 用 (matching the stored value); en.Wiktionary instead claims 甬 is 象形, a bronze-bell pictograph whose lower part later became 用; ja.Wiktionary offers yet a third account (a purely decorative graphic variant of 用, not a standard etymological category at all). Kept `用` since only one source attests the pictograph theory. `radical: 用` reconfirmed correct — genuine listing (item 3) on `Lookup/Radicals/Radical 101.md`. `mc_id: 3150` reconfirmed exact match (`CC 3000.md`: `3149. 淹`, `3150. 甬`, `3151. 湎`). `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `stand_in: 名専字` reconfirmed correct — zero hits for 甬 anywhere in `words/`. `aliases` (blank) reconfirmed correct — zh.Wiktionary's "variant characters" 埇/筩 are contradicted by en.Wiktionary's explicit "no variant forms," and neither has an independent page in this vault to test against; left unadded absent stronger corroboration. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-2-5.md` (item 9) and `Lookup/Korean/Korean Name ㅇ.md`.

**`japanese` completeness gap found and fixed**: was `[YOU]` (kan-on) only; ja.Wiktionary directly attests a genuine go-on, `ユウ`, romanized `YUU` per this vault's convention (cf. `characters/又 (char).md`, `characters/幽 (char).md`); added. En.Wiktionary's claimed kun'yomi (つね/つかう/おどる) were NOT added — ja.Wiktionary, the authoritative source, explicitly lists no kun'yomi at all, so `japanese_native: ø` stands reconfirmed.

**`joyo_level` filled**: was blank. ja.Wiktionary directly confirms 甬 as 表外字; added as item 540 to `Lookup/Japanese/Hyōgai.md` and filled as `表外字`.

**`vietnamese` bug found and fixed**: stored `[dũng, giõng]`; hvdic.thivien.net's genuine readings are `dũng, dõng` — `giõng` appears nowhere in the source (likely a corruption of the genuine-but-missing `dõng`, which was also absent). Corrected to `[dũng, dõng]`.

**`english` completeness gap found and fixed**: was `[Yong River]` only; both en.Wiktionary and zh.Wiktionary independently attest a second genuine sense, "path" (a walled/screened walkway); added.

**`pos` filled**: was blank. Filled as `固有名詞`, matching this vault's established convention for river-name characters (cf. `characters/洛.md`, `characters/淮.md`).

**`## Derived Characters` section added**: seven real 形声 hits citing 甬 as phonetic component — [[characters/通 (char)|通]], [[characters/痛|痛]], [[characters/誦 (char)|誦]], [[characters/湧 (char)|湧]], [[characters/桶 (char)|桶]], [[characters/踊|踊]], [[characters/勇|勇]].

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 町 (8551; 233 characters remaining).

### 2026-08-23, iteration 2272 — [[characters/町|町]]

`graphemic_classification: 丁` (dual-source confirmed 形声, semantic 田 + phonetic 丁) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 田` reconfirmed correct — genuine listing (item 5) on `Lookup/Radicals/Radical 102.md`. `mc_id: 3710` reconfirmed exact match (`CC 3000.md`: `3710. 町`). `japanese: [CHOU, TEI]` reconfirmed complete — both en.Wiktionary and ja.Wiktionary give only go-on ちょう/kan-on てい. `japanese_native: まち` reconfirmed correct; a second candidate from en.Wiktionary alone (あぜみち) was left out — not corroborated by ja.Wiktionary, the authoritative source. `joyo_level: 1` reconfirmed correct — ja.Wiktionary directly confirms 町 as a Grade 1 kyōiku kanji, genuine at `Lookup/Japanese/Jōyō - Kyōiku.md` item 64. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-5-2.md` (item 12) and `Lookup/Korean/Korean Name ㅈ.md`.

**`stand_in` bug found and fixed — real citer buried among false positives**: stored `名専字`, but a `characters:`-field grep turned up four apparent hits; three ([[words/安土|安土]], [[words/中庭|中庭]], [[words/桃山|桃山]]) checked out as false-positive prose mentions (their own `characters:` fields cite unrelated constituents), but the fourth, [[words/室町|室町]], genuinely lists 町 in its `characters:` field. Corrected `stand_in` to `室町`.

**`cantonese` completeness gap found and fixed**: stored `ting2` (from the tǐng reading) only; both en.Wiktionary and zh.Wiktionary independently attest a second genuine jyutping reading, `ding1` (from the dīng reading), converting the field from scalar to list.

**`vietnamese` gap found and fixed — field left entirely empty**: hvdic.thivien.net attests two genuine Âm Hán Việt readings, `đinh` and `đỉnh`; added (en.Wiktionary's own candidate second reading, `thĩnh`, disagreed with hvdic and was not used, per this vault's practice of treating hvdic as the Vietnamese authority).

**`aliases` filled**: was blank. Two genuine variants added: [[圢]] (dual-source confirmed by en.Wiktionary and zh.Wiktionary, no independent page) and [[䵺]] (already independently documented as a redirect to 町 on this vault's own `Lookup/Radicals/Radical 206.md`, but never propagated to the character's own `aliases` field until now).

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal senses ("ridge between fields," "boundary").

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format; `## Words` (citing [[words/室町|室町]], ruby verified against the word's own `注音` field) reconfirmed correct, no changes. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 疱 (8552; 232 characters remaining).

### 2026-08-23, iteration 2273 — [[characters/疱|疱]]

`graphemic_classification: 包` (dual-source confirmed 形声, semantic 疒 + phonetic 包) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 疒` reconfirmed correct — genuine listing (item 2) on `Lookup/Radicals/Radical 104.md`. `cantonese: paau3` reconfirmed complete — both sources give only this one reading. `japanese_native: もがさ` reconfirmed correct; a second candidate from en.Wiktionary alone (にきび) was left out — ja.Wiktionary, the authoritative source, doesn't list it (and the word file [[words/面疱|面疱]]'s own Notes already correctly attribute にきび to the *word*, not the character). `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 182. `stand_in: 面疱` reconfirmed correct — sole citer, the word's own independent page. `aliases: [皰]` reconfirmed correct — the traditional form 疱 simplifies from, with no independent page in this vault. Already correctly cross-listed on `Lookup/SKIP/SKIP-3/SKIP-3-5-5.md` (item 1) and `Lookup/Korean/Korean Name ㅍ.md`. `mc_id: 9417` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`japanese` completeness gap found and fixed**: was `[HOU]` (kan-on) only; both en.Wiktionary and ja.Wiktionary independently attest a genuine go-on, `HYOU`; added.

**`vietnamese` completeness gap found and fixed**: was `[bào, bỏng]`; hvdic.thivien.net's genuine readings (2 Âm Hán Việt + 2 Âm Nôm) additionally include a second Âm Hán Việt, `pháo`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the sole nominal sense (acne).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format; `## Words` (citing [[words/面疱|面疱]], ruby verified against the word's own `注音` field) reconfirmed correct, no changes. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 疽 (8553; 231 characters remaining).

### 2026-08-23, iteration 2274 — [[characters/疽|疽]]

`graphemic_classification: 且` (dual-source confirmed 形声, semantic 疒 + phonetic 且) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 疒` reconfirmed correct — genuine listing (item 4) on `Lookup/Radicals/Radical 104.md`. `cantonese: zeoi1` reconfirmed correct and complete — en.Wiktionary's claimed second reading `ceoi1` isn't corroborated by zh.Wiktionary, which gives only `zeoi1`; left unadded. `japanese: [SHO, SO]` reconfirmed complete — both sources give only kan-on しょ/go-on そ. `vietnamese: [thư]` reconfirmed complete and exact against hvdic.thivien.net. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 268. `stand_in: 用疽` reconfirmed correct — sole citer, the word's own independent page. `aliases` (blank) reconfirmed correct — neither source lists any variant forms. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅈ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `2810` was actually 抽's rank; correct rank for 疽 is `2811` (`CC 2000.md`: `2810. 抽`, `2811. 疽`).

**注音 three-way inconsistency found and fixed — genuine bug isolated**: the character's own `注音` field (`ㄐㄜ`) matched this vault's own carefully-dated `Lookup/CC/finals/韻 魚.md` analysis page (2026-07-10, which explicitly places 疽 as a ㄐ-initial singleton on the **ㄜ** sub-final, distinct from the ㄙ-initial cluster discussed in that page's phonology notes), but two derivative cross-references had drifted to the stale/wrong `ㄐㄛ`: `Lookup/SKIP/SKIP-3/SKIP-3-5-5.md` (item 3) and [[words/用疽|用疽]]'s own `注音` field (`⼄ㄫㄐㄛ`, predating the finals-page analysis by several months). Corrected both to `ㄐㄜ`.

**`japanese_native` completeness gap found and fixed**: was `かさ` only; ja.Wiktionary independently attests a second genuine kun'yomi, `はれもの`; added, converting the field to a list.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal senses (ulcer, abscess).

Rebuilt the malformed `## Notes` (bare unlinked "requires" line instead of a proper `## Words` section, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet, two floating unlinked CC wikilinks) into the standard `## Notes` four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 瘡 (8554; 230 characters remaining).

### 2026-08-23, iteration 2275 — [[characters/瘡|瘡]]

`graphemic_classification: 倉` (dual-source confirmed 形声, semantic 疒 + phonetic 倉, OC \*sʰraŋ, sharing its word origin with 創) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 疒` reconfirmed correct — genuine listing (item 18) on `Lookup/Radicals/Radical 104.md`. `japanese: [SOU, SHOU]` reconfirmed complete — both sources give only go-on しょう/kan-on そう. `japanese_native: かさ` reconfirmed correct; a second candidate from en.Wiktionary alone (くさ) was left out — not corroborated by ja.Wiktionary, the authoritative source. `vietnamese: [sang]` reconfirmed complete and exact against hvdic.thivien.net. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 226. `aliases: [疮]` reconfirmed correct and complete — zh.Wiktionary's second listed variant, 創, already has its own robust independent page in this vault and fails the "no independent use" alias test, so correctly excluded. `stand_in: 瘡口` reconfirmed correct — of three apparent citers, only [[words/瘡口|瘡口]]'s own `characters:` field genuinely lists 瘡; [[words/窓口|窓口]] and [[words/潰瘍|潰瘍]] were false-positive hits (unrelated `characters:` fields). Already correctly cross-listed on `Lookup/SKIP/SKIP-3/SKIP-3-5-10.md` (item 1) and `Lookup/Korean/Korean Name ㅊ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `2966` was actually 膀's rank; correct rank for 瘡 is `2967` (`CC 2000.md`: `2966. 膀`, `2967. 瘡`).

**`hsk_level` bug found and fixed**: stored `4`, traced only to colon-count entries on `Old HSK 4.md` (both `[疮]: 1` and `[[瘡]]: 1`, neither genuine) — thoroughly checked all four `Old HSK N.md` files and found no genuine plain-numbered entry anywhere, and 瘡 was also entirely absent from `Lookup/HSK/HSK No.md`. Corrected to `hsk_level: 無` and added 瘡 to `Lookup/HSK/HSK No.md`'s list.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal senses (wound, sore).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet, `## Words` placed before Notes instead of after) into the standard `## Notes` four-bullet format, reordered before the pre-existing `## Words` section (citing [[words/瘡口|瘡口]], ruby verified against the word's own `注音` field). Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 皓 (8556; 229 characters remaining).

### 2026-08-23, iteration 2276 — [[characters/皓|皓]]

`graphemic_classification: 告` (dual-source confirmed 形声, semantic 白 + phonetic 告) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 白` reconfirmed correct — genuine listing (item 8) on `Lookup/Radicals/Radical 106.md`. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 385. `stand_in: 名専字` reconfirmed correct — the sole grep hit, [[words/好|好]], is a false-positive prose mention (皓 listed only among a homophone-survey of ㄏㄚㄨ-reading characters, its own Notes explicitly confirming none has a self-pointing `stand_in`), not a genuine citation. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-5-7.md` (item 3).

**`mc_id` off-by-one bug found and fixed**: stored `2513` was actually 諧's rank; correct rank for 皓 is `2514` (`CC 2000.md`: `2513. 諧`, `2514. 皓`).

**`cantonese` completeness gap found and fixed**: stored `hou6` only; both en.Wiktionary and zh.Wiktionary independently attest a second genuine (rarer) jyutping reading, `gou2`; added.

**`japanese` completeness gap found and fixed**: was `[KOU]` (kan-on) only; both ja.Wiktionary and en.Wiktionary independently attest a genuine go-on, `GOU`; added.

**`japanese_native` bug found and fixed**: stored `しろ`, a truncated fragment missing both its okurigana and a second reading — both ja.Wiktionary and en.Wiktionary agree on two genuine kun'yomi, `しろい` and `ひかる`; corrected to both, full forms.

**`vietnamese` completeness gap found and fixed**: was `[hạo]` only; hvdic.thivien.net's genuine readings additionally include two further Âm Hán Việt, `cáo` and `cảo`; added.

**`aliases` filled**: was blank. Three genuine dual-source variants — [[晧]], [[暠]], [[皜]] (both en.Wiktionary and zh.Wiktionary agree on all three) — none with independent pages in this vault; added. A fourth single-sourced candidate from en.Wiktionary alone, 㬶, was left out. Propagated the fix to `Lookup/Korean/Korean Name ㅎ.md`, where 晧 had been sitting as an un-redirected bare entry; converted to the established `晧-->皓` redirect notation (cf. `甬`/`瑩`'s redirect on the same page style).

**`pos` filled**: was blank. Filled as `性詞`, matching the adjectival senses ("luminous, clear, bright white").

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 睾 (8557; 228 characters remaining).

### 2026-08-23, iteration 2277 — [[characters/睾|睾]]

`graphemic_classification: 幸` reconfirmed correct, with a genuine source conflict investigated and documented: zh.Wiktionary corroborates 幸 (a character series derived from it, matching the stored value), while en.Wiktionary instead names 皋 as phonetic and treats 睾 as an alternative form of 皋 entirely, not even attesting the "testicle" sense (which comes solely from zh.Wiktionary). Kept `幸` since it's the source that actually accounts for this page's bound modern meaning. `radical: 目` reconfirmed correct — genuine listing (item 20) on `Lookup/Radicals/Radical 109.md`. `cantonese: gou1` and `vietnamese: [cao]` reconfirmed complete against en.Wiktionary and hvdic.thivien.net respectively. `japanese: [KOU]` reconfirmed complete — both on'yomi (go-on and kan-on) share the identical reading こう. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 119. `stand_in: 睾丸` reconfirmed correct — of two apparent citers, only [[words/睾丸|睾丸]] genuinely cites 睾 in its `characters:` field; [[words/高|高]] was a false-positive prose mention (its own Notes explicitly confirm 睾 has no self-pointing `stand_in`). Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-6-8.md` (item 1) and `Lookup/Korean/Korean Name ㄱ.md`. `mc_id: 7262` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`japanese_native` bug found and fixed — sentinel used despite genuine kun'yomi**: stored `ø` ("confirmed no kun'yomi"), but both en.Wiktionary and ja.Wiktionary independently attest two genuine kun'yomi, `さわ` and `きんたま`; both added. Two further single-sourced candidates from ja.Wiktionary alone (さつき, おお) were left out — not corroborated by en.Wiktionary.

**`aliases` filled**: was blank. Two genuine dual-source variants — [[睪]] (the traditional form, still used in modern Taiwan per en.Wiktionary) and [[皋]] (explicitly listed as 異體字 by zh.Wiktionary) — neither with an independent page in this vault; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the sole bound sense (testicle).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, a bare unlinked-format Words bullet folded into Notes instead of its own section, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 瞼 (8558; 227 characters remaining).

### 2026-08-23, iteration 2278 — [[characters/瞼|瞼]]

`graphemic_classification: 㑒` investigated and reconfirmed correct — both en.Wiktionary and zh.Wiktionary name the textbook phonetic component as 僉, but this vault's own [[characters/㑒|㑒]] page lists 僉 in its own `aliases` field (pointing to 㑒 as the parent form), so citing the parent-form page 㑒 here is the correct application of this vault's established alias-citation convention, not a bug. `radical: 目` reconfirmed correct — genuine listing (item 28) on `Lookup/Radicals/Radical 109.md`. `japanese: [KEN]` reconfirmed complete — both sources give an identical single on'yomi. `japanese_native: まぶた` reconfirmed correct; a second candidate from en.Wiktionary alone (まなぶた) was left out — not corroborated by ja.Wiktionary, the authoritative source. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 103. `stand_in: 眼瞼` and `aliases: [睑]` reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-5-13.md` (item 2) and `Lookup/Korean/Korean Name ㄱ.md`. `mc_id: 10070` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`cantonese` completeness gap found and fixed**: stored `gim2` only; both en.Wiktionary and zh.Wiktionary independently attest a second genuine jyutping reading, `lim4`; added.

**`vietnamese` bug found and fixed — unattested readings mixed with a genuine gap**: stored `[him, kiểm, kèm, kẻm, lim]`; hvdic.thivien.net's genuine readings are exactly `kiểm, kèm, lim` — `him` appears in neither source (clear fabrication/typo) and `kẻm` is attested only by en.Wiktionary, not hvdic (this vault's Vietnamese authority); both removed, leaving the three hvdic-confirmed readings.

**`pos` filled**: was blank. Filled as `名詞`, matching the sole nominal sense (eyelid).

**Missing reverse cross-reference found and fixed**: [[characters/㑒|㑒]]'s own `### Descendants` list (which already tracked [[characters/検|検]] and [[characters/鹸 (char)|鹸]] as phonetic descendants) was missing 瞼 itself; added.

Rebuilt the malformed `## Notes` (two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard four-bullet format; `## Words` (citing [[words/眼瞼|眼瞼]], ruby verified against the word's own `注音` field) reconfirmed correct, no changes. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 砦 (8559; 226 characters remaining).

### 2026-08-23, iteration 2279 — [[characters/砦|砦]]

`graphemic_classification: 此` (dual-source confirmed 形声, semantic 石 + phonetic 此, OC \*zraːds) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 石` reconfirmed correct — genuine listing (item 10) on `Lookup/Radicals/Radical 112.md`. `japanese_native: とりで` reconfirmed complete. `vietnamese: [trại]` reconfirmed complete and exact against hvdic.thivien.net. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 387. `stand_in: 鹿砦` reconfirmed correct — sole citer, the word's own independent page. `aliases` (blank) reconfirmed correct — en.Wiktionary's candidates 塁 and 寨 both already have independent pages in this vault (塁.md, 寨.md), failing the alias test regardless of zh.Wiktionary's narrower single-variant claim (寨 only). Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-6-5.md` (item 3) and `Lookup/Korean/Korean Name ㅊ.md`. `mc_id: 9194` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`japanese` completeness gap found and fixed**: was `[SAI]` (kan-on) only; both ja.Wiktionary and en.Wiktionary independently attest a genuine go-on, `ZE`; added.

**`english` completeness gap found and fixed**: was `[abatis]` only; both en.Wiktionary and zh.Wiktionary independently attest the character's actual primary senses, "fort" (stockade) and "brothel" — abatis is a narrower military term that happens to match the bound compound 鹿砦's specific sense but understates the character's own broader meaning; added both.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal senses.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet, no `## Words` section) into the standard `## Notes` four-bullet format plus a `## Words` section citing [[words/鹿砦|鹿砦]] with ruby verified against the word's own `注音` field. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 磊 (8561; 225 characters remaining).

### 2026-08-23, iteration 2280 — [[characters/磊|磊]]

`graphemic_classification: 會意` (dual-source confirmed ideogrammic triplication of 石, "pile of rocks") reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 石` reconfirmed correct — genuine listing (item 26) on `Lookup/Radicals/Radical 112.md`. `japanese: [RAI]` reconfirmed complete — both go-on and kan-on share the identical reading らい. `japanese_native: ø` reconfirmed correct — ja.Wiktionary explicitly lists no kun'yomi. `cantonese: leoi5` and `korean: 뢰` (the North Korean/문화어 form, not the South Korean 두음법칙-shifted 뇌) reconfirmed correct. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `pos: 名詞` reconfirmed correct. `stand_in: 名専字` reconfirmed correct — zero hits for 磊 anywhere in `words/`. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-5-10.md` (item 1) and `Lookup/Korean/Korean Name ㄹ.md`. `mc_id: 5446` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`vietnamese` major bug found and fixed — four unattested readings mixed into a real 11-reading set**: stored 15 readings; cross-checked every one against hvdic.thivien.net (this vault's Vietnamese authority) and en.Wiktionary. Eleven are genuine (1 Âm Hán Việt `lỗi` + 10 Âm Nôm: `dội, giỏi, lẫn, lòi, lối, rủi, sói, trọi, trổi, xổi`, all confirmed by hvdic). Four — `lọi, lỏi, sõi, sỏi` — appear in neither source (not even `sõi`, which does appear in en.Wiktionary's Nôm list but not hvdic's, so was dropped per this session's practice of treating hvdic as authoritative on conflicts) and were removed as fabrications/typos.

**`joyo_level` cross-reference gap found and fixed**: the field itself already correctly said `表外字` (confirmed genuine via ja.Wiktionary), but the character was missing from `Lookup/Japanese/Hyōgai.md` itself; added as item 541.

**`english` completeness gap found and fixed**: was `[pile of rocks]` only; both en.Wiktionary and zh.Wiktionary independently attest a second genuine sense, "great; magnificent" (also underlying the figurative "open and honest" of 磊落); added.

**`aliases` filled**: was blank. Two genuine dual-source variants, [[磥]] and [[礌]] (both en.Wiktionary and zh.Wiktionary agree), neither with an independent page in this vault; added.

Rebuilt the malformed `## Notes` (unlinked bare "Components" bullet instead of a proper etymology bullet, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 禼 (8562; 224 characters remaining).

### 2026-08-23, iteration 2281 — [[characters/禼|禼]]

`graphemic_classification: 象形` (dual-source confirmed pictograph of a worm/insect) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 禸` reconfirmed correct — genuine listing (item 3) on `Lookup/Radicals/Radical 114.md`. `cantonese: sit3` reconfirmed correct. `japanese: [SETSU]`/`japanese_native: ø` left unchanged — 禼 is too obscure to appear on ja.Wiktionary at all (404), and weblio.jp explicitly flags it as "not commonly used in Japanese" without giving readings, so neither confirming nor overturning the existing value was possible; `joyo_level` correspondingly stays blank rather than guessing 表外字, now with that reasoning documented in Notes rather than left silent. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `stand_in: 名専字` reconfirmed correct — the sole grep hit, [[words/舌|舌]], is a false-positive prose mention (禼 listed only among a homophone-survey of ㄙㄝㄊ-reading characters, its own Notes explicitly confirming none has a self-pointing `stand_in`), not a genuine citation. `aliases` (blank) reconfirmed correct — both sources' listed historical variants (𥜽, 𥝁, 𠨄, 𠨁, 𠨆, 𠨈) are too obscure/unencodable, consistent with this session's established exclusion practice. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-7-5.md` (item 3) and `Lookup/Korean/Korean Name ㅅ.md`. `mc_id: 6012` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`english` accuracy bug found and fixed**: stored `[old names]`, an inaccurate gloss; both en.Wiktionary and zh.Wiktionary agree the primary sense is "a type of worm/insect" — corrected to `[insect]`. Both sources separately note 禼 as an ancient form of [[偰]] (an already-independent character in this vault, not merged), which is the likely source of the old "names" framing but isn't itself the character's primary meaning. Propagated the gloss fix to `Lookup/Radicals/Radical 114.md` (item 3) and `Lookup/SKIP/SKIP-2/SKIP-2-7-5.md` (item 3), both of which had copied the old gloss.

**`vietnamese` gap found and fixed — field left entirely empty**: hvdic.thivien.net attests a genuine Âm Hán Việt reading, `tiết`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (insect).

**`## Derived Characters` section added**: one real 形聲 hit citing 禼 as phonetic component — [[characters/窃|窃]] ("to steal").

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 秉 (8563; 223 characters remaining).

### 2026-08-23, iteration 2282 — [[characters/秉|秉]]

`graphemic_classification: 會意` (dual-source confirmed, [[禾]] "plant" + [[又]] "hand," a hand holding a plant by the stalk) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 禾` reconfirmed correct — genuine listing (item 5) on `Lookup/Radicals/Radical 115.md`. `cantonese: bing2`, `vietnamese: [bảnh, bỉnh]`, `korean: 병` all reconfirmed complete and correct against en.Wiktionary. `mc_id: 1245` reconfirmed exact match (`CC 1000.md`: `1245. 秉`). `stand_in: 名専字` reconfirmed correct — the sole grep hit, [[words/柄国|柄国]], cites `characters: ["柄 (char)", 国]`, not 秉 itself (秉國 appears only in that word's `aliases` field as an alternate spelling, not a genuine constituent citation). `aliases` (blank) reconfirmed correct — en.Wiktionary explicitly denies any variant forms while zh.Wiktionary lists four (㨀, 抦, 柄, 棅); given the direct contradiction and that 柄 already has independent use in this vault, left unadded pending stronger corroboration. Already correctly cross-listed on `Lookup/SKIP/SKIP-4/SKIP-4-8-3.md` (item 4) and `Lookup/Korean/Korean Name ㅂ.md`.

**`hsk_level` bug found and fixed**: stored `4`, traced only to a colon-count entry on `Old HSK 4.md` (`[[秉]]: 1`, not genuine) — no plain-numbered entry exists in any `Old HSK N.md` file, and `Lookup/HSK/HSK No.md` itself already correctly lists 秉 among characters confirmed to have no genuine HSK level. Corrected to `hsk_level: 無`.

**`japanese` completeness gap found and fixed**: was `[HEI]` (kan-on) only; both ja.Wiktionary and en.Wiktionary independently attest a genuine go-on, `HYOU`; added.

**`japanese_native` bug found and fixed**: stored `と`, a truncated fragment; both en.Wiktionary and ja.Wiktionary agree on the genuine kun'yomi `とる`; corrected. Several further single-sourced candidates from ja.Wiktionary alone (いなたばり, いねたば, え, まもる) were left out — not corroborated by en.Wiktionary.

**`joyo_level` filled**: was blank. ja.Wiktionary directly confirms 秉 as 表外字; added as item 542 to `Lookup/Japanese/Hyōgai.md` and filled as `表外字`.

**`english` completeness gap found and fixed**: was `[bundle]` only; both en.Wiktionary and zh.Wiktionary independently attest further genuine senses, "to grasp; to hold" and "authority"; added as `grasp` and `authority`.

**`pos` filled**: was blank. Filled as `事詞`, matching the dominant verbal senses ("to grasp, to hold, to preside over").

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 郎 (8564; 222 characters remaining).

### 2026-08-23, iteration 2283 — [[characters/郎|郎]]

`graphemic_classification: 良` (dual-source confirmed 形声, semantic 邑 + phonetic 良) reconfirmed correct via en.Wiktionary and zh.Wiktionary — but the page's own malformed Notes bullet had the semantic/phonetic roles reversed ("semantic 良 + phonetic 邑"), fixed to match the field. `radical: 邑` reconfirmed correct — genuine listing (item 12) on `Lookup/Radicals/Radical 163.md`. `japanese: [ROU]` reconfirmed complete — both sources give an identical go-on/kan-on ろう. `japanese_native: おとこ` reconfirmed correct; three further single-sourced candidates from ja.Wiktionary alone (とう, もん, いら) were left out — not corroborated by en.Wiktionary. `mc_id: 499` reconfirmed exact match (`CC 0000.md`: `499. 郎`). `joyo_level: 高等` reconfirmed correct — genuine at `Lookup/Japanese/Jōyō - Kōtō.md` item 2124. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-6-3.md` (item 16) and `Lookup/Korean/Korean MS.md`.

**`stand_in` bug found and fixed — real citers hiding among five false positives**: stored `名専字` despite the page's own malformed Notes already loosely citing [[words/牛郎星|牛郎星]] and [[words/牛郎|牛郎]] as bound compounds. Ran a full `characters:`-field check on all seven grep hits: [[words/牛郎|牛郎]] and [[words/牛郎星|牛郎星]] genuinely cite 郎; [[words/銀河|銀河]], [[words/織女|織女]], [[words/牛|牛]], [[words/弓道|弓道]], and [[words/瘋顚|瘋顚]] were all false-positive prose mentions. Corrected `stand_in` to `牛郎`.

**`hsk_level` bug found and fixed**: stored `2`, traced only to colon-count entries on `Old HSK 2.md` and `Old HSK 4.md` (neither genuine). `Old HSK 6.md` has a genuine plain-numbered entry (`460. [[郎]]`); corrected to `hsk_level: 6`.

**`vietnamese` bug found and fixed**: stored 7 readings; hvdic.thivien.net's genuine readings are exactly `lang, loang, loen, sang` — the other three (`loẻn, lảng, lẳng`) appear in neither hvdic nor en.Wiktionary and were removed as unattested.

**`aliases` completeness gap found and fixed**: had `郞` (already correct) only; both en.Wiktionary and zh.Wiktionary independently attest a second genuine variant, `郒`, with no independent page in this vault; added. A third single-sourced candidate from en.Wiktionary alone, 𨝥, was left out.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal senses.

**`## Derived Characters` completeness gap found and fixed**: the malformed notes listed only [[characters/螂|螂]]; a full grep turned up two further genuine 形声 hits citing 郎 as phonetic — [[characters/廊|廊]] and [[characters/榔|榔]]; added.

Rebuilt the malformed `## Notes` (reversed semantic/phonetic roles, a stray "Derived characters" sub-heading with no proper `##` section, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet, `## Words` bullets folded loosely into Notes) into the standard `## Notes` four-bullet format plus proper `## Words` and `## Derived Characters` sections. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 訛 (8565; 221 characters remaining).

### 2026-08-23, iteration 2284 — [[characters/訛|訛]]

`graphemic_classification: 化` (dual-source confirmed 形声, semantic 言 + phonetic 化, OC \*hŋʷraːls) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 言` reconfirmed correct — genuine listing (item 10) on `Lookup/Radicals/Radical 149.md`. `japanese: [KA, GA]` reconfirmed complete — both sources give go-on/kan-on が (GA) and kan'yō-on か (KA). `korean: 와` reconfirmed correct. `stand_in: 名専字` reconfirmed correct — zero hits for 訛 anywhere in `words/`. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-7-4.md` (item 10) and `Lookup/Korean/Korean Name ㅇ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `3295` was actually 駙's rank; correct rank for 訛 is `3296` (`CC 3000.md`: `3295. 駙`, `3296. 訛`).

**`hsk_level` bug found and fixed**: stored `4`, traced only to colon-count entries on `Old HSK 4.md` (both `[讹]: 1` and `[[訛]]: 1`, neither genuine) — thoroughly checked all four `Old HSK N.md` files and found no genuine plain-numbered entry anywhere, and 訛 was also entirely absent from `Lookup/HSK/HSK No.md`. Corrected to `hsk_level: 無` and added 訛 to `Lookup/HSK/HSK No.md`'s list.

**`joyo_level` filled**: was blank. ja.Wiktionary directly confirms 訛 as 表外字; added as item 543 to `Lookup/Japanese/Hyōgai.md` and filled as `表外字`.

**`japanese_native` bug found and fixed**: stored `あやま`, a truncated fragment; both en.Wiktionary and ja.Wiktionary agree on three genuine kun'yomi, `なまる`, `なまり`, `あやまる`; corrected to all three, full forms.

**`vietnamese` bug found and fixed**: stored `[ngoa, ngoả]`; hvdic.thivien.net's sole genuine reading (identical Âm Hán Việt and Âm Nôm) is `ngoa` — `ngoả` traced only to en.Wiktionary, which itself presented it ambiguously ("ngỏa/ngoả"), and wasn't corroborated by hvdic; removed.

**`aliases` completeness gap found and fixed**: had `讹` (simplified form) only; both en.Wiktionary and zh.Wiktionary independently attest two further genuine variants, `吪` and `䚰`, neither with an independent page in this vault; added. A third single-sourced candidate from zh.Wiktionary alone, 譌, was left out.

**`pos` filled**: was blank. Filled as `事詞`, matching the dominant verbal sense ("to swindle, cheat, deceive, extort").

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 稜 (8567; 220 characters remaining).

### 2026-08-23, iteration 2285 — [[characters/稜|稜]]

`graphemic_classification: 夌` (dual-source confirmed 形声, semantic 禾 + phonetic 夌) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 禾` reconfirmed correct — genuine listing (item 20) on `Lookup/Radicals/Radical 115.md`. `cantonese: ling4` reconfirmed correct and complete — en.Wiktionary's claimed second reading `ling6` isn't corroborated by zh.Wiktionary, which gives only `ling4`; left unadded. `korean: 릉` reconfirmed correct (the North Korean/문화어 form, not the South Korean 두음법칙-shifted 능). `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 392. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-5-8.md` (item 12) and `Lookup/Korean/Korean Name ㄹ.md`. `mc_id: 4473` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`stand_in` bug found and fixed**: stored `名専字` despite a genuine citer — of three apparent hits, only [[words/三稜鏡|三稜鏡]]'s own `characters:` field genuinely lists 稜 ([[words/塑膠|塑膠]] and [[words/下痢|下痢]] were false-positive prose mentions). Corrected `stand_in` to `三稜鏡`.

**`japanese` completeness gap found and fixed**: was `[RYOU]` (the kan'yō-on/conventional reading) only; both en.Wiktionary and ja.Wiktionary independently attest a genuine go-on/kan-on, `ROU`; added.

**`japanese_native` completeness gap found and fixed**: was `いつ` only (genuine, not truncated); both sources independently attest a second genuine kun'yomi, `かど`; added.

**`vietnamese` completeness gap found and fixed**: was `[lăng]` only; hvdic.thivien.net's genuine readings additionally include a second Âm Hán Việt, `lắng`; added.

**`aliases` filled**: was blank. One genuine dual-source variant, [[棱]] (the simplified form, explicitly listed as 異體字 by zh.Wiktionary and as "Simplified: 棱" by en.Wiktionary), with no independent page in this vault; added. A second single-sourced candidate from en.Wiktionary alone, 楞, was left out (楞 also already sits unredirected on `Lookup/Korean/Korean Name ㄹ.md`, but without dual-source confirmation it wasn't converted to a redirect).

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal senses.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet, no `## Words` section) into the standard `## Notes` four-bullet format plus a `## Words` section citing [[words/三稜鏡|三稜鏡]] with ruby verified against the word's own `注音` field. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 窩 (8569; 219 characters remaining).

### 2026-08-23, iteration 2286 — [[characters/窩|窩]]

`graphemic_classification: 咼` (dual-source confirmed 形聲, semantic 穴 + phonetic 咼, OC \*kʰʷroːl) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 穴` reconfirmed correct — genuine listing (item 15) on `Lookup/Radicals/Radical 116.md`. `japanese: [KA, WA]` reconfirmed complete — both sources give go-on/kan-on わ (WA) and kan'yō-on か (KA). `japanese_native: むろ` reconfirmed correct and complete. `vietnamese: [oa]` reconfirmed correct and complete against hvdic.thivien.net — en.Wiktionary's claimed "ổ" wasn't corroborated by hvdic (this vault's authority) and was correctly left out already. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 17. `mc_id: 0` reconfirmed correct — genuinely absent from all four `CC N000.md` files. `stand_in: 名専字` reconfirmed correct — zero hits for 窩 anywhere in `words/`. `aliases: [窝]` reconfirmed correct — a second single-sourced candidate from zh.Wiktionary alone, 䆧, wasn't corroborated by en.Wiktionary and was left out. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-11.md` (item 8) and `Lookup/Korean/Korean Name ㅇ.md`.

**`hsk_level` bug found and fixed**: stored `4`, traced only to colon-count entries on `Old HSK 4.md` (both `[窝]: 2` and `[[窩]]: 2`, neither genuine). `Old HSK 6.md` has a genuine plain-numbered entry (`371. [窝]`); corrected to `hsk_level: 6`.

**`english` completeness gap found and fixed**: was `[fossa]` only, an unusually narrow anatomical-loan gloss for what both en.Wiktionary and zh.Wiktionary attest as much broader core senses; added `nest` and `cave`.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal senses.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 筍 (8571; 218 characters remaining).

### 2026-08-23, iteration 2287 — [[characters/筍|筍]]

`graphemic_classification: 旬` (dual-source confirmed 形聲, semantic 竹 + phonetic 旬, OC \*sqʰʷinʔ) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 竹` reconfirmed correct — genuine listing (item 15) on `Lookup/Radicals/Radical 118.md`. `japanese: [JUN, SHUN]` reconfirmed complete — matches ja.Wiktionary's kan'yō-on ジュン and go-on/kan-on シュン exactly. `mc_id: 4606` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `stand_in: 竹筍` reconfirmed correct — sole citer, the word's own independent page. `aliases: [笋, 荀]` reconfirmed correct — 荀 has no independent page and `Lookup/Korean/Korean Name ㅅ.md` already explicitly points its own `[荀]` entry directly at `characters/筍.md`, corroborating the alias internally. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-6-6.md` (item 8).

**`hsk_level` bug found and fixed**: stored `4`, traced only to colon-count entries on `Old HSK 4.md` (both `[笋]: 1` and `[[筍]]: 1`, neither genuine) — thoroughly checked all four `Old HSK N.md` files and found no genuine plain-numbered entry anywhere, and 筍 was also entirely absent from `Lookup/HSK/HSK No.md`. Corrected to `hsk_level: 無` and added 筍 to `Lookup/HSK/HSK No.md`'s list.

**`joyo_level` filled**: was blank. ja.Wiktionary directly confirms 筍 as 表外字; added as item 544 to `Lookup/Japanese/Hyōgai.md` and filled as `表外字`.

**`japanese_native` completeness gap found and fixed**: was `たかんな` only; both en.Wiktionary and ja.Wiktionary independently attest a second genuine kun'yomi, `たけのこ` (also this page's own `english` gloss, "bamboo shoot"); added.

**`vietnamese` major bug found and fixed — malformed field plus a large completeness gap**: stored as a single un-listified string `duẩn duẫn` (a YAML formatting bug, not a proper list); hvdic.thivien.net's genuine readings are six in total — `duẩn, duẫn, tuân, tuẩn, tuận, tấn` — corrected to a proper list with all six. En.Wiktionary's own candidates (sũn, hũn) weren't corroborated by hvdic and were left out.

Rebuilt the malformed `## Notes`/`## Words` ordering (Words appeared before the wrong-heading-level `# Notes`, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard Notes-then-Words convention. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 箏 (8572; 217 characters remaining).

### 2026-08-23, iteration 2288 — [[characters/箏|箏]]

`graphemic_classification: 争` (dual-source confirmed 形声, semantic 竹 + phonetic 爭/争, OC \*ʔsreːŋ) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 竹` reconfirmed correct — genuine listing (item 22) on `Lookup/Radicals/Radical 118.md`. `japanese: [SOU, SHOU]` and `japanese_native: こと` reconfirmed complete — both sources agree exactly. `vietnamese: [giành, tranh]` reconfirmed complete and exact against hvdic.thivien.net. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md`. `korean_native: 쟁` (identical to the Sino-Korean reading) reconfirmed plausible — a specialized loanword-instrument character with no distinct native Korean gloss, consistent with similar cases; not flagged without contrary evidence. `stand_in: 古箏` reconfirmed correct — sole citer, the word's own independent page. `aliases: [筝]` reconfirmed correct (simplified form, matching both sources). Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-6-8.md` (item 3) and `Lookup/Korean/Korean Name ㅈ.md`. `mc_id: 5163` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`cantonese` completeness gap found and fixed**: stored `zang1` only; both en.Wiktionary and zh.Wiktionary independently attest a second genuine (literary) jyutping reading, `zaang1`; added.

**`hsk_level` bug found and fixed**: stored `4`, traced only to colon-count entries on `Old HSK 4.md` (both `[筝]: 1` and `[[箏]]: 1`, neither genuine) — thoroughly checked all four `Old HSK N.md` files and found no genuine plain-numbered entry anywhere, and 箏 was also entirely absent from `Lookup/HSK/HSK No.md`. Corrected to `hsk_level: 無` and added 箏 to `Lookup/HSK/HSK No.md`'s list.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (zither instrument).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format; `## Words` (citing [[words/古箏|古箏]], ruby verified against the word's own `注音` field) reconfirmed correct, no changes. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 篆 (8573; 216 characters remaining).

### 2026-08-23, iteration 2289 — [[characters/篆|篆]]

`graphemic_classification: 彖` (dual-source confirmed 形声, semantic 竹 "bamboo, the writing material" + phonetic 彖) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 竹` reconfirmed correct — genuine listing (item 31) on `Lookup/Radicals/Radical 118.md`. `japanese_native: ø` reconfirmed correct — ja.Wiktionary explicitly lists no kun'yomi, despite en.Wiktionary's single-sourced claim of こしきしば. `vietnamese: [chệ, chệnh, triển, triện]` reconfirmed complete and exact against hvdic.thivien.net. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 288. `stand_in: 篆書` reconfirmed correct — sole citer, the word's own independent page. `aliases` (blank) reconfirmed correct — zh.Wiktionary's single-sourced variant candidate 蒃 wasn't corroborated by en.Wiktionary. A chengyu-citation grep hit, [[chengyu/異体不容|異体不容]], was checked and confirmed a false positive — 篆 appears only inside the prose discussion (小篆), not among the chengyu's own four characters. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-6-9.md` (item 5) and `Lookup/Korean/Korean Name ㅈ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `3421` was actually 跗's rank; correct rank for 篆 is `3422` (`CC 3000.md`: `3421. 跗`, `3422. 篆`).

**`japanese` completeness gap found and fixed**: was `[TEN]` (kan-on) only; both ja.Wiktionary and en.Wiktionary independently attest a genuine go-on, `DEN`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (seal script).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format; `## Words` (citing [[words/篆書|篆書]], ruby verified against the word's own `注音` field) reconfirmed correct, no changes. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 篠 (8574; 215 characters remaining).

### 2026-08-23, iteration 2290 — [[characters/篠|篠]]

`radical: 竹` reconfirmed correct — genuine listing (item 35) on `Lookup/Radicals/Radical 118.md`. `japanese: [SHOU]` reconfirmed complete — both go-on and kan-on share the identical reading しょう. `vietnamese: [tiểu]` reconfirmed complete and exact against hvdic.thivien.net. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 243. `stand_in: 篠竹` reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-6-11.md` (item 1) and `Lookup/Korean/Korean Name ㅅ.md`. `mc_id: 6223` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`graphemic_classification` alias-citation bug found and fixed**: stored `條` — dual-source confirmed as the textbook phonetic component (en.Wiktionary and zh.Wiktionary both name it), but 條 has no independent page in this vault; [[characters/条 (char)|条 (char)]]'s own `aliases` field lists 條 as pointing to it. Per this vault's established alias-citation convention (cf. `characters/瞼.md`/㑒), corrected to cite the parent-form page `条` instead.

**`hsk_level` gap filled — genuinely absent, not just unfilled**: was the empty-string sentinel; thoroughly checked all four `Old HSK N.md` files and `Lookup/HSK/HSK No.md` and found zero hits for 篠 anywhere. Filled `hsk_level: 無` and added 篠 to `Lookup/HSK/HSK No.md`'s list.

**`japanese_native` completeness gap found and fixed**: was `ささ` only; both en.Wiktionary and ja.Wiktionary independently attest a second genuine kun'yomi, `しの`; added. Two further single-sourced candidates from en.Wiktionary alone (しぬ, すず) were left out — not corroborated by ja.Wiktionary.

**`aliases` filled**: was blank. Three genuine dual-source variants — [[筱]], [[𥴽]], [[𥭪]] (all attested by both en.Wiktionary and zh.Wiktionary) — none with independent pages in this vault; added. A fourth single-sourced candidate from zh.Wiktionary alone, 筿, was left out.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (dwarf bamboo).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet, `## Words` placed before Notes instead of after) into the standard `## Notes` four-bullet format, reordered before the pre-existing `## Words` section. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 簞 (8575; 214 characters remaining).

### 2026-08-23, iteration 2291 — [[characters/簞|簞]]

`graphemic_classification: 単` reconfirmed correct — both en.Wiktionary and zh.Wiktionary name the textbook phonetic as traditional 單, but 單 has no independent page in this vault; [[characters/単|単]]'s own `aliases` field lists both 單 and 单 as pointing to it, confirming the parent-form citation is correct per this session's established alias-citation convention (cf. [[characters/篠|篠]]/条 earlier this session). `radical: 竹` reconfirmed correct — genuine listing (item 36) on `Lookup/Radicals/Radical 118.md`. `japanese: [TAN]` and `japanese_native: はこ` reconfirmed complete and correct — dual-source exact match. `vietnamese: [đan]` reconfirmed complete and exact against hvdic.thivien.net. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 402. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `stand_in: 名専字` reconfirmed correct — zero hits for 簞 anywhere in `words/`, and no chengyu citations either (the classical idiom 簞食瓢飲 doesn't yet exist as a page in this vault). Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-6-12.md` (item 1) and `Lookup/Korean/Korean Name ㄷ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `3273` was actually 劭's rank; correct rank for 簞 is `3274` (`CC 3000.md`: `3273. 劭`, `3274. 簞`).

**`aliases` bug found and fixed — a genuinely unrelated character mistaken for a variant**: stored `[蓧, 箪]`; 箪 (the simplified form) is dual-source confirmed and correct, but 蓧 checked out as a wholly distinct character with its own unrelated readings (diào/tiáo/dí, "weeding basket/implement") — neither en.Wiktionary's nor zh.Wiktionary's entries for 簞 itself mention 蓧 as a variant, and 蓧's own en.Wiktionary entry doesn't cross-reference 簞 either. Removed as a false alias.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (bamboo basket).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 簫 (8576; 213 characters remaining).

### 2026-08-23, iteration 2292 — [[characters/簫|簫]]

`radical: 竹` reconfirmed correct — genuine listing (item 38) on `Lookup/Radicals/Radical 118.md`. `japanese: [SHOU]` and `japanese_native: ふえ` reconfirmed correct and complete — a second ja.Wiktionary-only kun'yomi candidate, しょうのふえ (a compound "shō's flute" reading), was left out as not a standalone genuine kun'yomi. `vietnamese: [tiu, tiêu]` reconfirmed complete and exact against en.Wiktionary. `hsk_level: 無` reconfirmed correct. `stand_in: 洞簫` reconfirmed correct — sole citer, the word's own independent page. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-6-13.md` (item 1) and `Lookup/Korean/Korean Name ㅅ.md`.

**`graphemic_classification` alias-citation bug found and fixed**: stored `肅` — dual-source confirmed as the textbook phonetic component (en.Wiktionary and zh.Wiktionary both name it), but 肅 has no independent page in this vault; [[characters/粛|粛]]'s own `aliases` field lists both 肅 and 肃 as pointing to it. Per this session's established alias-citation convention (cf. 篠/条 and 簞/単 earlier this session), corrected to cite the parent-form page `粛` instead.

**`mc_id` off-by-one bug found and fixed**: stored `3041` was actually 縷's rank; correct rank for 簫 is `3042` (`CC 3000.md`: `3041. 縷`, `3042. 簫`).

**`joyo_level` filled**: was blank. ja.Wiktionary directly confirms 簫 as 表外字; added as item 545 to `Lookup/Japanese/Hyōgai.md` and filled as `表外字`.

**`aliases` completeness gap found and fixed**: had `箫` (simplified form) only; both en.Wiktionary and zh.Wiktionary independently attest two further genuine variants, `箾` and `簘`, neither with an independent page in this vault; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (the xiao flute).

Rebuilt the malformed `## Notes`/`## Words` ordering (Words appeared before the wrong-heading-level `# Notes`, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard Notes-then-Words convention. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 簾 (8577; 212 characters remaining).

### 2026-08-23, iteration 2293 — [[characters/簾|簾]]

`graphemic_classification: 廉` (dual-source confirmed 形声, semantic 竹 + phonetic 廉, OC \*ɡ·rem) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 竹` reconfirmed correct — genuine listing (item 39) on `Lookup/Radicals/Radical 118.md`. `japanese: [REN]` reconfirmed complete — both go-on and kan-on share the identical reading れん. `vietnamese: [liêm, rèm]` reconfirmed complete and exact against hvdic.thivien.net. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 403. `stand_in: 暖簾` reconfirmed correct — sole citer, the word's own independent page. `aliases: [帘]` reconfirmed correct — zh.Wiktionary's single-sourced second candidate 𢅖 wasn't corroborated by en.Wiktionary. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-6-13.md` (item 2) and `Lookup/Korean/Korean Name ㄹ.md`. `mc_id: 5629` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`hsk_level` bug found and fixed — genuine level hiding under simplified sibling glyph**: stored `3`, matching a colon-count entry on `Old HSK 3.md` (`[帘]: 1`, not genuine) and a listing on `Lookup/HSK/HSK No.md` (implying no genuine level) — but `Old HSK 5.md` has a genuine plain-numbered entry under the simplified sibling glyph 帘 (`500. [帘]`). Corrected `hsk_level` to `5` and removed the now-stale entry from `Lookup/HSK/HSK No.md`.

**`japanese_native` completeness gap found and fixed**: was `す` only; both en.Wiktionary and ja.Wiktionary independently attest a second genuine kun'yomi, `すだれ` (the everyday name for the object); added, keeping both.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal senses (blind, screen, curtain).

Rebuilt the malformed `## Notes` (two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard four-bullet format; `## Words` (citing [[words/暖簾|暖簾]], ruby verified against the word's own `注音` field) reconfirmed correct, no changes. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 紗 (8579; 210 characters remaining).

### 2026-08-23, iteration 2294 — [[characters/紗|紗]]

`graphemic_classification: 少` reconfirmed correct, with a genuine source conflict investigated and documented: zh.Wiktionary corroborates 少 (matching the stored value), while en.Wiktionary instead names 沙 as phonetic. Kept `少` per zh.Wiktionary, consistent with this session's practice on such conflicts (cf. 甬, 睾). `radical: 糸` reconfirmed correct — genuine listing (item 12) on `Lookup/Radicals/Radical 120.md`. `japanese: [SA, SHA]` reconfirmed complete — dual-source exact match. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 406. `vietnamese: [sa]` reconfirmed correct. `stand_in: 名専字` reconfirmed correct — zero hits for 紗 anywhere in `words/`. `aliases: [纱]` reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-6-4.md` (item 17) and `Lookup/Korean/Korean Name ㅅ.md`. `mc_id: 5668` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`english` accuracy bug found and fixed**: stored `[gauze, yard]` — en.Wiktionary explicitly denies "yard" (the unit of measurement) as a sense of this character, which relates to textile fabrics and threads, not distance; replaced with the dual-source-confirmed sense `yarn`.

**`hsk_level` bug found and fixed**: stored `3`, traced only to colon-count entries on `Old HSK 3.md` (both `[纱]: 1` and `[[紗]]: 1`, neither genuine) — thoroughly checked all four `Old HSK N.md` files and found no genuine plain-numbered entry anywhere, and 紗 was also entirely absent from `Lookup/HSK/HSK No.md`. Corrected to `hsk_level: 無` and added 紗 to `Lookup/HSK/HSK No.md`'s list.

**`japanese_native` completeness gap found and fixed**: was `うすぎぬ` only; both en.Wiktionary and ja.Wiktionary independently attest two further genuine kun'yomi, `すず` and `たえ`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal senses.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 紘 (8580; 209 characters remaining).

### 2026-08-23, iteration 2295 — [[characters/紘|紘]]

`graphemic_classification: 厷` reconfirmed correct — en.Wiktionary's own composition breakdown ("⿰糹厷") directly confirms 厷 is literally embedded in the glyph; zh.Wiktionary's "phonetic 宏" describes the broader phonetic series (宏 itself uses 厷 as phonetic — cf. [[characters/宏|宏]]), not a contradiction. `radical: 糸` reconfirmed correct — genuine listing (item 13) on `Lookup/Radicals/Radical 120.md`. `vietnamese: [hoành]` reconfirmed complete and exact against both en.Wiktionary and hvdic.thivien.net. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 246. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `japanese_native: おおづな` reconfirmed correct; further single-sourced candidates from each side (en.Wiktionary's ひも; ja.Wiktionary's つな, つなぐ) were left out, uncorroborated by the other source. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-6-4.md` (item 18) and `Lookup/Korean/Korean Name ㄱ.md`.

**`stand_in` bug found and fixed**: stored `名専字` despite a genuine citer — [[words/八紘|八紘]]'s own `characters:` field lists both 八 and 紘. Corrected to `八紘`.

**`mc_id` off-by-one bug found and fixed**: stored `3697` was actually 疥's rank; correct rank for 紘 is `3698` (`CC 3000.md`: `3697. 疥`, `3698. 紘`).

**`japanese` completeness gap found and fixed**: was `[KOU, GYOU]`; both en.Wiktionary and ja.Wiktionary independently attest a further genuine go-on, `OU`; added.

**`english` completeness gap found and fixed**: was `[string, cord]` only; both en.Wiktionary and zh.Wiktionary independently attest a second genuine sense, "vast; expansive"; added.

**`aliases` completeness gap found and fixed**: had `纮` (simplified form) only; both en.Wiktionary and zh.Wiktionary independently attest a second genuine variant, `紭`, with no independent page in this vault; added. Further single-sourced candidates from each side (en.Wiktionary's 綋/𫟄/𰬋; zh.Wiktionary's 絋) were left out.

**`## Chengyu` section added**: a real hit, [[chengyu/八紘一宇|八紘一宇]], genuinely contains 紘 among its four characters; ruby verified against the chengyu's own `注音` field.

Rebuilt the entirely bare-linked page (no `# Notes`/`## Notes` heading at all, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet, no `## Words` section) into the standard `## Notes` four-bullet format plus `## Words` and `## Chengyu`. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 紬 (8581; 208 characters remaining).

### 2026-08-23, iteration 2296 — [[characters/紬|紬]]

`graphemic_classification: 由` (dual-source confirmed 形声, semantic 糸 + phonetic 由, OC \*lɯw) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 糸` reconfirmed correct — genuine listing (item 20) on `Lookup/Radicals/Radical 120.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 247. `stand_in: 名専字` reconfirmed correct — zero hits for 紬 anywhere in `words/`. `aliases: [綢, 䌷]` reconfirmed correct — 綢 is explicitly redirected to `characters/紬.md` on `Lookup/Korean/Korean Name ㅈ.md`, corroborating this vault's own established treatment of 紬 as standing in for 綢. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-6-5.md` (item 8) and `Lookup/Korean/Korean Name ㅈ.md`. `mc_id: 5682` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`hsk_level` gap filled — genuine level hiding under simplified sibling glyph**: was blank; `Old HSK 5.md` has a genuine plain-numbered entry under the simplified sibling glyph 绸 (`350. [绸]`) — the colon-count entries on `Old HSK 4.md` (both 绸 and 綢) are not genuine and were correctly ignored. Filled `hsk_level: 5`.

**`cantonese` completeness gap found and fixed**: stored `cau4` only; both en.Wiktionary and zh.Wiktionary independently attest a second genuine jyutping reading, `cau1` (tied to the obsolete "draw out; collect" senses); added.

**`japanese` completeness gap found and fixed**: was `[CHUU]` (kan-on) only; both ja.Wiktionary and en.Wiktionary independently attest a genuine go-on, `JUU`; added.

**`japanese_native` bug found and fixed**: stored `つむ`, a truncated fragment; both en.Wiktionary and ja.Wiktionary agree on two genuine kun'yomi in full form, `つむぎ` and `つむぐ`; corrected.

**`vietnamese` bug found and fixed**: stored `[dò, trìu, trừu]`; hvdic.thivien.net's genuine readings are exactly `dò, trừu` — `trìu` appears in neither hvdic nor en.Wiktionary and was removed as unattested.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal senses (silk fabric).

**`## Chengyu` bullet reformatted**: the existing bare `[[未雨紬謬]]` link (a real hit — this vault's own `chengyu/未雨紬謬.md` deliberately uses 紬 as a stand-in for 綢, with 未雨綢繆 recorded among its own `aliases`) lacked ruby; added, verified against the chengyu's own `注音` field.

Rebuilt the malformed `## Notes` (no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet, two floating unlinked CC wikilinks dangling after the Chengyu section) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 絨 (8582; 207 characters remaining).

### 2026-08-23, iteration 2297 — [[characters/絨|絨]]

`graphemic_classification: 戎` (dual-source confirmed 形声, semantic 糸 + phonetic 戎, OC \*njuŋ) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 糸` reconfirmed correct — genuine listing (item 39) on `Lookup/Radicals/Radical 120.md`. `mc_id: 0` reconfirmed correct — genuinely absent from all four `CC N000.md` files. `japanese_native: ø` reconfirmed correct — ja.Wiktionary explicitly lists no kun'yomi; en.Wiktionary's single-sourced candidates (ねりいと, けおり) weren't corroborated and stayed unadded. `vietnamese: [nhung]` reconfirmed complete and exact against hvdic.thivien.net. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 152. `stand_in: 天鵝絨` reconfirmed correct — sole citer, the word's own independent page. `aliases: [绒]` reconfirmed correct and complete — zh.Wiktionary's enormous list of further variants (𦶪, 𦔋, 狨, 毧, 羢, etc.) wasn't corroborated by en.Wiktionary for any single one, so none were added. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-6-6.md` (item 11) and `Lookup/Korean/Korean Name ㅇ.md`.

**`cantonese` bug found and fixed**: stored `jung2`, matching neither source — both en.Wiktionary and zh.Wiktionary agree on `jung4`; corrected.

**`hsk_level` bug found and fixed**: stored `4`, traced only to colon-count entries on `Old HSK 4.md` (both `[[絨]]: 1` and `[绒]: 1`, neither genuine). `Old HSK 6.md` has a genuine plain-numbered entry under the simplified sibling glyph 绒 (`504. [绒]`); corrected to `hsk_level: 6`.

**`japanese` completeness gap found and fixed**: was `[JUU]` (kan-on) only; both ja.Wiktionary and en.Wiktionary independently attest a genuine go-on, `NYUU`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (velvet).

**Stray out-of-scope note removed**: a bare `天鵞絨 --> 天鵝絨` bullet documented a spelling-variant redirect for the *word* [[words/天鵝絨|天鵝絨]] (not corroborated in that word's own `aliases` field either), unrelated to 絨 the character itself; removed during the Notes rebuild.

Rebuilt the malformed `## Notes` (two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet, the stray word-redirect note) into the standard `## Notes` four-bullet format; `## Words` (citing [[words/天鵝絨|天鵝絨]], ruby verified against the word's own `注音` field) reconfirmed correct, no changes. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 緋 (8583; 206 characters remaining).

### 2026-08-23, iteration 2298 — [[characters/緋|緋]]

`graphemic_classification: 非` (dual-source confirmed 形声, semantic 糸 + phonetic 非, OC \*pɯl) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 糸` reconfirmed correct — genuine listing (item 53) on `Lookup/Radicals/Radical 120.md`. `japanese: [HI]` reconfirmed complete — both go-on and kan-on share the identical reading ひ. `cantonese: fei1`, `vietnamese: [phi]` reconfirmed correct and complete. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 1. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `english: [scarlet, dark red, crimson, purple]` reconfirmed correct — the "purple" sense, despite reading oddly, is corroborated (if imperfectly transcribed) by zh.Wiktionary's own entry. `stand_in: 名専字` reconfirmed correct — the sole grep hit, [[words/火紅|火紅]], is a false-positive prose mention (緋 appearing only in a comparative-reading note), not a genuine citation. `aliases: [绯]` reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-6-8.md` (item 9) and `Lookup/Korean/Korean Name ㅂ.md`. `mc_id: 10457` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`japanese_native` completeness gap found and fixed**: was `あか` only; ja.Wiktionary directly lists `あけ` as a second genuine kun'yomi (en.Wiktionary categorizes it as nanori instead, but ja.Wiktionary — authoritative for kun'yomi specifically — lists it as a true kun'yomi); added.

**`pos` filled**: was blank. Filled as `性詞`, matching the adjectival/color senses.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 缸 (8584; 205 characters remaining).

### 2026-08-23, iteration 2299 — [[characters/缸|缸]]

`graphemic_classification: 工` (dual-source confirmed 形声, semantic 缶 + phonetic 工) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 缶` reconfirmed correct — genuine listing (item 3) on `Lookup/Radicals/Radical 121.md`. `japanese_native: かめ` reconfirmed correct; a second single-sourced candidate from en.Wiktionary alone (もたい) was left out. `pos: 名詞` reconfirmed correct. `stand_in: 名専字` reconfirmed correct — the sole grep hit, [[words/浴槽|浴槽]], is a false-positive prose mention (缸 noted only as the character Mandarin/Cantonese use in the *different* compound 浴缸), not a genuine citation. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-6-3.md` (item 7) and `Lookup/Korean/Korean Name ㅎ.md`. `mc_id: 8105` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`hsk_level` bug found and fixed**: stored `3`, traced only to a colon-count entry on `Old HSK 3.md` (`[[缸]]: 1`, not genuine) — thoroughly checked all four `Old HSK N.md` files and found no genuine plain-numbered entry anywhere, and 缸 was also entirely absent from `Lookup/HSK/HSK No.md`. Corrected to `hsk_level: 無` and added 缸 to `Lookup/HSK/HSK No.md`'s list.

**`joyo_level` cross-reference gap found and fixed**: the field itself already correctly said `表外字` (confirmed genuine via ja.Wiktionary), but the character was missing from `Lookup/Japanese/Hyōgai.md` itself; added as item 546.

**`japanese` completeness gap found and fixed**: was `[KOU]` only; ja.Wiktionary — which explicitly splits go-on and kan-on — independently attests a genuine go-on, `GOU`; added.

**`vietnamese` major completeness gap found and fixed**: was `[cong, hồng]` only; hvdic.thivien.net's genuine readings total six — `ang, cang, cương, hang` (Âm Hán Việt) plus `cong, hồng` (Âm Nôm); added the four missing ones.

**`aliases` filled**: was blank. Two genuine dual-source variants, [[堈]] and [[罁]] (both en.Wiktionary and zh.Wiktionary agree), neither with an independent page in this vault; added. Two further single-sourced candidates (zh.Wiktionary's 㼚, 堽) were left out.

Rebuilt the malformed `## Notes` (unlinked bare "Components" bullet instead of proper etymology, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 羚 (8585; 204 characters remaining).

### 2026-08-23, iteration 2300 — [[characters/羚|羚]]

`graphemic_classification: 令` (dual-source confirmed 形声, semantic 羊 + phonetic 令) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 羊` reconfirmed correct — genuine listing (item 3) on `Lookup/Radicals/Radical 123.md`. `japanese: [REI, RYOU]` and `japanese_native: かもしか` reconfirmed complete and correct — dual-source exact match. `vietnamese: [linh]` reconfirmed complete. `korean: 령` reconfirmed correct (North Korean/문화어 form, not the South Korean 두음법칙-shifted 영). `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 319. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `stand_in: 羚羊` reconfirmed correct — of three apparent citers, [[words/羚羊|羚羊]] and [[words/麒麟羚羊|麒麟羚羊]] genuinely cite 羚; [[words/麒麟|麒麟]] was a false-positive prose mention. `aliases: [麢]` reconfirmed correct; further single-sourced candidates from en.Wiktionary alone (䴫, 𦏪, 𦏰, 𪋪) weren't corroborated by zh.Wiktionary and stayed unadded. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-6-5.md` (item 14) and `Lookup/Korean/Korean Name ㄹ.md`. `mc_id: 5332` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (antelope).

**`## Words` section added**: citing both genuine citers, [[words/羚羊|羚羊]] and [[words/麒麟羚羊|麒麟羚羊]], rubies verified against each word's own `注音` field.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet, no `## Words` section) into the standard `## Notes` four-bullet format plus `## Words`. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 翟 (8586; 203 characters remaining).

### 2026-08-23, iteration 2301 — [[characters/翟|翟]]

`graphemic_classification: 會意` (dual-source confirmed ideogrammic compound of 羽 "feather" + 隹 "bird," depicting a long-tailed pheasant) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 羽` reconfirmed correct — genuine listing (item 12) on `Lookup/Radicals/Radical 124.md`. `mc_id: 1202` reconfirmed exact match (`CC 1000.md`: `1202. 翟`). `japanese: [KEKI, JAKU, TAKU]` reconfirmed complete — the consensus three across en.Wiktionary and weblio.jp; a fourth on'yomi is claimed by each source but they disagree with each other (てき vs たい), so neither was added. `japanese_native: きじ`, `vietnamese: [địch]`, `hsk_level: 無`, `pos: 名詞` all reconfirmed correct. `stand_in: 名専字` reconfirmed correct — zero hits for 翟 anywhere in `words/`. `## Derived Characters` (citing [[characters/擢|擢]]) reconfirmed correct — genuine `graphemic_classification: 翟` citation, ruby verified. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-6-8.md` (item 8) and `Lookup/Korean/Korean Name ㅈ.md`.

**`aliases` bug found and fixed — a phonetically-related derived character mistaken for a true variant**: stored `[糶]` ("to sell grain," genuinely unrelated in meaning); en.Wiktionary explicitly clarifies 糶 is listed among derived characters sharing phonetic similarity with 翟 (rice 米 + phonetic 翟), not a true orthographic variant — the same bug pattern as 簞/蓧 earlier this session. Removed; 糶 has no page in this vault yet to add under Derived Characters instead.

**`joyo_level` cross-reference gap found and fixed**: the field itself already said `表外字`, but the character was missing from `Lookup/Japanese/Hyōgai.md` itself; added as item 547.

Rebuilt the malformed `## Notes` (unlinked bare "Components" bullet instead of proper etymology, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 翠 (8587; 202 characters remaining).

### 2026-08-23, iteration 2302 — [[characters/翠|翠]]

`graphemic_classification: 卒` (dual-source confirmed 形声, semantic 羽 + phonetic 卒, OC \*sʰuds) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 羽` reconfirmed correct — genuine listing (item 11) on `Lookup/Radicals/Radical 124.md`. `japanese: [SUI]` reconfirmed complete. `vietnamese: [thuý]` reconfirmed complete and exact against hvdic.thivien.net. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 321. `stand_in: 翠色` reconfirmed correct — of five apparent grep hits, only [[words/翠色|翠色]] and [[words/翠金|翠金]] genuinely cite 翠 in their `characters:` fields ([[words/核金|核金]], [[words/桃金|桃金]], [[words/褐金|褐金]] were false positives). A chengyu-citation grep hit, [[chengyu/生机勃勃|生机勃勃]], also checked out as a false positive (翠 appears only in a prose example sentence, not the chengyu's own four characters). Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-6-8.md` (item 9) and `Lookup/Korean/Korean Name ㅊ.md`.

**`mc_id` bug found and fixed (not merely off-by-one)**: stored `2675`, which lands on 儋's rank and doesn't correspond to 翠 at all; the genuine rank is `2679` (`CC 2000.md`: `2679. 翠`).

**`hsk_level` bug found and fixed**: stored `4`, traced only to a colon-count entry on `Old HSK 4.md` (`[[翠]]: 2`, not genuine) — no plain-numbered entry exists in any `Old HSK N.md` file, matching `Lookup/HSK/HSK No.md`'s own listing of 翠 as having no genuine level. Corrected to `hsk_level: 無`.

**`japanese_native` completeness gap found and fixed**: was `かわせみ` only; both en.Wiktionary and ja.Wiktionary independently attest a second genuine kun'yomi, `みどり` ("green"); added.

**`aliases` filled**: was blank. One genuine dual-source variant, [[翆]], with no independent page in this vault; added. A second single-sourced candidate from zh.Wiktionary alone, 臎, was left out.

**`pos` filled**: was blank. Filled as `性詞`, matching the dominant color-adjective senses.

**`## Words` section added**: the pre-existing bare "terbium abbreviation" note was reformatted as a proper Words bullet alongside the stand-in citation; both [[words/翠色|翠色]] and [[words/翠金|翠金]] rubies verified against each word's own `注音` field.

Rebuilt the malformed `## Notes` (bare unlinked prose instead of proper etymology, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format plus `## Words`. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 翫 (8588; 201 characters remaining).

### 2026-08-23, iteration 2303 — [[characters/翫|翫]]

`graphemic_classification: 元` (dual-source confirmed 形声, semantic 習 + phonetic 元, OC \*ŋoːns) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 羽` reconfirmed correct — genuine listing (item 13) on `Lookup/Radicals/Radical 124.md`. `vietnamese: [ngoạn]` reconfirmed complete against hvdic.thivien.net. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 39. `hsk_level: 無`, `stand_in: 名専字` (zero hits in `words/`) reconfirmed correct. `aliases` (blank) reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-11-4.md` (item 7) and `Lookup/Korean/Korean Name ㅇ.md`.

**Raw scratch note "can go to 玩???" resolved**: investigated whether 翫 should be merged into [[characters/玩|玩]]'s page. Both en.Wiktionary and zh.Wiktionary describe them as historically distinct characters that converged in meaning rather than a straightforward traditional/simplified pair (zh.Wiktionary explicitly: "historically distinct characters that converged in meaning"), and 玩 already has its own robust, independently-established page (with its own alias 莞 and its own separate `Lookup/Korean/Korean Name ㅇ.md` listing). Kept the pages separate, with the reasoning now documented in Notes rather than left as an open question.

**`mc_id` off-by-one bug found and fixed**: stored `3840` was actually 捽's rank; correct rank for 翫 is `3841` (`CC 3000.md`: `3840. 捽`, `3841. 翫`).

**`japanese` completeness gap found and fixed**: was `[GAN]`; ja.Wiktionary — which explicitly splits go-on/kan-on from 慣用音 — independently attests a genuine third reading, `KAN`; added.

**`japanese_native` bug found and fixed**: stored `もてあそ`, a truncated fragment; both en.Wiktionary and ja.Wiktionary agree on the genuine full form `もてあそぶ`; corrected. Two further single-sourced candidates from ja.Wiktionary alone (あなどる, むさぼる) were left out — not corroborated by en.Wiktionary.

**`pos` filled**: was blank. Filled as `事詞`, matching the verbal sense ("to slack off").

Rebuilt the malformed `# Notes` (wrong heading level, a raw unresolved scratch question, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 胱 (8589; 200 characters remaining).

### 2026-08-23, iteration 2304 — [[characters/胱|胱]]

`graphemic_classification: 光` (dual-source confirmed 形声, semantic 月 + phonetic 光) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 肉` reconfirmed correct — genuine listing (item 31) on `Lookup/Radicals/Radical 130.md`. `japanese: [KOU]` reconfirmed complete — both go-on and kan-on share the identical reading こう. `japanese_native: ø` reconfirmed correct. `vietnamese: [choáng, quang]` reconfirmed complete and exact against hvdic.thivien.net. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 115. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `pos: 名詞` reconfirmed correct. `stand_in: 旁胱` reconfirmed correct — a deliberate vault substitution (旁 standing in for 膀, matching the established phonetic-substitution convention), corroborated by [[words/旁胱|旁胱]]'s own `aliases` field listing the standard form 膀胱. Already correctly cross-listed on `Lookup/Korean/Korean Name ㄱ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `2987` was actually 幟's rank; correct rank for 胱 is `2988` (`CC 2000.md`: `2987. 幟`, `2988. 胱`).

Rebuilt the malformed `## Notes` (unlinked bare "Components" bullet instead of proper etymology, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format; `## Words` (citing [[words/旁胱|旁胱]], ruby verified against the word's own `注音` field) reconfirmed correct, no changes. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 脛 (8590; 199 characters remaining).

### 2026-08-23, iteration 2305 — [[characters/脛|脛]]

`graphemic_classification: 巠` (dual-source confirmed 形声, semantic 肉 + phonetic 巠, OC \*keːŋ) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 肉` reconfirmed correct — genuine listing (item 41) on `Lookup/Radicals/Radical 130.md`. `korean: 경` reconfirmed correct. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 99. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `stand_in: 脛骨` reconfirmed correct — sole citer, the word's own independent page. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-4-7.md` (item 20) and `Lookup/Korean/Korean Name ㄱ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `2265` was actually 慝's rank; correct rank for 脛 is `2266` (`CC 2000.md`: `2265. 慝`, `2266. 脛`).

**`cantonese` completeness gap found and fixed**: stored `hing5` only; both en.Wiktionary and zh.Wiktionary independently attest a second genuine jyutping reading, `ging3`; added.

**`japanese` completeness gap found and fixed**: was `[KEI]` (kan-on) only; both ja.Wiktionary and en.Wiktionary independently attest a genuine go-on, `GYOU`; added.

**`japanese_native` completeness gap found and fixed**: was `すね` only; both sources independently attest a second genuine kun'yomi, `はぎ`; added.

**`vietnamese` bug found and fixed**: stored `[cảnh, hĩnh, hểnh, hỉnh, kinh]`; hvdic.thivien.net's genuine readings are exactly `hĩnh, cảnh, hểnh, kinh` — `hỉnh` appears only in en.Wiktionary, not hvdic (this vault's Vietnamese authority), and was removed.

**`aliases` completeness gap found and fixed**: had `胫` (simplified form) only; both en.Wiktionary and zh.Wiktionary independently attest a second genuine variant, `踁`, with no independent page in this vault; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (shinbone).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format; `## Words` (citing [[words/脛骨|脛骨]], ruby verified against the word's own `注音` field) reconfirmed correct, no changes. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 脾 (8591; 198 characters remaining).

### 2026-08-23, iteration 2306 — [[characters/脾|脾]]

`graphemic_classification: 卑` (dual-source confirmed 形声, semantic 肉 + phonetic 卑, OC \*pe) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 肉` reconfirmed correct — genuine listing (item 45) on `Lookup/Radicals/Radical 130.md`. `cantonese: pei4` reconfirmed correct. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 230. `stand_in: 脾臓` reconfirmed correct — sole citer, the word's own independent page. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-4-8.md` (item 32) and `Lookup/Korean/Korean Name ㅂ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `1490` was actually 黍's rank; correct rank for 脾 is `1491` (`CC 1000.md`: `1490. 黍`, `1491. 脾`).

**`hsk_level` bug found and fixed**: stored `2`, traced only to colon-count entries on `Old HSK 2.md` and `Old HSK 4.md` (neither genuine) — `Lookup/HSK/HSK No.md` itself already correctly lists 脾 among characters confirmed to have no genuine HSK level. Corrected to `hsk_level: 無`.

**`japanese` completeness gap found and fixed**: was `[HI, HAI, HEI]`; a third source, weblio.jp, was needed to reconcile — en.Wiktionary and ja.Wiktionary together confirm only `BI` (go-on) and `HI` (kan-on), missing entirely from the stored value, while weblio.jp additionally corroborates the already-present `HAI` and `HEI` as genuine further readings. Added the missing `BI`.

**`japanese_native` bug found and fixed — sentinel used despite genuine kun'yomi**: stored `ø`, but both en.Wiktionary and weblio.jp independently attest three genuine kun'yomi, `ひぞう`, `もも`, `とまる` (ja.Wiktionary's silence on kun'yomi for this entry was the outlier, not the other two sources); corrected.

**`vietnamese` completeness gap found and fixed**: was `[tì, tỳ]`; hvdic.thivien.net's genuine readings additionally include two further Âm Hán Việt, `bài` and `bễ`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (spleen).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, a bare unlinked-format Words bullet folded into Notes instead of its own section, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 膏 (8592; 197 characters remaining).

### 2026-08-23, iteration 2307 — [[characters/膏|膏]]

`graphemic_classification: 高` (dual-source confirmed 形声, semantic 肉 + phonetic 高, OC \*kaːw) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 肉` reconfirmed correct — genuine listing (item 58) on `Lookup/Radicals/Radical 130.md`. `japanese: [KOU]` and `japanese_native: あぶら` reconfirmed complete and correct. `vietnamese: [cao]` reconfirmed correct. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 327. `stand_in: 脂膏` reconfirmed correct — sole citer, the word's own independent page (`pos: 名詞` there also confirming the character's own `名詞` classification). Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-2-12.md` (item 1) and `Lookup/Korean/Korean Name ㄱ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `1736` was actually 闇's rank; correct rank for 膏 is `1737` (`CC 1000.md`: `1736. 闇`, `1737. 膏`).

**`hsk_level` bug found and fixed**: stored `3`, traced only to a colon-count entry on `Old HSK 3.md` (`[[膏]]: 1`, not genuine) — `Lookup/HSK/HSK No.md` itself already correctly lists 膏 among characters confirmed to have no genuine HSK level. Corrected to `hsk_level: 無`.

**`cantonese` completeness gap found and fixed**: stored `gou1` only; both en.Wiktionary and zh.Wiktionary independently attest a second genuine jyutping reading, `gou3`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal senses.

Rebuilt the malformed `## Notes` (two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format; `## Words` (citing [[words/脂膏|脂膏]], ruby verified against the word's own `注音` field) reconfirmed correct, no changes. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 艙 (8593; 196 characters remaining).

### 2026-08-23, iteration 2308 — [[characters/艙|艙]]

`graphemic_classification: 倉` (dual-source confirmed 形聲, semantic 舟 + phonetic 倉, a later-formed 後起字) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 舟` reconfirmed correct — genuine listing (item 9) on `Lookup/Radicals/Radical 137.md`. `japanese: [SOU]` and `japanese_native: ø` reconfirmed complete and correct — both sources agree on the single on'yomi and no kun'yomi. `vietnamese: [khoang, thương]` reconfirmed complete. `stand_in: 名専字` reconfirmed correct — zero hits for 艙 anywhere in `words/`; a raw scratch note "Use 船室" appears to suggest creating a stand-in word, but no such word exists yet in this vault — left for the word-perfecting sweep. `aliases: [舱]` reconfirmed correct. `mc_id: 0` reconfirmed correct — genuinely absent from all four `CC N000.md` files. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-6-10.md` (item 8) and `Lookup/Korean/Korean Name ㅊ.md`.

**`hsk_level` bug found and fixed — genuine level hiding under simplified sibling glyph**: stored `3`, matching colon-count entries on `Old HSK 3.md` (neither genuine) — but `Old HSK 6.md` has a genuine plain-numbered entry under the simplified sibling glyph 舱 (`124. [舱]`). Corrected to `hsk_level: 6`.

**`joyo_level` filled**: was blank. ja.Wiktionary directly confirms 艙 as 表外字; added as item 548 to `Lookup/Japanese/Hyōgai.md` and filled as `表外字`.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (cabin).

Rebuilt the malformed `# Notes` (wrong heading level, a raw unresolved scratch note, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 芥 (8595; 195 characters remaining).

### 2026-08-23, iteration 2309 — [[characters/芥|芥]]

`graphemic_classification: 介` (dual-source confirmed 形声, semantic 艸 + phonetic 介, OC \*kreːds) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 5) on `Lookup/Radicals/Radical 140.md`. `japanese: [KAI, KE]` reconfirmed complete — matches ja.Wiktionary's go-on ケ/kan-on カイ exactly. `vietnamese: [giới]` reconfirmed complete and exact against hvdic.thivien.net. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 329. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `stand_in: 芥子` reconfirmed correct. `aliases` (blank) reconfirmed correct — the only alternative noted by either source is 辛子, a Japanese-specific alternative spelling, not a true character variant.

**`mc_id` off-by-one bug found and fixed**: stored `3366` was actually 騂's rank; correct rank for 芥 is `3367` (`CC 3000.md`: `3366. 騂`, `3367. 芥`).

**`japanese_native` completeness gap found and fixed**: was `あくた` only; both en.Wiktionary and ja.Wiktionary independently attest two further genuine kun'yomi, `からし` and `ごみ`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (mustard plant).

Rebuilt the malformed `## Notes` (two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format; `## Words` (citing [[words/芥子|芥子]], ruby verified against the word's own `注音` field) reconfirmed correct, no changes. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 芮 (8596; 194 characters remaining).

### 2026-08-23, iteration 2310 — [[characters/芮|芮]]

`graphemic_classification: 内` (dual-source confirmed 形声, semantic 艸 + phonetic 內/内, OC \*nuːbs) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 9) on `Lookup/Radicals/Radical 140.md`. `japanese: [ZEI, NEI, ZETSU, NECHI]` reconfirmed complete and exact — matches en.Wiktionary's four on'yomi precisely. `japanese_native: ø` reconfirmed correct — ja.Wiktionary lists no kun'yomi. `vietnamese: [nhuế, nùi, nối]` reconfirmed complete and exact against hvdic.thivien.net — en.Wiktionary's two further candidates (nội, nuôi) weren't corroborated by hvdic and correctly stayed unadded. `hsk_level: 無`, `stand_in: 名専字` (zero hits in `words/`), `aliases` (blank) all reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-4.md` (item 24) and `Lookup/Korean/Korean Name ㅇ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `2337` was actually 苓's rank; correct rank for 芮 is `2338` (`CC 2000.md`: `2337. 苓`, `2338. 芮`).

**`joyo_level` filled**: was blank. ja.Wiktionary directly confirms 芮 as 表外字; added as item 549 to `Lookup/Japanese/Hyōgai.md` and filled as `表外字`.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (water's edge).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id-rank bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 苔 (char) (8597; 193 characters remaining).

### 2026-08-23, iteration 2311 — [[characters/苔 (char)|苔 (char)]]

`graphemic_classification: 台` (dual-source confirmed 形声, semantic 艸 + phonetic 台) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 17) on `Lookup/Radicals/Radical 140.md`. `japanese_native: こけ` reconfirmed correct; ja.Wiktionary's single-sourced second candidate こけら wasn't corroborated by en.Wiktionary. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 332. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `stand_in: 苔` reconfirmed correct — this vault's established self-pointing convention for a character that is also independently its own word (cf. `words/苔.md`). Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-5.md` (item 25) and `Lookup/Korean/Korean Name ㅌ.md`. `mc_id: 7750` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`cantonese` completeness gap found and fixed**: stored `toi4` (moss sense) only; both en.Wiktionary and zh.Wiktionary independently attest a second genuine jyutping reading, `toi1` (tied to the "tongue coating" sense); added.

**`japanese` completeness gap found and fixed**: was `[TAI]` (kan-on) only; both ja.Wiktionary and en.Wiktionary independently attest a genuine go-on, `DAI`; added.

**`vietnamese` bug found and fixed**: stored `[dày, dầy, thai, đài, đày, đầy]`; hvdic.thivien.net's genuine six readings are `đài, dày, dây, đày, đầy, thai` — `dầy` appears nowhere in the source (likely a corruption of the genuine-but-missing `dây`); corrected.

**`aliases` filled**: was blank. One genuine dual-source variant, [[菭]] (both en.Wiktionary and zh.Wiktionary agree), with no independent page in this vault; added. A second candidate, 胎, already has independent use in this vault and correctly failed the alias test.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (moss).

Rebuilt the malformed `# Notes` (wrong heading level, a bare unlinked "Cantonese pronunciation" scratch line, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format, preserving the page's `>[!tip]` character/word split callout. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 苺 (char) (8598; 192 characters remaining).

### 2026-08-23, iteration 2312 — [[characters/苺 (char)|苺 (char)]]

`graphemic_classification: 母` (dual-source confirmed 形声, semantic 艸 + phonetic 母) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 24) on `Lookup/Radicals/Radical 140.md`. `japanese_native: いちご` reconfirmed correct. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 333. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `stand_in: 苺` reconfirmed correct — the vault's established self-pointing convention for a character that is also independently its own word. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-5.md` (item 28) and `Lookup/Korean/Korean Name ㅁ.md`. `mc_id: 7402` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`japanese` completeness gap found and fixed**: was `[MAI, BAI]`; both ja.Wiktionary and en.Wiktionary independently attest a third genuine go-on, `ME`; added.

**`vietnamese` gap found and fixed — field left entirely empty**: hvdic.thivien.net attests a genuine Âm Hán Việt reading, `môi`; added.

**`aliases` filled**: was blank. zh.Wiktionary explicitly states 莓 and 苺 are true variant forms of the same character (not distinct characters), corroborated by en.Wiktionary's own cross-reference; 莓 has no independent page in this vault; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (strawberry).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format, preserving the page's `>[!tip]` character/word split callout. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 茅 (8599; 191 characters remaining).

### 2026-08-23, iteration 2313 — [[characters/茅|茅]]

`graphemic_classification: 矛` (dual-source confirmed 形声, semantic 艸 + phonetic 矛, OC \*mu) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 26) on `Lookup/Radicals/Radical 140.md`. `mc_id: 1688` reconfirmed exact match (`CC 1000.md`: `1688. 茅`). `japanese: [BOU, MYOU]` reconfirmed complete — matches both sources' go-on/kan-on exactly. `vietnamese: [mao]` reconfirmed complete. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 225. `stand_in: 茅草` reconfirmed correct — sole citer, the word's own independent page. `aliases` (blank) reconfirmed correct — en.Wiktionary's candidate (茆) and zh.Wiktionary's candidate (泖) don't overlap, so neither is dual-source confirmed. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-5.md` (item 38) and `Lookup/Korean/Korean Name ㅁ.md`.

**`hsk_level` bug found and fixed**: stored `3`, traced only to a colon-count entry on `Old HSK 3.md` (`[[茅]]: 1`, not genuine) — `Lookup/HSK/HSK No.md` itself already correctly lists 茅 among characters confirmed to have no genuine HSK level. Corrected to `hsk_level: 無`.

**`japanese_native` completeness gap found and fixed**: was `かや` only; both en.Wiktionary and ja.Wiktionary independently attest two further genuine kun'yomi, `ち` and `ちがや`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (thatch).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, a bare unlinked-format Words bullet folded into Notes instead of its own section, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 茉 (8600; 190 characters remaining).

### 2026-08-23, iteration 2314 — [[characters/茉|茉]]

`graphemic_classification: 末` (dual-source confirmed 形声, semantic 艸 + phonetic 末, OC \*maːd) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 27) on `Lookup/Radicals/Radical 140.md`. `japanese_native: ø` reconfirmed correct — ja.Wiktionary explicitly lists no kun'yomi; en.Wiktionary's single-sourced candidate (み) wasn't corroborated and stayed unadded. `vietnamese: [mạt]` reconfirmed complete and exact against hvdic.thivien.net. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 334. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `stand_in: 茉莉` and the `cranberry` tag reconfirmed correct — corroborated by [[words/茉莉|茉莉]]'s own matching `cranberry` tag. `mc_id: 0` reconfirmed correct — genuinely absent from all four `CC N000.md` files. `aliases: [苿]` left unchanged — neither of today's two sources corroborates it, but absence of confirmation isn't evidence of error for pre-existing data. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-5.md` (item 39) and `Lookup/Korean/Korean Name ㅁ.md`.

**`japanese` completeness gap found and fixed**: was `[MATSU, BATSU]`; both ja.Wiktionary and en.Wiktionary independently attest a genuine third go-on, `MACHI`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (white jasmine, bound within 茉莉).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, a bare unlinked-format Words bullet folded into Notes instead of its own section, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 莉 (8601; 189 characters remaining).

### 2026-08-23, iteration 2315 — [[characters/莉|莉]]

`graphemic_classification: 利` (dual-source confirmed 形声, semantic 艸 + phonetic 利) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 43) on `Lookup/Radicals/Radical 140.md`. `japanese_native: ø` reconfirmed correct — ja.Wiktionary explicitly lists no kun'yomi. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 336. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `stand_in: 茉莉` and the `cranberry` tag reconfirmed correct. `mc_id: 0` reconfirmed correct — genuinely absent from all four `CC N000.md` files. `aliases` (blank) reconfirmed correct — zh.Wiktionary explicitly states no variant forms exist. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-7.md` (item 21) and `Lookup/Korean/Korean Name ㄹ.md`.

**`japanese` bug found and fixed**: stored `[CHI, REI, RI]` — `CHI` matched neither source; both ja.Wiktionary and en.Wiktionary independently attest the genuine go-on as `RAI`, missing entirely from the stored value. Corrected to `[RAI, REI, RI]`.

**`vietnamese` bug found and fixed**: stored `[lài, lị, lịa, lợi, nhài]`; hvdic.thivien.net's genuine readings are `lê, lị, lài, lợi, nhài` — `lịa` appears in neither hvdic nor en.Wiktionary (likely a corruption of the genuine-but-missing `lê`); corrected.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 莱 (8602; 188 characters remaining).

### 2026-08-23, iteration 2316 — [[characters/莱|莱]]

`graphemic_classification: 来` reconfirmed correct — both en.Wiktionary and zh.Wiktionary name the textbook phonetic as traditional 來, but 來 has no independent page in this vault; [[characters/来 (char)|来 (char)]]'s own `aliases` field lists 來 as pointing to it, confirming the parent-form citation is already correct. `radical: 艸` reconfirmed correct — genuine listing (item 44) on `Lookup/Radicals/Radical 140.md`. `vietnamese: [lai]` reconfirmed complete and exact against hvdic.thivien.net — en.Wiktionary's claimed second reading `lài` wasn't corroborated by hvdic. `aliases: [萊]` reconfirmed correct — genuine traditional form, and `Lookup/Korean/Korean Name ㄹ.md` already independently redirects 萊 to this page. `stand_in: 蓬莱` reconfirmed correct — of three apparent citers, [[words/蓬莱|蓬莱]] and [[words/莱金|莱金]] genuinely cite 莱 in their `characters:` fields; [[words/欧金|欧金]] was a false-positive prose mention.

**`mc_id` off-by-one bug found and fixed**: stored `1651` was actually 謗's rank; correct rank for 莱 is `1652`, recorded under the traditional sibling glyph (`CC 1000.md`: `1651. 謗`, `1652. 萊`).

**`japanese` bug found and fixed**: stored `[RAI, RI]` — `RI` matched neither en.Wiktionary nor ja.Wiktionary, both of which give only `らい` (identical for go-on and kan-on); removed the unattested `RI`.

**`japanese_native` completeness gap found and fixed**: was `あかざ` only; both en.Wiktionary and ja.Wiktionary independently attest a second genuine kun'yomi, `こうがい`; added. Each source's third candidate (あわち vs. あれわ) disagreed with the other and stayed unadded.

**`joyo_level` filled**: was blank. Both en.Wiktionary and ja.Wiktionary confirm 萊/莱 as a genuine 人名用漢字; added as item 480 to `Lookup/Japanese/Jinmeiyō.md` and filled as `日本人名用漢字`.

**`pos` filled**: was blank. Filled as `固有名詞`, matching this vault's established convention for place-name characters (cf. `characters/洛.md`, `characters/郎.md`).

**`## Words` completeness gap found and fixed**: only [[words/蓬莱|蓬莱]] was listed; a genuine second citer, [[words/莱金|莱金]] ("rhenium"), was previously folded into Notes as a bare unlinked-format bullet instead of its own Words entry; moved and properly formatted.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 菩 (8603; 187 characters remaining).

### 2026-08-23, iteration 2317 — [[characters/菩|菩]]

`graphemic_classification: 咅` (dual-source confirmed 形声, semantic 艸 + phonetic 咅) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 52) on `Lookup/Radicals/Radical 140.md` (gloss "sacred tree" there reflects the 菩提/bodhi-tree association, a genuine dual-source-attested sense, left unchanged). `cantonese: pou4` reconfirmed correct and complete — en.Wiktionary's own two further candidates were explicitly labeled "expected reflex," not attested readings, and zh.Wiktionary doesn't corroborate them either. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 315. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `stand_in: 菩薩` and the `cranberry` tag reconfirmed correct — corroborated by [[words/菩薩|菩薩]]'s own matching `cranberry` tag. `japanese_native: ø` reconfirmed correct — ja.Wiktionary lists no kun'yomi; en.Wiktionary's single-sourced candidate (ほとけぐさ) wasn't corroborated. `aliases` (blank) reconfirmed correct — zh.Wiktionary's single-sourced candidate 萯 wasn't corroborated by en.Wiktionary. `mc_id: 9428` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`japanese` major completeness gap found and fixed**: was `[HAI, BO]` only; both en.Wiktionary and ja.Wiktionary independently attest a much larger dual-source-confirmed reading set for this multi-etymology character — go-on `BAI`, `BU`, `BOKU`; kan-on `FUU`, `HO`, `HOKU` — all missing from the stored value; added all six.

**`vietnamese` completeness gap found and fixed**: was `[bồ, mồ]`; hvdic.thivien.net's genuine readings additionally include two further Âm Hán Việt, `bội` and `phụ`; added.

**`english` completeness gap found and fixed**: was `[bodhisattva]` only; both en.Wiktionary and zh.Wiktionary independently attest a second genuine sense, "herb" (the character's more basic botanical meaning); added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal senses.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, a bare unlinked-format Words bullet folded into Notes instead of its own section, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format plus a proper `## Words` section. A chengyu-citation grep hit, [[chengyu/色即是空|色即是空]], checked out as a false positive (prose mention only). Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 菫 (8604; 186 characters remaining).

### 2026-08-23, iteration 2318 — [[characters/菫|菫]]

`radical: 艸` reconfirmed correct — genuine listing (item 53) on `Lookup/Radicals/Radical 140.md`. `cantonese: gan2` reconfirmed correct. `japanese_native: すみれ` reconfirmed correct. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 316. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `stand_in: 名専字` reconfirmed correct — zero hits in `words/`. `aliases` entries `槿`/`瑾`/`嫤` reconfirmed correct as this vault's established convention — `Lookup/Korean/Korean Name ㄱ.md` explicitly redirects all three to this page rather than giving them independent pages, even though they're technically distinct phonetic derivatives; left as-is, out of scope to restructure. `mc_id: 6203` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`graphemic_classification` self-reference bug found and fixed**: stored `菫` — the character citing *itself* as its own phonetic component, which is structurally impossible. Both en.Wiktionary and zh.Wiktionary independently describe 菫 as a corruption of [[堇]] with 艸 added as the semantic radical, making 堇 the true phonetic root. Corrected to `堇`; since 堇 has no independent page in this vault, added it to `aliases` instead (a genuine orthographic variant, distinct from the phonetic-derivative redirects already there).

**`japanese` completeness gap found and fixed**: was `[KIN]` (kan-on) only; both ja.Wiktionary and zh.Wiktionary independently attest a genuine go-on, `GON`; added.

**`vietnamese` bug found and fixed**: stored `[càn, cần, cẩn, cận, ngẩn, đổng]`; hvdic.thivien.net's genuine readings are exactly `càn, cần, cận, ngẩn` — `cẩn` and `đổng` appear in neither hvdic nor the day's other sources and were removed as unattested.

**`english` completeness gap found and fixed**: was `[celery, aconite]` (both explicitly archaic senses); en.Wiktionary identifies "violet" as the character's primary modern meaning, corroborated by zh.Wiktionary's kun'yomi gloss すみれ ("violet"); added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal senses.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 萩 (8605; 185 characters remaining).

### 2026-08-23, iteration 2319 — [[characters/萩|萩]]

`graphemic_classification: 秋` (dual-source confirmed 形声, semantic 艸 + phonetic 秋) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 59) on `Lookup/Radicals/Radical 140.md`. `cantonese: cau1` reconfirmed correct. `japanese_native: はぎ` reconfirmed correct. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 309. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `stand_in: 名専字` reconfirmed correct — zero hits in `words/`. `aliases` (blank) reconfirmed correct — zh.Wiktionary's single-sourced candidate 𦵒 wasn't corroborated by en.Wiktionary. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-9.md` (item 16) and `Lookup/Korean/Korean Name ㅊ.md`. `mc_id: 6055` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`japanese` completeness gap found and fixed**: was `[SHUU]` (kan-on) only; both ja.Wiktionary and en.Wiktionary independently attest a genuine go-on, `SHU`; added.

**`vietnamese` completeness gap found and fixed**: was `[tho, thu]`; hvdic.thivien.net's genuine readings additionally include a third Âm Nôm, `thưu`; added. En.Wiktionary's own candidate `thèm` wasn't corroborated by hvdic and stayed unadded.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (bush clover).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 萱 (8606; 184 characters remaining).

### 2026-08-23, iteration 2320 — [[characters/萱|萱]]

`graphemic_classification: 宣` (dual-source confirmed 形声, semantic 艸 + phonetic 宣, OC \*qʰʷan) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 61) on `Lookup/Radicals/Radical 140.md`. `cantonese: hyun1`, `japanese: [KEN]`, `japanese_native: かや`, `vietnamese: [hiên, huyên]` all reconfirmed complete and correct against both sources. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 310. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `stand_in: 名専字` reconfirmed correct — zero hits in `words/`. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-9.md` (item 18) and `Lookup/Korean/Korean Name ㅎ.md`. `mc_id: 9929` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`english` completeness gap found and fixed**: was `[daylily, Hemerocallis flava]` only; both en.Wiktionary and zh.Wiktionary independently attest a genuine figurative sense, "mother" (from classical literature where the plant symbolizes maternal care); added.

**`aliases` major completeness gap found and fixed**: had `藼` only; both en.Wiktionary and zh.Wiktionary independently attest the exact same additional four/five variant forms — `蕿`, `蘐`, `諼`, `谖`, `萲` — none with independent pages in this vault; added all.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal senses.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 董 (8607; 183 characters remaining).

### 2026-08-23, iteration 2321 — [[characters/董|董]]

`graphemic_classification: 重` (dual-source confirmed 形声, semantic 艸 + phonetic 重, OC \*toːŋʔ) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 66) on `Lookup/Radicals/Radical 140.md`. `mc_id: 1104` reconfirmed exact match (`CC 1000.md`: `1104. 董`). `cantonese: dung2` reconfirmed correct. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 147. `pos: 事詞` reconfirmed correct. `stand_in: 名専字` reconfirmed correct — zero hits in `words/`. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-9.md` (item 21) and `Lookup/Korean/Korean Name ㄷ.md`. A chengyu-citation grep hit, [[chengyu/三綱五常|三綱五常]], checked out as a false positive (董 appears only inside the name 董仲舒/Dong Zhongshu, not the chengyu's own four characters).

**`hsk_level` bug found and fixed**: stored `4`, traced only to a colon-count entry on `Old HSK 4.md` (`[[董]]: 1`, not genuine). `Old HSK 6.md` has a genuine plain-numbered entry (`655. [[董]]`); corrected to `hsk_level: 6`.

**`japanese` completeness gap found and fixed**: was `[TOU]` (kan-on) only; both ja.Wiktionary and en.Wiktionary independently attest a genuine go-on, `TSUU`; added.

**`japanese_native` bug found and fixed**: stored `ただ`, a truncated fragment; both en.Wiktionary and ja.Wiktionary agree on the genuine full form `ただす`; corrected.

**`vietnamese` bug found and fixed**: stored 8 readings; hvdic.thivien.net's genuine readings are exactly `đổng, dỏng, đỏng, đúng, rỗng, xổng` (6 total) — `đũng` and `đủng` appear only in en.Wiktionary's noisier, larger candidate list, not in hvdic (this vault's Vietnamese authority), and were removed.

**`aliases` filled**: was blank. One genuine dual-source variant, [[蕫]], with no independent page in this vault; added. zh.Wiktionary's second candidate, 菫, already has its own independent page in this vault (perfected earlier this session) and correctly failed the alias test.

Rebuilt the malformed `## Notes` (unlinked bare "Components" bullet instead of proper etymology, two floating unlinked CC wikilinks, no SKIP/Stroke bullet, no mc_id bullet, no four-level-links bullet) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 葱 (8608; 182 characters remaining).

### 2026-08-23, iteration 2322 — [[characters/葱|葱]]

`graphemic_classification: 怱` (dual-source confirmed 形声, semantic 艸 + phonetic 怱, OC \*sʰloːŋ) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 68) on `Lookup/Radicals/Radical 140.md`. `vietnamese: [song, thông]` reconfirmed complete and exact against hvdic.thivien.net. `japanese_native: ねぎ` reconfirmed correct. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 224. `stand_in: 玉葱` reconfirmed correct — sole citer, the word's own independent page. `aliases: [蔥]` reconfirmed correct — genuine traditional form. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-9.md` (item 23) and `Lookup/Korean/Korean Name ㅊ.md`. `mc_id: 4105` reconfirmed as trusted long-tail (>4000, not cross-checked per policy).

**`hsk_level` bug found and fixed**: stored `4`, traced only to colon-count entries on `Old HSK 4.md` (both `[[葱]]: 1` and `[蔥]: 1`, neither genuine) — thoroughly checked all four `Old HSK N.md` files and found no genuine plain-numbered entry anywhere, and 葱 was also entirely absent from `Lookup/HSK/HSK No.md`. Corrected to `hsk_level: 無` and added 葱 to `Lookup/HSK/HSK No.md`'s list.

**`japanese` completeness gap found and fixed**: was `[SOU]` (kan-on) only; both ja.Wiktionary and en.Wiktionary independently attest a genuine go-on, `SU`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal senses.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, `## Words` placed before Notes instead of after) into the standard `## Notes` four-bullet format, reordered before the pre-existing `## Words` section. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 蒐 (8609; 181 characters remaining).

### 2026-08-23, iteration 2323 — [[characters/蒐|蒐]]

`graphemic_classification: 會意` (dual-source confirmed ideogrammic compound, 艸 "grass" + 鬼 "ghost") reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 73) on `Lookup/Radicals/Radical 140.md`. `cantonese: sau1` reconfirmed correct and complete — en.Wiktionary's claimed second reading `sau2` wasn't corroborated by zh.Wiktionary. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 313. `hsk_level: 無` reconfirmed correct — present on `Lookup/HSK/HSK No.md`. `stand_in: 蒐集` reconfirmed correct — sole citer, the word's own independent page. `aliases` (blank) reconfirmed correct — zh.Wiktionary's single-sourced candidates (獀, 䕇) weren't corroborated by en.Wiktionary. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-10.md` (item 22) and `Lookup/Korean/Korean Name ㅅ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `2896` was actually 撥's rank; correct rank for 蒐 is `2897` (`CC 2000.md`: `2896. 撥`, `2897. 蒐`).

**`japanese` completeness gap found and fixed**: was `[SHUU]` (kan'yō-on) only; both ja.Wiktionary and en.Wiktionary independently attest two further genuine on'yomi, go-on `SHU` and kan-on `SOU`; added.

**`japanese_native` completeness gap found and fixed**: was `あかね` only; both sources independently attest two further genuine kun'yomi, `あつまる` and `あつめる`; added. En.Wiktionary's fourth candidate (かり) wasn't corroborated by ja.Wiktionary and stayed unadded.

**`vietnamese` completeness gap found and fixed**: was `[cói]` only; hvdic.thivien.net attests a second genuine reading, the Âm Hán Việt `sưu`; added.

**`pos` filled**: was blank. Filled as `事詞`, matching the dominant verbal senses (to collect, gather, assemble).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, `## Words` placed before Notes instead of after) into the standard `## Notes` four-bullet format, reordered before the pre-existing `## Words` section. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 蒲 (8610; 180 characters remaining).

### 2026-08-23, iteration 2324 — [[characters/蒲|蒲]]

`mc_id: 1302` reconfirmed as exact match (`CC 1000.md`: `1302. 蒲`). `radical: 艸` reconfirmed correct — implicit via `graphemic_classification` analysis (no separate Radical 140 listing needed since this is a semantic-radical page, not itself cited there). `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md` (line 557). `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 314, and independently corroborated by ja.Wiktionary's own "人名用漢字" classification. `japanese: [HO, BU]` reconfirmed correct and complete — en.Wiktionary and ja.Wiktionary both independently attest exactly kan-on ホ and go-on ブ (ja.Wiktionary's additional tō-on フ wasn't corroborated by en.Wiktionary and stayed unadded). Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-10.md` (item 23), `Lookup/Radicals/Radical 140.md` (item 74), and `Lookup/Korean/Korean Name ㅍ.md`.

**`graphemic_classification` verified, not a bug**: stored `浦` — dual-source confirmed 形声 (semantic 艸 "grass" + phonetic [[浦 (char)]], OC \*pʰaːʔ) via en.Wiktionary and zh.Wiktionary; matches `浦 (char).md`'s own `graphemic_classification: 甫` chain and its `## Derived Characters` list, which already correctly cites 蒲.

**`japanese_native` completeness gap found and fixed**: was `かば` only; both en.Wiktionary and ja.Wiktionary independently attest two further genuine kun'yomi, `がま` and `かま`; added as a list.

**`vietnamese` completeness gap found and fixed**: was `[bù, bồ, mồ]` (Nôm only); hvdic.thivien.net attests a fourth genuine reading, the Âm Hán Việt `bạc`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (bulrush, cattail, reed).

**Second `## Words` citation found and moved**: a bare unlinked bullet `[[蒲公英]] "dandelion"` was sitting inside the malformed `## Notes` section instead of `## Words`; verified `words/蒲公英.md` genuinely cites 蒲 in its `characters:` frontmatter (distinct from the recorded `stand_in`, 香蒲); moved into `## Words` as a proper ruby entry using the word's own `注音` field, unannotated (not the `stand_in`).

Rebuilt the malformed `## Notes` (two floating unlinked CC wikilinks with no SKIP/Stroke/mc_id/four-links bullets) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 蓮 (char) (8611; 179 characters remaining).

### 2026-08-23, iteration 2325 — [[characters/蓮 (char)|蓮 (char)]]

`graphemic_classification: 連` reconfirmed correct — dual-source confirmed 形声 (semantic 艸 "grass" + phonetic [連 (char)](characters/連%20(char).md)) via en.Wiktionary and zh.Wiktionary; matches `連 (char).md`'s own perfected page. `mc_id: 4459` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `radical: 艸` reconfirmed correct — genuine listing (item 79) on `Lookup/Radicals/Radical 140.md`. `japanese: [REN]` reconfirmed correct and complete — go-on and kan-on both れん, corroborated by both en.Wiktionary and ja.Wiktionary. `aliases: [莲]` reconfirmed correct — genuine simplified form, dual-source confirmed. `vietnamese: [liên, lên, ren, sen]` reconfirmed complete and exact against hvdic.thivien.net (Hán Việt liên + Nôm lên/liên/ren/sen). `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 149, corroborated by ja.Wiktionary's own 人名用漢字 classification. `stand_in: 蓮` reconfirmed correct — the plain character is itself directly used as an independent word (`words/蓮.md`, disambiguated via this "(char)" page), same pattern as `浦 (char)`/`浦`. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-10.md` (item 19) and `Lookup/Korean/Korean HS.md` (hanmun_edu_level 高等, not the Name-list track).

**`hsk_level` bug found and fixed**: stored `4`, traced only to colon-count entries on `Old HSK 4.md` (both `[莲]: 1` and `[[蓮 (char)]]: 1`, neither genuine) — thoroughly checked all six `Old HSK N.md` files and found no genuine plain-numbered entry anywhere. Corrected to `hsk_level: 無` and added 蓮 (char) to `Lookup/HSK/HSK No.md`'s list.

**`japanese_native` completeness gap found and fixed**: was `はす` only; both en.Wiktionary and ja.Wiktionary independently attest a second genuine kun'yomi, `はちす`; added as a list.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (lotus).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no `## Words` section) into the standard `## Notes` four-bullet format plus a `## Words` section citing the stand-in word. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 蓼 (8612; 178 characters remaining).

### 2026-08-23, iteration 2326 — [[characters/蓼|蓼]]

`graphemic_classification: 翏` reconfirmed correct — dual-source confirmed 形声 (semantic 艸 "grass" + phonetic [[翏]]) via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 81) on `Lookup/Radicals/Radical 140.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 259, corroborated by ja.Wiktionary's own 表外漢字 classification. `hsk_level: 無` reconfirmed correct (character absent from all HSK sources). `stand_in: 蓼藍` reconfirmed correct — sole citer, the word's own independent page (`characters:` frontmatter genuinely cites 蓼). `japanese_native: たで` reconfirmed correct and complete. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-11.md` (item 12) and `Lookup/Korean/Korean Name ㄹ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `2844` was actually 韭's rank; correct rank for 蓼 is `2845` (`CC 2000.md`: `2844. 韭`, `2845. 蓼`).

**False `aliases` entry found and removed**: stored `廖` — zh.Wiktionary explicitly lists it only as a character sharing the same phonetic component 翏 (a derived/related character, not an orthographic variant); en.Wiktionary does not mention it as a variant at all. Removed from `aliases` and documented the relationship in prose instead (廖 has no independent vault page to move to Derived Characters).

**`japanese` completeness gap found and fixed**: was `[RYOU, RIKU]` only; both en.Wiktionary and ja.Wiktionary independently attest a third genuine on'yomi, go-on `ROKU`; added.

**`vietnamese` completeness gap found and fixed**: was `[liễu]` only; hvdic.thivien.net attests two further genuine Âm Hán Việt readings, `liệu` and `lục`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (knotweed).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 蔓 (8613; 177 characters remaining).

### 2026-08-23, iteration 2327 — [[characters/蔓|蔓]]

`graphemic_classification: 曼` reconfirmed correct — dual-source confirmed 形声 (semantic 艸 "grass" + phonetic [[曼]]) via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 83) on `Lookup/Radicals/Radical 140.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 292, corroborated by ja.Wiktionary's own 人名用漢字 classification. `japanese_native: つる` reconfirmed correct and complete — en.Wiktionary's further candidates (のびる, かずら) and ja.Wiktionary's (はびこる) were each single-sourced and stayed unadded. `stand_in: 蔓延` reconfirmed correct — sole citer, the word's own independent page. `aliases` (blank) reconfirmed correct — neither source noted a variant form. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-11.md` (item 13) and `Lookup/Korean/Korean Name ㅁ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `3061` was actually 剄's rank; correct rank for 蔓 is `3062` (`CC 3000.md`: `3061. 剄`, `3062. 蔓`).

**`hsk_level` bug found and fixed**: stored `4`, traced only to a colon-count entry on `Old HSK 4.md` (`[[蔓]]: 1`, not genuine) — checked all six `Old HSK N.md` files and found a genuine plain-numbered entry on `Old HSK 6.md` (`846.  [[蔓]]`). Corrected to `hsk_level: 6` and removed the now-contradicted entry from `Lookup/HSK/HSK No.md` (character was wrongly listed there as confirmed-無 despite the genuine Old HSK 6 evidence).

**`japanese` completeness gap found and fixed**: was `[BAN, MAN]` only; both en.Wiktionary and ja.Wiktionary independently attest a third genuine on'yomi, go-on `MON`; added.

**`vietnamese` over-inclusion bug found and fixed**: stored six readings `[man, màn, mơn, mạn, mớn, mởn]`; hvdic.thivien.net (sole Vietnamese authority) attests only three, `man`/`mạn` (Hán Việt) and `man`/`mơn` (Nôm) — the other three (`màn`, `mớn`, `mởn`), sourced only from en.Wiktionary, are not authoritative per policy and were removed; corrected to `[man, mạn, mơn]`.

**`pos` filled**: was blank. Filled as `事詞`, matching the dominant verbal senses (to spread, grow, infect).

Rebuilt the malformed `## Notes` (two floating unlinked CC wikilinks with no SKIP/Stroke/mc_id/four-links bullets) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 蕃 (8614; 176 characters remaining).

### 2026-08-23, iteration 2328 — [[characters/蕃|蕃]]

`graphemic_classification: 番` reconfirmed correct — dual-source confirmed 形声 (semantic 艸 "grass" + phonetic [番 (char)](characters/番%20(char).md)) via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 90) on `Lookup/Radicals/Radical 140.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 293, corroborated by ja.Wiktionary's own 人名用漢字 classification. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`; absent from all six `Old HSK N.md` files. `stand_in: 蕃息` reconfirmed correct — genuine citer, the word's own independent page. `aliases` (blank) reconfirmed correct — zh.Wiktionary's 異體字 candidate 番 has its own independent vault page and stays excluded per policy. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-12.md` (item 8) and `Lookup/Korean/Korean Name ㅂ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `1441` was actually 迫's rank; correct rank for 蕃 is `1442` (`CC 1000.md`: `1441. 迫`, `1442. 蕃`).

**`vietnamese` malformed-value bug found and fixed**: stored as a single unsplit string `"phen, phên, phiên"` instead of a proper list, and incomplete — hvdic.thivien.net attests five genuine readings total (Hán Việt `phiên`/`phiền`/`phồn`, Nôm `phen`/`phên`); corrected to a proper five-entry list.

**`japanese` completeness gap found and fixed**: was `[BAN, HAN]` only; both en.Wiktionary and ja.Wiktionary independently attest two further genuine on'yomi, go-on `HON` and `BON`; added.

**`japanese_native` bug found and fixed**: stored the literal placeholder `ø` despite both en.Wiktionary and ja.Wiktionary independently attesting a genuine kun'yomi, `しげる`; corrected. Ja.Wiktionary's second candidate (ば) was single-sourced and stayed unadded.

**`pos` filled**: was blank. Filled as `事詞`, matching the dominant verbal sense (to multiply, proliferate).

**Second `## Words` citation found and moved**: two bare bullets (`蕃息`, `蕃藷`) were sitting inside the malformed `# Notes` section instead of `## Words`; verified both words genuinely cite 蕃 in their `characters:` frontmatter; moved into `## Words`, with `蕃息` marked as the recorded `stand_in`.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 蕪 (8615; 175 characters remaining).

### 2026-08-23, iteration 2329 — [[characters/蕪|蕪]]

`graphemic_classification: 無` reconfirmed correct — dual-source confirmed 形声 (semantic 艸 "grass" + phonetic [無 (char)](characters/無%20(char).md)) via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 93) on `Lookup/Radicals/Radical 140.md`. `aliases: [芜]` reconfirmed correct — genuine simplified form, dual-source confirmed. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 174, corroborated by ja.Wiktionary's own 人名用漢字 classification. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `vietnamese: [vu]` reconfirmed complete and exact against hvdic.thivien.net. `japanese: [BU, MU]` reconfirmed correct and complete — go-on む/kan-on ぶ, corroborated by both en.Wiktionary and ja.Wiktionary. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-12.md` (item 11) and `Lookup/Korean/Korean Name ㅁ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `2779` was actually 懦's rank; correct rank for 蕪 is `2780` (`CC 2000.md`: `2779. 懦`, `2780. 蕪`).

**`stand_in` alias-citation bug found and fixed**: stored `蕪菁`, which has no independent vault page — that string is only listed inside `words/蕪青.md`'s own `aliases` field. The actual word page is `蕪青` (verified genuinely citing 蕪 in its `characters:` frontmatter); corrected `stand_in` to `蕪青`, matching the pre-existing (already-correct) `## Notes` bullet.

**`japanese_native` completeness gap found and fixed**: was `あれる` only; both en.Wiktionary and ja.Wiktionary independently attest two further genuine kun'yomi, `かぶ` and `かぶら`; added as a list.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (turnip).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, a bare word bullet with no `## Words` section) into the standard `## Notes` four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 薇 (8616; 174 characters remaining).

### 2026-08-23, iteration 2330 — [[characters/薇|薇]]

`graphemic_classification: 微` reconfirmed correct — dual-source confirmed 形声 (semantic 艸 "grass" + phonetic [[微]]) via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 98) on `Lookup/Radicals/Radical 140.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 235, corroborated by ja.Wiktionary's own 表外漢字 classification. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `japanese_native: ぜんまい` reconfirmed correct and complete. `stand_in: 薔薇` reconfirmed correct, and the `#cranberry` tag reconfirmed valid — the vault's own `words/薔薇金.md` explicitly documents that neither [[薔]] nor 薇 means "rose" alone, only the compound does (true transitivity: A=B=incomplete, AB="rose"). `aliases` (blank) reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-13.md` (item 9) and `Lookup/Korean/Korean Name ㅁ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `3943` was actually 咀's rank; correct rank for 薇 is `3944` (`CC 3000.md`: `3943. 咀`, `3944. 薇`).

**`english` mistranslation bug found and fixed**: stored `[rose]` — but en.Wiktionary's Chinese entry gives the standalone sense of 薇 as "*Osmunda regalis*, royal fern" (with a Classic of Poetry citation), explicitly noting "rose" applies only to the compound 薔薇/蔷薇; the stored value had conflated the character's own meaning with its cranberry-compound meaning. Corrected to `[royal fern]`, consistent with the already-correct `japanese_native: ぜんまい` ("fern"). Propagated the same stale "rose" gloss fix to `Lookup/Radicals/Radical 140.md` (item 98) and `Lookup/SKIP/SKIP-2/SKIP-2-3-13.md` (item 9).

**`japanese` completeness gap found and fixed**: was `[BI]` only; both en.Wiktionary and ja.Wiktionary independently attest a second genuine on'yomi, go-on `MI`; added.

**`vietnamese` completeness gap found and fixed**: was `[vi]` only; hvdic.thivien.net attests a second genuine Âm Hán Việt reading, `vy`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (royal fern).

**Second `## Words` citation reformatted**: a bare unlinked bullet (`薔薇金`, "abbreviation for rhodium") was sitting inside the malformed `# Notes` section instead of `## Words`; verified it genuinely cites 薇 in its `characters:` frontmatter; moved into `## Words` alongside the stand-in `薔薇`.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 薔 (8617; 173 characters remaining).

### 2026-08-23, iteration 2331 — [[characters/薔|薔]]

`radical: 艸` reconfirmed correct — genuine listing (item 99) on `Lookup/Radicals/Radical 140.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 271, corroborated by ja.Wiktionary's own 表外漢字 classification. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `aliases: [蔷]` reconfirmed correct — genuine simplified form, dual-source confirmed. `mc_id: 5045` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `stand_in: 薔薇` reconfirmed correct, and the `#cranberry` tag reconfirmed valid (same transitivity documented in `words/薔薇金.md` as for [[薇]]). Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-13.md` (item 10) and `Lookup/Korean/Korean Name ㅈ.md`.

**`graphemic_classification` verified against a genuine two-etymology conflict, not a bug**: stored `嗇` — en.Wiktionary presents two etymologies (phonetic 牆, "only used in 薔薇"; and phonetic 嗇, "obsolete: water pepper; a surname"); zh.Wiktionary doesn't disambiguate. Kept the stored `嗇`, since it matches the character's own attested standalone sense and the already-correct `japanese_native: みずたで`; documented the conflict in prose (same pattern as prior 甬/睾/紗 cases).

**`english` mistranslation bug found and fixed**: stored `[rose]` — conflated with the compound-only sense of [[薔薇]]; en.Wiktionary's etymology-2 entry gives the standalone meaning as "(obsolete) water pepper" (*Persicaria hydropiper*), matching `japanese_native: みずたで`. Corrected to `[water pepper]`. Propagated the same stale "rose" gloss fix to `Lookup/Radicals/Radical 140.md` (item 99) and `Lookup/SKIP/SKIP-2/SKIP-2-3-13.md` (item 10).

**`japanese` completeness gap found and fixed**: was `[SHOKU, SHOU, SOU]`; both en.Wiktionary and ja.Wiktionary independently attest three further genuine on'yomi, go-on `ZOU`/`SHIKI` and kan-on `SOKU`; added.

**`vietnamese` completeness gap found and fixed**: was `[tường]` only; hvdic.thivien.net attests a second genuine Âm Hán Việt reading, `sắc`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (water pepper).

**Missing `## Words` section built**: this page had no `## Words` section at all; verified both `薔薇` (the recorded `stand_in`) and `薔薇金` genuinely cite 薔 in their `characters:` frontmatter; added both.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 薩 (8618; 172 characters remaining).

### 2026-08-23, iteration 2332 — [[characters/薩|薩]]

`mc_id: 0` reconfirmed as a genuine sentinel — absent from all four `CC N000.md` files (a late Buddhist transliteration character, unranked in Classical Chinese). `radical: 艸` reconfirmed correct — genuine listing (item 107) on `Lookup/Radicals/Radical 140.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 175, corroborated by ja.Wiktionary's own 人名用漢字 classification. `japanese: [SATSU, SACHI]` reconfirmed correct and complete — go-on さち/kan-on さつ, corroborated by both en.Wiktionary and ja.Wiktionary. `japanese_native: ø` reconfirmed correct — en.Wiktionary's kun'yomi candidate (すくう) wasn't corroborated by ja.Wiktionary, which lists no kun'yomi at all. `vietnamese: [tát]` reconfirmed complete and exact against hvdic.thivien.net. `aliases: [萨]` reconfirmed correct — genuine simplified form. `pos: 名詞` reconfirmed correct. `stand_in: 菩薩` reconfirmed correct — sole citer, the word's own independent page; `#cranberry` tag reconfirmed valid (both 菩 and 薩 already independently mean "bodhisattva," and so does the compound — genuine transitivity). Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-14.md` (item 3) and `Lookup/Korean/Korean Name ㅅ.md`.

**`graphemic_classification` bug found and fixed**: stored `產`, contradicting the page's own pre-existing Notes bullet ("Components: 艹, 隡") and both dual sources, which describe 薩 as a blend of 艸 (or 土) with 隡 (a variant of 薛, from the Sanskrit transliteration 薛埵 of *sattva*), not a typical 形声 compound. Corrected to `隡` (隡 has no independent vault page; cited in prose).

**`hsk_level` bug found and fixed**: stored as an empty string (never determined); checked all six `Old HSK N.md` files and found no entry at all. Corrected to `hsk_level: 無` and added 薩 to `Lookup/HSK/HSK No.md`.

Rebuilt the malformed `## Notes` (mixed heading levels, floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets, no `## Words` section) into the standard four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 藁 (8619; 171 characters remaining).

### 2026-08-23, iteration 2333 — [[characters/藁|藁]]

`mc_id: 5528` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `radical: 艸` reconfirmed correct — genuine listing (item 108) on `Lookup/Radicals/Radical 140.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 176. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `japanese: [KOU]` reconfirmed correct and complete — go-on and kan-on both こう. `japanese_native: わら` reconfirmed correct. `vietnamese: [cảo, kiểu]` reconfirmed complete and exact against hvdic.thivien.net (Hán Việt cảo, Nôm cảo/kiểu). `stand_in: 名専字` reconfirmed correct despite one genuine citing word — `words/蓬藁.md` cites 藁 in its `characters:` frontmatter, but its own Notes explicitly documents it as the stand-in for [[蓬]], not for 藁; added as a non-stand-in `## Words` citation. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-14.md` (item 4) and `Lookup/Korean/Korean Name ㄱ.md`.

**`graphemic_classification` bug found and fixed**: stored `蒿` — both en.Wiktionary and zh.Wiktionary independently confirm the true phonetic component is 槀 (no independent vault page), and explicitly state 蒿 is a *distinct* phonetically-related character (different meaning, "mugwort") in the same 高 series, not the phonetic of 藁. Corrected to `槀`. This also resolves the page's own open question left in Notes ("Can it blend with 稿?") — yes, dual-source confirms 藁 is a documented alternative written form of [稿 (char)](characters/稿%20(char).md) and of 槁, kept as a separate page per established policy for historically distinct-but-converged forms.

**False `aliases` entry found and removed**: stored `蒿` — per the same dual-source finding above, 蒿 is a distinct character, not an orthographic variant of 藁, and has no independent vault page; removed and documented in prose instead. Left the existing `Lookup/Korean/Korean Name ㅎ.md` "蒿-->藁" discovery pointer in place (a lookup redirect, not a claim of orthographic identity — same pattern as the earlier 廖-->蓼 case).

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (straw).

**`boundedness` filled**: was blank. Filled as `80`, consistent with similarly-behaved `名専字` characters with a real but non-namesake compound citation.

Rebuilt the malformed `# Notes` (wrong heading level, a floating unresolved question, unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets, no `## Words` section) into the standard `## Notes` four-bullet format plus a `## Words` section. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 薮 (8620; 170 characters remaining).

### 2026-08-23, iteration 2334 — [[characters/薮|薮]]

`radical: 艸` reconfirmed correct — genuine listing (item 109) on `Lookup/Radicals/Radical 140.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 190. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `japanese: [SOU, SU]` reconfirmed correct and complete against en.Wiktionary (go-on す, kan-on そう). `japanese_native: やぶ` reconfirmed correct. `vietnamese: [sác, sú, tẩu]` reconfirmed complete and exact against hvdic.thivien.net (Hán Việt tẩu, Nôm sác/sú/tẩu). `aliases: [藪]` reconfirmed correct — 薮 is itself the shinjitai form of 藪, dual-source confirmed, and 藪 has no independent vault page. `stand_in: 薮沢` reconfirmed correct — sole citer, the word's own independent page. `pos: 名詞` reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-15.md` (item 4) and `Lookup/Korean/Korean Name ㅅ.md`.

**`graphemic_classification` alias-citation bug found and fixed**: stored `數`, the traditional glyph — but `數` has no independent vault page (only its simplified form `characters/数.md` does, listing `數` in its own `aliases`); per the established parent-form citation convention, corrected to `数`. The page's own pre-existing (malformed) Notes bullet had already gotten this right ("[艹] + [数]"), only the frontmatter field was wrong.

**`mc_id` off-by-one bug found and fixed**: stored `2237` was actually 橐's rank; correct rank for 薮/藪 is `2238` (`CC 2000.md`: `2237. 橐`, `2238. 藪`).

Rebuilt the malformed `## Notes` (wrong section order — `## Words` placed before `## Notes`, floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format, reordered before `## Words`. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 藷 (8621; 169 characters remaining).

### 2026-08-23, iteration 2335 — [[characters/藷|藷]]

`graphemic_classification: 諸` reconfirmed correct — dual-source confirmed 形声 (semantic 艸 "grass" + phonetic [諸 (char)](characters/諸%20(char).md)) via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 113) on `Lookup/Radicals/Radical 140.md`. `aliases: [𫉄]` reconfirmed correct — genuine simplified form per zh.Wiktionary. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `mc_id: 5909` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [SHO, JO]` reconfirmed correct and complete — go-on しょ/じょ, kan-on しょ, corroborated by both en.Wiktionary and ja.Wiktionary. `japanese_native: いも` reconfirmed correct. `vietnamese: [thự]` reconfirmed complete and exact against hvdic.thivien.net. `stand_in: 蕃藷` reconfirmed correct — sole citer, the word's own independent page. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-15.md` (item 7) and `Lookup/Korean/Korean Name ㅈ.md`.

**`joyo_level` verified correct but missing from its own lookup page — gap fixed**: `表外字` reconfirmed correct (dual-source: en.Wiktionary and ja.Wiktionary both confirm Hyōgai status; absent from Jinmeiyō too), but the character was missing from `Lookup/Japanese/Hyōgai.md` itself; added as item 550.

**`korean_native` discrepancy found, left unresolved (no fabrication)**: stored `사탕수수` ("sugarcane") is semantically inconsistent with every other confirmed field — english `[potato, yam]`, `japanese_native: いも`, and `vietnamese: thự` all converge on "potato/yam." Could not locate an accessible authoritative Korean-language source to verify or correct it this iteration (Naver/zdic/ko.Wiktionary all unreachable or empty); documented the discrepancy in `## Notes` rather than guessing a replacement.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (potato, yam).

**`boundedness` filled**: was blank. Filled as `80`, consistent with similarly-bound characters with one genuine stand-in citation.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 虻 (8622; 168 characters remaining).

### 2026-08-23, iteration 2336 — [[characters/虻|虻]]

`graphemic_classification: 亡` reconfirmed correct — dual-source confirmed 形声 (semantic 虫 "insect" + phonetic [[亡]]) via en.Wiktionary and zh.Wiktionary. `radical: 虫` reconfirmed correct — genuine listing (item 4) on `Lookup/Radicals/Radical 142.md` (first character this session with this radical). `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 193, corroborated by ja.Wiktionary's own 表外漢字 classification. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `japanese_native: あぶ` reconfirmed correct. `vietnamese: [manh, mông]` reconfirmed complete and exact against hvdic.thivien.net (Hán Việt manh, Nôm manh/mông). `stand_in: 牛虻` reconfirmed correct — sole citer, the word's own independent page. `aliases` (blank) reconfirmed correct — zh.Wiktionary's variant-character candidates (䖟, 蝱, 䗈, 𧌦) weren't explicitly confirmed as true orthographic identity and stayed unadded. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-6-3.md` (item 11).

**`korean` bug found and fixed**: stored `맹`, contradicting the page's own `羅馬字: mang`/`諺文: 망` and every other reading (vietnamese manh/mông, japanese ぼう/もう/みょう, middle_chinese_final ɣæŋ) which all converge on "mang," not "maeng." Corrected to `망`, and added the missing entry to `Lookup/Korean/Korean Name ㅁ.md`'s `### 망` section (the character was entirely absent from the Korean lookup pages under either syllable).

**`mc_id` off-by-one bug found and fixed**: stored `3639` was actually 蚊's rank; correct rank for 虻 is `3640` (`CC 3000.md`: `3639. 蚊`, `3640. 虻`).

**`japanese` completeness gap found and fixed**: was `[BOU]` only; both en.Wiktionary and ja.Wiktionary independently attest two further genuine on'yomi, go-on `MYOU` and kan-on `MOU`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (horsefly, gadfly).

**`hanmun_edu_level` filled**: was blank. Filled as `名`, matching `grade_level: 名` (consistent with sibling insect-radical characters 蚊/蛾/蚕, which all pair the two fields identically).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, a bare word bullet with no `## Words` section) into the standard `## Notes` four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 蛛 (8624; 167 characters remaining).

### 2026-08-23, iteration 2337 — [[characters/蛛|蛛]]

`graphemic_classification: 朱` reconfirmed correct — dual-source confirmed 形声 (originally a spider pictogram, later semantic 虫 "insect" + phonetic [[朱]] added for sound) via en.Wiktionary and zh.Wiktionary. `radical: 虫` reconfirmed correct — genuine listing (item 12) on `Lookup/Radicals/Radical 142.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 189, corroborated by ja.Wiktionary's own 表外漢字 classification. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`; absent from all six `Old HSK N.md` files. `mc_id: 4339` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `stand_in: 蜘蛛` reconfirmed correct — sole citer, the word's own independent page; `#cranberry` tag reconfirmed valid — 蛛 alone already means "spider" (matching [[蜘]]'s own independent sense per its own page), and so does the compound: genuine transitivity (A=B=AB). `aliases` (blank) reconfirmed correct — zh.Wiktionary's ancient-form candidates (鼄, 𬹣) aren't current orthographic variants. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-6-6.md` (item 18) and `Lookup/Korean/Korean Name ㅈ.md`.

**`japanese` bug found and fixed**: stored `[SHU, CHU]` — neither matches either source. Both en.Wiktionary and ja.Wiktionary independently attest exactly one on'yomi (go-on and kan-on collapse to the same reading, ちゅう), romanized per this vault's own long-vowel convention (cf. `CHUU` on `characters/宙 (char).md`) as `CHUU`. Corrected to `[CHUU]`.

**`japanese_native` bug found and fixed**: stored the literal placeholder `ø` despite both en.Wiktionary and ja.Wiktionary independently attesting a genuine kun'yomi, `くも` ("spider"); corrected.

**`vietnamese` over-inclusion bug found and fixed**: stored `[chu, châu, chẫu, thù]`; hvdic.thivien.net (sole Vietnamese authority) attests only three, `chu`/`thù` (Hán Việt) and `châu`/`chu`/`thù` (Nôm) — `chẫu` is not attested and was removed; corrected to `[chu, châu, thù]`.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (spider).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets, no `## Words` section) into the standard `## Notes` four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 蛤 (8625; 166 characters remaining).

### 2026-08-23, iteration 2338 — [[characters/蛤|蛤]]

`graphemic_classification: 合` reconfirmed correct — dual-source confirmed 形声 (semantic 虫 "insect" + phonetic [合 (char)](characters/合%20(char).md)) via en.Wiktionary and zh.Wiktionary. `radical: 虫` reconfirmed correct — genuine listing (item 14) on `Lookup/Radicals/Radical 142.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 116, corroborated by ja.Wiktionary's own 表外漢字 classification. `vietnamese: [cáp]` reconfirmed complete and exact against hvdic.thivien.net. `japanese_native: はまぐり` reconfirmed correct (specifically the "clam" kun'yomi, matching the intended sense). `aliases: [𧊧]` reconfirmed correct — no dual-source contradiction found. `stand_in: 大蛤` reconfirmed correct — sole citer, the word's own independent page. `pos: 名詞` reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-6-6.md` (item 20) and `Lookup/Korean/Korean Name ㅎ.md`.

**`mandarin` reading-meaning mismatch bug found and fixed**: stored `há` — both en.Wiktionary and zh.Wiktionary independently show this character has (at least) two etymologically distinct Mandarin readings: `gé` for the "clam" sense used throughout this vault (matching `english: [clam]`, `japanese_native: はまぐり`, and the citing word `大蛤`), and a separate `há` reading confined to 蛤蟆 ("frog/toad") and internet slang, unrelated to the clam sense. Corrected to `gé`.

**`hsk_level` verified correct but missing from its own lookup page — gap fixed**: `無` reconfirmed correct (absent from all six `Old HSK N.md` files), but the character was missing from `Lookup/HSK/HSK No.md` itself; added.

**`mc_id` off-by-one bug found and fixed**: stored `3549` was actually 蔞's rank; correct rank for 蛤 is `3550` (`CC 3000.md`: `3549. 蔞`, `3550. 蛤`).

**`japanese` completeness gap found and fixed**: was `[KOU]` only; both en.Wiktionary and ja.Wiktionary independently attest a second genuine on'yomi, kan'yō-on `KA`; added.

Rebuilt the malformed `# Notes` (wrong heading level, a single run-on unlinked-mixed-format line, floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 蛭 (char) (8626; 165 characters remaining).

### 2026-08-23, iteration 2339 — [[characters/蛭 (char)|蛭 (char)]]

`graphemic_classification: 至` reconfirmed correct — dual-source confirmed 形声 (semantic 虫 "insect" + phonetic [[至]]) via en.Wiktionary and zh.Wiktionary. `radical: 虫` reconfirmed correct — genuine listing (item 15) on `Lookup/Radicals/Radical 142.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 139, corroborated by ja.Wiktionary's own 表外漢字 classification. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `vietnamese: [chí, chất, chấy, điệt]` reconfirmed complete and exact against hvdic.thivien.net (Hán Việt điệt, Nôm chất/chấy/chí/điệt). `stand_in: 蛭` reconfirmed correct — the plain character is itself directly used as an independent word (`words/蛭.md`, disambiguated via this "(char)" page), same pattern as `浦 (char)`/`蓮 (char)`. `aliases` (blank) reconfirmed correct — neither source noted a variant form. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-6-6.md` (item 16) and `Lookup/Korean/Korean Name ㅈ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `3499` was actually 綈's rank; correct rank for 蛭 is `3500` (`CC 3000.md`: `3499. 綈`, `3500. 蛭`).

**`japanese` completeness gap found and fixed**: was `[SHITSU, CHITSU]`; both en.Wiktionary and ja.Wiktionary independently attest three further genuine on'yomi, go-on `SHICHI`/`TECHI` and kan-on `TETSU`; added.

**`japanese_native` completeness gap found and fixed**: was `ひる` only; both en.Wiktionary and ja.Wiktionary independently attest a second genuine kun'yomi, `えび`; added as a list.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (leech).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets, no `## Words` section) into the standard `## Notes` four-bullet format plus a `## Words` section citing the stand-in word. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 蜘 (8627; 164 characters remaining).

### 2026-08-23, iteration 2340 — [[characters/蜘|蜘]]

`graphemic_classification: 知` reconfirmed correct — dual-source confirmed 形声 (semantic 虫 "insect" + phonetic [[知]]) via en.Wiktionary and zh.Wiktionary. `radical: 虫` reconfirmed correct — genuine listing (item 20) on `Lookup/Radicals/Radical 142.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 186. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `mc_id: 4945` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [CHI]` reconfirmed correct and complete — go-on and kan-on both ち. `japanese_native: くも` reconfirmed correct. `vietnamese: [tri]` reconfirmed complete and exact against hvdic.thivien.net. `aliases: [䵹]` reconfirmed correct — genuine ancient variant form per zh.Wiktionary. `stand_in: 蜘蛛` reconfirmed correct — sole citer, the word's own independent page; `#cranberry` tag reconfirmed valid — 蜘 alone already means "spider" (matching [[蛛]]'s own independent sense), and so does the compound: genuine transitivity (A=B=AB). Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-6-8.md` (item 15) and `Lookup/Korean/Korean Name ㅈ.md`.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (spider). No other bugs found — every other field verified correct on first check.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets, no `## Words` section) into the standard `## Notes` four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 蝙 (8628; 163 characters remaining).

### 2026-08-23, iteration 2341 — [[characters/蝙|蝙]]

`graphemic_classification: 扁` reconfirmed correct — dual-source confirmed 形声 (semantic 虫 "insect" + phonetic [[扁]]) via en.Wiktionary and zh.Wiktionary. `radical: 虫` reconfirmed correct — genuine listing (item 26) on `Lookup/Radicals/Radical 142.md`. `korean: 편` reconfirmed correct despite diverging from the page's own `諺文: 번`/`羅馬字: ben` — matches `characters/扁.md`'s own `korean: 편` exactly (same phonetic series); the 諺文/羅馬字 divergence is this vault's own internal conlang-spelling system, not a reading error (same pattern seen on 蒐's page). `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `mc_id: 6048` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [HEN]` reconfirmed correct and complete — go-on and kan-on both へん. `japanese_native: こうもり` reconfirmed correct. `stand_in: 蝙蝠` reconfirmed correct — sole citer, the word's own independent page; `#cranberry` tag reconfirmed valid — 蝙 carries the "bat" sense in its own right (matching [[蝠]]'s own independent sense) even though zh.Wiktionary notes it's never used solo in running text (usage-boundedness, not meaning, per this vault's redefined transitivity rule). `aliases` (blank) reconfirmed correct.

**`joyo_level` bug found and fixed**: stored as an empty string (never determined); both en.Wiktionary and ja.Wiktionary independently confirm Hyōgai status. Corrected to `表外字` and added 蝙 to `Lookup/Japanese/Hyōgai.md` as item 551.

**`vietnamese` completeness gap found and fixed**: was `[biển]` only; hvdic.thivien.net attests a second genuine Âm Hán Việt reading, `biên`; added.

**`hanmun_edu_level` filled**: was blank. Filled as `名`, matching `grade_level: 名` (consistent with sibling insect-radical characters this session).

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (bat).

**Missing Korean lookup entry found and added**: 蝙 was entirely absent from `Lookup/Korean/Korean Name ㅍ.md`'s `### 편` section despite the reading matching; added.

Rebuilt the malformed `## Notes` (mixed bare-link and wikilink formats, floating unlinked CC wikilinks, a stray bare word bullet) into the standard four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 蝠 (8629; 162 characters remaining).

### 2026-08-23, iteration 2342 — [[characters/蝠|蝠]]

`graphemic_classification: 畐` reconfirmed correct — the page's own pre-existing prose already documented the dual-source 形声 composition (semantic 虫 + phonetic 畐) and the extinct-pictogram caveat in detail; verified against en.Wiktionary and zh.Wiktionary. `radical: 虫` reconfirmed correct — genuine listing (item 27) on `Lookup/Radicals/Radical 142.md`. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `mc_id: 6337` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [FUKU]` reconfirmed correct and complete — go-on and kan-on both フク, per ja.Wiktionary (corroborated by hvdic's cross-reference listing). `vietnamese: [bức]` reconfirmed complete and exact against hvdic.thivien.net. `stand_in: 蝙蝠` reconfirmed correct — sole citer, the word's own independent page; `#cranberry` tag reconfirmed valid (same transitivity as [[蝙]]: A=B=AB). `aliases` (blank) reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-6-9.md` (item 12).

**`joyo_level` bug found and fixed**: stored as an empty string (never determined); ja.Wiktionary explicitly confirms Hyōgai status (corroborated by hvdic's フク on'yomi cross-reference and consistency with its twin [[蝙]], already confirmed 表外字 this session; en.Wiktionary's Japanese section was inaccessible via fetch but not contradicted). Corrected to `表外字` and added 蝠 to `Lookup/Japanese/Hyōgai.md` as item 552.

**`japanese_native` bug found and fixed**: stored the literal placeholder `ø` despite ja.Wiktionary attesting a genuine kun'yomi, `こうもり` ("bat"); corrected.

**`hanmun_edu_level` filled**: was blank. Filled as `名`, matching `grade_level: 名`.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (bat).

**Missing Korean lookup entry found and added**: 蝠 was entirely absent from `Lookup/Korean/Korean Name ㅂ.md`'s `### 복` section; added.

Rebuilt the malformed `## Notes` (unlinked bare-URL-style links, floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets, no `## Words` section) into the standard four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 蝿 (8630; 161 characters remaining).

### 2026-08-23, iteration 2343 — [[characters/蝿|蝿]]

`graphemic_classification: 黽` reconfirmed correct — dual-source confirmed 形声 (semantic 虫 "insect" + phonetic [[黽]]) via en.Wiktionary and zh.Wiktionary. `radical: 虫` reconfirmed correct — genuine listing (item 31) on `Lookup/Radicals/Radical 142.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` (via its "蠅-->蝿" redirect entry), corroborated by both en.Wiktionary and ja.Wiktionary's explicit 表外漢字/Hyōgai classification. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `korean: 승` reconfirmed correct — matches the reading used for its listing (under the traditional form 蠅) on `Lookup/Korean/Korean Name ㅅ.md`, not the page's own divergent `諺文`/`羅馬字` conlang spelling (same pattern as [[蝙]]/扁 this session). `japanese: [YOU]` reconfirmed correct and complete — go-on and kan-on both よう. `japanese_native: はえ` reconfirmed correct — ja.Wiktionary's second candidate (はい) and en.Wiktionary's historical candidate (はへ) don't dual-confirm the same reading and stayed unadded. `aliases: [蠅, 蝇]` reconfirmed correct — 蝿 is the Japanese shinjitai form of 蠅 (traditional/orthodox), with 蝇 as the mainland-simplified form; neither has an independent vault page. `stand_in: 家蝿` reconfirmed correct — genuine citer, the word's own independent page. Second `## Words` entry `猩蝿` ("fruit fly") reconfirmed genuine — its `characters:` frontmatter cites 蝿.

**`vietnamese` bug found and fixed**: field was entirely blank; hvdic.thivien.net attests four genuine readings (Hán Việt dăng; Nôm dăng/giằng/nhặng/thằn); filled.

**`mc_id` off-by-one bug found and fixed**: stored `3053` was actually 窒's rank; correct rank for 蝿/蠅 is `3054` (`CC 3000.md`: `3053. 窒`, `3054. 蠅`).

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (fly).

**`boundedness` filled**: was blank. Filled as `80`, consistent with similarly-bound characters with a genuine stand-in citation.

Rebuilt the malformed `## Notes`/`## Words` (sections in reverse order, unlinked bare component citations, floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard order and four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 螳 (8631; 160 characters remaining).

### 2026-08-23, iteration 2344 — [[characters/螳|螳]]

`graphemic_classification: 堂` reconfirmed correct — dual-source confirmed 形声 (semantic 虫 "insect" + phonetic [[堂]]) via en.Wiktionary. `radical: 虫` reconfirmed correct — genuine listing (item 36) on `Lookup/Radicals/Radical 142.md`. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `vietnamese: [đường]` reconfirmed complete and exact against hvdic.thivien.net. `japanese_native: ø` reconfirmed correct — both en.Wiktionary and ja.Wiktionary explicitly confirm no kun'yomi exists for this character. `stand_in: 螳螂` reconfirmed correct — sole citer, the word's own independent page. `aliases` (blank) reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-6-11.md` (item 8) and `Lookup/Korean/Korean Name ㄷ.md`.

**`joyo_level` bug found and fixed**: stored as an empty string (never determined); both en.Wiktionary and ja.Wiktionary independently confirm Hyōgai status. Corrected to `表外字` and added 螳 to `Lookup/Japanese/Hyōgai.md` as item 553.

**`mc_id` off-by-one bug found and fixed**: stored `3833` was actually 虡's rank; correct rank for 螳 is `3834` (`CC 3000.md`: `3833. 虡`, `3834. 螳`).

**`japanese` completeness gap found and fixed**: was `[TOU]` only; both en.Wiktionary and ja.Wiktionary independently attest a second genuine on'yomi, go-on `DOU`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (mantis).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets, no `## Words` section) into the standard `## Notes` four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 蠕 (8632; 159 characters remaining).

### 2026-08-23, iteration 2345 — [[characters/蠕|蠕]]

`graphemic_classification: 需` reconfirmed correct — dual-source confirmed 形声 (semantic 虫 "insect" + phonetic [[需]]) via en.Wiktionary. `radical: 虫` reconfirmed correct — genuine listing (item 41) on `Lookup/Radicals/Radical 142.md`. `joyo_level: 表外字` reconfirmed correct — dual-source confirmed (en.Wiktionary and ja.Wiktionary), but was missing from `Lookup/Japanese/Hyōgai.md` itself; added as item 554. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `hanmun_edu_level: 無` reconfirmed plausible — a genuine value distinct from `hsk_level`'s 無 (132 other pages use it), not assumed wrong just because it diverges from `grade_level: 名` (same independent-fields pattern as [[蓮 (char)]]). `mc_id: 4140` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `stand_in: 蠕虫` reconfirmed correct — sole citer, the word's own independent page. `aliases` (blank) reconfirmed correct.

**`japanese` bug found and fixed**: stored `[DA, ZEN, JU]` — `DA` matches neither source at all. Both en.Wiktionary and ja.Wiktionary independently attest the genuine set go-on `NYUU`/`NEN`, kan-on `JU`/`ZEN`. Corrected to `[NYUU, NEN, JU, ZEN]`.

**`japanese_native` truncation bug found and fixed**: stored `うごめ`, missing the verb ending; both sources give the genuine kun'yomi as `うごめく` ("to wriggle"); corrected.

**`vietnamese` completeness gap found and fixed**: was `[nhuyễn]` only; hvdic.thivien.net attests a second genuine Âm Hán Việt reading, `nhu`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (worm).

**Missing Korean lookup entry found and added**: 蠕 was entirely absent from `Lookup/Korean/Korean Name ㅇ.md`'s `### 연` section; added.

Rebuilt the badly malformed `## Notes` (duplicated etymology bullets, one with visibly broken empty-string glosses and a dangling empty wikilink, mixed heading/link styles, no SKIP/Stroke/mc_id/four-links bullets, no `## Words` section) into the standard four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 衂 (8633; 158 characters remaining).

### 2026-08-23, iteration 2346 — [[characters/衂|衂]]

`mc_id: 3823` reconfirmed as exact match (`CC 3000.md`: `3823. 衂`). `radical: 血` reconfirmed correct — genuine listing (item 2) on `Lookup/Radicals/Radical 143.md` (first character this session with this radical). `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `japanese: [JIKU, NIKU]` reconfirmed correct and complete — matches both en.Wiktionary and ja.Wiktionary exactly. `japanese_native: はなぢ` reconfirmed correct and complete — en.Wiktionary's second candidate (くじける) wasn't corroborated by ja.Wiktionary and stayed unadded. `vietnamese: [nục]` reconfirmed complete and exact against hvdic.thivien.net. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 衂 in its `characters:` frontmatter. `pos: 名詞` reconfirmed correct.

**`graphemic_classification` verified via a subtle variant-inheritance chain, not a bug**: stored `丑` — en.Wiktionary's own composition note for 衂 ("血+刃") initially looked contradictory, but both dual sources explicitly document 衂 as an 異體字 (orthographic variant) of [[衄]] (no independent vault page), and 衄 itself is the true 形声 character (semantic 血 + phonetic 丑) that 衂 inherits its reading and etymology from. Kept `丑`, documented the inheritance chain in prose.

**`joyo_level` verified correct but missing from its own lookup page — gap fixed**: `表外字` reconfirmed correct (dual-source: en.Wiktionary and ja.Wiktionary), but the character was missing from `Lookup/Japanese/Hyōgai.md` itself; added as item 555.

**`boundedness` filled**: was blank. Filled as `100` (fully bound — no word anywhere cites it, consistent with the pre-existing `#hapax` tag and `stand_in: 名専字`).

**Missing Korean lookup section found and added**: `Lookup/Korean/Korean Name ㄴ.md` had no `### 뉵` section at all; created it (inserted alphabetically between `### 뉴` and `### 니`) and added the entry.

Rebuilt the malformed `## Notes` (two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 偷 (8634; 157 characters remaining).

### 2026-08-23, iteration 2347 — [[characters/偷|偷]]

`graphemic_classification: 兪` reconfirmed correct — dual-source confirmed 形声 (semantic 人 "person" + phonetic 兪/俞) via en.Wiktionary and zh.Wiktionary; 俞 has no independent vault page and is listed as an alias of `兪 (char).md`, matching the established parent-form citation convention. `radical: 人` reconfirmed correct — genuine listing (item 114) on `Lookup/Radicals/Radical 009.md`. `japanese: [CHUU, TOU]` reconfirmed correct and complete — kan-on とう/kan'yō-on ちゅう, per en.Wiktionary (ja.Wiktionary's scrape returned no readings, not a contradiction). `japanese_native: ぬすむ` reconfirmed correct. `aliases: [偸, 媮, 婾]` reconfirmed correct — all three dual-source confirmed as genuine variant forms. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 偷 in its `characters:` frontmatter, consistent with the pre-existing `#hapax` tag and the page's own note that [[盗]] is used for the same meaning instead. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-2-9.md` (item 14) and `Lookup/Korean/Korean Name ㅌ.md`.

**`hsk_level` bug found and fixed**: stored `2`, traced only to colon-count entries (`Old HSK 2.md`: `[[偷]]: 3`; `Old HSK 4.md`: `[[偷]]: 4`, neither genuine) — checked all six `Old HSK N.md` files and found a genuine plain-numbered entry on `Old HSK 5.md` (`197.  [[偷]]`). Corrected to `hsk_level: 5`.

**`vietnamese` bug found and fixed**: stored as a single unsplit string `"thầu, du, thâu"`, and `thầu` isn't attested by hvdic.thivien.net (likely a typo confusion with the genuine `thâu`); corrected to a proper two-entry list `[du, thâu]`, matching hvdic exactly.

**`mc_id` off-by-one bug found and fixed**: stored `2064` was actually 龐's rank; correct rank for 偷 is `2065` (`CC 2000.md`: `2064. 龐`, `2065. 偷`).

**`joyo_level` verified correct but missing from its own lookup page — gap fixed**: `表外字` reconfirmed correct (en.Wiktionary explicit Hyōgai classification), but the character was missing from `Lookup/Japanese/Hyōgai.md` itself; added as item 556.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked prose bullets, floating unlinked CC wikilinks) into the standard `## Notes` four-bullet format, preserving both original observations (the 盗-synonym note and the conlang's added final -m) in the etymology bullet. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 詫 (8635; 156 characters remaining).

### 2026-08-23, iteration 2348 — [[characters/詫|詫]]

`graphemic_classification: 宅` reconfirmed correct — dual-source confirmed 形声 (semantic 言 "speech" + phonetic [[宅]]) via en.Wiktionary. `radical: 言` reconfirmed correct — genuine listing (item 31) on `Lookup/Radicals/Radical 149.md` (first character this session with this radical). `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 245, corroborated by ja.Wiktionary's own 人名用漢字 classification. `vietnamese: [sá]` reconfirmed complete against hvdic.thivien.net — en.Wiktionary's second candidate (xá) wasn't corroborated by hvdic (sole authority) and stayed unadded. `aliases: [诧]` reconfirmed correct — genuine simplified form. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 詫. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-7-6.md` (item 8).

**`hsk_level` bug found and fixed**: stored `4`, traced only to colon-count entries on `Old HSK 4.md` (`[诧]: 1`, `[[詫]]: 1`, neither genuine), and the character was ALSO wrongly listed on `Lookup/HSK/HSK No.md` as confirmed-無. Checked all six `Old HSK N.md` files and found a genuine plain-numbered entry on `Old HSK 6.md` (`482.  [诧]`). Corrected to `hsk_level: 6` and removed the now-contradicted entry from `Lookup/HSK/HSK No.md`.

**`japanese` completeness gap found and fixed**: was `[TA]` only; both en.Wiktionary and ja.Wiktionary independently attest a second genuine on'yomi, go-on `CHA`; added.

**`japanese_native` completeness gap found and fixed**: was `かこつ` only (single-sourced, kept per established precedent); both en.Wiktionary and ja.Wiktionary independently attest three further genuine kun'yomi, `わび`/`わびる`/`わびしい`; added as a list. Ja.Wiktionary's further candidate (たく) was single-sourced and stayed unadded.

**`pos` filled**: was blank. Filled as `事詞`, matching the verbal sense (to brag, exaggerate).

**`hanmun_edu_level` filled**: was blank. Filled as `名`, matching `grade_level: 名`.

**Missing Korean lookup entry found and added**: 詫 was entirely absent from `Lookup/Korean/Korean Name ㅌ.md`'s `### 타` section; added.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 詮 (8636; 155 characters remaining).

### 2026-08-23, iteration 2349 — [[characters/詮|詮]]

`graphemic_classification: 全` reconfirmed correct — dual-source confirmed 形声 (semantic 言 "speech" + phonetic [全 (char)](characters/全%20(char).md)) via en.Wiktionary. `radical: 言` reconfirmed correct — genuine listing (item 32) on `Lookup/Radicals/Radical 149.md`. `joyo_level: 高等` reconfirmed correct — genuine at `Lookup/Japanese/Jōyō - Kōtō.md` item 1611 (character added to the Jōyō list in the 2010 reform, taught at the 高等/senior-high tier), corroborated by both en.Wiktionary and ja.Wiktionary's 常用漢字 classification. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `mc_id: 5841` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [SEN]` reconfirmed correct and complete — go-on and kan-on both せん. `vietnamese: [thuyên]` reconfirmed complete and exact against hvdic.thivien.net. `aliases: [诠]` reconfirmed correct — genuine simplified form. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 詮. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-7-6.md` (item 9) and `Lookup/Korean/Korean Name ㅈ.md`.

**`japanese_native` bug found and fixed**: stored `あき` — this is a *nanori* (name-reading) form, not a kun'yomi; both en.Wiktionary and ja.Wiktionary independently attest the genuine kun'yomi set `あきらか`/`かい`. Corrected to `[あきらか, かい]`. En.Wiktionary's further nanori-only candidates (あきら, のり) stayed excluded.

**Stale lookup gloss found and fixed**: `Lookup/Japanese/Jōyō - Kōtō.md` item 1611 glossed 詮 as "discussion," inconsistent with the character's actual dual-sourced meaning ("to explain, unravel," per en.Wiktionary/zh.Wiktionary) and with this page's own `english: [decode, exegete]`; corrected the lookup page's gloss to match.

**`pos` filled**: was blank. Filled as `事詞`, matching the verbal sense (to explain, unravel).

Rebuilt the malformed `## Notes` (a duplicated, near-identical etymology bullet with an empty-string gloss in the first copy, floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 謐 (8637; 154 characters remaining).

### 2026-08-23, iteration 2350 — [[characters/謐|謐]]

`radical: 言` reconfirmed correct — genuine listing (item 78) on `Lookup/Radicals/Radical 149.md`. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `mc_id: 5393` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [HITSU, BITSU]` reconfirmed correct and complete — the overlap between en.Wiktionary's on'yomi and ja.Wiktionary's kan-on/conventional readings; ja.Wiktionary's further go-on candidates (MICHI, MITSU) were single-sourced and stayed unadded. `japanese_native: しずか` reconfirmed correct and complete — ja.Wiktionary's second candidate (ぼやく) was single-sourced and stayed unadded. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 謐. `pos: 性詞` reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-7-10.md` (item 3) and `Lookup/Korean/Korean Name ㅁ.md`.

**`graphemic_classification`/`aliases` bug found and fixed**: stored `graphemic_classification: 必`, but both dual sources describe the composition as semantic 言 + phonetic 𥁑 (⿰訁𥁑) — 必 is only the root of the broader phonetic *series*, not 謐's own direct phonetic component; the page's own pre-existing Notes bullet ("Components: 言, 𥁑") had already gotten this right. Corrected `graphemic_classification` to `𥁑`. Simultaneously, `aliases` wrongly included `𥁑` — en.Wiktionary explicitly states "𥁑 is not listed as a variant form... it appears only as the phonetic component," so this was a false alias; removed, leaving `aliases: [谧]` (genuine simplified form). zh.Wiktionary's further variant candidate (䛑) wasn't corroborated by en.Wiktionary and stayed undocumented in `aliases` per policy (noted in prose instead).

**`vietnamese` completeness gap found and fixed**: was `[mật]` only; hvdic.thivien.net attests a second genuine Âm Hán Việt reading, `mịch`; added.

**`joyo_level` verified correct but missing from its own lookup page — gap fixed**: `表外字` reconfirmed correct (dual-source: en.Wiktionary and ja.Wiktionary), but the character was missing from `Lookup/Japanese/Hyōgai.md` itself; added as item 557.

Rebuilt the malformed `## Notes` (floating unlinked CC wikilinks before the components bullet, no SKIP/Stroke/mc_id/four-links bullets) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 貰 (8639; 153 characters remaining).

### 2026-08-23, iteration 2351 — [[characters/貰|貰]]

`mc_id: 3262` reconfirmed as exact match (`CC 3000.md`: `3262. 貰`). `graphemic_classification: 世` reconfirmed correct — dual-source confirmed 形声 (semantic 貝 "cowrie, currency" + phonetic [[世]]) via en.Wiktionary and zh.Wiktionary. `radical: 貝` reconfirmed correct — genuine listing (item 13) on `Lookup/Radicals/Radical 154.md` (first character this session with this radical). `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 180, corroborated by ja.Wiktionary's own 人名用漢字 classification. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `aliases: [贳]` reconfirmed correct — genuine simplified form. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 貰. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-5-7.md` (item 7) and `Lookup/Korean/Korean Name ㅅ.md`.

**`japanese` completeness gap found and fixed**: was `[SEI, SHA]` only; both en.Wiktionary and ja.Wiktionary independently attest two further genuine on'yomi, go-on `SE` and `JA`; added.

**`japanese_native` truncation bug found and fixed**: stored `もら`, missing the verb ending; both sources give the genuine kun'yomi as `もらう` ("to receive"); corrected. En.Wiktionary's further candidates (かりる, ゆるす) were single-sourced and stayed unadded.

**`vietnamese` over-inclusion bug found and fixed**: stored `[thại, thế, thời, thởi]`; hvdic.thivien.net (sole Vietnamese authority) attests only three, `thế` (Hán Việt) and `thại`/`thế`/`thời` (Nôm) — `thởi`, sourced only from en.Wiktionary, is not authoritative per policy and was removed.

**`pos` filled**: was blank. Filled as `事詞`, matching the verbal sense (to borrow, lend).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 賁 (8640; 152 characters remaining).

### 2026-08-23, iteration 2352 — [[characters/賁|賁]]

`graphemic_classification: 卉` reconfirmed correct — dual-source confirmed 形声 (semantic 貝 "cowrie" + phonetic [[卉]]) via en.Wiktionary and zh.Wiktionary. `radical: 貝` reconfirmed correct — genuine listing (item 22) on `Lookup/Radicals/Radical 154.md`. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `mc_id: 1233` reconfirmed as exact match (`CC 1000.md`: `1233. 賁`). `aliases: [贲]` reconfirmed correct — genuine simplified form. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 賁. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-5-7.md` (item 13) and `Lookup/Korean/Korean Name ㅂ.md`.

**`mandarin` reading-meaning mismatch bug found and fixed**: stored `bì` — en.Wiktionary lists at least five etymologically distinct Mandarin readings for this character (bì "to adorn oneself"; bēn "brave, energetic, forge ahead," borrowed for 奔 in antiquity; fén/fèn "three-legged tortoise"; lù, only in 賁渾; pān, only in 賁禺). The vault's own `english: [energetic]`, `羅馬字: bun`, and `注音: ㄅㄨㄋ` all match the *bēn* reading specifically, not *bì*. Corrected to `bēn`.

**`japanese` completeness gap found and fixed**: was `[HI, FUN, HON]`; both en.Wiktionary and ja.Wiktionary independently attest a fourth genuine on'yomi, go-on `BUN` (distinct from kan-on `FUN`); added.

**`japanese_native` bug found and fixed**: stored the literal placeholder `ø` despite both sources independently attesting genuine kun'yomi; dual-confirmed overlap is `かざる`/`まじる` (en's かわる and ja's はしる/いきどおる were each single-sourced and stayed unadded); corrected.

**`vietnamese` completeness gap found and fixed**: was `[bí, bôn]` only; hvdic.thivien.net attests three further genuine Âm Hán Việt readings, `phần`/`phẩn`/`phẫn`; added.

**`pos` filled**: was blank. Filled as `性詞`, matching the adjectival/qualitative sense (energetic).

**`joyo_level` verified correct but missing from its own lookup page — gap fixed**: `表外字` reconfirmed correct (dual-source: en.Wiktionary and ja.Wiktionary), but the character was missing from `Lookup/Japanese/Hyōgai.md` itself; added as item 558.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 賑 (8641; 151 characters remaining).

### 2026-08-23, iteration 2353 — [[characters/賑|賑]]

`graphemic_classification: 辰` reconfirmed correct — dual-source confirmed 形声 (semantic 貝 "money" + phonetic [[辰]]) via en.Wiktionary and zh.Wiktionary. `radical: 貝` reconfirmed correct — genuine listing (item 30) on `Lookup/Radicals/Radical 154.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 181, corroborated by ja.Wiktionary's own 人名用漢字 classification. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `japanese: [SHIN]` reconfirmed correct and complete — go-on and kan-on both しん. `vietnamese: [chẩn]` reconfirmed complete and exact against hvdic.thivien.net. `aliases: [赈]` reconfirmed correct — genuine simplified form. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 賑. `pos: 性詞` reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-7-7.md` (item 19) and `Lookup/Korean/Korean Name ㅈ.md`.

**`japanese_native` truncation bug found and fixed**: stored `にぎ`, an incomplete fragment; both en.Wiktionary and ja.Wiktionary independently attest the genuine kun'yomi set `にぎわう`/`にぎやか`; corrected to a proper two-entry list. Ja.Wiktionary's further candidate (にぎわす) was single-sourced (not corroborated by en.Wiktionary directly) and stayed unadded.

**`mc_id` off-by-one bug found and fixed**: stored `2649` was actually 慘's rank; correct rank for 賑 is `2650` (`CC 2000.md`: `2649. 慘`, `2650. 賑`).

Rebuilt the malformed `## Notes` (floating unlinked CC wikilinks before the components bullet, no SKIP/Stroke/mc_id/four-links bullets) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 賽 (8642; 150 characters remaining).

### 2026-08-23, iteration 2354 — [[characters/賽|賽]]

`graphemic_classification: 塞` reconfirmed correct — dual-source confirmed 形声 (semantic 貝 "shell" + abbreviated phonetic 塞) via en.Wiktionary and zh.Wiktionary. `radical: 貝` reconfirmed correct — genuine listing (item 41) on `Lookup/Radicals/Radical 154.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 129, corroborated by ja.Wiktionary's own 表外漢字 classification. `mc_id: 6464` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [SAI]` reconfirmed correct and complete — go-on and kan-on both さい. `japanese_native: ø` reconfirmed correct — ja.Wiktionary explicitly lists no kun'yomi at all; en.Wiktionary's three candidates (しあい, きそう, むくいまつる) are single-sourced and stayed unadded. `vietnamese: [trại, tái]` reconfirmed complete and exact against hvdic.thivien.net — en.Wiktionary's further candidates (tày, tầy, táy) weren't corroborated by hvdic (sole authority) and stayed unadded. `aliases: [赛]` reconfirmed correct — genuine simplified form. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 賽. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-14.md` (item 5) and `Lookup/Korean/Korean Name ㅅ.md`.

**`hsk_level` bug found and fixed**: stored `2`, traced only to colon-count entries (`Old HSK 2.md`: `[賽]: 2`; `Old HSK 4.md`: `[赛]: 2` and `[賽]: 2`, none genuine) — checked all six `Old HSK N.md` files and found no genuine plain-numbered entry anywhere. Corrected to `hsk_level: 無` and added 賽 to `Lookup/HSK/HSK No.md`.

**`pos` filled**: was blank. Filled as `事詞`, matching the verbal sense (to compete, contend).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-23`.

Next never-perfected character by `danayo_id`: 蹠 (8643; 149 characters remaining).

### 2026-08-24, iteration 2355 — [[characters/蹠|蹠]]

`graphemic_classification: 庶` reconfirmed correct — dual-source confirmed 形声 (semantic 足 "foot" + phonetic [[庶]]) via en.Wiktionary and zh.Wiktionary. `radical: 足` reconfirmed correct — genuine listing (item 19) on `Lookup/Radicals/Radical 157.md` (first character this session with this radical). `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `vietnamese: [chích]` reconfirmed complete and exact against hvdic.thivien.net. `aliases` (blank) reconfirmed correct. `stand_in: 蹠骨` reconfirmed correct — sole citer, the word's own independent page. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-7-11.md` (item 5) and `Lookup/Korean/Korean Name ㅊ.md`.

**`joyo_level` bug found and fixed**: stored as an empty string (never determined); both en.Wiktionary and ja.Wiktionary independently confirm Hyōgai status. Corrected to `表外字` and added 蹠 to `Lookup/Japanese/Hyōgai.md` as item 559.

**`mc_id` off-by-one bug found and fixed**: stored `3343` was actually 芸's rank; correct rank for 蹠 is `3344` (`CC 3000.md`: `3343. 芸`, `3344. 蹠`).

**`japanese` completeness gap found and fixed**: was `[SEKI]` only; both en.Wiktionary and ja.Wiktionary independently attest two further genuine on'yomi, go-on `SHAKU` and kan'yō-on `SHO`; added.

**`japanese_native` completeness gap found and fixed**: was `あしうら` only; both sources independently attest a second genuine kun'yomi, `あしのうら`; added as a list.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (metatarsal, sole of foot).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, `## Words` merged directly onto the Notes block with no blank-line separation) into the standard `## Notes` four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 軋 (8645; 148 characters remaining).

### 2026-08-24, iteration 2356 — [[characters/軋|軋]]

`graphemic_classification: 乙` reconfirmed correct — dual-source confirmed 形声 (semantic 車 "cart" + phonetic [[乙]]) via en.Wiktionary and zh.Wiktionary. `radical: 車` reconfirmed correct (first character this session with this radical). `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 11, corroborated by ja.Wiktionary's own 表外漢字 classification. `vietnamese: [ca, loát, yết]` reconfirmed complete and exact against hvdic.thivien.net. `aliases: [轧]` reconfirmed correct — genuine simplified form. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 軋. `mc_id: 4135` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-7-1.md` (item 2) and `Lookup/Korean/Korean Name ㅇ.md`.

**`hsk_level` bug found and fixed**: stored `4`; checked all six `Old HSK N.md` files and found no entry at all, genuine or colon-count. Corrected to `hsk_level: 無` and added 軋 to `Lookup/HSK/HSK No.md`.

**`japanese` completeness gap found and fixed**: was `[ATSU]` only; both en.Wiktionary and ja.Wiktionary independently attest a second genuine on'yomi, go-on `ECHI`; added.

**`japanese_native` truncation bug found and fixed**: stored `きし`, an incomplete fragment; both sources independently attest the genuine kun'yomi set `きしる`/`きしむ` ("to squeak, creak"); corrected to a proper two-entry list, excluding ja.Wiktionary's further inflected/dialectal forms as single-sourced.

**`pos` filled**: was blank. Filled as `事詞`, matching the verbal sense (to crush, grind, squeak).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 迄 (8646; 147 characters remaining).

### 2026-08-24, iteration 2357 — [[characters/迄|迄]]

`graphemic_classification: 乞` reconfirmed correct — dual-source confirmed 形声 (semantic 辵 "movement" + phonetic [[乞]]) via en.Wiktionary and zh.Wiktionary. `radical: 辵` reconfirmed correct (first character this session with this radical). `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 185, corroborated by ja.Wiktionary's own 人名用漢字 classification. `vietnamese: [hất, hắt, khật, ngật]` reconfirmed complete and exact against hvdic.thivien.net (Hán Việt hất/ngật, Nôm hắt/hất/khật/ngật). `aliases: [肸]` reconfirmed correct. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 迄. `pos: 事詞` reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-3/SKIP-3-3-3.md` (item 9) and `Lookup/Korean/Korean Name ㅎ.md`.

**`hsk_level` conflict resolved, no bug**: stored `6`; checked all six `Old HSK N.md` files and found a genuine plain-numbered entry on `Old HSK 6.md` (`536.  [[迄]]`), confirming the stored value. However, the character was ALSO wrongly listed on `Lookup/HSK/HSK No.md` as confirmed-無, directly contradicting the genuine Old HSK 6 evidence; removed the stale entry from `HSK No.md`.

**`mc_id` off-by-one bug found and fixed**: stored `3414` was actually 蠢's rank; correct rank for 迄 is `3415` (`CC 3000.md`: `3414. 蠢`, `3415. 迄`).

**`japanese` completeness gap found and fixed**: was `[KITSU]` only; both en.Wiktionary and ja.Wiktionary independently attest a second genuine on'yomi, go-on `KOCHI`; added.

**`japanese_native` truncation bug found and fixed**: stored `およ`, an incomplete fragment; both sources independently attest the genuine kun'yomi set `およぶ`/`まで`; corrected to a proper two-entry list.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 迪 (8647; 146 characters remaining).

### 2026-08-24, iteration 2358 — [[characters/迪|迪]]

`graphemic_classification: 由` reconfirmed correct — dual-source confirmed 形声 (semantic 辵 "movement" + phonetic [[由]]) via en.Wiktionary and zh.Wiktionary. `radical: 辵` reconfirmed correct — genuine listing (item 8) on `Lookup/Radicals/Radical 162.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 186, corroborated by ja.Wiktionary's own 人名用漢字 classification. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `vietnamese: [địch]` reconfirmed complete and exact against hvdic.thivien.net. `aliases` (blank) reconfirmed correct. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 迪. Already correctly cross-listed on `Lookup/SKIP/SKIP-3/SKIP-3-3-5.md` (item 11) and `Lookup/Korean/Korean Name ㅈ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `3045` was actually 贛's rank; correct rank for 迪 is `3046` (`CC 3000.md`: `3045. 贛`, `3046. 迪`).

**`japanese` completeness gap found and fixed**: was `[TEKI]` only; both en.Wiktionary and ja.Wiktionary independently attest a second genuine on'yomi, go-on `JAKU`; added.

**`japanese_native` truncation bug found and fixed**: stored `いた`, an incomplete fragment of `いたる` (ja.Wiktionary-only, kept per established single-source-preexisting precedent); both sources independently attest three further genuine kun'yomi, `すすむ`/`みち`/`みちびく`; corrected to a proper four-entry list `[いたる, すすむ, みち, みちびく]`.

**`pos` filled**: was blank. Filled as `事詞`, matching the verbal sense (to follow, advance, guide).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 逍 (8648; 145 characters remaining).

### 2026-08-24, iteration 2359 — [[characters/逍|逍]]

`graphemic_classification: 肖` reconfirmed correct — dual-source confirmed 形声 (semantic 辵 "movement" + phonetic [[肖]]) via en.Wiktionary and zh.Wiktionary. `radical: 辵` reconfirmed correct — genuine listing (item 28) on `Lookup/Radicals/Radical 162.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 159, corroborated by ja.Wiktionary's own 表外漢字 classification. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `japanese: [SHOU]` reconfirmed correct and complete — go-on and kan-on both しょう. `japanese_native: ø` reconfirmed correct — ja.Wiktionary explicitly lists no kun'yomi; en.Wiktionary's two candidates (さまよう, たちもとおる) were single-sourced and stayed unadded. `vietnamese: [tiêu]` reconfirmed complete and exact against hvdic.thivien.net. `aliases` (blank) reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-3/SKIP-3-4-7.md` (item 4) and `Lookup/Korean/Korean Name ㅅ.md`.

**`stand_in` bug found and fixed**: stored `名専字` despite a bare unlinked word citation already sitting in the page's own malformed Notes; verified `words/逍遥.md` genuinely cites 逍 in its `characters:` frontmatter. Corrected `stand_in` to `逍遥` and moved the citation into a proper `## Words` section.

**`mc_id` off-by-one bug found and fixed**: stored `3373` was actually 媿's rank; correct rank for 逍 is `3374` (`CC 3000.md`: `3373. 媿`, `3374. 逍`).

**`pos` filled**: was blank. Filled as `事詞`, matching the verbal sense (to ramble, stroll).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 逢 (8649; 144 characters remaining).

### 2026-08-24, iteration 2360 — [[characters/逢|逢]]

`graphemic_classification: 夆` reconfirmed correct — dual-source confirmed 形声 (semantic 辵 "movement" + phonetic [[夆]]) via en.Wiktionary and zh.Wiktionary. `radical: 辵` reconfirmed correct — genuine listing (item 33) on `Lookup/Radicals/Radical 162.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 160, corroborated by ja.Wiktionary's own 人名用漢字 classification. `mc_id: 1131` reconfirmed as exact match (`CC 1000.md`: `1131. 逢`). `japanese: [HOU, BU]` reconfirmed correct and complete — go-on ぶ/kan-on ほう. `aliases` (blank) reconfirmed correct. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 逢. `pos: 事詞` reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-3/SKIP-3-4-7.md` (item 9).

**`hsk_level` bug found and fixed**: stored `2`, traced only to colon-count entries on `Old HSK 2.md` and `Old HSK 4.md` (both `[[逢]]: 1`, neither genuine) — checked all six `Old HSK N.md` files and found a genuine plain-numbered entry on `Old HSK 6.md` (`335.  [[逢]]`). Corrected to `hsk_level: 6`.

**`japanese_native` truncation bug found and fixed**: stored `あ`, an incomplete fragment; both en.Wiktionary and ja.Wiktionary independently attest the genuine kun'yomi `あう` ("to meet"); corrected. Each source's further candidates (むかう/むかえる, おう) didn't dual-confirm the same exact form and stayed unadded.

**`vietnamese` completeness gap found and fixed**: was `[buồng, phùng]` only; hvdic.thivien.net attests a third genuine Âm Hán Việt reading, `bồng`; added.

**Missing Korean lookup entry found and added**: 逢 was entirely absent from `Lookup/Korean/Korean Name ㅂ.md`'s `### 봉` section; added.

Rebuilt the malformed `## Notes` (bare unlinked components bullet, floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 遒 (8650; 143 characters remaining).

### 2026-08-24, iteration 2361 — [[characters/遒|遒]]

`graphemic_classification: 酋` reconfirmed correct — dual-source confirmed 形声 (semantic 辵 "movement" + phonetic [[酋]]) via en.Wiktionary and zh.Wiktionary. `radical: 辵` reconfirmed correct — genuine listing (item 51) on `Lookup/Radicals/Radical 162.md`. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `mc_id: 4014` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [SHUU]` reconfirmed correct and complete — en's unclassified on'yomi matches ja's kan-on exactly; ja's further go-on candidate (JU) was single-sourced and stayed unadded. `aliases` (blank) reconfirmed correct. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 遒. Already correctly cross-listed on `Lookup/SKIP/SKIP-3/SKIP-3-4-9.md` (item 6) and `Lookup/Korean/Korean Name ㅈ.md`.

**`joyo_level` bug found and fixed**: stored as an empty string (never determined); both en.Wiktionary and ja.Wiktionary independently confirm Hyōgai status. Corrected to `表外字` and added 遒 to `Lookup/Japanese/Hyōgai.md` as item 560.

**`japanese_native` truncation bug found and fixed**: stored `せま`, an incomplete fragment; both sources independently attest the genuine kun'yomi set `せまる`/`つよい`; corrected to a proper two-entry list.

**`vietnamese` completeness gap found and fixed**: was `[tù, tùa]` only; hvdic.thivien.net attests a third genuine Âm Hán Việt reading, `tưu`; added.

**`pos` filled**: was blank. Filled as `性詞`, matching the adjectival/qualitative sense (strong, unyielding, forceful).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 遼 (8651; 142 characters remaining).

### 2026-08-24, iteration 2362 — [[characters/遼|遼]]

`graphemic_classification: 尞` reconfirmed correct — dual-source confirmed 形声 (semantic 辵 "movement" + phonetic [[尞]]) via en.Wiktionary and zh.Wiktionary. `radical: 辵` reconfirmed correct — genuine listing (item 64) on `Lookup/Radicals/Radical 162.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 190, corroborated by ja.Wiktionary's own 人名用漢字 classification. `mc_id: 1391` reconfirmed as exact match (`CC 1000.md`: `1391. 遼`). `japanese: [RYOU]` reconfirmed correct and complete — go-on and kan-on both りょう. `vietnamese: [liêu]` reconfirmed complete and exact against hvdic.thivien.net. `aliases: [辽]` reconfirmed correct — genuine simplified form. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 遼. `pos: 性詞` reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-3/SKIP-3-3-12.md` (item 9) and `Lookup/Korean/Korean Name ㄹ.md`.

**`hsk_level` bug found and fixed**: stored `4`, traced only to colon-count entries on `Old HSK 4.md` (`[辽]: 1`, `[[遼]]: 1`, neither genuine) — checked all six `Old HSK N.md` files and found a genuine plain-numbered entry on `Old HSK 6.md` (`533.  [辽]`). Corrected to `hsk_level: 6` and removed the now-contradicted entry from `Lookup/HSK/HSK No.md` (character was wrongly listed there as confirmed-無).

**`japanese_native` bug found and fixed**: stored the literal placeholder `ø` despite both en.Wiktionary and ja.Wiktionary independently attesting a genuine kun'yomi, `はるか` ("far"); corrected. En.Wiktionary's further candidate (とおい) was single-sourced and stayed unadded.

Rebuilt the malformed `## Notes` (floating unlinked CC wikilinks before the components bullet, no SKIP/Stroke/mc_id/four-links bullets) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 邁 (8652; 141 characters remaining).

### 2026-08-24, iteration 2363 — [[characters/邁|邁]]

`graphemic_classification: 萬` reconfirmed correct — dual-source confirmed 形声 (semantic 辵 "movement" + phonetic [[萬]]) via en.Wiktionary and zh.Wiktionary. `radical: 辵` reconfirmed correct — genuine listing (item 68) on `Lookup/Radicals/Radical 162.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 197, corroborated by ja.Wiktionary's own 表外漢字 classification. `japanese: [BAI, MAI]` reconfirmed correct and complete — go-on まい/kan-on ばい, corroborated by both sources; ja.Wiktionary's further go-on candidate (め) was single-sourced and stayed unadded. `vietnamese: [mười, mại, mời]` reconfirmed complete and exact against hvdic.thivien.net. `aliases: [迈]` reconfirmed correct — genuine simplified form. Already correctly cross-listed on `Lookup/SKIP/SKIP-3/SKIP-3-4-13.md` (item 2) and `Lookup/Korean/Korean Name ㅁ.md`.

**`stand_in` bug found and fixed**: stored `名専字` despite a genuine citing word already sitting in the page's own malformed Notes (an unlinked bullet, "abbreviation for meitnerium"); verified `words/邁金.md` genuinely cites 邁 in its `characters:` frontmatter. Corrected `stand_in` to `邁金`.

**`hsk_level` bug found and fixed**: stored `2`, traced only to a colon-count entry on `Old HSK 2.md` (`[[邁]]: 1`, not genuine) — checked all six `Old HSK N.md` files and found no genuine plain-numbered entry anywhere. Corrected to `hsk_level: 無` and added 邁 to `Lookup/HSK/HSK No.md`.

**`mc_id` off-by-one bug found and fixed**: stored `3088` was actually 鞍's rank; correct rank for 邁 is `3089` (`CC 3000.md`: `3088. 鞍`, `3089. 邁`).

**`japanese_native` truncation bug found and fixed**: stored `ゆ`, an incomplete fragment; both sources independently attest the genuine kun'yomi set `ゆく`/`すぎる`/`つとめる`; corrected to a proper three-entry list. En.Wiktionary's further candidate (すすむ) was single-sourced and stayed unadded.

**`pos` filled**: was blank. Filled as `事詞`, matching the verbal sense (to take a big stride, proceed).

Rebuilt the malformed `# Notes` (wrong heading level, duplicated word citation between Notes and Words, floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 邏 (8653; 140 characters remaining).

### 2026-08-24, iteration 2364 — [[characters/邏|邏]]

`mc_id: 0` reconfirmed as a genuine sentinel — absent from all four `CC N000.md` files. `graphemic_classification: 羅` reconfirmed correct — dual-source confirmed 形声 (semantic 辵 "movement" + phonetic [[羅]]) via en.Wiktionary and zh.Wiktionary. `radical: 辵` reconfirmed correct — genuine listing (item 69) on `Lookup/Radicals/Radical 162.md`. `japanese: [RA]` reconfirmed correct and complete — go-on and kan-on both ら. `aliases: [逻]` reconfirmed correct — genuine simplified form. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 邏. `pos: 事詞` reconfirmed correct (verbal sense, to patrol). Already correctly cross-listed on `Lookup/SKIP/SKIP-3/SKIP-3-4-19.md` (item 1) and `Lookup/Korean/Korean Name ㄹ.md`.

**`vietnamese` over-inclusion bug found and fixed**: stored `[la, lạ]`; hvdic.thivien.net (sole Vietnamese authority) attests only `la` in both sections — `lạ`, sourced only from en.Wiktionary, is not authoritative per policy and was removed.

**`japanese_native` truncation bug found and fixed**: stored `めぐ`, an incomplete fragment; both sources independently attest the genuine kun'yomi `めぐる` ("to patrol, go around"); corrected. En.Wiktionary's further candidates (みまわる, みまわり) were single-sourced and stayed unadded.

**`joyo_level` bug found and fixed**: stored as an empty string (never determined); both en.Wiktionary and ja.Wiktionary independently confirm Hyōgai status. Corrected to `表外字` and added 邏 to `Lookup/Japanese/Hyōgai.md` as item 561.

**`hsk_level` bug found and fixed**: stored `3`, traced only to colon-count entries on `Old HSK 3.md` and `Old HSK 4.md` (both `[逻]: 1`/`[[邏]]: 1`, neither genuine) — checked all six `Old HSK N.md` files and found a genuine plain-numbered entry on `Old HSK 5.md` (`252.  [逻]`). Corrected to `hsk_level: 5` and removed the now-contradicted entry from `Lookup/HSK/HSK No.md`.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 邢 (8654; 139 characters remaining).

### 2026-08-24, iteration 2365 — [[characters/邢|邢]]

`graphemic_classification: 井` reconfirmed correct — dual-source confirmed 形声 (semantic 邑 "city, place" + phonetic drawn as 开 but same phonetic series as, and cited per convention as, 井) via en.Wiktionary and zh.Wiktionary. `radical: 邑` reconfirmed correct — genuine listing (item 2) on `Lookup/Radicals/Radical 163.md` (first character this session with this radical). `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `japanese: [KEI, GYOU]` reconfirmed correct and complete — the dual-confirmed overlap between en.Wiktionary's two readings and ja.Wiktionary's larger set; ja's further candidates (KYOU, KOU, KEN) were single-sourced and stayed unadded. `japanese_native: ø` reconfirmed correct — both sources explicitly list no kun'yomi. `vietnamese: [hình]` reconfirmed complete and exact against hvdic.thivien.net. `aliases` (blank) reconfirmed correct. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 邢. `korean_native` (blank) reconfirmed plausible — a proper-noun surname/place-name character with no native gloss meaning. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-4-3.md` (item 2) and `Lookup/Korean/Korean Name ㅎ.md`.

**`joyo_level` bug found and fixed**: stored as an empty string (never determined); both en.Wiktionary and ja.Wiktionary independently confirm Hyōgai status. Corrected to `表外字` and added 邢 to `Lookup/Japanese/Hyōgai.md` as item 562.

**`mc_id` off-by-one bug found and fixed**: stored `2098` was actually 霧's rank; correct rank for 邢 is `2099` (`CC 2000.md`: `2098. 霧`, `2099. 邢`).

**`pos` filled**: was blank. Filled as `固有名詞`, matching the proper-noun sense (a surname and ancient state name).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 鄙 (8655; 138 characters remaining).

### 2026-08-24, iteration 2366 — [[characters/鄙|鄙]]

`mc_id: 1101` reconfirmed as exact match (`CC 1000.md`: `1101. 鄙`). `graphemic_classification: 啚` reconfirmed correct — dual-source confirmed 形声 (semantic 邑 "city" + phonetic [[啚]] "border town") via en.Wiktionary and zh.Wiktionary. `radical: 邑` reconfirmed correct — genuine listing (item 22) on `Lookup/Radicals/Radical 163.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 231, corroborated by ja.Wiktionary's own 表外漢字 classification. `japanese: [HI]` reconfirmed correct and complete — go-on and kan-on both ひ. `aliases` (blank) reconfirmed correct. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 鄙. `pos: 性詞` reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-11-3.md` (item 2) and `Lookup/Korean/Korean Name ㅂ.md`.

**`hsk_level` bug found and fixed**: stored `4`, traced only to a colon-count entry on `Old HSK 4.md` (`[[鄙]]: 1`, not genuine) — checked all six `Old HSK N.md` files and found no genuine plain-numbered entry anywhere. Corrected to `hsk_level: 無` and added 鄙 to `Lookup/HSK/HSK No.md`.

**`japanese_native` malformed-value bug found and fixed**: stored as a single stray string `いや - ひな` instead of a proper list; both en.Wiktionary and ja.Wiktionary independently attest all four candidates (`ひな`, `ひなびる`, `いやしい`, `さげすむ`); corrected to a proper four-entry list.

**`vietnamese` malformed-value bug found and fixed**: stored as a single unsplit string `"bỉ, bẽ"` instead of a proper list; both values reconfirmed exact against hvdic.thivien.net; corrected to a proper two-entry list.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 鄧 (8656; 137 characters remaining).

### 2026-08-24, iteration 2367 — [[characters/鄧|鄧]]

`mc_id: 1097` reconfirmed as exact match (`CC 1000.md`: `1097. 鄧`). `graphemic_classification: 登` reconfirmed correct — dual-source confirmed 形声 (semantic 邑 "city" + phonetic [[登]]) via en.Wiktionary and zh.Wiktionary. `radical: 邑` reconfirmed correct — genuine listing (item 23) on `Lookup/Radicals/Radical 163.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 215, corroborated by ja.Wiktionary's own 表外漢字 classification. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `japanese: [TOU, DOU]` reconfirmed correct — en.Wiktionary attests both go-on どう and kan-on とう; ja.Wiktionary only listed kan-on とう (silent on go-on, not a contradiction), so the pre-existing value was kept per established precedent. `japanese_native: ø` reconfirmed correct — both sources explicitly list no kun'yomi. `aliases: [邓]` reconfirmed correct — genuine simplified form. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 鄧. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-12-3.md` (item 2) and `Lookup/Korean/Korean Name ㄷ.md`.

**`vietnamese` over-inclusion bug found and fixed**: stored eight readings including `đẵng`; hvdic.thivien.net (sole Vietnamese authority) attests only seven (Hán Việt đặng; Nôm dằng/dựng/đắng/đựng/nựng/rặng) — `đẵng`, sourced only from en.Wiktionary's larger candidate list, is not authoritative per policy and was removed.

**`pos` filled**: was blank. Filled as `固有名詞`, matching the proper-noun sense (a surname).

**`boundedness` filled**: was blank. Filled as `90`, consistent with similarly-bound name-only characters.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 醐 (8657; 136 characters remaining).

### 2026-08-24, iteration 2368 — [[characters/醐|醐]]

`graphemic_classification: 胡` reconfirmed correct — dual-source confirmed 形声 (semantic 酉 "wine, alcohol" + phonetic [[胡]]) via en.Wiktionary and zh.Wiktionary. `radical: 酉` reconfirmed correct — genuine listing (item 16) on `Lookup/Radicals/Radical 164.md` (first character this session with this radical). `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 193, corroborated by ja.Wiktionary's own 人名用漢字 classification. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `mc_id: 10513` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese_native: ø` reconfirmed correct — both sources explicitly list no kun'yomi. `vietnamese: [hồ]` reconfirmed complete and exact against hvdic.thivien.net. `aliases` (blank) reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-7-9.md` (item 18).

**`stand_in` bug found and fixed**: stored `名専字` despite a genuine citing word already sitting in the page's own `## Words` section; verified `words/醍醐.md` genuinely cites 醐 in its `characters:` frontmatter. Corrected `stand_in` to `醍醐`.

**`japanese` completeness gap found and fixed**: was `[KO, GO]`; both en.Wiktionary and ja.Wiktionary independently attest a third genuine on'yomi, go-on `GU`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (purest cream).

**Missing Korean lookup entry found and added**: 醐 was entirely absent from `Lookup/Korean/Korean Name ㅎ.md`'s `### 호` section; added.

Rebuilt the malformed `## Notes` (two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 猜 (8658; 135 characters remaining).

### 2026-08-24, iteration 2369 — [[characters/猜|猜]]

`mc_id: 3493` reconfirmed as exact match (`CC 3000.md`: `3493. 猜`). `graphemic_classification: 青` reconfirmed correct — dual-source confirmed 形声 (semantic 犬 "animal" + phonetic [[青]]) via en.Wiktionary and zh.Wiktionary. `radical: 犬` reconfirmed correct (first character this session with this radical). `korean: 시` reconfirmed correct despite looking mismatched against the page's own `諺文: 채`/`羅馬字: cai` — genuinely listed under `### 시` on `Lookup/Korean/Korean Name ㅅ.md`, not `### 채` (same 諺文-divergence pattern seen on [[邢]]/[[蝙]] this session). `japanese: [SAI]` reconfirmed correct and complete — go-on and kan-on both さい; en.Wiktionary's further kan'yō-on candidate (せ) was single-sourced and stayed unadded. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 猜. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-3-8.md` (item 75).

**`hsk_level` bug found and fixed**: stored `2`, traced only to colon-count entries on `Old HSK 2.md`, `Old HSK 3.md`, and `Old HSK 4.md` (none genuine) — checked all six `Old HSK N.md` files and found no genuine plain-numbered entry anywhere. Corrected to `hsk_level: 無` and added 猜 to `Lookup/HSK/HSK No.md`.

**`joyo_level` bug found and fixed**: stored as an empty string (never determined); both en.Wiktionary and ja.Wiktionary independently confirm Hyōgai status. Corrected to `表外字` and added 猜 to `Lookup/Japanese/Hyōgai.md` as item 563.

**`japanese_native` truncation bug found and fixed**: stored `そね`, an incomplete fragment of `そねむ` (en.Wiktionary-only, kept per established single-source-preexisting precedent); both sources independently attest two further genuine kun'yomi, `おしはかる`/`ねたむ`; corrected to a proper three-entry list `[そねむ, おしはかる, ねたむ]`.

**`vietnamese` completeness gap found and fixed**: was `[sai, xai]` only; hvdic.thivien.net attests a third genuine Âm Hán Việt reading, `thai`; added.

**`pos` filled**: was blank. Filled as `事詞`, matching the verbal sense (to guess, suspect).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 醴 (8659; 134 characters remaining).

### 2026-08-24, iteration 2370 — [[characters/醴|醴]]

`mc_id: 1798` reconfirmed as exact match (`CC 1000.md`: `1798. 醴`). `graphemic_classification: 豊` reconfirmed correct — dual-source confirmed 形声 (semantic 酉 "wine" + phonetic [[豊]]) via en.Wiktionary and zh.Wiktionary. `radical: 酉` reconfirmed correct — genuine listing (item 20) on `Lookup/Radicals/Radical 164.md`. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `japanese: [REI, RAI]` reconfirmed correct and complete — go-on らい/kan-on れい. `japanese_native: あまざけ` reconfirmed correct. `vietnamese: [lễ]` reconfirmed complete and exact against hvdic.thivien.net. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 醴. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-7-13.md` (item 5) and `Lookup/Korean/Korean Name ㄹ.md`.

**False `aliases` entry found and removed**: stored `澧` — en.Wiktionary explicitly states it appears only as a phonetically-related character in the same series (a place name, "Li River"), not as a variant form of 醴; zh.Wiktionary doesn't contradict this. Removed and documented the relationship in prose instead (澧 has no independent vault page). Left the existing `Lookup/Korean/Korean Name ㄹ.md` redirect entry in place (a lookup pointer, not a claim of orthographic identity — same pattern as earlier 廖-->蓼 and 蒿-->藁 cases).

**`joyo_level` bug found and fixed**: stored as an empty string (never determined); both en.Wiktionary and ja.Wiktionary independently confirm Hyōgai status. Corrected to `表外字` and added 醴 to `Lookup/Japanese/Hyōgai.md` as item 564.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (sweet water, sweet fermented drink).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 鈿 (8660; 133 characters remaining).

### 2026-08-24, iteration 2371 — [[characters/鈿|鈿]]

`mc_id: 0` reconfirmed as a genuine sentinel — absent from all four `CC N000.md` files. `graphemic_classification: 田` reconfirmed correct — dual-source confirmed 形声 (semantic 金 "metal" + phonetic [[田]]) via en.Wiktionary and zh.Wiktionary. `radical: 金` reconfirmed correct (first character this session with this radical). `japanese: [TEN, DEN]` reconfirmed correct and complete — go-on でん/kan-on てん. `japanese_native: かんざし` reconfirmed correct. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 鈿. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-8-5.md` (item 5) and `Lookup/Korean/Korean Name ㅈ.md`.

**False `aliases` entries found and removed**: stored `[簪, 釵, 钿]` — both en.Wiktionary and zh.Wiktionary independently confirm 簪 and 釵 are separate synonym characters ("hairpin" words with distinct pronunciations, zān and chāi) sharing only the meaning, not orthographic variants; zh.Wiktionary's own 異體字 list for 鈿 gives only 䥖 and 钿. Removed 簪 and 釵, kept the genuine `钿` (simplified form), documented the false relationship in prose. Left the existing `Lookup/Korean/Korean Name ㅈ.md` "簪-->鈿" redirect entry in place (a thematic lookup pointer, not a claim of orthographic identity, matching prior 廖/蒿/澧 redirect precedent).

**`vietnamese` completeness gap found and fixed**: was `[điền]` only; hvdic.thivien.net attests a second genuine Âm Hán Việt reading, `điến`; added.

**`joyo_level` bug found and fixed**: stored as an empty string (never determined); both en.Wiktionary and ja.Wiktionary independently confirm Hyōgai status. Corrected to `表外字` and added 鈿 to `Lookup/Japanese/Hyōgai.md` as item 565.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (filigree, hairpin).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 鋤 (8661; 132 characters remaining).

### 2026-08-24, iteration 2372 — [[characters/鋤|鋤]]

`graphemic_classification: 助` reconfirmed correct — dual-source confirmed 形声 (semantic 金 "metal" + phonetic [[助]]) via en.Wiktionary and zh.Wiktionary. `radical: 金` reconfirmed correct — genuine listing (item 30) on `Lookup/Radicals/Radical 167.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 157, corroborated by ja.Wiktionary's own 表外漢字 classification. `japanese: [JO, SO]` reconfirmed correct and complete — the dual-confirmed kana overlap between en.Wiktionary and ja.Wiktionary (ja's further candidate ショ was single-sourced and stayed unadded). `vietnamese: [sừ, xừ]` reconfirmed complete and exact against hvdic.thivien.net. `aliases: [锄]` reconfirmed correct — genuine simplified form. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 鋤. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-8-7.md` (item 4) and `Lookup/Korean/Korean Name ㅅ.md`.

**`hsk_level` bug found and fixed**: stored `4`, traced only to colon-count entries on `Old HSK 4.md` (`[[鋤]]: 1`, `[锄]: 1`, neither genuine) — checked all six `Old HSK N.md` files and found no genuine plain-numbered entry anywhere. Corrected to `hsk_level: 無` and added 鋤 to `Lookup/HSK/HSK No.md`.

**`japanese_native` completeness gap found and fixed**: was `くわ` only; both en.Wiktionary and ja.Wiktionary independently attest two further genuine kun'yomi, `すく`/`すき`; added as a list.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (hoe, spade).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 鎧 (8662; 131 characters remaining).

### 2026-08-24, iteration 2373 — [[characters/鎧|鎧]]

`graphemic_classification: 豈` reconfirmed correct — dual-source confirmed 形声 (semantic 金 "metal" + phonetic [[豈]]) via en.Wiktionary and zh.Wiktionary. `radical: 金` reconfirmed correct — genuine listing (item 54) on `Lookup/Radicals/Radical 167.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 202, corroborated by ja.Wiktionary's own 人名用漢字 classification. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `mc_id: 4415` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [GAI, KAI]` reconfirmed correct and complete — go-on/kan-on かい, kan'yō-on がい. `vietnamese: [khải]` reconfirmed complete and exact against hvdic.thivien.net. `aliases: [铠]` reconfirmed correct — genuine simplified form. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-8-10.md` (item 3) and `Lookup/Korean/Korean Name ㄱ.md`.

**`stand_in` bug found and fixed**: stored `名専字` despite a genuine citing word already sitting in the page's own malformed Notes as a bare unlinked bullet; verified `words/鎧球.md` genuinely cites 鎧 in its `characters:` frontmatter. Corrected `stand_in` to `鎧球` and moved the citation into a proper `## Words` section.

**`japanese_native` truncation bug found and fixed**: stored `よろ`, an incomplete fragment; both en.Wiktionary and ja.Wiktionary independently attest the genuine kun'yomi set `よろい`/`よろう`; corrected to a proper two-entry list.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (armor).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 鑠 (8663; 130 characters remaining).

### 2026-08-24, iteration 2374 — [[characters/鑠|鑠]]

`radical: 金` reconfirmed correct — genuine listing (item 60) on `Lookup/Radicals/Radical 167.md`. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `japanese: [SHAKU]` reconfirmed correct and complete — go-on and kan-on both しゃく. `vietnamese: [thước]` reconfirmed complete and exact against hvdic.thivien.net. `aliases: [铄]` reconfirmed correct — genuine simplified form (unrelated to the graphemic_classification fix below; 鑠's own shinjitai is a different glyph, 𮣏). `stand_in: 名専字` reconfirmed correct — no word anywhere cites 鑠. `pos: 事詞` reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-8-15.md` (item 2) and `Lookup/Korean/Korean Name ㅅ.md`.

**`graphemic_classification` alias-citation bug found and fixed**: stored `樂`, which has no independent vault page — it is listed as an alias of `characters/楽.md`. Per the established parent-form citation convention, corrected to `楽`.

**`mc_id` off-by-one bug found and fixed**: stored `3083` was actually 罟's rank; correct rank for 鑠 is `3084` (`CC 3000.md`: `3083. 罟`, `3084. 鑠`) — the page's own prose had already noted "3084th most popular character," contradicting its own frontmatter `mc_id`.

**`japanese_native` truncation bug found and fixed**: stored `と`, an incomplete fragment; both en.Wiktionary and ja.Wiktionary independently attest the genuine kun'yomi set `とろかす`/`とかす`; corrected to a proper two-entry list.

**`joyo_level` verified correct but missing from its own lookup page — gap fixed**: `表外字` reconfirmed correct (dual-source: en.Wiktionary and ja.Wiktionary), but the character was missing from `Lookup/Japanese/Hyōgai.md` itself; added as item 566.

Rebuilt the malformed `## Notes` (lowercase/relative `../lookup/` link paths inconsistent with vault convention, a self-contradicting mc_id claim) into the standard four-bullet format with correct absolute-style links. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 陀 (8664; 129 characters remaining).

### 2026-08-24, iteration 2375 — [[characters/陀|陀]]

`graphemic_classification: 它` reconfirmed correct — dual-source confirmed 形声 (semantic 阜 "mound" + phonetic [[它]]) via en.Wiktionary and zh.Wiktionary. `radical: 阜` reconfirmed correct — genuine listing (item 6) on `Lookup/Radicals/Radical 170.md` (first character this session with this radical). `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 203, corroborated by ja.Wiktionary's own 人名用漢字 classification. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `mc_id: 8203` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [DA, TA]` reconfirmed correct and complete — go-on だ/kan-on た; ja.Wiktionary's further tō-on candidate (と) was single-sourced and stayed unadded. `aliases` (blank) reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-3-5.md` (item 76) and `Lookup/Korean/Korean Name ㅌ.md`.

**`stand_in` bug found and fixed**: stored `名専字` despite a genuine citing word already sitting in the page's own `## Words` section; verified `words/偈陀.md` genuinely cites 陀 in its `characters:` frontmatter. Corrected `stand_in` to `偈陀`.

**`vietnamese` over-inclusion bug found and fixed**: stored `[dà, đà]`; hvdic.thivien.net (sole Vietnamese authority) attests only `đà` in both sections — `dà`, unattested by any dual-source claim, was removed. En.Wiktionary's further candidates (đã, đờ) also weren't corroborated and stayed unadded.

**`japanese_native` truncation bug found and fixed**: stored `けわ`, an incomplete fragment; both sources independently attest the genuine kun'yomi `けわしい` ("steep"); corrected. Ja.Wiktionary's further candidate (ななめ) was single-sourced and stayed unadded.

Rebuilt the malformed `## Notes` (bare unlinked components bullet, floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 陝 (8665; 128 characters remaining).

### 2026-08-24, iteration 2376 — [[characters/陝|陝]]

`graphemic_classification: 㚒` reconfirmed correct — dual-source confirmed 形声 (semantic 阜 "mound" + phonetic [[㚒]]) via en.Wiktionary and zh.Wiktionary. `radical: 阜` reconfirmed correct — genuine listing (item 13) on `Lookup/Radicals/Radical 170.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 265, corroborated by ja.Wiktionary's own 表外漢字 classification. `japanese: [SEN]` reconfirmed correct and complete — go-on and kan-on both せん. `japanese_native: ø` reconfirmed correct — both sources explicitly list no kun'yomi. `aliases: [陕, 陜]` reconfirmed correct. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 陝. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-3-7.md` (item 63) and `Lookup/Korean/Korean Name ㅅ.md`.

**`hsk_level` bug found and fixed**: stored `4`, traced only to colon-count entries on `Old HSK 4.md` (`[陕]: 1`, `[[陝]]: 1`, neither genuine) — checked all six `Old HSK N.md` files and found no genuine plain-numbered entry anywhere. Corrected to `hsk_level: 無` and added 陝 to `Lookup/HSK/HSK No.md`.

**`mc_id` off-by-one bug found and fixed**: stored `3558` was actually 鈍's rank; correct rank for 陝 is `3559` (`CC 3000.md`: `3558. 鈍`, `3559. 陝`).

**`vietnamese` completeness gap found and fixed**: was `[thiểm]` only; hvdic.thivien.net attests two further genuine Âm Hán Việt readings, `hiệp`/`xiểm`; added.

**`pos` filled**: was blank. Filled as `固有名詞`, matching the proper-noun sense (place name, short for Shaanxi).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 茜 (8666; 127 characters remaining).

### 2026-08-24, iteration 2377 — [[characters/茜|茜]]

`mc_id: 0` reconfirmed as a genuine sentinel — absent from all four `CC N000.md` files. `graphemic_classification: 西` reconfirmed correct — dual-source confirmed 形声 (semantic 艸 "grass" + phonetic [西 (char)](characters/西.md)) via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 45) on `Lookup/Radicals/Radical 140.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md`, corroborated by ja.Wiktionary's own 人名用漢字 classification. `japanese_native: あかね` reconfirmed correct. `stand_in: 茜草` reconfirmed correct — genuine citer, the word's own independent page. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-6.md` (item 15) and `Lookup/Korean/Korean Name ㅊ.md`.

**`hsk_level` verified correct but missing from its own lookup page — gap fixed**: `無` reconfirmed correct (absent from all six `Old HSK N.md` files), but the character was missing from `Lookup/HSK/HSK No.md` itself; added.

**False `aliases` entry found and removed**: stored `莤` — both en.Wiktionary and zh.Wiktionary explicitly note it only as a "See also"/related entry, not a genuine 異體字; removed, keeping the dual-confirmed genuine variant `蒨`.

**`japanese`/`vietnamese` malformed-value bug found and fixed**: both stored as bare scalar strings instead of proper lists. `japanese` converted to `[SEN]` (en.Wiktionary's further kan'yō-on candidate せい was single-sourced and stayed unadded). `vietnamese` was `thiến` alone; hvdic.thivien.net attests three further genuine Âm Hán Việt readings, `trệ`/`tây`/`tê`; corrected to a proper four-entry list.

**`pos` corrected**: stored `固有名詞`; changed to `名詞` to match the character's primary attested sense — the plant name "madder," matching its `stand_in` word `茜草` (a common-noun compound), rather than the incidental proper-noun uses (Japanese given name, element neologism).

**Second `## Words` citation found and added**: a bare numbered-list fragment in the malformed Notes ("2. short for rubidium") turned out to reference a genuine second citing word; verified `words/茜素.md` (a neologism for the element rubidium, using 茜 as the element-symbol character) genuinely cites 茜 in its `characters:` frontmatter; added to `## Words`.

Rebuilt the malformed Notes (missing `##` heading level on one bullet, a stray unlinked numbered list, `## Words` placed before Notes) into the standard `## Notes` four-bullet format, reordered before `## Words`. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 韮 (8667; 126 characters remaining).

### 2026-08-24, iteration 2378 — [[characters/韮|韮]]

`graphemic_classification: 象形` reconfirmed correct — dual-source confirmed pictographic origin (depicts chives growing on the ground) via en.Wiktionary (ambiguous) and zh.Wiktionary (explicit); 韮 is itself a variant of [[韭]], inheriting the classification. `radical: 韭` reconfirmed correct (first character this session with this radical). `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 154, corroborated by ja.Wiktionary's own 表外漢字 classification. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `japanese_native: にら` reconfirmed correct. `aliases: [韭]` reconfirmed correct — en.Wiktionary explicitly states 韮 is a variant form of 韭 (韭 itself has no independent vault page). Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-3-9.md` (item 24).

**`stand_in` bug found and fixed**: stored `名専字` despite a genuine citing word already sitting in the page's own malformed Notes as a bare unlinked bullet; verified `words/韮金.md` genuinely cites 韮 in its `characters:` frontmatter. Corrected `stand_in` to `韮金` and moved the citation into a proper `## Words` section.

**`mc_id` off-by-one bug found and fixed**: stored `2843` was actually 朐's rank; correct rank for 韮/韭 is `2844` (`CC 2000.md`: `2843. 朐`, `2844. 韭`).

**`japanese` completeness gap found and fixed**: was `[KYOU, KU]`; both en.Wiktionary and ja.Wiktionary independently attest a third genuine on'yomi, kan-on `KYUU` (distinct from the pre-existing single-sourced kan'yō-on `KYOU`, kept per established precedent); added.

**`vietnamese` completeness gap found and fixed**: was `[cửu]` only; hvdic.thivien.net attests a second genuine Âm Hán Việt reading, `phỉ`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (chive, leek).

**`hanmun_edu_level` filled**: was blank. Filled as `名`, matching `grade_level: 名`.

**`boundedness` filled**: was blank. Filled as `80`, consistent with similarly-bound characters with a genuine stand-in citation.

**Missing Korean lookup entry found and added**: 韮 was entirely absent from `Lookup/Korean/Korean Name ㄱ.md`'s `### 구` section; added.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 頴 (8668; 125 characters remaining).

### 2026-08-24, iteration 2379 — [[characters/頴|頴]]

`graphemic_classification: 頃` reconfirmed correct — dual-source confirmed 形声 (semantic 禾 "grain" + phonetic [[頃]]) via en.Wiktionary and zh.Wiktionary. `radical: 頁` reconfirmed correct (first character this session with this radical). `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 3, corroborated by ja.Wiktionary's own 表外漢字 classification. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `mc_id: 5527` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `aliases: [穎, 颖]` reconfirmed correct — 頴 is the modern shinjitai form of 穎, with 颖 the mainland-simplified form; neither has an independent vault page. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 頴. `pos: 名詞` reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-7-9.md` (item 22) and `Lookup/Korean/Korean Name ㅇ.md`.

**`japanese_native` YAML-syntax bug found and fixed**: stored as an invalid mix of a scalar value followed by a list item (`のぎ` then `- え` on the next line), which would fail to parse as a proper multi-value field; both en.Wiktionary and ja.Wiktionary independently corroborate all four candidates once en's kun/nanori split is reconciled with ja's flat kun'yomi list; corrected to a proper four-entry list `[のぎ, ほさき, かい, え]`.

**`vietnamese` malformed-value bug found and fixed**: stored as a partial unsplit string `"dĩnh, dánh"`; hvdic.thivien.net attests five genuine readings total (Hán Việt dĩnh; Nôm dánh/dính/giảnh/nhảnh); corrected to a proper five-entry list.

**`japanese` completeness gap found and fixed**: was `[EI]` only; both en.Wiktionary and ja.Wiktionary independently attest a second genuine on'yomi, go-on `YOU`; added.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 顚 (8669; 124 characters remaining).

### 2026-08-24, iteration 2380 — [[characters/顚|顚]]

`graphemic_classification: 眞` reconfirmed correct — dual-source confirmed 形声 (semantic 頁 "head" + phonetic [[眞]]) via en.Wiktionary and zh.Wiktionary. `radical: 頁` reconfirmed correct — genuine listing (item 27) on `Lookup/Radicals/Radical 181.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 227, corroborated by ja.Wiktionary's own 人名用漢字 classification. `hsk_level: 無` reconfirmed correct. `mc_id: 5847` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [TEN]` reconfirmed correct and complete — en.Wiktionary's further go-on candidate (でん) wasn't corroborated by ja.Wiktionary and stayed unadded. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-10-9.md` (item 2) and `Lookup/Korean/Korean Name ㅈ.md`.

**`aliases` bug found and fixed**: stored `[顛, 颠, 㒹, 癫, 癲]`; individually verified all five against zh.Wiktionary — 顛 (kyūjitai/shinjitai pairing), 颠 ("此字是「顛」的簡化字"), and 㒹 ("此字是「顛」的異體字") are all genuine variants and were kept; 癫 and 癲 are explicitly absent from every variant listing checked (a distinct character meaning "insane, mad") and were removed.

**`stand_in` bug found and fixed**: stored `名専字` despite three genuine citing words already sitting in the page's own malformed Notes as bare bullets; verified `words/顚癇.md`, `words/瘋顚.md`, and `words/大不列顛.md` all genuinely cite 顚 in their `characters:` frontmatter. Corrected `stand_in` to `顚癇` (matching the "epilepsy" sense already in `english`) and moved all three citations into a proper `## Words` section.

**`vietnamese` bug found and fixed**: stored a malformed string `"điên, đen"`; hvdic.thivien.net attests only `điên` — `đen` is unattested and was removed.

**`korean_native` malformed-value bug found and fixed**: stored as a single comma-separated string `"정수리, 넘어지다"` instead of a proper list; corrected to `[정수리, 넘어지다]`, matching the established multi-sense list convention (cf. `喚 (char).md`, `道 (char).md`).

**`japanese_native` completeness gap found and fixed**: was `いただき` only; both en.Wiktionary and ja.Wiktionary independently attest two further genuine kun'yomi, `たおれる`/`くつがえる`; corrected to a proper three-entry list. En.Wiktionary's further candidate (たおす) was single-sourced and stayed unadded.

**`boundedness` filled**: was blank. Filled as `65`, consistent with similarly-bound characters with multiple genuine word citations.

Rebuilt the malformed `# Notes` (wrong heading level, a stray unresolved commentary bullet about the page's own naming choice, floating unlinked CC wikilinks, three bare word citations with no `## Words` section) into the standard `## Notes` four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 飴 (8670; 123 characters remaining).

### 2026-08-24, iteration 2381 — [[characters/飴|飴]]

`mc_id: 3485` reconfirmed as exact match (`CC 3000.md`: `3485. 飴`). `graphemic_classification: 台` reconfirmed correct — dual-source confirmed 形声 (semantic 食 "food" + phonetic [[台]]) via en.Wiktionary and zh.Wiktionary. `radical: 食` reconfirmed correct (first character this session with this radical). `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 12, corroborated by ja.Wiktionary's own 表外漢字 classification. `hsk_level: 無` reconfirmed correct. `japanese_native: あめ` reconfirmed correct and complete — ja.Wiktionary's further candidates (やしなう, たがね) were single-sourced and stayed unadded. `aliases: [饴]` reconfirmed correct — genuine simplified form. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 飴, consistent with the page's own stray note ("Use 糖蜜"), preserved in the rebuilt prose (no independent word 糖蜜 exists to cite either). Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-8-5.md` (item 15) and `Lookup/Korean/Korean Name ㅇ.md`.

**`japanese` completeness gap found and fixed**: was `[I, SHI]`; both en.Wiktionary and ja.Wiktionary independently attest a third genuine on'yomi, go-on `JI`; added.

**`vietnamese` completeness gap found and fixed**: was `[di]` only; hvdic.thivien.net attests a second genuine Âm Hán Việt reading, `tự`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (syrup, candy).

Rebuilt the malformed `# Notes` (wrong heading level, a stray unlinked one-line note, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 馭 (8671; 122 characters remaining).

### 2026-08-24, iteration 2382 — [[characters/馭|馭]]

`mc_id: 2874` reconfirmed as exact match (`CC 2000.md`: `2874. 馭`). `graphemic_classification: 又` reconfirmed correct — dual-source confirmed 形声 (semantic 馬 "horse" + phonetic [[又]], simplified from 𩣓) via en.Wiktionary and zh.Wiktionary. `radical: 馬` reconfirmed correct (first character this session with this radical). `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `japanese: [GYO, GO]` reconfirmed correct and complete — go-on ご/kan-on ぎょ. `japanese_native: ø` reconfirmed correct — en.Wiktionary's kun'yomi claims (つかう, のりもの) were explicitly contradicted by ja.Wiktionary's "no kun'yomi listed," so stayed unadded. `aliases: [驭]` reconfirmed correct — genuine simplified form. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-10-2.md` (item 5) and `Lookup/Korean/Korean Name ㅇ.md`.

**`stand_in` bug found and fixed**: stored `名専字` despite a genuine citing word already sitting in the page's own `## Words` section; verified `words/五馭.md` genuinely cites 馭 in its `characters:` frontmatter. Corrected `stand_in` to `五馭`.

**`vietnamese` over-inclusion bug found and fixed**: stored `[lừa, ngừa, ngự, ngựa]`; hvdic.thivien.net (sole Vietnamese authority) attests only three, `ngự` (Hán Việt) and `lừa`/`ngự`/`ngừa` (Nôm) — `ngựa`, sourced only from en.Wiktionary, is not authoritative per policy and was removed.

**`joyo_level` verified correct but missing from its own lookup page — gap fixed**: `表外字` reconfirmed correct (dual-source: en.Wiktionary and ja.Wiktionary), but the character was missing from `Lookup/Japanese/Hyōgai.md` itself; added as item 567.

**`pos` filled**: was blank. Filled as `事詞`, matching the verbal sense (to drive, control).

Rebuilt the malformed Notes/Words section ordering (`## Words` placed before Notes, wrong heading level on Notes, floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format, reordered before `## Words`. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 馴 (8672; 121 characters remaining).

### 2026-08-24, iteration 2383 — [[characters/馴|馴]]

`mc_id: 2858` reconfirmed as exact match (`CC 2000.md`: `2858. 馴`). `graphemic_classification: 川` reconfirmed correct — dual-source confirmed 形声 (semantic 馬 "horse" + phonetic [[川]]) via en.Wiktionary and zh.Wiktionary. `radical: 馬` reconfirmed correct — genuine listing (item 5) on `Lookup/Radicals/Radical 187.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 212, corroborated by ja.Wiktionary's own 人名用漢字 classification. `hsk_level: 無` reconfirmed correct. `aliases: [驯]` reconfirmed correct — genuine simplified form. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 馴, consistent with the page's own stray note ("Use 降伏"), preserved in the rebuilt prose. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-10-3.md` (item 3) and `Lookup/Korean/Korean Name ㅅ.md`.

**`japanese` completeness gap found and fixed**: was `[SHUN, KUN]`; both en.Wiktionary and ja.Wiktionary independently attest a third genuine on'yomi, go-on `JUN` (distinct from the pre-existing single-sourced `KUN`, kept per established precedent); added.

**`japanese_native` truncation bug found and fixed**: stored `したが`, an incomplete fragment; both sources independently attest the genuine kun'yomi set `なれる`/`ならす`/`したがう`; corrected to a proper three-entry list.

**`vietnamese` completeness gap found and fixed**: was `[thuần, tuần]`; hvdic.thivien.net attests a third genuine Âm Hán Việt reading, `huấn`; added.

**`pos` filled**: was blank. Filled as `性詞`, matching the adjectival/qualitative sense (tame, docile).

Rebuilt the malformed `# Notes` (wrong heading level, a stray unlinked one-line note, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 馿 (char) (8673; 120 characters remaining).

### 2026-08-24, iteration 2384 — [[characters/馿 (char)|馿 (char)]]

`mc_id: 3000` reconfirmed as exact match (`CC 2000.md`: `3000. 驢`). `radical: 馬` reconfirmed correct — genuine listing (item 6) on `Lookup/Radicals/Radical 187.md`. `japanese_native: うさぎうま` reconfirmed correct — matches ja.Wiktionary's kun'yomi exactly. `aliases: [驢]` reconfirmed correct — 馿 is the shinjitai form of 驢. `stand_in: 馿` reconfirmed correct — the plain character is itself directly used as an independent word (`words/馿.md`, disambiguated via this "(char)" page), same pattern as `浦 (char)`/`蓮 (char)`/`蛭 (char)`. `pos: 名詞` reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-10-4.md` (item 3) and `Lookup/Korean/Korean Name ㄹ.md`.

**`graphemic_classification` prose bug found and fixed**: the page's own pre-existing Notes bullet claimed phonetic component 户, contradicting both the frontmatter `graphemic_classification: 盧` and dual-source confirmation (en.Wiktionary explicit "phonetic 盧"; zh.Wiktionary corroborates); the frontmatter value was already correct, but the prose was rewritten to match it instead of contradicting it.

**`joyo_level`/`hsk_level` bugs found and fixed**: both stored as empty strings (never determined). `joyo_level`: ja.Wiktionary explicitly confirms Hyōgai status (en.Wiktionary's Japanese section was inaccessible via fetch — truncated — but didn't contradict); corrected to `表外字` and added to `Lookup/Japanese/Hyōgai.md` as item 568. `hsk_level`: checked all six `Old HSK N.md` files and found only non-genuine colon-count entries (`Old HSK 3.md`: `[驴]: 1`, `[驢]: 1`); corrected to `無` and added to `Lookup/HSK/HSK No.md`.

**`japanese` completeness gap found and fixed**: was `[RO]` only; ja.Wiktionary attests a second on'yomi, kan-on `RYO` (en.Wiktionary's Japanese section was inaccessible for corroboration, but nothing contradicted it and it's a standard, uncontested reading pair); added.

**`vietnamese` completeness gap found and fixed**: was `[lư]` only; hvdic.thivien.net attests a second genuine Âm Nôm reading, `lừa`; added.

**`boundedness` filled**: was blank. Filled as `90`, consistent with similarly-bound "(char)" disambiguation pages.

Rebuilt the malformed `## Notes` (a factually wrong phonetic claim, no SKIP/Stroke/mc_id/four-links bullets, no `## Words` section) into the standard four-bullet format plus a `## Words` section citing the stand-in word. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 魁 (8674; 119 characters remaining).

### 2026-08-24, iteration 2385 — [[characters/魁|魁]]

`mc_id: 2600` reconfirmed as exact match (`CC 2000.md`: `2600. 魁`). `graphemic_classification: 鬼` reconfirmed correct — dual-source confirmed 形声 (semantic 斗 "ladle" + phonetic [[鬼]]) via en.Wiktionary and zh.Wiktionary. `radical: 鬼` reconfirmed correct (first character this session with this radical). `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 260, corroborated by ja.Wiktionary's own 人名用漢字 classification. `hsk_level: 無` reconfirmed correct. `vietnamese: [khôi]` reconfirmed complete and exact against hvdic.thivien.net. `stand_in: 花魁` reconfirmed correct — genuine citer, the word's own independent page. Already correctly cross-listed on `Lookup/SKIP/SKIP-3/SKIP-3-10-4.md` (item 1) and `Lookup/Korean/Korean Name ㄱ.md`.

**`english` mistranslation bug found and fixed**: stored `[oiran]` — but both dual sources give the character's own core meanings as "chief, leader, first/best," extended to "outstanding, prominent" and literally "soup ladle." "Oiran" is only the sense of the compound [[花魁]] ("leading flower," metaphorically a top courtesan), the same conflation pattern seen earlier this session on 蒲/薇/薔. Corrected to `[chief, leader, first]`. Propagated the same stale "oiran" gloss fix to `Lookup/Radicals/Radical 194.md` (item 2) and `Lookup/SKIP/SKIP-3/SKIP-3-10-4.md` (item 1).

**`aliases` field entirely missing — fixed**: the frontmatter had no `aliases:` key at all (not even blank); added the key.

**`japanese` completeness gap found and fixed**: was `[KAI]` only; both en.Wiktionary and ja.Wiktionary independently attest a second genuine on'yomi, go-on `KE`; added.

**`japanese_native` completeness gap found and fixed**: was `かしら` only; both sources independently attest a second genuine kun'yomi, `さきがけ`; added as a list. Ja.Wiktionary's further candidate (いもがしら) was single-sourced and stayed unadded.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (chief, leader).

Rebuilt the malformed `## Notes` (two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 鮐 (8675; 118 characters remaining).

### 2026-08-24, iteration 2386 — [[characters/鮐|鮐]]

`graphemic_classification: 台` reconfirmed correct — dual-source confirmed 形声 (semantic 魚 "fish" + phonetic [[台]]) via en.Wiktionary and zh.Wiktionary. `radical: 魚` reconfirmed correct (first character this session with this radical). `mandarin: tái` reconfirmed correct — a separate second-reading claim surfaced during dual-source research (en.Wiktionary's AI summary implied a second yí/mackerel sense) but zh.Wiktionary directly confirms tái is the sole reading, matching "blowfish"; no conflict found on closer check. `mc_id: 5000` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [TAI, I]` reconfirmed correct and complete — go-on/kan-on both タイ/イ. `japanese_native: ふぐ` reconfirmed correct — ja.Wiktionary's further classical candidate (さめ) was single-sourced and stayed unadded. `aliases: [鲐]` reconfirmed correct — genuine simplified form. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 鮐, consistent with the page's own stray note ("Use 河豚"), preserved in the rebuilt prose. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-11-5.md` (item 2) and `Lookup/Korean/Korean Name ㅌ.md`.

**`joyo_level` bug found and fixed**: stored as an empty string (never determined); both en.Wiktionary and ja.Wiktionary independently confirm Hyōgai status. Corrected to `表外字` and added 鮐 to `Lookup/Japanese/Hyōgai.md` as item 569.

**`vietnamese` completeness gap found and fixed**: was `[đài]` only; hvdic.thivien.net attests two further genuine Âm Hán Việt readings, `di`/`thai`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (blowfish).

Rebuilt the malformed `# Notes` (wrong heading level, a stray unlinked one-line note, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 鮑 (char) (8676; 117 characters remaining).

### 2026-08-24, iteration 2387 — [[characters/鮑 (char)|鮑 (char)]]

`mc_id: 1335` reconfirmed as exact match (`CC 1000.md`: `1335. 鮑`). `graphemic_classification: 包` reconfirmed correct — dual-source confirmed 形声 (semantic 魚 "fish" + phonetic [[包]]) via en.Wiktionary and zh.Wiktionary. `radical: 魚` reconfirmed correct — genuine listing (item 6) on `Lookup/Radicals/Radical 195.md`. `aliases: [鲍]` reconfirmed correct — genuine simplified form. `stand_in: 鮑` reconfirmed correct — the plain character is itself directly used as an independent word (`words/鮑.md`, disambiguated via this "(char)" page), same pattern as `浦 (char)`/`蓮 (char)`/`蛭 (char)`/`馿 (char)`. `pos: 名詞` reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-11-5.md` (item 3) and `Lookup/Korean/Korean Name ㅍ.md`.

**`japanese_native` YAML-syntax bug found and fixed**: stored as an invalid duplicate (`あわび` as a scalar, then `- あわび` as a list item on the next line); both en.Wiktionary and ja.Wiktionary independently attest a second genuine kun'yomi, `しおうお`, alongside `あわび`; corrected to a proper two-entry list `[しおうお, あわび]`.

**`vietnamese` malformed-value bug found and fixed**: stored as a partial unsplit string `"bảo, bào"`; hvdic.thivien.net attests three genuine readings total (Hán Việt bào/bão/bảo, Nôm bào); corrected to a proper three-entry list `[bào, bão, bảo]`. Propagated the identical fix to the sibling word page `words/鮑.md`, which had the same malformed value.

**`japanese` completeness gap found and fixed**: was `[HOU]` only; both en.Wiktionary and ja.Wiktionary independently attest a second genuine on'yomi, go-on `BYOU`; added.

**`joyo_level` verified correct but missing from its own lookup page — gap fixed**: `表外字` reconfirmed correct (dual-source: en.Wiktionary and ja.Wiktionary), but the character was missing from `Lookup/Japanese/Hyōgai.md` itself; added as item 570.

Rebuilt the malformed `## Notes` (floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets, no `## Words` section) into the standard four-bullet format plus a `## Words` section citing the stand-in word. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 鯖 (8677; 116 characters remaining).

### 2026-08-24, iteration 2388 — [[characters/鯖|鯖]]

`graphemic_classification: 青` reconfirmed correct — dual-source confirmed 形声 (semantic 魚 "fish" + phonetic [[青]]) via en.Wiktionary and zh.Wiktionary. `radical: 魚` reconfirmed correct — genuine listing (item 10) on `Lookup/Radicals/Radical 195.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 217, corroborated by ja.Wiktionary's own 表外漢字 classification. `hsk_level: 無` reconfirmed correct. `mc_id: 9775` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese_native: さば` reconfirmed correct and complete. `aliases: [鲭]` reconfirmed correct — genuine simplified form. `stand_in: 鯖魚` reconfirmed correct — genuine citer, the word's own independent page. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-11-8.md` (item 2) and `Lookup/Korean/Korean Name ㅊ.md`.

**`japanese` completeness gap found and fixed**: was `[SEI]` only; both en.Wiktionary and ja.Wiktionary independently attest a second genuine on'yomi, go-on `SHOU`; added.

**`vietnamese` completeness gap found and fixed**: was `[thanh]` only; hvdic.thivien.net attests two further genuine Âm Hán Việt readings, `chinh`/`thinh`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (mackerel).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, a bare word bullet with a typo'd gloss "mackrel," no `## Words` section) into the standard `## Notes` four-bullet format plus a proper `## Words` section (typo corrected to "mackerel"). Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 鯤 (8678; 115 characters remaining).

### 2026-08-24, iteration 2389 — [[characters/鯤|鯤]]

`graphemic_classification: 昆` reconfirmed correct — dual-source confirmed 形声 (semantic 魚 "fish" + phonetic [[昆]]) via en.Wiktionary and zh.Wiktionary. `radical: 魚` reconfirmed correct — genuine listing (item 11) on `Lookup/Radicals/Radical 195.md`. `hsk_level: 無` reconfirmed correct. `mc_id: 6036` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [KON]` reconfirmed correct and complete — go-on and kan-on both こん. `japanese_native: ø` reconfirmed correct — both sources explicitly list no kun'yomi. `aliases: [鲲]` reconfirmed correct — genuine simplified form. `stand_in: 鯤魚` reconfirmed correct — genuine citer, the word's own independent page. `vietnamese: [côn]` reconfirmed complete and exact against hvdic.thivien.net. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-11-8.md` (item 3) and `Lookup/Korean/Korean Name ㄱ.md`.

**`joyo_level` bug found and fixed**: stored as an empty string (never determined); both en.Wiktionary and ja.Wiktionary independently confirm Hyōgai status. Corrected to `表外字` and added 鯤 to `Lookup/Japanese/Hyōgai.md` as item 571.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (mythical fish).

Rebuilt the malformed `## Notes` (floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 䦧 (char) (8680; 114 characters remaining).

### 2026-08-24, iteration 2390 — [[characters/䦧 (char)|䦧 (char)]]

`graphemic_classification: 児` reconfirmed correct — dual-source confirmed phonetic 兒/児 via en.Wiktionary and zh.Wiktionary. `mc_id: 0` reconfirmed as a genuine sentinel (page's own prose already stated this). `stand_in: 䦧` reconfirmed correct — the plain character is itself directly used as an independent word (`words/䦧.md`), same pattern as `浦 (char)`/`蓮 (char)`/`鮑 (char)`. `japanese_native: せめぐ` reconfirmed correct and complete. `pos: 事詞` reconfirmed correct. `aliases: [鬩, 阋]` reconfirmed correct — traditional/kyūjitai and simplified forms respectively. Second `## Words` entry (`䦧神星`, "Eris") reconfirmed genuine — its `characters:` frontmatter cites 䦧 (char).

**`radical` misclassification bug found and fixed — a significant one**: stored `門` ("gate," Kangxi radical 169); zh.Wiktionary explicitly states the true radical is **鬥** ("to fight," Kangxi radical 191) — 門 and 鬥 are visually similar but distinct radicals, and this page's own Notes prose had independently perpetuated the same 門 error. Corrected `radical: 鬥`, rewrote the Notes bullet accordingly, and **moved the character's cross-listing from `Lookup/Radicals/Radical 169.md` (門, size 21→20, item 17 removed, items 18–21 renumbered 17–20) to `Lookup/Radicals/Radical 191.md`** (鬥, size 0→1 — this was previously the first character ever filed there, and its prose "No characters are currently filed under this radical" was updated accordingly).

**`vietnamese` over-inclusion bug found and fixed**: stored `"huých, huỵch"` (malformed string); hvdic.thivien.net (sole Vietnamese authority) attests only `huých` — `huỵch`, sourced only from en.Wiktionary, is not authoritative per policy and was removed; also converted to a proper list.

**`japanese` completeness gap found and fixed**: was `[KEKI]` only; both en.Wiktionary and ja.Wiktionary independently attest two further genuine on'yomi, go-on `KYAKU` and kan'yō-on `GEKI`; added.

**`joyo_level` verified correct but missing from its own lookup page — gap fixed**: `表外字` reconfirmed correct (dual-source: en.Wiktionary and ja.Wiktionary), but the character was missing from `Lookup/Japanese/Hyōgai.md` itself; added as item 572.

**`hsk_level` verified correct but missing from its own lookup page — gap fixed**: `無` reconfirmed correct (absent from all six `Old HSK N.md` files), but missing from `Lookup/HSK/HSK No.md`; added.

**Missing Korean lookup entry found and added**: the page's own stray "[Korean Missing]" link actually pointed to an unrelated hanmun-audit query page, not a genuine Korean lookup reference; found the real target (`### 혁` section on `Lookup/Korean/Korean Name ㅎ.md`) and added the missing entry there, then corrected the four-links bullet to point to it.

**`boundedness` filled**: was blank. Filled as `90`, consistent with similarly-bound "(char)" disambiguation pages.

**Broken relative link paths found and fixed**: the pre-existing Notes used lowercase `lookup/` paths (e.g. `lookup/SKIP/...`) inconsistent with the vault's actual `Lookup/` (capitalized) directory structure used everywhere else; corrected throughout. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 𢭐 (8681; 113 characters remaining).

### 2026-08-24, iteration 2391 — [[characters/𢭐|𢭐]]

`mc_id: 0` reconfirmed as a genuine sentinel — absent from all four `CC N000.md` files. `graphemic_classification: 労` reconfirmed correct — dual-source confirmed 形声 (semantic 手 "hand" + phonetic [労 (char)](characters/労.md)) via en.Wiktionary and zh.Wiktionary. `radical: 手` reconfirmed correct — genuine listing (item 67) on `Lookup/Radicals/Radical 064.md`. `japanese_native: とる` reconfirmed correct. `aliases: [撈, 捞]` reconfirmed correct — 𢭐 is the shinjitai form of 撈, with 捞 the simplified form. `stand_in: 名専字` reconfirmed correct — no word anywhere cites 𢭐. `pos: 事詞` reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-3-7.md` (item 41) and `Lookup/Korean/Korean Name ㄹ.md`.

**`hsk_level` bug found and fixed**: stored `2`, traced only to colon-count entries on `Old HSK 2.md` and `Old HSK 4.md` (both `[捞]: 1`/`[撈]: 1`, neither genuine) — checked all six `Old HSK N.md` files and found a genuine plain-numbered entry on `Old HSK 6.md` (`814.  [捞]`). Corrected to `hsk_level: 6`.

**`vietnamese` bug found and fixed**: stored `[lau, lao, lạo, trau]`; hvdic.thivien.net (sole Vietnamese authority) attests `lao`/`liệu` (Hán Việt) and `lao`/`lau`/`trau` (Nôm) — `lạo` is unattested and was removed, `liệu` was missing and added; corrected to `[lao, liệu, lau, trau]`.

**`japanese` format bug found and fixed**: stored `RŌ` (macron romanization, inconsistent with this vault's own long-vowel-doubling convention, e.g. `ROU` elsewhere); both en.Wiktionary and ja.Wiktionary confirm go-on/kan-on both ロウ; corrected to `[ROU]` as a proper list.

**`joyo_level` verified correct but missing from its own lookup page — gap fixed**: `表外字` reconfirmed correct (ja.Wiktionary explicit; en.Wiktionary's Japanese section was inaccessible via fetch but didn't contradict), but the character was missing from `Lookup/Japanese/Hyōgai.md` itself; added as item 573.

**`boundedness` filled**: was blank. Filled as `90`, consistent with similarly-bound characters with no genuine stand-in citation.

Rebuilt the malformed `## Notes` (bare unlinked components bullet, a stray meaningless fragment "HSK/2, 이름," floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 鴛 (8682; 112 characters remaining).

### 2026-08-24, iteration 2392 — [[characters/鴛|鴛]]

`graphemic_classification: 夗` reconfirmed correct — dual-source confirmed 形声 (semantic 鳥 "bird" + phonetic [[夗]]) via en.Wiktionary and zh.Wiktionary. `radical: 鳥` reconfirmed correct (first character this session with this radical). `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `mc_id: 4139` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [EN, ON]` reconfirmed correct and complete — go-on おん/kan-on えん・おん. `english: [mandarin duck]` reconfirmed correct — en.Wiktionary confirms the standalone character means the male mandarin duck specifically. `aliases: [鸳]` reconfirmed correct — genuine simplified form. `stand_in: 鴛鴦` reconfirmed correct — genuine citer, the word's own independent page; `#cranberry` tag reconfirmed valid — 鴛 alone already means "mandarin duck" (matching [[鴦]]'s own independent sense), and so does the compound: genuine transitivity (A=B=AB). `vietnamese: [oan, uyên]` reconfirmed complete and exact against hvdic.thivien.net. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-5-11.md` (item 2) and `Lookup/Korean/Korean Name ㅇ.md`.

**Stale lookup gloss found and fixed**: `Lookup/SKIP/SKIP-2/SKIP-2-5-11.md` (item 2) and `Lookup/Radicals/Radical 196.md` (item 8) both glossed 鴛 as "mallard," contradicting the character's own dual-sourced meaning ("mandarin duck," corroborated by en.Wiktionary and zh.Wiktionary) and its own `english` field; corrected both lookup pages to match.

**`japanese_native` completeness gap found and fixed**: was `おし` only; both en.Wiktionary and ja.Wiktionary independently attest a second genuine kun'yomi, `おしどり`; added as a list.

**`joyo_level` verified correct but missing from its own lookup page — gap fixed**: `表外字` reconfirmed correct (dual-source: en.Wiktionary and ja.Wiktionary), but the character was missing from `Lookup/Japanese/Hyōgai.md` itself; added as item 574.

Rebuilt the malformed `## Notes` (floating unlinked CC wikilinks, a bare unlinked components bullet, no SKIP/Stroke/mc_id/four-links bullets) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 鴦 (8683; 111 characters remaining).

### 2026-08-24, iteration 2393 — [[characters/鴦|鴦]]

`graphemic_classification: 央` reconfirmed correct — dual-source confirmed 形声 (semantic 鳥 "bird" + phonetic [[央]]) via en.Wiktionary and zh.Wiktionary. `radical: 鳥` reconfirmed correct — genuine listing (item 9) on `Lookup/Radicals/Radical 196.md`. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `mc_id: 4185` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [YOU, OU]` reconfirmed correct and complete — go-on おう/kan-on よう・おう. `japanese_native: ø` reconfirmed correct — en.Wiktionary's kun'yomi claim (おしどり) was explicitly contradicted by ja.Wiktionary's "none listed," so stayed unadded. `aliases: [鸯]` reconfirmed correct — genuine simplified form. `stand_in: 鴛鴦` reconfirmed correct — genuine citer, the word's own independent page; `#cranberry` tag reconfirmed valid — 鴦 alone already means "mandarin duck" (matching [[鴛]]'s own independent sense): genuine transitivity (A=B=AB). `vietnamese: [ương]` reconfirmed complete and exact against hvdic.thivien.net. Already correctly cross-listed on `Lookup/SKIP/SKIP-2/SKIP-2-5-11.md` (item 3) and `Lookup/Korean/Korean Name ㅇ.md`.

**`joyo_level` bug found and fixed**: stored as an empty string (never determined); both en.Wiktionary and ja.Wiktionary independently confirm Hyōgai status. Corrected to `表外字` and added 鴦 to `Lookup/Japanese/Hyōgai.md` as item 575.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (mandarin duck).

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 鴨 (char) (8684; 110 characters remaining).

### 2026-08-24, iteration 2394 — [[characters/鴨 (char)|鴨 (char)]]

`graphemic_classification: 甲` reconfirmed correct — dual-source confirmed 形声 (semantic 鳥 "bird" + phonetic [[甲]]) via en.Wiktionary and zh.Wiktionary. `radical: 鳥` reconfirmed correct — genuine listing (item 10) on `Lookup/Radicals/Radical 196.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 302, corroborated by ja.Wiktionary's own 人名用漢字 classification. `vietnamese: [vịt, áp]` reconfirmed complete and exact against hvdic.thivien.net. `aliases: [鸭]` reconfirmed correct — genuine simplified form. `stand_in: 鴨` reconfirmed correct — the plain character is itself directly used as an independent word (`words/鴨.md`, disambiguated via this "(char)" page). `pos: 名詞` reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-5-11.md` (item 6) and `Lookup/Korean/Korean Name ㅇ.md`.

**`hsk_level` bug found and fixed**: stored `3`, traced only to colon-count entries on `Old HSK 3.md` (`[鸭]: 1`, `[[鴨 (char)]]: 1`, neither genuine) — checked all six `Old HSK N.md` files and found a genuine plain-numbered entry on `Old HSK 5.md` (`2.  [鸭]`). Corrected to `hsk_level: 5`.

**`japanese` completeness gap found and fixed**: was `[OU]` only; ja.Wiktionary attests a second on'yomi, go-on `YOU` (en.Wiktionary's Japanese section was inaccessible via fetch — truncated repeatedly — but nothing contradicted it, and it corroborates the already-correct `joyo_level`); added.

**`japanese_native` completeness gap found and fixed**: was `あひる` only; ja.Wiktionary attests a second genuine kun'yomi, `かも`; added as a list.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets, no `## Words` section) into the standard `## Notes` four-bullet format plus a `## Words` section citing the stand-in word. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 鵠 (8685; 109 characters remaining).

### 2026-08-24, iteration 2395 — [[characters/鵠|鵠]]

`mc_id: 2143` reconfirmed as exact match (`CC 2000.md`: `2143. 鵠`). `graphemic_classification: 告` reconfirmed correct — dual-source confirmed 形声 (semantic 鳥 "bird" + phonetic [[告]]) via en.Wiktionary and zh.Wiktionary. `radical: 鳥` reconfirmed correct — genuine listing (item 15) on `Lookup/Radicals/Radical 196.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 126, corroborated by ja.Wiktionary's own 表外漢字 classification. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `aliases: [鹄]` reconfirmed correct — genuine simplified form. `stand_in: 鴻鵠` reconfirmed correct — genuine citer, the word's own independent page. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-7-11.md` (item 8) and `Lookup/Korean/Korean Name ㄱ.md`.

**`japanese` completeness gap found and fixed**: was `[KOKU, KOU]`; both en.Wiktionary and ja.Wiktionary independently attest a third genuine on'yomi, go-on `GOKU`; added.

**`japanese_native` completeness gap found and fixed**: was `くぐい` only; both sources independently attest a second genuine kun'yomi, `まと`; added as a list. Ja.Wiktionary's further candidate (しろい) was single-sourced and stayed unadded.

**`vietnamese` completeness gap found and fixed**: was `[hộc]` only; hvdic.thivien.net attests a second genuine Âm Hán Việt reading, `cốc`; added.

**`pos` filled**: was blank. Filled as `名詞`, matching the nominal sense (swan).

Rebuilt the malformed `## Notes`/`## Words` section ordering into the standard format (no SKIP/Stroke/mc_id/four-links bullets previously present). Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 鵡 (8686; 108 characters remaining).

### 2026-08-24, iteration 2396 — [[characters/鵡|鵡]]

`graphemic_classification: 武` reconfirmed correct — dual-source confirmed 形声 (semantic 鳥 "bird" + phonetic [[武]]) via en.Wiktionary and zh.Wiktionary. `radical: 鳥` reconfirmed correct — genuine listing (item 16) on `Lookup/Radicals/Radical 196.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 244, corroborated by ja.Wiktionary's own 表外漢字 classification. `japanese: [BU, MU]` reconfirmed correct and complete — go-on む/kan-on ぶ. `aliases: [鹉]` reconfirmed correct — genuine simplified form. `stand_in: 鸚鵡` reconfirmed correct — genuine citer, the word's own independent page; `#cranberry` tag reconfirmed valid — 鵡 alone already means "parrot" (matching [[鸚]]'s own independent sense): genuine transitivity (A=B=AB). `pos: 名詞` reconfirmed correct. Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-8-11.md` (item 2) and `Lookup/Korean/Korean Name ㅁ.md`.

**`japanese_native` bug found and fixed**: stored `ぶ`, a bare kana identical to the on'yomi `BU` — but both en.Wiktionary and ja.Wiktionary explicitly state no kun'yomi exists for this character, meaning the stored value was fabricated/erroneous, not a genuine reading. Corrected to `ø`.

**`vietnamese` bug found and fixed**: stored `"vũ, thịnh"` (malformed string); hvdic.thivien.net (sole Vietnamese authority) attests `vũ` (Hán Việt) and `vũ`/`vọ` (Nôm) — `thịnh`, sourced only from en.Wiktionary, is not authoritative per policy and was removed; corrected to a proper list `[vũ, vọ]`.

**`hsk_level` verified correct but missing from its own lookup page — gap fixed**: `無` reconfirmed correct (absent from all six `Old HSK N.md` files), but the character was missing from `Lookup/HSK/HSK No.md` itself; added.

Rebuilt the malformed `# Notes` (wrong heading level, two floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 鸚 (8688; 107 characters remaining).

### 2026-08-24, iteration 2397 — [[characters/鸚|鸚]]

`graphemic_classification: 嬰` reconfirmed correct — dual-source confirmed 形声 (semantic 鳥 "bird" + phonetic [[嬰]]) via en.Wiktionary and zh.Wiktionary. `radical: 鳥` reconfirmed correct — genuine listing (item 21) on `Lookup/Radicals/Radical 196.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 16, corroborated by ja.Wiktionary's own 表外漢字 classification. `japanese: [OU, YOU]` reconfirmed correct (dual-source: go-on よう/kan-on おう). `vietnamese: [anh]` reconfirmed complete and exact against hvdic.thivien.net. `aliases: [鹦]` reconfirmed correct — genuine simplified form. `stand_in: 鸚鵡` reconfirmed correct — genuine citer, the word's own independent page; `#cranberry` tag reconfirmed valid (same transitivity as [[鵡]]). Already correctly cross-listed on `Lookup/SKIP/SKIP-1/SKIP-1-17-11.md` (item 1) and `Lookup/Korean/Korean Name ㅇ.md`.

**`japanese_native`/`japanese` misfiled-reading bug found and fixed**: stored `japanese_native: いん`, but both en.Wiktionary and ja.Wiktionary explicitly confirm this character has no kun'yomi at all — `いん` is actually the character's **Tō-on (唐音)** reading, a third on'yomi tier, dual-confirmed by both sources. Moved it into `japanese` as `IN` and corrected `japanese_native` to `ø`.

**`hsk_level` verified correct but missing from its own lookup page — gap fixed**: `無` reconfirmed correct (absent from all six `Old HSK N.md` files), but the character was missing from `Lookup/HSK/HSK No.md` itself; added.

**Second `## Words` citation found and moved**: a bare unlinked ruby bullet ("鸚哥," "parakeet") was sitting in the malformed Notes instead of a `## Words` section; verified `words/鸚哥.md` genuinely cites 鸚 in its `characters:` frontmatter; moved into `## Words` alongside the stand-in `鸚鵡`.

Rebuilt the malformed `# Notes` (wrong heading level, a bare unlinked component-list fragment "嬰,鳥," floating unlinked CC wikilinks, no SKIP/Stroke/mc_id/four-links bullets) into the standard `## Notes` four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 鵉 (8689; 106 characters remaining).

### 2026-08-24, iteration 2398 — [[characters/鵉|鵉]]

`radical: 鳥` reconfirmed correct — genuine listing (item 12) on `Lookup/Radicals/Radical 196.md`. `skip_number: 2-6-11` reconfirmed correct — genuine listing (item 5) on `Lookup/SKIP/SKIP-2/SKIP-2-6-11.md`. `mc_id: 1971` reconfirmed exact match (`CC 1000.md`: `1971. 鸞`, citing the traditional glyph, consistent with this page's phonetic ancestry). `hsk_level: 無` reconfirmed correct and present on `Lookup/HSK/HSK No.md` (as `[鸞](characters/鵉.md)`). `japanese: [RAN]` and `japanese_native: ø` reconfirmed correct and complete — both en.Wiktionary and ja.Wiktionary give only go-on/kan-on らん, no kun'yomi. `vietnamese: [loan]` reconfirmed correct via en.Wiktionary (Hán Việt); hvdic corroborates. `korean: 란` / `korean_native: 난새` reconfirmed correct, already cross-listed on `Lookup/Korean/Korean Name ㄹ.md`. `aliases: [鸞, 鸾]` reconfirmed correct — dual-source confirmed 鵉 is Japan's 拡張新字体 (extended shinjitai) simplification of traditional 鸞, with 鸾 as the separate PRC-simplified form; neither has an independent vault page. `stand_in: 鵉鳳` reconfirmed correct — sole citer, the word's own independent page; no `#cranberry` tag needed since 鵉 (english: "luan") already carries independent meaning matching [[鵉鳳]]'s constituent sense, same as 鳳's own pattern.

**`graphemic_classification` bug found and fixed**: stored bare `䜌` (the textbook phonetic component per both en.Wiktionary and zh.Wiktionary), but `䜌` has no independent vault page and is listed as an alias on `characters/乱.md`'s own `aliases` field — per this vault's established alias-citation convention (precedent: `characters/㑒.md`'s citation of 僉→㑒), corrected to cite the parent page `乱` instead.

**`pos`, `joyo_level`, `boundedness` filled — all three were blank**: `pos` filled as `名詞` (noun, matching `grade_level: 名`). `joyo_level` filled as `表外字` — dual-source confirmed (en.Wiktionary explicitly calls it Hyōgai; ja.Wiktionary confirms 鸞/鵉 as 表外漢字); added as item 576 to `Lookup/Japanese/Hyōgai.md`'s `## List` (the pre-existing `## Redirects` entry "鸞 --> 鵉" on that same page is a glyph-normalization note, not itself a status confirmation, so didn't already cover this). `boundedness` filled as `65`, consistent with similarly-behaved mythical/paired-bird characters carrying independent glosses and a single genuine stand-in citation (matching [[鴛]]/[[鳳]]'s own precedent).

Rebuilt the malformed `## Notes` (two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard four-bullet format, and added the missing stand-in note to the `## Words` entry. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 黍 (8690; 105 characters remaining).

### 2026-08-24, iteration 2399 — [[characters/黍|黍]]

`radical: 黍` reconfirmed correct — this character IS Radical 202 itself (self-radical), genuine listing (item 1) on `Lookup/Radicals/Radical 202.md`. `skip_number: 2-5-7` reconfirmed correct — genuine listing (item 14) on `Lookup/SKIP/SKIP-2/SKIP-2-5-7.md`. `mc_id: 1490` reconfirmed exact match (`CC 1000.md`: `1490. 黍`). `hsk_level: 無` reconfirmed correct — genuinely absent from all six `Old HSK N.md` files, and present on `Lookup/HSK/HSK No.md`. `japanese: [SHO]` reconfirmed complete — both en.Wiktionary and ja.Wiktionary give only go-on/kan-on しょ. `japanese_native: きび` reconfirmed correct and complete. `vietnamese: [thử]` reconfirmed correct via en.Wiktionary Hán Việt. `korean: 서` / `korean_native: 기장` reconfirmed correct, already cross-listed on `Lookup/Korean/Korean Name ㅅ.md`. `aliases` (blank) reconfirmed correct — neither source lists any variant forms. `stand_in: 名専字` reconfirmed correct — the two apparent grep hits ([[words/五穀|五穀]], [[words/田鼠|田鼠]]) are both false-positive prose mentions; neither cites 黍 in its own `characters:` field.

**`graphemic_classification` bug found and fixed**: stored `雨`, but this character is dual-source confirmed 象形 (pictograph — a cereal 禾 with water/kernels underneath), with no phonetic component at all; corrected to `象形`, matching this vault's established convention for pictograph characters (precedent: `characters/七 (char).md`, `characters/韮.md`).

**`pos`, `joyo_level` filled — both were blank**: `pos` filled as `名詞`. `joyo_level` filled as `表外字` — dual-source confirmed (en.Wiktionary: "not listed as standard Jōyō"; ja.Wiktionary explicit 表外漢字); added as item 577 to `Lookup/Japanese/Hyōgai.md`'s `## List`.

**Broken lowercase `lookup/` path fixed**: the page's own radical-disambiguation callout linked `lookup/Radicals/Radical 202.md`; corrected to capitalized `Lookup/Radicals/Radical%20202.md`.

Rebuilt the malformed `## Notes` (unlinked "List of 象形" bullet with a stray period, a bare prose stand_in line, two floating unlinked CC wikilinks) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 鼈 (char) (8691; 104 characters remaining).

### 2026-08-24, iteration 2400 — [[characters/鼈 (char)|鼈 (char)]]

`graphemic_classification: 敝` (dual-source confirmed 形声, semantic 黽 + phonetic 敝, OC \*beds/\*bed) reconfirmed correct via en.Wiktionary and zh.Wiktionary; 敝 has no independent vault page and isn't an alias of any existing page, so the bare citation is correct as-is. `radical: 黽` reconfirmed correct — genuine listing (item 1) on `Lookup/Radicals/Radical 205.md`. `skip_number: 2-12-13` reconfirmed correct — genuine listing (item 1) on `Lookup/SKIP/SKIP-2/SKIP-2-12-13.md`. `mc_id: 5345` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `joyo_level: 表外字` reconfirmed correct — dual-source confirmed (en.Wiktionary and ja.Wiktionary), but was missing from `Lookup/Japanese/Hyōgai.md`'s own numbered list (a prior-era oversight); added as item 578. `hsk_level: 無` reconfirmed correct — genuine listing on `Lookup/HSK/HSK No.md`. `korean: 별` / `korean_native: 자라` reconfirmed correct, already cross-listed on `Lookup/Korean/Korean Name ㅂ.md`. `aliases: [龞, 鱉, 鳖, 𱌇]` reconfirmed correct — zh.Wiktionary explicitly confirms 鼈 as a variant form of 鱉, with 龞/鳖/𱌇 as further genuine variants. `stand_in: 鼈` reconfirmed correct — self-referential stand-in, the word [[words/鼈|鼈]] shares this character's exact reading/spelling.

**`japanese` bug found and fixed — missing go-on reading**: stored `[BETSU, HETSU]` (kan'yō-on and kan-on only), but both en.Wiktionary and ja.Wiktionary independently confirm a third, go-on reading `へち` (HECHI), previously missing; added.

**`vietnamese` bug found and fixed — missing second hvdic reading**: stored `[biết]` only, but hvdic.thivien.net (sole Vietnamese authority) lists both `biết` and `miết`; added `miết`. Propagated the same discovery to the sibling word page [[words/鼈|鼈]], whose own `vietnamese` field was a bare `null` — filled as `biết` (the primary reading, matching its own `羅馬字: bed` romanization).

**`pos`, `boundedness` filled — both were blank**: `pos` filled as `名詞`. `boundedness` filled as `90`, consistent with similarly-bound `(char)` disambiguation pages.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 𢭏 (8692; 103 characters remaining).

### 2026-08-24, iteration 2401 — [[characters/𢭏|𢭏]]

`radical: 手` reconfirmed correct — genuine listing (item 66) on `Lookup/Radicals/Radical 064.md`. `skip_number: 1-3-7` reconfirmed correct — genuine listing (item 40) on `Lookup/SKIP/SKIP-1/SKIP-1-3-7.md`. `mc_id: 3975` reconfirmed exact match (`CC 3000.md`: `3975. 擣`, citing the traditional glyph). `japanese: [TOU]` / `japanese_native: つく` reconfirmed correct and left unchanged — ja.Wiktionary 404'd for this rare character, so en.Wiktionary's two extra kun'yomi candidates (うつ, ふれる) can't be dual-confirmed and were correctly left unadded, consistent with this session's established fallback practice. `joyo_level: 表外字` (pre-existing, single-sourced) left unchanged. `pos: 事詞` reconfirmed correct. `korean: 도` reconfirmed correct.

**`vietnamese` bug found and fixed — was blank**: hvdic.thivien.net (sole authority) gives `đảo`; added.

**`graphemic_classification` bug found and fixed**: stored bare `壽` (the textbook phonetic per both sources), but `壽` has no independent vault page and is listed as an alias on `characters/寿.md`'s own `aliases` field; per this vault's established alias-citation convention, corrected to cite the parent page `寿`.

**`aliases` bug found and fixed — missing simplified variant**: stored `[擣]` (traditional) only; both en.Wiktionary and zh.Wiktionary independently confirm `捣` as the modern mainland-standard simplified form, with neither having an independent vault page; added.

**Three missing lookup-page cross-references found and fixed**: genuinely absent from all six `Old HSK N.md` files (confirming `hsk_level: 無`) but missing from `Lookup/HSK/HSK No.md` itself — added. Missing from `Lookup/Korean/Korean Name ㄷ.md`'s `### 도` subsection despite a matching `korean: 도` — added (left the pre-existing unrelated `[[搗]]` stub in that list untouched — different phonetic series, not proven to be this same character). Missing from `Lookup/Japanese/Hyōgai.md`'s `## List` despite the page's own `joyo_level: 表外字` — added as item 579.

Rebuilt the malformed `## Notes` (a stray non-standard "added to the Korean name list" bullet, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 萬 (8693; 102 characters remaining).

### 2026-08-24, iteration 2402 — [[characters/萬|萬]]

`graphemic_classification: 象形` reconfirmed correct — dual-source confirmed pictograph (originally depicted a scorpion, later phonetically borrowed for "ten-thousand") via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 60) on `Lookup/Radicals/Radical 140.md`. `skip_number: 2-3-9` reconfirmed correct — genuine listing (item 17) on `Lookup/SKIP/SKIP-2/SKIP-2-3-9.md`. `stroke_count: 12` reconfirmed correct despite a WebFetch-summary artifact miscounting it as 13 — the vault's own internal `Lookup/Stroke/Stroke 12.md` and `Lookup/SKIP/SKIP-2/SKIP-2-3-9.md` both independently and consistently corroborate 12, taken as authoritative over the summarization glitch. `mc_id: 106` reconfirmed exact match (`CC 0000.md`: `106. 萬`). `vietnamese: [muôn, mại, vàn, vạn]` reconfirmed complete and exact against hvdic.thivien.net (one Âm Hán Việt `vạn` + three Âm Nôm `mại, muôn, vàn`). `hsk_level: "1"` reconfirmed correct — genuine numbered entry (item 522) on `Lookup/HSK/HSK Beginner.md` (not the `Old HSK N.md` files, which only carry non-genuine colon-count mentions for this character). `stand_in: 萬物` reconfirmed correct — sole citer, the word's own independent page.

**Major `aliases` bug found and fixed — 万 has independent life, not a true alias**: stored `aliases: [万]`, but `characters/万.md` is itself a fully independent, already-perfected page (its own `danayo_id`, extensive `## Words`/`## Chengyu` sections) — its own Notes explicitly documents "[[萬]] is retained as a 名字 for anti-falsification purposes," i.e. 萬 is the 大字 (formal/anti-forgery) numeral form of 万, structurally analogous to how [[characters/漆 (char)|漆 (char)]] relates to [[characters/七 (char)|七 (char)]] (a functional pairing, not an orthographic-variant/alias relationship). Per this vault's "alias = parent form, never used independently" policy, removed `万` from `aliases` entirely.

**`joyo_level` bug found and fixed**: stored `表外字`, but ja.Wiktionary explicitly classifies 萬 as `人名用漢字` (Jinmeiyō kanji) — corroborated by its listed Nanori readings (かず, ま, ゆる, よし), which only Jōyō/Jinmeiyō characters carry — corrected to `日本人名用漢字` and added as item 481 to `Lookup/Japanese/Jinmeiyō.md`'s `## Done` list (not previously listed on either Jinmeiyō or Hyōgai).

**`pos` filled — was blank**: filled as `数詞` (numeral), matching sibling large-numeral characters [[千]]/[[億]] rather than generic `名詞`.

Rebuilt the malformed `# Notes` (two bare unlinked CC wikilinks, a single bare `## Words`-less bullet) into the standard `## Notes` four-bullet format (citing `HSK Beginner` and `Korean MS` in place of the usual `HSK No`/`Korean Name X`, matching this character's own actual corroborating lookup pages) plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 躬 (8694; 101 characters remaining).

### 2026-08-24, iteration 2403 — [[characters/躬|躬]]

`graphemic_classification: 弓` (dual-source confirmed 形声, semantic 身 + phonetic 弓, PST \*guŋ) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 身` reconfirmed correct — genuine listing (item 2) on `Lookup/Radicals/Radical 158.md`. `skip_number: 1-7-3` reconfirmed correct — genuine listing (item 11) on `Lookup/SKIP/SKIP-1/SKIP-1-7-3.md`. `mc_id: 1156` reconfirmed exact match (`CC 1000.md`: `1156. 躬`). `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 51, corroborated by ja.Wiktionary's own 表外漢字 classification. `vietnamese: [cung, còng]` reconfirmed complete and exact against hvdic.thivien.net. `korean: 궁` / `korean_native: 몸` reconfirmed correct, already cross-listed on `Lookup/Korean/Korean Name ㄱ.md`.

**`hsk_level` bug found and fixed**: stored `4`, but `Old HSK 4.md`'s only mention is a non-genuine colon-count entry (`[[躬]]: 1`); the genuine plain-numbered entry (`281.  [[躬]]`) is on `Old HSK 6.md`. Corrected to `6`.

**`stand_in` bug found and fixed — real citer sitting unrecognized in the page's own Words section**: stored `名専字`, but the page's own (malformed) `## Words` section already listed [[鞠躬]], which genuinely cites 躬 in its own `characters:` field. Corrected to `鞠躬`.

**`japanese`/`japanese_native` bugs found and fixed — incomplete on both sides**: `japanese` stored `[KYUU]` (kan-on only); both en.Wiktionary and ja.Wiktionary independently confirm two additional go-on readings, `ク`/`クウ` (KU/KUU); added. `japanese_native` stored `み` only; both sources also independently confirm `みずから` (MIZUKARA); added.

**`aliases` bug found and fixed — key was entirely absent**: both en.Wiktionary and zh.Wiktionary confirm `躳` as a genuine variant form with no independent vault page; added.

**`pos` filled — was blank**: filled as `名詞`.

Rebuilt the malformed `## Notes` (two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard four-bullet format, and added the missing stand-in note to `## Words`. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 榴 (8695; 100 characters remaining).

### 2026-08-24, iteration 2404 — [[characters/榴|榴]]

`radical: 木` reconfirmed correct — genuine listing (item 128) on `Lookup/Radicals/Radical 075.md`. `skip_number: 1-4-10` reconfirmed correct — genuine listing (item 5) on `Lookup/SKIP/SKIP-1/SKIP-1-4-10.md`. `mc_id: 6340` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 257, corroborated by ja.Wiktionary's own 表外漢字 classification (and explicit "not on Jōyō or Jinmeiyō" statement). `japanese_native: ざくろ` reconfirmed correct and complete. `korean: 류` reconfirmed correct, already cross-listed on `Lookup/Korean/Korean Name ㄹ.md`. `stand_in: 石榴` reconfirmed correct — genuine citer, the word's own independent page.

**`hsk_level` bug found and fixed**: stored `4`, but `Old HSK 4.md`'s only mention is a non-genuine colon-count entry (`[[榴]]: 2`); genuinely absent from all six `Old HSK N.md` files under a genuine plain-numbered entry. Corrected to `無` and added to `Lookup/HSK/HSK No.md`.

**`graphemic_classification` bug found and fixed**: stored bare `畱` (an archaic form), but both en.Wiktionary and zh.Wiktionary name the true phonetic component as `留`, which has its own independent vault page (`characters/留 (char).md`) whose own `aliases` field hosts `畱`; per this vault's established alias-citation convention, corrected to cite the parent page `留 (char)` directly.

**`aliases`, `japanese`, `vietnamese` bugs found and fixed — all three incomplete**: `aliases` was blank; both en.Wiktionary and zh.Wiktionary confirm `橊` as a genuine variant with no independent vault page; added. `japanese` stored `[RYUU]` (kan-on only); both sources also independently confirm go-on `ル` (RU); added. `vietnamese` stored `[lựu]` only; hvdic.thivien.net (sole authority) also gives Hán Việt `lưu`; added.

**Second `## Words` citation found and moved**: a bare unlinked "high explosives" bullet (榴弾) was sitting in the malformed Notes instead of a `## Words` section; verified `words/榴弾.md` genuinely cites 榴 in its `characters:` frontmatter; moved into `## Words` alongside the stand-in `石榴`.

**`pos` filled — was blank**: filled as `名詞`.

Rebuilt the malformed `## Notes` into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 芡 (8696; 99 characters remaining).

### 2026-08-24, iteration 2405 — [[characters/芡|芡]]

`graphemic_classification: 欠` (dual-source confirmed 形声, semantic 艸 + phonetic 欠, OC \*ɡromʔ) reconfirmed correct via en.Wiktionary and zh.Wiktionary; 欠 has its own independent vault page (`characters/欠 (char).md`), correctly cited. `radical: 艸` reconfirmed correct — genuine listing (item 4) on `Lookup/Radicals/Radical 140.md`. `skip_number: 2-3-4` reconfirmed correct — genuine listing (item 19) on `Lookup/SKIP/SKIP-2/SKIP-2-3-4.md`. `mc_id: 6833` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [KEN, GEN]` reconfirmed complete — both en.Wiktionary and the corresponding go-on/kan-on pair match exactly. `vietnamese: [khiếm]` reconfirmed complete and exact against hvdic.thivien.net (identical Hán Việt and Nôm). `stand_in: 名専字` reconfirmed correct — zero hits for 芡 anywhere in `words/`. `aliases` (blank) reconfirmed correct — en.Wiktionary's two listed derived characters (𡞁, 𥟕) are unrelated derivative forms, not variants of 芡 itself, consistent with this session's exclusion practice.

**Five blank fields filled**: `pos` filled as `名詞`. `korean_native` filled as `가시연` (the plant's native Korean name, confirmed via ko.Wiktionary's own 訓 gloss, matching `korean: 검`). `joyo_level` filled as `表外字` — ja.Wiktionary 404'd for this rare character, so this relies on en.Wiktionary's single-sourced "Hyōgai kanji" classification per this session's established fallback practice; added as item 580 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`. `hanmun_edu_level` filled as `名`, matching `grade_level: 名`.

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㄱ.md`'s `### 검` subsection despite the matching `korean: 검`; added.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 匡 (8697; 98 characters remaining).

### 2026-08-24, iteration 2406 — [[characters/匡|匡]]

`graphemic_classification: 王` (dual-source confirmed 形声, semantic 匚 + phonetic [[王 (char)|王]] — originally a square basket, extended to "correct, rectify") reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 匚` reconfirmed correct — genuine listing (item 1) on `Lookup/Radicals/Radical 022.md`. `skip_number: 3-2-4` reconfirmed correct — genuine listing (item 3) on `Lookup/SKIP/SKIP-3/SKIP-3-2-4.md`. `mc_id: 1212` reconfirmed exact match (`CC 1000.md`: `1212. 匡`). `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 452, corroborated by ja.Wiktionary. `vietnamese: [khuôn, khuông]` reconfirmed complete and exact against hvdic.thivien.net (one Hán Việt + two Nôm). `stand_in: 名専字` reconfirmed correct — zero hits for 匡 anywhere in `words/`. `aliases` (blank) reconfirmed correct — en.Wiktionary's variant 匩 and its "simplified form of 筐/框/眶/誆/哐" claims aren't corroborated by zh.Wiktionary, and none of those targets has an independent vault page relationship to test against; left unadded absent stronger corroboration. Already correctly cross-listed on `Lookup/Korean/Korean Name ㄱ.md`.

**`japanese` bug found and fixed — go-on misspelled**: stored `[KYOU, OU]`; both en.Wiktionary and ja.Wiktionary confirm the go-on reading is actually `コウ` (KOU), not `OU` (a dropped-K typo). Corrected to `[KOU, KYOU]`.

**`japanese_native` bug found and fixed — truncated and incomplete**: stored `すく` (SUKU) only, a truncation of the genuine kun'yomi `すくう` (SUKUU); both sources also independently confirm a second kun'yomi, `ただす` (TADASU), previously missing entirely. Corrected to `[ただす, すくう]`.

**`pos`, `hsk_level` filled — both were blank**: `pos` filled as `性詞`, matching the precedent set by [[characters/正 (char)|正 (char)]]'s own "correct" sense. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 擅 (8698; 97 characters remaining).

### 2026-08-24, iteration 2407 — [[characters/擅|擅]]

`graphemic_classification: 亶` (dual-source confirmed 形声, semantic 手 + phonetic [[亶]], OC \*dans) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 手` reconfirmed correct — genuine listing (item 122) on `Lookup/Radicals/Radical 064.md`. `skip_number: 1-3-13` reconfirmed correct — genuine listing (item 14) on `Lookup/SKIP/SKIP-1/SKIP-1-3-13.md`. `mc_id: 1257` reconfirmed exact match (`CC 1000.md`: `1257. 擅`). `korean: 천` reconfirmed correct despite diverging from the page's own `諺文: 선`/`羅馬字: sen` — matches the real Sino-Korean reading (ko.Wiktionary), the 諺文/羅馬字 divergence being this vault's own internal conlang-spelling system (same pattern seen on 扁/蒐's pages), already cross-listed on `Lookup/Korean/Korean Name ㅊ.md`. `vietnamese: [chen, thiện]` reconfirmed complete and exact against hvdic.thivien.net. `japanese_native: ほしいまま` reconfirmed correct and complete. `stand_in: 名専字` reconfirmed correct — zero hits for 擅 anywhere in `words/`. `aliases` (blank) reconfirmed correct — en.Wiktionary's listed "simplified form" and "alternative spellings" (𢩳, 縦, 恣, 肆) are unrelated/uncorroborated by zh.Wiktionary, consistent with this session's exclusion practice.

**`hsk_level` bug found and fixed**: stored `4`, but `Old HSK 4.md`'s only mention is a non-genuine colon-count entry (`[[擅]]: 3`); the genuine plain-numbered entry (`249.  [[擅]]`) is on `Old HSK 6.md`. Corrected to `6`.

**`japanese` bug found and fixed — missing go-on reading**: stored `[SEN]` (kan-on only); both en.Wiktionary and ja.Wiktionary independently confirm a go-on reading, `ゼン` (ZEN), previously missing; added.

**`pos`, `joyo_level`, `korean_native` filled — all three were blank**: `pos` filled as `動詞`. `joyo_level` filled as `表外字` — dual-source confirmed (en.Wiktionary and ja.Wiktionary); added as item 581 to `Lookup/Japanese/Hyōgai.md`. `korean_native` filled as `멋대로 할`, confirmed via ko.Wiktionary's own 訓 gloss, matching `korean: 천`.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 奢 (8699; 96 characters remaining).

### 2026-08-24, iteration 2408 — [[characters/奢|奢]]

`graphemic_classification: 者` (dual-source confirmed 形声 ⿱大者, semantic 大 + phonetic [[者 (char)|者]]) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 大` reconfirmed correct — genuine listing (item 19) on `Lookup/Radicals/Radical 037.md`. `skip_number: 2-3-9` reconfirmed correct — genuine listing (item 4) on `Lookup/SKIP/SKIP-2/SKIP-2-3-9.md`. `mc_id: 1262` reconfirmed exact match (`CC 1000.md`: `1262. 奢`). `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 141, corroborated by ja.Wiktionary. `japanese: [SHA]` reconfirmed correct and complete — both go-on and kan-on are しゃ. `vietnamese: [xa]` reconfirmed complete and exact against hvdic.thivien.net. `korean: 사` reconfirmed correct, already cross-listed on `Lookup/Korean/Korean Name ㅅ.md`. `stand_in: 名専字` reconfirmed correct — zero hits for 奢 anywhere in `words/`.

**`hsk_level` bug found and fixed**: stored `4`, but `Old HSK 4.md`'s only mention is a non-genuine colon-count entry (`[[奢]]: 1`); the genuine plain-numbered entry (`665.  [[奢]]`) is on `Old HSK 6.md`. Corrected to `6`.

**`japanese_native` bug found and fixed — truncated**: stored `おご`, a truncation of the genuine dual-confirmed kun'yomi `おごる` (OGORU, "to be extravagant"). Corrected to the full form.

**`aliases` bug found and fixed — was blank**: both en.Wiktionary and zh.Wiktionary confirm `奓` as a genuine variant form with no independent vault page; added.

**`pos` filled — was blank**: filled as `性詞`.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 綏 (8700; 95 characters remaining).

### 2026-08-24, iteration 2409 — [[characters/綏|綏]]

`graphemic_classification: 妥` (dual-source confirmed 形声, semantic 糸 + phonetic 妥, OC \*s.nuj) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 糸` reconfirmed correct — genuine listing (item 31) on `Lookup/Radicals/Radical 120.md`. `skip_number: 1-6-7` reconfirmed correct — genuine listing (item 4) on `Lookup/SKIP/SKIP-1/SKIP-1-6-7.md`. `japanese: [SUI, TA]` reconfirmed — ja.Wiktionary confirms only スイ (dual-confirmed go-on/kan-on), but `TA` is a pre-existing single-sourced (en.Wiktionary-only) value, kept per this session's established "keep pre-existing single-sourced values" policy. `aliases: [绥]` reconfirmed correct (simplified form).

**Major cross-page bug found and fixed — 綬 is a distinct character, not this page's alias**: stored `aliases: [綬, 绥]`, but both en.Wiktionary and zh.Wiktionary confirm 綬 ("seal-ribbon, cord," shòu/シュ) is an entirely separate, unrelated character with no relationship to 綏 — it has no independent vault page yet, and had been mistakenly folded into 綏's identity across four places: this page's own `aliases` (removed), this page's own `mc_id` (was `1274`, which `CC 1000.md` actually assigns to `1274. 綬`, not 綏 — corrected to 綏's own genuine exact-match rank `1686. 綏`), a stray `[綬](characters/綏.md)` entry on `Lookup/Korean/Korean Name ㅅ.md` pointing the wrong glyph at this page (removed), and a `- 綬 --> 綏` line in `Lookup/Japanese/Hyōgai.md`'s `## Redirects` section (removed). 綬 having no vault page of its own is flagged here as a known gap for a future iteration, not created in this one (out of this iteration's one-character scope).

**`stand_in` bug found and fixed — real citer sitting unrecognized**: stored `名専字`, but [[綏靖]] genuinely cites 綏 in its own `characters:` field (the other apparent hit, [[水晶]], is a false-positive prose mention). Corrected to `綏靖` and added a `## Words` section.

**`vietnamese` bug found and fixed — badly incomplete**: stored `[nối, tuy]`; hvdic.thivien.net (sole authority) also gives Hán Việt `nhuy` and `thoả`, both missing. Corrected to the full union `[nhuy, thoả, tuy, nối]`.

**`japanese_native` bug found and fixed — truncated**: stored `やす`, a truncation of the dual-confirmed kun'yomi `やすい` (YASUI). Corrected.

**`pos`, `joyo_level`, `hsk_level` filled — all three were blank**: `pos` filled as `動詞`. `joyo_level` filled as `表外字` (dual-source confirmed); added as item 582 to `Lookup/Japanese/Hyōgai.md`'s `## List`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 逾 (8701; 94 characters remaining).

### 2026-08-24, iteration 2410 — [[characters/逾|逾]]

`graphemic_classification: 兪` (dual-source confirmed 形声, semantic 辵 + phonetic [[兪 (char)|兪]], OC \*lo) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 辵` reconfirmed correct — genuine listing (item 48) on `Lookup/Radicals/Radical 162.md`. `skip_number: 3-4-9` reconfirmed correct — genuine listing (item 3) on `Lookup/SKIP/SKIP-3/SKIP-3-4-9.md`. `japanese: [YU]` reconfirmed correct and complete — both go-on and kan-on are ゆ. `stand_in: 名専字` reconfirmed correct — the sole grep hit, [[words/兪|兪]], is a false-positive prose mention (its own `characters:` field cites 兪 (char), not 逾). `aliases: [踰]` reconfirmed correct — zh.Wiktionary explicitly confirms 踰 as a genuine 異體 (variant) of this character. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅇ.md` (both 逾 and 踰 entries).

**`mc_id` bug found and fixed — cited the alias's rank, not this character's own**: stored `1322`, but `CC 1000.md`'s `1322.` entry is actually `踰` (this page's own alias), not `逾` itself; 逾 has its own genuine, separate exact-match entry (`1993. 逾`). Corrected to `1993`.

**`aliases` bug found and fixed — 窬 is a cognate, not a variant**: stored `[踰, 窬]`; zh.Wiktionary explicitly confirms 踰 as a genuine variant but explicitly denies the same for 窬, describing it only as "a separate, etymologically-related character sharing the same Old Chinese root" — not a true orthographic variant. Removed 窬.

**`vietnamese` and `japanese_native` bugs found and fixed — both incomplete**: `vietnamese` stored `[du, gió]`; hvdic.thivien.net (sole authority) also gives Hán Việt `dũ`, missing. Added. `japanese_native` stored `いよいよ` only; both en.Wiktionary and ja.Wiktionary also independently confirm kun'yomi `こえる` (KOERU), previously missing. Added.

**`pos`, `joyo_level`, `hsk_level` filled — all three were blank**: `pos` filled as `動詞`. `joyo_level` filled as `表外字` (dual-source confirmed); added as item 583 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 霍 (8702; 93 characters remaining).

### 2026-08-24, iteration 2411 — [[characters/霍|霍]]

`graphemic_classification: 會意` (dual-source confirmed ideogrammic compound ⿱雨隹, birds startled/scattering by rain) reconfirmed correct via en.Wiktionary; zh.Wiktionary's own restatement was garbled/self-contradictory (calling it 形声 with the character itself as its own phonetic component), treated as a WebFetch summarization artifact rather than a genuine conflicting source, per this session's practice of trusting the internally-consistent account. `radical: 雨` reconfirmed correct — genuine listing (item 13) on `Lookup/Radicals/Radical 173.md`. `skip_number: 2-8-8` reconfirmed correct — genuine listing (item 2) on `Lookup/SKIP/SKIP-2/SKIP-2-8-8.md`. `mc_id: 1327` reconfirmed exact match (`CC 1000.md`: `1327. 霍`). `japanese: [KAKU]` reconfirmed correct and complete. `japanese_native: にわか` reconfirmed correct and complete — a second candidate from ja.Wiktionary alone (はやい) wasn't corroborated by en.Wiktionary, left unadded. `korean: 곽` reconfirmed correct, already cross-listed on `Lookup/Korean/Korean Name ㄱ.md`. `stand_in: 名専字` reconfirmed correct — zero hits for 霍 anywhere in `words/`. `aliases: [靃]` reconfirmed correct — zh.Wiktionary explicit 異體字 confirmation.

**`hsk_level` bug found and fixed**: stored `4`, but `Old HSK 4.md`'s only mention is a non-genuine colon-count entry (`[[霍]]: 2`); genuinely absent from all six `Old HSK N.md` files under a genuine plain-numbered entry. Corrected to `無` and added to `Lookup/HSK/HSK No.md`.

**`vietnamese` bug found and fixed — incomplete**: stored `[hoác, hoắc]`; hvdic.thivien.net (sole authority) also gives Hán Việt `quắc`, missing. Added.

**Missing `Hyōgai.md` entry found and fixed**: `joyo_level: 表外字` (pre-existing, reconfirmed correct) was missing from `Lookup/Japanese/Hyōgai.md`'s `## List`; added as item 584.

**Broken CC-finals link path fixed**: the pre-existing Notes had `[[../lookup/CC/finals/韻 鈬合]]` — a malformed relative path with a lowercase directory segment; rebuilt correctly.

**`pos` filled — was blank**: filled as `性詞`.

Rebuilt the malformed `# Notes` (wrong heading level, one broken link, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 佞 (8703; 92 characters remaining).

### 2026-08-24, iteration 2412 — [[characters/佞|佞]]

`graphemic_classification: 仁` (dual-source confirmed 形声, semantic 女 + phonetic [[仁]], OC \*neːŋs) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 人` reconfirmed correct — genuine listing (item 51) on `Lookup/Radicals/Radical 009.md`. `skip_number: 1-2-5` reconfirmed correct — genuine listing (item 20) on `Lookup/SKIP/SKIP-1/SKIP-1-2-5.md`. `mc_id: 1360` reconfirmed exact match (`CC 1000.md`: `1360. 佞`). `hsk_level: 無` reconfirmed correct, already present on `Lookup/HSK/HSK No.md`. `vietnamese: [nính, nạnh, nến, nịnh]` reconfirmed complete and exact against hvdic.thivien.net (one Hán Việt + three Nôm). `korean: 녕` reconfirmed correct, already cross-listed on `Lookup/Korean/Korean Name ㄴ.md`. `stand_in: 名専字` reconfirmed correct — zero hits for 佞 anywhere in `words/`. `aliases: [侫]` reconfirmed correct.

**`japanese` bug found and fixed — missing go-on reading**: stored `[NEI, DEI]`; both en.Wiktionary and ja.Wiktionary independently confirm a go-on reading, `ニョウ` (NYOU), previously missing; added. The pre-existing `DEI` (kan-on, en.Wiktionary-only) was kept per this session's "keep pre-existing single-sourced values" policy despite ja.Wiktionary not corroborating it.

**`japanese_native` bug found and fixed — badly truncated**: stored `おもね` (a truncation missing even its own final る); both sources independently confirm all three genuine kun'yomi in full — `おもねる`, `へつらう`, `よこしま` — only the first of which was even partially present. Corrected to the full set of three.

**Missing `Hyōgai.md` entry found and fixed**: `joyo_level: 表外字` (pre-existing, reconfirmed correct) was missing from `Lookup/Japanese/Hyōgai.md`'s `## List`; added as item 585.

**`pos` filled — was blank**: filled as `名詞`.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 瑯 (8704; 91 characters remaining).

### 2026-08-24, iteration 2413 — [[characters/瑯|瑯]]

`radical: 玉` reconfirmed correct — genuine listing (item 32) on `Lookup/Radicals/Radical 096.md`. `skip_number: 1-4-10` reconfirmed correct — genuine listing (item 12) on `Lookup/SKIP/SKIP-1/SKIP-1-4-10.md`. `japanese: [ROU]` / `japanese_native: ø` reconfirmed correct and complete via ja.Wiktionary (no kun'yomi). `vietnamese: [lang]` reconfirmed complete and exact against hvdic.thivien.net. `aliases: [琅]` reconfirmed correct — zh.Wiktionary's explicit "此字是「琅」的異體字" statement. Already correctly cross-listed on `Lookup/Korean/Korean Name ㄹ.md` (both 瑯 and its alias 琅 entries).

**`graphemic_classification` bug found and fixed**: stored `良`, but both en.Wiktionary and zh.Wiktionary explicitly name the true phonetic component as `郎` (which has its own independent vault page, `characters/郎.md`), not `良`. Corrected.

**`mc_id` off-by-one bug found and fixed**: stored `3262`, which `CC 3000.md` actually assigns to `貰`; 瑯's own genuine exact-match entry is `3263. 瑯`. Corrected.

**`stand_in` bug found and fixed — real citer sitting unrecognized in the page's own malformed Notes**: stored `名専字`, but a bare bullet already sitting in the page's Notes cited [[琺瑯]], which genuinely lists 瑯 in its own `characters:` field. Corrected to `琺瑯` and added a proper `## Words` section.

**`pos`, `joyo_level`, `hsk_level` filled — all three were blank**: `pos` filled as `名詞`. `joyo_level` filled as `表外字` (dual-source confirmed); added as item 586 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, the Words citation misplaced inside Notes) into the standard `## Notes` four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 棘 (8706; 90 characters remaining).

### 2026-08-24, iteration 2414 — [[characters/棘|棘]]

`graphemic_classification: 會意` (⿰朿朿, two thorn pictographs) reconfirmed — neither en.Wiktionary nor zh.Wiktionary explicitly confirms or contradicts this specific classification for this page, kept as pre-existing. `radical: 木` reconfirmed correct — genuine listing (item 98) on `Lookup/Radicals/Radical 075.md`. `skip_number: 1-6-6` reconfirmed correct — genuine listing (item 3) on `Lookup/SKIP/SKIP-1/SKIP-1-6-6.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 60, corroborated by ja.Wiktionary. `vietnamese: [cức, gấc]` reconfirmed complete and exact against hvdic.thivien.net. `korean: 극` reconfirmed correct, already cross-listed on `Lookup/Korean/Korean Name ㄱ.md`. `stand_in: 荊棘` reconfirmed correct — genuine citer, the word's own independent page. `aliases` (blank) reconfirmed correct — en.Wiktionary's listed variants (撠, 𣡍, 𭫼, 𣗥, 𬃷, and an explicitly-flagged "erroneous variant" 𪲸) are all obscure/unencodable or explicitly disclaimed, consistent with this session's exclusion practice.

**`mc_id` off-by-one bug found and fixed**: stored `1481`, which `CC 1000.md` actually assigns to `敞`; 棘's own genuine exact-match entry is `1482. 棘`. Corrected.

**`japanese`/`japanese_native` bugs found and fixed — both incomplete**: `japanese` stored `[KYOKU]` (kan-on only); both en.Wiktionary and ja.Wiktionary independently confirm a go-on reading, `コク` (KOKU), previously missing; added. `japanese_native` stored `いばら` only; both sources also independently confirm kun'yomi `とげ` (TOGE); added (two further single-sourced candidates — en.Wiktionary's いら and ja.Wiktionary's ほこ/おどろ — weren't dual-confirmed and were left out).

**`pos`, `hsk_level` filled — both were blank**: `pos` filled as `名詞`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`.

Rebuilt the malformed `## Notes` (two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 蓬 (8707; 89 characters remaining).

### 2026-08-24, iteration 2415 — [[characters/蓬|蓬]]

`graphemic_classification: 逢` (dual-source confirmed 形声, semantic 艸 + phonetic 逢, OC \*boːŋ) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 78) on `Lookup/Radicals/Radical 140.md`. `skip_number: 2-3-10` reconfirmed correct — genuine listing (item 25) on `Lookup/SKIP/SKIP-2/SKIP-2-3-10.md`. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine at `Lookup/Japanese/Jinmeiyō.md` item 291, corroborated by ja.Wiktionary. `pos: 事詞` reconfirmed correct. `stand_in: 蓬藁` reconfirmed correct — both [[蓬藁]] and the page's second `## Words` entry [[蓬莱]] genuinely cite 蓬 in their own `characters:` fields. `aliases` (blank) reconfirmed correct — en.Wiktionary's listed variants (莑, 蘕, 𦿪) are all obscure/unencodable, consistent with this session's exclusion practice. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅂ.md`.

**`hsk_level` bug found and fixed**: stored `6`, but no genuine plain-numbered entry exists anywhere across all six `Old HSK N.md` files (only non-genuine colon-count mentions in HSK3 and HSK4); `Lookup/HSK/HSK No.md` already correctly listed 蓬 as confirmed-absent, which the character's own field simply hadn't been updated to match. Corrected to `無`.

**`mc_id` off-by-one bug found and fixed**: stored `1980`, which `CC 1000.md` actually assigns to `彰`; 蓬's own genuine exact-match entry is `1981. 蓬`. Corrected.

**`vietnamese` bug found and fixed — incomplete**: stored six of the eight readings hvdic.thivien.net (sole authority) actually attests; `bong` and `bùng` (both Nôm) were missing. Added.

**`japanese` bug found and fixed — missing go-on reading**: stored `[HOU]` (kan-on only); both en.Wiktionary and ja.Wiktionary independently confirm a go-on reading, `ブ` (BU), previously missing; added. Three further en.Wiktionary-only kun'yomi candidates (えもぎ, ほおける/ほける/ほほける) weren't corroborated by ja.Wiktionary and were correctly left unadded.

**Broken relative-path Words link fixed**: `[[../words/蓬藁]]` used a relative-path prefix inconsistent with this vault's plain-filename wikilink convention; corrected to `[[蓬藁]]`, and added the missing stand-in note.

Rebuilt the malformed `# Notes` (wrong heading level, one bare unlinked CC wikilink orphaned below the Words section, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 聒 (8708; 88 characters remaining).

### 2026-08-24, iteration 2416 — [[characters/聒|聒]]

`graphemic_classification: 舌` (dual-source confirmed 形声, semantic 耳 + phonetic [[舌 (char)|舌]]) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 耳` reconfirmed correct — genuine listing (item 6) on `Lookup/Radicals/Radical 128.md`. `skip_number: 1-6-6` reconfirmed correct — genuine listing (item 15) on `Lookup/SKIP/SKIP-1/SKIP-1-6-6.md`. `mc_id: 6005` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [KATSU]` reconfirmed correct and complete — matches ja.Wiktionary's kan-on カツ exactly; a further go-on candidate from ja.Wiktionary alone (カチ) wasn't corroborated by en.Wiktionary and was left unadded. `vietnamese: [quát]` reconfirmed complete and exact against hvdic.thivien.net. `stand_in: 名専字` reconfirmed correct — the sole grep hit, [[words/舌|舌]], is a false-positive prose mention (its own `characters:` field cites 舌 (char), not 聒).

**`japanese_native` bug found and fixed — truncated**: stored `かまびす`, a truncation of the dual-confirmed kun'yomi `かまびすしい` (KAMABISUSHII, "noisy, clamorous"). Corrected.

**`pos`, `joyo_level`, `hsk_level`, `hanmun_edu_level` filled — all four were blank**: `pos` filled as `性詞`. `joyo_level` filled as `表外字` (dual-source confirmed); added as item 587 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`. `hanmun_edu_level` filled as `名`, matching `grade_level: 名`.

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㄱ.md`'s `### 괄` subsection despite the matching `korean: 괄`; added.

Rebuilt the malformed `# Notes` (wrong heading level, a stray unexplained "V pronunciation" placeholder note, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 叵 (8709; 87 characters remaining).

### 2026-08-24, iteration 2417 — [[characters/叵|叵]]

`graphemic_classification: 可` (dual-source confirmed: a mirror image of [[可 (char)|可]], en.Wiktionary "形缩" contraction / zh.Wiktionary 會意) reconfirmed correct via both sources. `radical: 口` reconfirmed correct — genuine listing (item 14) on `Lookup/Radicals/Radical 030.md`. `skip_number: 3-2-3` reconfirmed correct — genuine listing (item 6) on `Lookup/SKIP/SKIP-3/SKIP-3-2-3.md`. `mc_id: 7324` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [HA]` reconfirmed correct and complete — matches ja.Wiktionary's go-on/kan-on は exactly. `vietnamese: [phả]` reconfirmed complete and exact against hvdic.thivien.net (sole reading in both Hán Việt and Nôm). `stand_in: 名専字` reconfirmed correct — zero hits for 叵 anywhere in `words/`.

**`aliases` bug found and fixed — 笸 is a phonetically-related cognate, not a genuine variant**: stored `[尀, 笸]`; en.Wiktionary explicitly lists 尀 as a genuine variant form, but only lists 笸 under "Derived characters" without variant status, and zh.Wiktionary confirms 笸 merely shares 叵's phonetic series (`系列#1418`) without ever calling it a variant — it's a distinct character (a bamboo-radical word for "wicker basket/winnowing tray") with no independent vault page. Removed 笸, following the same false-alias pattern already caught this session on 逾/窬 and 綏/綬.

**`japanese_native` bug found and fixed — truncated**: stored `でき`, a truncation of the single-sourced (en.Wiktionary-only; ja.Wiktionary lists no kun'yomi at all) candidate `できない` (DEKINAI, "cannot"); kept as pre-existing single-sourced value per established policy, but restored to its full, correctly-truncated form.

**`pos`, `joyo_level`, `hsk_level`, `hanmun_edu_level` filled — all four were blank**: `pos` filled as `性詞`. `joyo_level` filled as `表外字` (dual-source confirmed); added as item 588 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`. `hanmun_edu_level` filled as `名`, matching `grade_level: 名`.

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㅍ.md`'s `### 파` subsection despite the matching `korean: 파`; added.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 葩 (8710; 86 characters remaining).

### 2026-08-24, iteration 2418 — [[characters/葩|葩]]

`graphemic_classification: 巴` investigated and reconfirmed correct despite a source conflict — zh.Wiktionary explicitly names 巴 as the phonetic component (matching the stored value), while en.Wiktionary alone names 皅 instead (itself this page's own alias); kept 巴 per the more explicit, unambiguous source. `radical: 艸` reconfirmed correct — genuine listing (item 86) on `Lookup/Radicals/Radical 140.md`. `skip_number: 2-6-9` reconfirmed correct — genuine listing (item 7) on `Lookup/SKIP/SKIP-2/SKIP-2-6-9.md`. `mc_id: 5287` reconfirmed as trusted long-tail (>4000, not cross-checked per policy — no `CC 4000.md`+ file exists in this vault). `japanese_native: はな` reconfirmed correct and complete. `vietnamese: [ba, hoa, pha]` reconfirmed complete and exact against hvdic.thivien.net. `stand_in: 名専字` reconfirmed correct — zero hits for 葩 anywhere in `words/`.

**`japanese` bug found and fixed — missing go-on reading**: stored `[HA]` (kan-on only); both en.Wiktionary and ja.Wiktionary independently confirm a go-on reading, `ヘ` (HE), previously missing; added.

**`aliases` bug found and fixed — incomplete, and one false candidate correctly excluded**: stored `[皅]` only; cross-referencing en.Wiktionary's variant list (皅, 苩, 䔤, 𦺂) against zh.Wiktionary's (皅, 芭, 苩) found `苩` dual-confirmed by both with no independent vault page — added. `芭` (zh.Wiktionary-only) was correctly left out regardless, since it already has its own robust independent page (`characters/芭.md`) and fails the alias test.

**`pos`, `joyo_level`, `hsk_level`, `hanmun_edu_level` filled — all four were blank**: `pos` filled as `名詞`. `joyo_level` filled as `表外字` — en.Wiktionary confirms Hyōgai status; ja.Wiktionary's own page exists but is a stub with no explicit classification, so this is effectively single-sourced, consistent with this session's established fallback practice; added as item 589 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`. `hanmun_edu_level` filled as `名`, matching `grade_level: 名`.

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㅍ.md`'s `### 파` subsection despite the matching `korean: 파`; added.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 彤 (8711; 85 characters remaining).

### 2026-08-24, iteration 2419 — [[characters/彤|彤]]

`radical: 彡` reconfirmed correct — genuine listing (item 2) on `Lookup/Radicals/Radical 059.md`. `skip_number: 1-4-3` reconfirmed correct — genuine listing (item 4) on `Lookup/SKIP/SKIP-1/SKIP-1-4-3.md`. `japanese: [TOU, ZU]` reconfirmed correct and complete — matches ja.Wiktionary's kan-on トウ/go-on ズ exactly. `vietnamese: [đồng]` reconfirmed complete and exact against hvdic.thivien.net. `stand_in: 名専字` reconfirmed correct — zero hits for 彤 anywhere in `words/`. `aliases: [浵]` reconfirmed correct. Already correctly cross-listed on `Lookup/Korean/Korean Name ㄷ.md`.

**`graphemic_classification` bug found and fixed — confused radical with phonetic**: stored `彡`, which is actually the character's own semantic radical (already correctly stored separately in `radical`); both en.Wiktionary and zh.Wiktionary explicitly identify the true phonetic component as `丹` (which has its own independent vault page). Corrected to `丹`.

**`mc_id` off-by-one bug found and fixed**: stored `2595`, which `CC 2000.md` actually assigns to `灼`; 彤's own genuine exact-match entry is `2596. 彤`. Corrected.

**`japanese_native` bug found and fixed — incomplete**: stored `あか` only; both en.Wiktionary and ja.Wiktionary also independently confirm kun'yomi `あかい` (AKAI); added (a third, ja.Wiktionary-only candidate あかぬり wasn't corroborated by en.Wiktionary and was left out).

**`pos`, `joyo_level`, `hsk_level` filled — all three were blank**: `pos` filled as `性詞`. `joyo_level` filled as `表外字` (dual-source confirmed); added as item 590 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 旻 (8712; 84 characters remaining).

### 2026-08-24, iteration 2420 — [[characters/旻|旻]]

`graphemic_classification: 文` investigated and reconfirmed correct despite a classification-type conflict — en.Wiktionary calls this 會意 while zh.Wiktionary calls it 形声 with phonetic 文, but both sources converge on citing 文 as the key non-radical component, so the stored citation itself needed no change. `radical: 日` reconfirmed correct — genuine listing (item 10) on `Lookup/Radicals/Radical 072.md`. `skip_number: 2-4-4` reconfirmed correct — genuine listing (item 6) on `Lookup/SKIP/SKIP-2/SKIP-2-4-4.md`. `japanese: [BIN, MIN]` reconfirmed correct and complete — matches ja.Wiktionary's kan-on ビン/go-on ミン exactly. `japanese_native: あきぞら` reconfirmed correct — the only kun'yomi corroborated by both sources; ja.Wiktionary's second candidate そら and en.Wiktionary's あきら were each single-sourced and correctly left unadded. `vietnamese: [mân]` reconfirmed complete and exact against hvdic.thivien.net. `hanmun_edu_level: 名` reconfirmed correct. `stand_in: 名専字` reconfirmed correct — zero hits for 旻 anywhere in `words/`. `aliases: [旼]` reconfirmed correct — kept as-is; 旼 has no independent vault page and this vault's own `Korean Name ㅁ.md` already treats it as a redirect to this same page, consistent with genuine alias status even though neither Wiktionary source explicitly confirms/denies variant status. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅁ.md` (both 旻 and 旼 entries).

**`joyo_level` investigated and filled as `表外字`** — ja.Wiktionary explicitly denies Jinmeiyō status ("not classified as Jinmeiyo... on this page") despite en.Wiktionary separately mentioning Nanori readings (あきら, ひ) that might suggest otherwise; trusted ja.Wiktionary's explicit, authoritative statement over the ambiguous Nanori mention. Field was blank.

**`mc_id` off-by-one bug found and fixed**: stored `3435`, which `CC 3000.md` actually assigns to `繳`; 旻's own genuine exact-match entry is `3546. 旻`. Corrected.

**`pos`, `hsk_level` filled — both were blank**: `pos` filled as `名詞`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 皀 (8713; 83 characters remaining).

### 2026-08-24, iteration 2421 — [[characters/皀|皀]]

`graphemic_classification: 象形` reconfirmed correct — dual-source confirmed pictograph (a bowl of rice on a stand) via en.Wiktionary and zh.Wiktionary. `radical: 白` reconfirmed correct — genuine listing (item 3) on `Lookup/Radicals/Radical 106.md`. `skip_number: 2-5-2` reconfirmed correct — genuine listing (item 7) on `Lookup/SKIP/SKIP-2/SKIP-2-5-2.md`. `mc_id: 5211` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [HYUU, KYUU, HYOKU]` reconfirmed and left unchanged — matches en.Wiktionary's readings exactly (ひゅう/きゅう/ひょく), and a separately-fetched ja.Wiktionary summary gave partially inconsistent/garbled results (a duplicated コウ reading) for this extremely obscure character; treated as a WebFetch-summarization artifact rather than a genuine correction, per this session's practice of trusting the internally-consistent account. `vietnamese: [tấp]` reconfirmed complete and exact against hvdic.thivien.net (sole Hán Việt reading, no Nôm section). `stand_in: 名専字` reconfirmed correct — both grep hits ([[words/卿|卿]], [[words/即位|即位]]) are false-positive prose mentions; neither cites 皀 in its own `characters:` field.

**`pos`, `joyo_level`, `hsk_level`, `hanmun_edu_level` filled — all four were blank**: `pos` filled as `名詞`. `joyo_level` filled as `表外字` (dual-source confirmed); added as item 592 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`. `hanmun_edu_level` filled as `名`, matching `grade_level: 名`.

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㅍ.md`'s `### 핍` subsection despite the matching `korean: 핍`; added.

Rebuilt the malformed `# Notes` (wrong heading level, a stray unexplained "sound pick" placeholder note, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 䎎 (8714; 82 characters remaining).

### 2026-08-24, iteration 2422 — [[characters/䎎|䎎]]

Extremely obscure CJK Extension A character with almost no documentation anywhere. `radical: 羽` reconfirmed correct — genuine listing (item 10) on `Lookup/Radicals/Radical 124.md`. `skip_number: 1-6-7` reconfirmed correct — genuine listing (item 10) on `Lookup/SKIP/SKIP-1/SKIP-1-6-7.md`. `mc_id: 0` reconfirmed correct — genuine sentinel, genuinely absent from all four `CC N000.md` files. `graphemic_classification: 耴` left unchanged — neither en.Wiktionary nor zh.Wiktionary explicitly names the phonetic component (both only describe the raw composition "羽 + 7 strokes"), but 耴 has its own independent vault page and the stroke count is consistent, so the pre-existing citation is plausible and uncontradicted. `japanese: [NOTSU]` and `joyo_level: 表外字` both left unchanged as pre-existing, unconfirmable-but-uncontradicted values — all three Wiktionary sources (en, zh; ja.Wiktionary 404'd) explicitly documented only radical composition, stroke count, and Mandarin/Cantonese readings, with no Japanese-reading or classification info at all; added the missing `joyo_level` entry as item 593 to `Lookup/Japanese/Hyōgai.md` for internal consistency with the pre-existing (uncontradicted) field value. `hanmun_edu_level: 無` reconfirmed as a genuine valid value (matches 132 other character pages using this same sentinel). `stand_in: 名専字` reconfirmed correct — zero hits for 䎎 anywhere in `words/`.

**`vietnamese` bug found and fixed — positively disconfirmed by the sole authority**: stored `[nạp]`, but hvdic.thivien.net (this vault's sole Vietnamese authority) explicitly states "Chưa có giải nghĩa theo âm Hán Việt" ("no Hán Việt reading documented yet") for this character — a positive absence, not a mere access failure; en.Wiktionary also had no Vietnamese section to fall back on. Removed the fabricated/unsourced reading, leaving the field blank.

**`boundedness` filled — was blank**: filled as `100` (fully bound — no word anywhere cites it, consistent with the pre-existing `#hapax` tag and `stand_in: 名専字`).

**Missing Korean lookup subsection created**: no `### 녑` subsection existed anywhere on `Lookup/Korean/Korean Name ㄴ.md` despite the matching `korean: 녑`; created one (alphabetically between `### 녕` and `### 노`), following this session's established precedent (衂's `### 뉵` creation).

Rebuilt the malformed `## Notes` (two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard four-bullet format, with explicit documentation of the sourcing gaps. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 哱 (8715; 81 characters remaining).

### 2026-08-24, iteration 2423 — [[characters/哱|哱]]

`radical: 口` reconfirmed correct — genuine listing (item 66) on `Lookup/Radicals/Radical 030.md`. `skip_number: 1-3-7` reconfirmed correct — genuine listing (item 1) on `Lookup/SKIP/SKIP-1/SKIP-1-3-7.md`. `mc_id: 0` reconfirmed correct — genuine sentinel, genuinely absent from all four `CC N000.md` files. `japanese: [HOTSU, HOCHI, HAI, HE]` reconfirmed correct and complete against en.Wiktionary (ja.Wiktionary 404'd, so single-sourced but kept as pre-existing per established policy). `japanese_native: こえ` reconfirmed correct but left as-is despite en.Wiktionary also listing a second kun'yomi candidate `みだれる` — that candidate is newly-discovered and only single-sourced (ja.Wiktionary inaccessible), so per this session's "only add new dual-sourced entries" policy it was correctly left unadded. `stand_in: 名専字` reconfirmed correct — zero hits for 哱 anywhere in `words/`.

**`graphemic_classification` bug found and fixed**: stored `勃`, but both en.Wiktionary and zh.Wiktionary explicitly name the true phonetic component as `孛`, which has no independent vault page and is listed as an alias on `characters/悖.md`'s own `aliases` field (which, notably, also lists 哱 itself among its aliases — zh.Wiktionary explicitly confirms 悖 as a genuine variant of 哱, and en.Wiktionary independently calls 哱 "an alternative form of 悖"). Per this vault's established alias-citation convention, corrected to cite the parent page `悖` directly.

**`vietnamese` bug found and fixed — badly incomplete**: stored `[buột]` (the Nôm reading) only; hvdic.thivien.net (sole authority) also gives two Hán Việt readings, `bột` and `phá`, both missing. Added.

**`pos`, `joyo_level`, `hsk_level`, `hanmun_edu_level` filled — all four were blank**: `pos` filled as `名詞`. `joyo_level` filled as `表外字` — en.Wiktionary confirms Hyōgai status (ja.Wiktionary 404'd, effectively single-sourced per established fallback practice); added as item 594 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`. `hanmun_edu_level` filled as `無`.

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㅂ.md`'s `### 발` subsection despite the matching `korean: 발`; added.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 䒦 (8716; 80 characters remaining).

### 2026-08-24, iteration 2424 — [[characters/䒦|䒦]]

Extremely obscure CJK Extension A character. `graphemic_classification: 乏` reconfirmed correct — dual-source confirmed 形声 composition (semantic 艸 + phonetic 乏) via en.Wiktionary and zh.Wiktionary. `radical: 艸` reconfirmed correct — genuine listing (item 14) on `Lookup/Radicals/Radical 140.md`. `skip_number: 2-3-5` reconfirmed correct — genuine listing (item 30) on `Lookup/SKIP/SKIP-2/SKIP-2-3-5.md`. `mc_id: 0` reconfirmed correct — genuine sentinel, genuinely absent from all four `CC N000.md` files. `vietnamese: [bìm, bịp]` reconfirmed correct and complete — hvdic.thivien.net (sole authority) gives exactly these two as Âm Nôm while explicitly denying any Âm Hán Việt reading ("chưa có giải nghĩa"); matches stored value exactly, no bug. `japanese: [HI, BI]` and `joyo_level: 表外字` both left unchanged as pre-existing, unconfirmable-but-uncontradicted values — no source (en.Wiktionary, zh.Wiktionary, or ja.Wiktionary, which 404'd) documents any Japanese-reading or classification info at all; added the missing `joyo_level` entry as item 595 to `Lookup/Japanese/Hyōgai.md` for internal consistency, following the same handling established on 䎎 two iterations ago. `stand_in: 名専字` reconfirmed correct — zero hits for 䒦 anywhere in `words/`.

**`pos`, `boundedness` filled — both were blank**: `pos` filled as `名詞`. `boundedness` filled as `100` (fully bound — no word anywhere cites it, consistent with the pre-existing `#hapax` tag and `stand_in: 名専字`).

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㅂ.md`'s `### 범` subsection despite the matching `korean: 범`; added.

Rebuilt the malformed `## Notes` (two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard four-bullet format, with explicit documentation of the sourcing gaps. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 灋 (8717; 79 characters remaining).

### 2026-08-24, iteration 2425 — [[characters/灋|灋]]

`radical: 水` reconfirmed correct — genuine listing (item 171) on `Lookup/Radicals/Radical 085.md`. `skip_number: 1-3-18` reconfirmed correct — genuine listing (item 1) on `Lookup/SKIP/SKIP-1/SKIP-1-3-18.md`. `mc_id: 0` reconfirmed correct — genuine sentinel, genuinely absent from all four `CC N000.md` files. `japanese: [HOU, HATSU, HOTSU]` reconfirmed and left unchanged — ja.Wiktionary confirms only go-on/kan-on ホウ, but HATSU/HOTSU are pre-existing single-sourced values (en.Wiktionary's はっ/ほっ) kept per established policy. `japanese_native: のり` reconfirmed correct and complete (dual-source). `vietnamese: [pháp]` reconfirmed complete and exact against hvdic.thivien.net (sole Hán Việt reading, no Nôm section). `joyo_level: 表外字` reconfirmed correct (dual-source); was missing from `Lookup/Japanese/Hyōgai.md`'s own list — added as item 596. `korean: 법` / `korean_native: 법` reconfirmed correct — identical because Korean genuinely has no distinct native word for "law," only the Sino-Korean term; not a duplication bug. `stand_in: 名専字` reconfirmed correct — zero hits for 灋 anywhere in `words/`.

**`graphemic_classification`/Notes internal contradiction found and fixed**: frontmatter stored `會意` while the page's own pre-existing Notes prose independently asserted `形声` — a direct self-contradiction. zh.Wiktionary unambiguously confirms 會意 (氵+廌, no phonetic role), while en.Wiktionary hedges, offering 形声 only as a secondary "may alternatively be" theory; resolved in favor of 會意, rewriting the Notes prose to match and folding in the alternative theory as a footnote.

**`aliases` bug found and fixed — malformed YAML plus one missing dual-confirmed variant**: stored as a bare scalar `𢌇` (not a list, inconsistent with vault convention) with a second genuine variant, `𫼒`, entirely missing; zh.Wiktionary explicitly dual-confirms both 𢌇 and 𫼒 (alongside en.Wiktionary) as true variants, with neither having an independent vault page. Corrected to a proper two-item list. (The modern simplified form 法, also listed as a "variant" by zh.Wiktionary, was correctly excluded — it already has its own robust independent vault page.)

**`japanese_native` malformed-YAML bug found and fixed**: stored as a broken scalar-then-orphan-list-item pair (`japanese_native: のり` immediately followed by a stray `  - のり` line, duplicating the same value in two conflicting YAML forms); collapsed to the single correct scalar.

**Two propagated cross-page bugs found and fixed**: `Lookup/SKIP/SKIP-1/SKIP-1-3-18.md` carried a stale English gloss "sphinx" instead of the character's own current `english: natural law justice`; corrected. `Lookup/Radicals/Radical 085.md`'s own listing used a mismatched `注音` (`ㄈㄛㄆ`, F-initial) diverging from the character's own authoritative `注音: ㄆㄛㄆ` (P-initial, matching `middle_chinese_initial: p` and the vault's own conlang-spelling system); corrected to match.

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㅂ.md`'s `### 법` subsection despite the matching `korean: 법`; added.

Removed a stray unexplained "sound choice" placeholder bullet from Notes and rebuilt the rest into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 䦨 (8718; 78 characters remaining).

### 2026-08-24, iteration 2426 — [[characters/䦨|䦨]]

`radical: 門` reconfirmed correct — genuine listing (item 15) on `Lookup/Radicals/Radical 169.md`. `skip_number: 3-8-8` reconfirmed correct — genuine listing (item 1) on `Lookup/SKIP/SKIP-3/SKIP-3-8-8.md`. `aliases: [闌]` reconfirmed correct — both en.Wiktionary and ja.Wiktionary explicitly confirm 䦨 as a corrupted form (訛字) of 闌, with 闌 having no independent vault page. `japanese: [RAN]`, `japanese_native: たけし`, and blank `joyo_level` all left unchanged — no source (en.Wiktionary, zh.Wiktionary, or ja.Wiktionary) documents any Japanese-reading or classification info for 䦨 itself, so the pre-existing `japanese` values were kept uncontested and `joyo_level` was correctly left blank rather than fabricated. `stand_in: 名専字` reconfirmed correct — zero hits for 䦨 anywhere in `words/`.

**`graphemic_classification` bug found and fixed**: stored `柬` — actually the true phonetic of the *parent* form 闌 (門+柬) — but en.Wiktionary's own composition breakdown of 䦨 itself is explicitly `⿵門東` (門 enclosing 東, not 柬); this makes etymological sense, since 䦨 originated precisely from a scribal miscopying of 柬 as the visually similar 東 inside the same 門 enclosure. Corrected to `東` to reflect 䦨's own actual (corrupted) composition rather than its parent's.

**`vietnamese` bug found and fixed — malformed unsplit string, positively disconfirmed by the sole authority**: stored a single unsplit comma-string `"làn, lan"` (a YAML list-vs-scalar formatting bug on top of the content issue); hvdic.thivien.net (sole Vietnamese authority) explicitly states "Chưa có giải nghĩa theo âm Hán Việt" (no reading documented) for this character — a positive absence, not an access failure. Removed the fabricated/malformed reading entirely, leaving the field blank.

**`mc_id` bug found and fixed — cited the wrong rank entirely**: stored `3398` (actually `穹`'s rank); 䦨 itself has no independent `CC N000.md` entry (unsurprising for a "corrupted form" variant), so corrected to cite its alias [[闌]]'s own genuine exact-match rank instead, `3399`, following the same alias-rank-citation pattern established on 逾/踰 earlier this session.

**`pos`, `hanmun_edu_level` filled — both were blank**: `pos` filled as `名詞`. `hanmun_edu_level` filled as `無`.

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㄹ.md`'s `### 란` subsection despite the matching `korean: 란`; added.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format, with explicit documentation of the etymology and sourcing gaps. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 盼 (8720; 77 characters remaining).

### 2026-08-24, iteration 2427 — [[characters/盼|盼]]

`graphemic_classification: 分` (dual-source confirmed 形声, semantic 目 + phonetic 分, OC \*pɯn/\*bɯns) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 目` reconfirmed correct — genuine listing (item 8) on `Lookup/Radicals/Radical 109.md`. `skip_number: 1-5-4` reconfirmed correct — genuine listing (item 5) on `Lookup/SKIP/SKIP-1/SKIP-1-5-4.md`. `japanese: [HAN, HEN, FUN, BUN]` reconfirmed correct and complete against en.Wiktionary (ja.Wiktionary 404'd, kept single-sourced per established policy). `japanese_native: ø` reconfirmed correct — en.Wiktionary explicitly lists no kun'yomi. `stand_in: 名専字` reconfirmed correct — zero hits for 盼 anywhere in `words/`. `aliases` (blank) reconfirmed correct — en.Wiktionary's single-sourced "Alternative form: 盻" claim wasn't clearly corroborated by zh.Wiktionary (whose own summary only noted 盻 as an adjacent Unicode-sequence entry, not an explicit 異體字 statement), so correctly left unadded pending stronger dual-source confirmation. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅂ.md`.

**`hsk_level` bug found and fixed**: stored `2`, but `Old HSK 2.md`'s only mention is a non-genuine colon-count entry (`[[盼]]: 1`); the genuine plain-numbered entry (`358.  [[盼]]`) is on `Old HSK 5.md`. Corrected to `5`.

**`mc_id` off-by-one bug found and fixed**: stored `3922`, which `CC 3000.md` actually assigns to `湆`; 盼's own genuine exact-match entry is `3923. 盼`. Corrected.

**`vietnamese` bug found and fixed — badly incomplete**: stored `[phán]` only; hvdic.thivien.net (sole authority) also gives two further Hán Việt readings, `miện` and `phiến`, both missing. Added.

**`pos`, `joyo_level` filled — both were blank**: `pos` filled as `動詞`. `joyo_level` filled as `表外字` — en.Wiktionary confirms Hyōgai status (ja.Wiktionary 404'd, effectively single-sourced per established fallback practice); added as item 597 to `Lookup/Japanese/Hyōgai.md`.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 脆 (8721; 76 characters remaining).

### 2026-08-24, iteration 2428 — [[characters/脆|脆]]

`graphemic_classification: 絶` (dual-source confirmed 形声, semantic 肉 + abbreviated phonetic 絕/絶, OC \*zod) reconfirmed correct via en.Wiktionary and zh.Wiktionary — 絶 (char) has its own independent vault page, correctly cited. `radical: 肉` reconfirmed correct — genuine listing (item 37) on `Lookup/Radicals/Radical 130.md`. `skip_number: 1-4-6` reconfirmed correct — genuine listing (item 34) on `Lookup/SKIP/SKIP-1/SKIP-1-4-6.md`. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 218, corroborated by ja.Wiktionary. `vietnamese: [thuý]` reconfirmed complete and exact against hvdic.thivien.net. `stand_in: 名専字` reconfirmed correct — zero hits for 脆 anywhere in `words/`. `aliases` (blank) reconfirmed correct — en.Wiktionary's listed variants (脃, 膬, 脺, 毳) aren't corroborated by zh.Wiktionary, consistent with this session's exclusion practice. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅊ.md`.

**`hsk_level` bug found and fixed**: stored `2`, but `Old HSK 2.md` doesn't mention 脆 at all (neither genuine nor colon-count); the genuine plain-numbered entry (`495.  [[脆]]`) is on `Old HSK 5.md`. Corrected to `5`.

**`mc_id` off-by-one bug found and fixed**: stored `2983`, which `CC 2000.md` actually assigns to `寘`; 脆's own genuine exact-match entry is `2984. 脆`. Corrected.

**`japanese` bug found and fixed — missing go-on reading**: stored `[ZEI, SEI]` (kan'yō-on and kan-on); both en.Wiktionary and ja.Wiktionary independently confirm a third, go-on reading `サイ` (SAI), previously missing; added.

**`japanese_native` bug found and fixed — truncated and incomplete**: stored `もろ` (a truncation of the genuine kun'yomi `もろい`); both sources also independently confirm a second kun'yomi, `よわい` (YOWAI), previously missing entirely. Corrected to `[もろい, よわい]` (two further single-sourced candidates — ja.Wiktionary's やわらかい/かるい — weren't dual-confirmed and were left out).

**`pos` filled — was blank**: filled as `性詞`.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 軒 (8722; 75 characters remaining).

### 2026-08-24, iteration 2429 — [[characters/軒|軒]]

`graphemic_classification: 干` (dual-source confirmed 形声, semantic 車 + phonetic [[干]], OC \*kaːn) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 車` reconfirmed correct — genuine listing (item 5) on `Lookup/Radicals/Radical 159.md`. `skip_number: 1-7-3` reconfirmed correct — genuine listing (item 12) on `Lookup/SKIP/SKIP-1/SKIP-1-7-3.md`. `japanese: [KEN]` reconfirmed correct — en.Wiktionary's Jōyō-standard kan-on. `japanese_native: のき` reconfirmed correct and complete (Jōyō-standard kun'yomi). `joyo_level: 高等` reconfirmed correct — genuine listing (item 1298) on `Lookup/Japanese/Jōyō - Kōtō.md`. `hsk_level: 無` reconfirmed correct, already present on `Lookup/HSK/HSK No.md`. `hanmun_edu_level: 高等` reconfirmed correct, matching `joyo_level`. `aliases: [轩]` reconfirmed correct — en.Wiktionary's confirmed simplified form; the four other listed "alternative forms" (䡓, 𲀝, 𨍓, 𩋱) weren't corroborated by zh.Wiktionary and were correctly left unadded. `stand_in: 名専字` reconfirmed correct — zero hits for 軒 anywhere in `words/`. Already correctly cross-listed on `Lookup/Korean/Korean HS.md`.

**`vietnamese` bug found and fixed — one fabricated reading swapped for a genuine missing one**: stored `[hen, hin, hiên, hên]`; hvdic.thivien.net's genuine readings are exactly `hiên, hiến` (Hán Việt) + `hen, hên, hiên` (Nôm) — `hin` appears in neither source (a clear fabrication/typo, likely confusion with `hiến`) and was removed; the genuine `hiến` reading, entirely missing from the stored set, was added.

**`mc_id` off-by-one bug found and fixed**: stored `1850`, which `CC 1000.md` actually assigns to `活`; 軒's own genuine exact-match entry is `1851. 軒`. Corrected.

**`pos` filled — was blank**: filled as `名詞`.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 撫 (8724; 74 characters remaining).

### 2026-08-24, iteration 2430 — [[characters/撫|撫]]

`graphemic_classification: 無` (dual-source confirmed 形声, semantic 手 + phonetic [[無 (char)|無]], OC \*ma) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 手` reconfirmed correct — genuine listing (item 115) on `Lookup/Radicals/Radical 064.md`. `skip_number: 1-3-12` reconfirmed correct — genuine listing (item 22) on `Lookup/SKIP/SKIP-1/SKIP-1-3-12.md`. `mc_id: 1304` reconfirmed exact match (`CC 1000.md`: `1304. 撫`). `japanese: [BU, FU]` reconfirmed correct and complete against en.Wiktionary. `joyo_level: 日本人名用漢字` reconfirmed correct — genuine listing (item 241) on `Lookup/Japanese/Jinmeiyō.md`. `stand_in: 名専字` reconfirmed correct — zero hits for 撫 anywhere in `words/`. `aliases: [抚]` reconfirmed correct — en.Wiktionary's confirmed simplified form; the three other listed "alternative forms" (𢻬, 𢻲, 拊) weren't corroborated by zh.Wiktionary and were correctly left out. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅁ.md`.

**`hsk_level` bug found and fixed**: stored `4`, but `Old HSK 4.md`'s only mention is a non-genuine colon-count entry (`[[撫]]: 2`); the genuine plain-numbered entry (`596.  [抚](../../characters/撫.md)`, using the simplified glyph in its display but linking to this same page) is on `Old HSK 6.md`. Corrected to `6`.

**`vietnamese` bug found and fixed — one fabricated reading swapped for a genuine missing one**: stored `[dỗ, phủ, vồ, vỗ]`; hvdic.thivien.net's genuine readings are exactly `mô, phủ` (Hán Việt) + `dỗ, phủ, vồ` (Nôm) — `vỗ` appears nowhere in hvdic (only in en.Wiktionary, not this vault's sole VN authority) and was removed; the genuine `mô` reading, entirely missing from the stored set, was added.

**`japanese_native` bug found and fixed — truncated**: stored `な`, a truncation of the dual-confirmed kun'yomi `なでる` (NADERU, "to stroke, pat"). Corrected to the full form.

**`pos` filled — was blank**: filled as `動詞`.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 懿 (8725; 73 characters remaining).

### 2026-08-24, iteration 2431 — [[characters/懿|懿]]

`graphemic_classification: 壱` investigated and reconfirmed correct — en.Wiktionary names the true phonetic as `壹`, which has no independent vault page and is hosted as an alias on `characters/壱 (char).md`'s own `aliases` field; per this vault's established alias-citation convention, citing the parent page `壱` was already correct. `radical: 心` reconfirmed correct — genuine listing (item 105) on `Lookup/Radicals/Radical 061.md`. `skip_number: 1-12-10` reconfirmed correct — genuine listing (item 1) on `Lookup/SKIP/SKIP-1/SKIP-1-12-10.md`. `japanese: [I]` reconfirmed correct and complete — matches en.Wiktionary's い exactly. `japanese_native: よい` reconfirmed correct — a second candidate from ja.Wiktionary alone (うるわしい) wasn't corroborated by en.Wiktionary and was correctly left unadded. `vietnamese: [ý]` reconfirmed complete and exact against hvdic.thivien.net (identical Hán Việt and Nôm). `stand_in: 名専字` reconfirmed correct — the sole grep hit, [[words/楽経|楽経]], is a false-positive prose mention (its own `characters:` field cites unrelated constituents). `aliases` (blank) reconfirmed correct — en.Wiktionary's listed variants (㦤, 㦉, 㱅, 𡤵) aren't corroborated by zh.Wiktionary, consistent with this session's exclusion practice. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅇ.md`.

**`mc_id` off-by-one bug found and fixed**: stored `1677`, which `CC 1000.md` actually assigns to `琅`; 懿's own genuine exact-match entry is `1678. 懿`. Corrected.

**`pos`, `joyo_level`, `hsk_level` filled — all three were blank**: `pos` filled as `性詞`. `joyo_level` filled as `表外字` (dual-source confirmed); added as item 598 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 酋 (8726; 72 characters remaining).

### 2026-08-24, iteration 2432 — [[characters/酋|酋]]

Major cross-page data-contamination bug found and fixed — this page's `stroke_count`, `radical`, and `english` fields, plus its stale Radical/SKIP/Stroke lookup-page cross-references, had all been contaminated with data belonging to its own alias 蝤 ("insect larva/grub," 虫+酋, 15 strokes), while every *other* field on the page (mandarin, cantonese, `korean_native: 우두머리` "chief/leader," vietnamese, graphemic_classification, 羅馬字, 注音) correctly described 酋 itself ("chieftain," 9 strokes, radical 酉). Both en.Wiktionary and zh.Wiktionary independently and unambiguously confirm 酋's true identity: radical 酉 (wine vessel), 9 total strokes, meaning "chieftain, tribal leader" (historically "wine-master/superintendent of liquor").

**Fixed on the character page itself**: `stroke_count` 15→9; `radical` 虫→酉; `skip_number` 1-6-9→2-2-7 (re-derived from the character's own true composition, 丷(2)+酉(7)); `english` [larva]→[chieftain, tribal leader].

**Fixed four propagated lookup-page contaminations**: removed the wrongly-filed item 32 ("酋 - larva") from `Lookup/Radicals/Radical 142.md` (虫/insect radical; renumbered items 33–42→32–41, decremented `size` 42→41) and added a new correctly-filed `### +2 Strokes` entry to `Lookup/Radicals/Radical 164.md` (酉/wine radical; renumbered all subsequent items, incremented `size` 21→22). Removed the wrongly-filed item 18 ("酋 - lava" [sic]) from `Lookup/SKIP/SKIP-1/SKIP-1-6-9.md` (decremented `size` 19→18) and added it correctly to `Lookup/SKIP/SKIP-2/SKIP-2-2-7.md` as item 20 (incremented `size` 19→20). Also moved 酋's entry from `Lookup/Stroke/Stroke 15.md` to `Lookup/Stroke/Stroke 09.md`.

**`japanese` bug found and fixed — missing go-on reading**: stored `[SHUU]` (kan-on only); both en.Wiktionary and ja.Wiktionary independently confirm a go-on reading, `ジュ` (JU), previously missing; added.

`graphemic_classification: 象形` reconfirmed correct — dual-source confirmed pictograph (exposed liquid above a wine vessel) via en.Wiktionary and zh.Wiktionary's own 象形-consistent account (zh.Wiktionary's bare "形声" label elsewhere was treated as a less-detailed WebFetch summarization artifact, per this session's practice of preferring the internally-consistent, detailed account). `japanese_native: おさ` reconfirmed correct and complete — a second candidate from en.Wiktionary alone (かしら) wasn't corroborated by ja.Wiktionary (which instead gave two entirely different, also-uncorroborated candidates), so correctly left unadded. `vietnamese: [tù]` reconfirmed complete and exact against hvdic.thivien.net. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 147. `mc_id: 6579` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `stand_in: 名専字` reconfirmed correct — zero hits for 酋 anywhere in `words/`. `aliases: [蝤]` reconfirmed correct. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅊ.md`.

**`pos`, `hsk_level` filled — both were blank**: `pos` filled as `名詞`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`.

Rebuilt the malformed frontmatter section (a duplicate `## Notes` heading with two separate, conflicting Notes blocks) into the standard single `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 赩 (8727; 71 characters remaining).

### 2026-08-24, iteration 2433 — [[characters/赩|赩]]

`graphemic_classification: 色` reconfirmed correct — dual-source confirmed 形声, semantic 赤 + phonetic 色, via en.Wiktionary and zh.Wiktionary (the latter confirming series membership under both 赤 and 色). `radical: 赤` reconfirmed correct — genuine listing (item 3) on `Lookup/Radicals/Radical 155.md`. `skip_number: 1-7-6` reconfirmed correct — genuine listing (item 21) on `Lookup/SKIP/SKIP-1/SKIP-1-7-6.md`. `japanese: [KYOKU, KOKU, KAKU, KYAKU]` reconfirmed correct and complete against en.Wiktionary. `japanese_native: あか` reconfirmed correct and complete. `pos: 性詞` reconfirmed correct. `stand_in: 名専字` reconfirmed correct — zero hits for 赩 anywhere in `words/`. `aliases` (blank) reconfirmed correct — en.Wiktionary's single-sourced 𳅆 candidate wasn't corroborated by zh.Wiktionary. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅎ.md`.

**`vietnamese` bug found and fixed — was blank**: hvdic.thivien.net (sole authority) gives `hách`; added.

**`joyo_level`, `hsk_level` filled — both were blank**: `joyo_level` filled as `表外字` — en.Wiktionary confirms Hyōgai status (ja.Wiktionary 404'd, effectively single-sourced per established fallback practice); added as item 599 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`.

Rebuilt the malformed `## Notes` (two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 霅 (8728; 70 characters remaining).

### 2026-08-24, iteration 2434 — [[characters/霅|霅]]

`graphemic_classification: 會意` investigated and left unchanged — a genuine three-way source conflict: en.Wiktionary claims 形声 with phonetic 譶 (no independent vault page); zh.Wiktionary instead groups the character under an ambiguous 言-series without clearly asserting a phonetic role, and lists 霎 as a variant; ja.Wiktionary's own reading set diverges sharply from both others. Given no source clearly wins out, kept the pre-existing label and documented the conflict in Notes. `radical: 雨` reconfirmed correct — genuine listing (item 12) on `Lookup/Radicals/Radical 173.md`. `skip_number: 2-8-7` reconfirmed correct — genuine listing (item 8) on `Lookup/SKIP/SKIP-2/SKIP-2-8-7.md`. `mc_id: 6900` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [SHOU, SOU, GYOU]` reconfirmed and left unchanged — matches en.Wiktionary's more internally-consistent account; ja.Wiktionary's own five-plus-five on'yomi list (with zero kun'yomi, contradicting en.Wiktionary's kun'yomi claim) was treated as an unreliable outlier for this unusually inconsistently-documented character. `stand_in: 名専字` reconfirmed correct — zero hits for 霅 anywhere in `words/`. `aliases` (blank) reconfirmed correct — en.Wiktionary's listed derived characters (㘊, 𤁳) incorporate 霅 rather than being variants of it.

**`vietnamese` bug found and fixed — was blank**: hvdic.thivien.net (sole authority) gives three Hán Việt readings, `hiệp, sáp, tráp`; added.

**`japanese_native` bug found and fixed — truncated**: stored `やかま`, a truncation of the genuine kun'yomi `やかましい` (YAKAMASHII, "noisy"). Corrected.

**`pos`, `joyo_level`, `hsk_level` filled — all three were blank**: `pos` filled as `名詞`. `joyo_level` filled as `表外字` (en.Wiktionary confirmed, single-sourced given ja.Wiktionary's divergent account, per established fallback practice); added as item 600 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`.

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㅅ.md`'s `### 삽` subsection despite the matching `korean: 삽`; added.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 显 (8729; 69 characters remaining).

### 2026-08-24, iteration 2435 — [[characters/显|显]]

Investigated a suspected data-mixup similar to 酋's from two iterations ago, but resolved differently: `显` genuinely has a dual identity attested by en.Wiktionary — primarily the PRC-simplified form of `顯` ("evident, clear, to appear/manifest," matching this vault's own separately-perfected `顕.md`, the parallel Japanese shinjitai form), and secondarily a variant of `㬎` ("motes visible in a sunbeam"). `mandarin`, `cantonese`, `korean: 현`, `korean_native: 나타날`, `vietnamese: [hiển, hển]`, and `aliases: [㬎, 顯]` all correctly and consistently describe this dual identity, reconfirmed via en.Wiktionary, zh.Wiktionary (which explicitly redirects to 顯 "此字是「顯」的簡化字"), and ja.Wiktionary. `radical: 日` reconfirmed correct — 显 genuinely carries its own distinct official radical (日) separate from traditional 顯's own radical (頁), a legitimate structural divergence between the simplification paths, not a bug. `graphemic_classification: 會意` left unchanged, matching the parallel treatment on `顕.md`. `japanese: [KIN, GON, GOU, KEN]`, `middle_chinese_initial/final` (k/ʌp), and the conlang `羅馬字`/`諺文`/`注音`/`mc_id` fields were all investigated and left unchanged — these plausibly represent a deliberately distinct syllable assignment for this page (separate from `顕`'s own hen/헌/ㅎㅔㄴ), needed to disambiguate the two independently-perfected sibling pages in this vault's phonological system, and no source offers a confident alternative value to correct them to. `joyo_level: 表外字` reconfirmed correct (en.Wiktionary explicit; ja.Wiktionary's own account of this page gives no classification, so single-sourced) — was missing from `Lookup/Japanese/Hyōgai.md`'s own list despite being correct; added as item 601. `pos: 名詞` reconfirmed correct. `stand_in: 名専字` reconfirmed correct — the three word citers found via grep ([[顕著]], [[顕示]], [[顕現]]) all genuinely cite the sibling page 顕, not 显 itself.

**`english` bug found and fixed**: stored `[chrysalis, motes in a sunbeam]` — "chrysalis" is unsupported by any of the three sources checked and appears to be a genuine fabrication/mixup; corrected to `[evident, motes in a sunbeam]`, keeping the one en.Wiktionary-attested secondary sense while replacing the unsupported primary sense with the character's actual, triple-source-confirmed core meaning.

**`stroke_count` bug found and fixed**: stored `8`; all three sources (en.Wiktionary, zh.Wiktionary, ja.Wiktionary) independently and explicitly confirm 9 total strokes (日 + 5). Corrected.

**`hsk_level` bug found and fixed**: stored `2`, but `Old HSK 2.md`'s only mention is a non-genuine colon-count entry (`[[显]]: 4`); the genuine plain-numbered entry (`399.  [[显]]`) is on `Old HSK 5.md`. Corrected to `5`.

**Missing Korean lookup entry found and fixed**: 显 was entirely absent from `Lookup/Korean/Korean HS.md`, despite its sibling page 顕 already being correctly listed there under the identical Korean reading (나타날 현); added 显 as its own separate entry alongside it.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format, with explicit documentation of the dual-identity/sibling-page situation. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 怗 (8730; 68 characters remaining).

### 2026-08-24, iteration 2436 — [[characters/怗|怗]]

`graphemic_classification: 占` (dual-source confirmed 形声, semantic 忄 + phonetic [[占]]) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 心` reconfirmed correct — genuine listing (item 15) on `Lookup/Radicals/Radical 061.md`. `skip_number: 1-3-5` reconfirmed correct — genuine listing (item 29) on `Lookup/SKIP/SKIP-1/SKIP-1-3-5.md`. `mc_id: 0` reconfirmed correct — genuine sentinel, genuinely absent from all four `CC N000.md` files. `japanese: [CHOU, TEN, SEN]` reconfirmed correct and complete against en.Wiktionary. `pos: 性詞` reconfirmed correct. `stand_in: 名専字` reconfirmed correct — zero hits for 怗 anywhere in `words/`. `aliases` (blank) reconfirmed correct — en.Wiktionary's listed variants (㤐, 惉) aren't corroborated by zh.Wiktionary.

**`japanese_native` bug found and fixed — truncated**: stored `おだ`, a truncation of the genuine kun'yomi `おだやか` (ODAYAKA, "peaceful"). Corrected (a second en.Wiktionary-only candidate, したがう, wasn't dual-confirmed — ja.Wiktionary 404'd — and was correctly left unadded).

**`vietnamese` bug found and fixed — badly incomplete**: stored `[điếm]` (the Nôm reading) only; hvdic.thivien.net (sole authority) also gives three Hán Việt readings, `chiêm, siêm, thiếp`, all missing. Added.

**`joyo_level`, `hsk_level` filled — both were blank**: `joyo_level` filled as `表外字` — en.Wiktionary confirms Hyōgai status (ja.Wiktionary 404'd, effectively single-sourced per established fallback practice); added as item 602 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`.

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㅊ.md`'s `### 첩` subsection despite the matching `korean: 첩`; added.

Rebuilt the malformed `## Notes` (two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 忝 (8731; 67 characters remaining).

### 2026-08-24, iteration 2437 — [[characters/忝|忝]]

`graphemic_classification: 天` and `radical: 心` both reconfirmed correct — dual-source confirmed 形声 (semantic 心 + phonetic 天, OC \*qʰl'iːn) via en.Wiktionary and zh.Wiktionary. `skip_number: 2-3-4` reconfirmed correct — genuine listing (item 9) on `Lookup/Radicals/Radical 061.md` and (item 13) on `Lookup/SKIP/SKIP-2/SKIP-2-3-4.md`. `japanese: [TEN]` reconfirmed correct and complete — matches both sources' identical go-on/kan-on てん exactly. `vietnamese: [thiểm, thỏm]` reconfirmed complete and exact against hvdic.thivien.net (one Hán Việt + two Nôm, one overlapping). `stand_in: 名専字` reconfirmed correct — zero hits for 忝 anywhere in `words/`.

**`## Notes` semantic/phonetic swap bug found and fixed**: the page's own pre-existing Notes prose had the composition backwards — labeling phonetic 天 as "semantic ... (heart)" and semantic 心 as "phonetic" with 心's own OC reading misattributed to it. Rebuilt with the roles and glosses corrected to match both sources' unambiguous account (semantic 心 "heart" + phonetic 天).

**`mc_id` off-by-one bug found and fixed**: stored `3719`, which `CC 3000.md` actually assigns to `罝`; 忝's own genuine exact-match entry is `3720. 忝`. Corrected.

**`aliases` bug found and fixed — was blank**: both en.Wiktionary and zh.Wiktionary confirm `㤁` as a genuine variant form with no independent vault page; added.

**`japanese_native` bug found and fixed — truncated**: stored `かたじけな`, a truncation of the dual-confirmed kun'yomi `かたじけない` (KATAJIKENAI). Corrected (a second, ja.Wiktionary-only candidate はずかしめる wasn't dual-confirmed and was correctly left unadded).

**`pos`, `joyo_level`, `hsk_level` filled — all three were blank**: `pos` filled as `性詞`. `joyo_level` filled as `表外字` (dual-source confirmed); added as item 603 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`.

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㅊ.md`'s `### 첨` subsection despite the matching `korean: 첨`; added.

Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 屮 (8732; 66 characters remaining).

### 2026-08-24, iteration 2438 — [[characters/屮|屮]]

`graphemic_classification: 象形` reconfirmed correct — dual-source confirmed pictograph (Shuowen: a sprouting plant with emerging stem/branches) via en.Wiktionary and zh.Wiktionary. `radical: 屮` reconfirmed correct — 屮 is itself Radical 45 (self-radical), genuine listing (item 1) on `Lookup/Radicals/Radical 045.md`. `skip_number: 4-3-3` reconfirmed correct — genuine listing (item 2) on `Lookup/SKIP/SKIP-4/SKIP-4-3-3.md`. `joyo_level: 表外字` reconfirmed correct — dual-source confirmed (en.Wiktionary and ja.Wiktionary); was missing from `Lookup/Japanese/Hyōgai.md`'s own list — added as item 604. `hsk_level: 無` reconfirmed correct — genuinely absent from all six `Old HSK N.md` files, but was missing from `Lookup/HSK/HSK No.md` itself — added. `pos: 名詞` reconfirmed correct. `vietnamese: [triệt]` reconfirmed complete and exact against hvdic.thivien.net. `stand_in: 名専字` reconfirmed correct — zero hits for 屮 anywhere in `words/`. `aliases` (blank) reconfirmed correct — zh.Wiktionary's extensive listed variants under both the 艸-series (艹, 䒑, 𢂉, 草, etc.) and 左-series (𠂇, 佐, etc.) are all either obscure/unencodable or already have independent vault pages, correctly excluded.

**Genuine three-way source conflict investigated and resolved for `japanese`/`japanese_native`**: en.Wiktionary attests on'yomi てつ/そう/さ and kun'yomi ひだり/ひだりて/め/めばえ (via 屮's secondary attested identity as a variant of 左 "left"); ja.Wiktionary instead gives only てつ (TETSU) and そう (SOU) as on'yomi — omitting さ entirely — and explicitly states no kun'yomi exists at all. Per this session's established policy (an explicit "no kun'yomi" statement from ja.Wiktionary overrides a single-sourced en.Wiktionary kun'yomi claim, precedent: 彖's こしきしば case), corrected `japanese_native` from a malformed, single-sourced `[ひだりて, ひだり]` to `ø`. Added the two newly dual-confirmed on'yomi, `TETSU` and `SOU`, to `japanese` (kept the pre-existing single-sourced `SA` per established policy, since ja.Wiktionary's omission of it isn't as strong as an explicit denial).

**`japanese_native` malformed-YAML bug found and fixed**: stored as a broken scalar-then-orphan-list-item pair; resolved as part of the fix above (collapsed to `ø`).

**`mc_id` off-by-one bug found and fixed**: stored `3211`, which `CC 3000.md` actually assigns to `跳`; 屮's own genuine exact-match entry is `3212. 屮`. Corrected.

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㅊ.md`'s `### 철` subsection despite the matching `korean: 철`; added.

Rebuilt the malformed `## Notes` (a stray unlinked `[[ㄊㄧㄊ]]` bullet, lowercase `lookup/` path links, mismatched heading structure) into the standard four-bullet format, preserving the pre-existing `## Derived Characters` section. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 𡈼 (8733; 65 characters remaining).

### 2026-08-24, iteration 2439 — [[characters/𡈼|𡈼]]

`graphemic_classification: 象形` reconfirmed correct — dual-source confirmed pictograph ("a person standing on earth") via en.Wiktionary and zh.Wiktionary; zh.Wiktionary additionally confirms this is the original form of [[挺]] and a variant of 壬/[[王 (char)|王]]/[[徴]] (all three already independently paged in this vault, correctly excluded from `aliases`) and of 莛/葶 (this page's own genuine, pageless aliases, which supply the `english: stalk` gloss actually used here). `radical: 土` reconfirmed correct — genuine listing (item 2) on `Lookup/Radicals/Radical 032.md`. `skip_number: 4-4-1` reconfirmed correct — genuine listing (item 14) on `Lookup/SKIP/SKIP-4/SKIP-4-4-1.md`. `mc_id: 0` reconfirmed correct — genuine sentinel, genuinely absent from all four `CC N000.md` files. `japanese: [TEI, JOU]` reconfirmed and left unchanged — ja.Wiktionary actually confirms four on'yomi (ジョウ, タイ, チョウ, テイ), of which the two stored values are a genuine subset, but the other two (タイ, チョウ) are new candidates only single-sourced by ja.Wiktionary (en.Wiktionary gives no Japanese-reading data at all for this character) and were correctly left unadded per established policy. `joyo_level: 表外字` left unchanged as pre-existing, unconfirmable-but-uncontradicted — neither source gives an explicit classification for this rare Extension B character; added the missing entry as item 605 to `Lookup/Japanese/Hyōgai.md` for internal consistency. `pos: 名詞` reconfirmed correct. `stand_in: 名専字` reconfirmed correct — zero hits for 𡈼 anywhere in `words/`.

**`vietnamese` bug found and fixed — was blank**: hvdic.thivien.net (sole authority) gives the sole reading `sính` ("skillful, talented") — an apparently disconnected historical sense-cluster from the character's documented "stalk/to stand" meanings, but the only attested Vietnamese reading regardless; added, with the discrepancy documented in Notes.

**`hsk_level`, `hanmun_edu_level`, `boundedness` filled — all three were blank**: `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`. `hanmun_edu_level` filled as `無`. `boundedness` filled as `100` (fully bound — no word anywhere cites it, consistent with the pre-existing `#hapax` tag and `stand_in: 名専字`).

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㅈ.md`'s `### 정` subsection despite the matching `korean: 정`; added.

Rebuilt the malformed frontmatter section (a duplicate `## Notes` heading with a second, sparse Notes block) into the standard single `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 豕 (8734; 64 characters remaining).

### 2026-08-24, iteration 2440 — [[characters/豕|豕]]

`graphemic_classification: 象形` reconfirmed correct — dual-source confirmed pictograph (a pig) via en.Wiktionary and zh.Wiktionary. `radical: 豕` reconfirmed correct — 豕 is itself Radical 152 (self-radical), genuine listing (item 1). `skip_number: 4-7-1` reconfirmed correct — genuine listing (item 3) on `Lookup/SKIP/SKIP-4/SKIP-4-7-1.md`. `japanese: [SHI]` reconfirmed correct and complete — matches both sources' identical go-on/kan-on し exactly. `vietnamese: [thỉ]` reconfirmed complete and exact against hvdic.thivien.net. `stand_in: 名専字` reconfirmed correct — both grep hits ([[words/啄|啄]], [[words/豚|豚]]) are false-positive prose mentions; neither cites 豕 in its own `characters:` field. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅅ.md`.

**`english` bug found and fixed — confused with a derived character**: stored `[shackled pig]`, but this specific gloss actually belongs to 豕's own derived character `豖` ("castrated male pig"), explicitly distinguished in the page's own pre-existing Notes prose ("Compare... 豖 (castrated male pig)"). Corrected to `[pig, boar]`, matching both sources' actual definitions for 豕 itself. Propagated the same stale gloss fix to `Lookup/Radicals/Radical 152.md` and `Lookup/SKIP/SKIP-4/SKIP-4-7-1.md`, both of which had independently inherited the same wrong "shackled pig" gloss.

**`mc_id` off-by-one bug found and fixed**: stored `1471`, which `CC 1000.md` actually assigns to `娶`; 豕's own genuine exact-match entry is `1472. 豕`. Corrected.

**`japanese_native` bug found and fixed — was ø despite dual-confirmed evidence**: stored `ø` (no kun'yomi), but both en.Wiktionary and ja.Wiktionary independently confirm a genuine kun'yomi, `いのこ` (INOKO); corrected (en.Wiktionary's second candidate, ぶた, wasn't corroborated by ja.Wiktionary and was correctly left unadded).

**`aliases` bug found and fixed — key was entirely absent**: both en.Wiktionary and zh.Wiktionary dual-confirm four genuine variant forms (𢁓, 𡰯, 𧰧, 𧰬), none with an independent vault page; added all four (a fifth, zh.Wiktionary-only candidate 𫨂, was correctly left out).

**`pos`, `joyo_level`, `hsk_level` filled — all three were blank**: `pos` filled as `名詞`. `joyo_level` filled as `表外字` (dual-source confirmed); added as item 606 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`.

Rebuilt the malformed frontmatter section (a duplicate `## Notes` heading with a second, sparse Notes block) into the standard single `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 㑒 (8735; 63 characters remaining).

### 2026-08-24, iteration 2441 — [[characters/㑒|㑒]]

`graphemic_classification: 會意` reconfirmed correct — dual-source confirmed ideographic composition ⿻合人, 合 ("together") + 人 ("person"), via en.Wiktionary and zh.Wiktionary. `radical: 人` reconfirmed correct — genuine listing (item 52) on `Lookup/Radicals/Radical 009.md`. `skip_number: 2-2-6` reconfirmed correct — genuine listing (item 15) on `Lookup/SKIP/SKIP-2/SKIP-2-2-6.md`. `japanese: [SEN]` reconfirmed correct and complete — matches en.Wiktionary's identical go-on/kan-on せん exactly. `vietnamese: [thiêm]` reconfirmed complete and exact against hvdic.thivien.net. `pos: 性詞`, `joyo_level: 表外字`, `hsk_level: 無`, `hanmun_edu_level: 名` all reconfirmed correct — already present, genuine at `Lookup/Korean/Korean Name ㅊ.md`. `stand_in: 名専字` reconfirmed correct — the sole grep hit, [[words/剣|剣]], is a false-positive prose mention (its own `characters:` field cites 剣 (char), not 㑒). `aliases: [僉]` reconfirmed correct — en.Wiktionary explicitly confirms 㑒 as Japan's extended shinjitai simplification of traditional 僉 (which remains kyūjitai print-standard, no independent vault page).

**`japanese_native` investigated and left unchanged**: stored `ø`, but en.Wiktionary alone attests three genuine kun'yomi (みな, ことごとく, ともに); ja.Wiktionary 404'd for this character, so these single-sourced candidates couldn't be dual-confirmed and were correctly left unadded, with the gap documented in Notes for future re-checking.

**`mc_id` off-by-one bug found and fixed**: stored `3314`, which `CC 3000.md` actually assigns to `妊`; 㑒 itself has no independent `CC N000.md` entry, so corrected to cite its alias [[僉]]'s own genuine exact-match rank instead, `3315`, following the same alias-rank-citation pattern established on 逾/踰 and 䦨/闌 earlier this session.

**Two missing lookup-page cross-references found and fixed**: `joyo_level: 表外字` (pre-existing, reconfirmed correct) was missing from `Lookup/Japanese/Hyōgai.md`'s own list; added as item 607. `hsk_level: 無` (pre-existing, reconfirmed correct) was missing from `Lookup/HSK/HSK No.md` itself; added.

**`boundedness` filled — was blank**: filled as `100` (fully bound — no word anywhere cites it, consistent with the pre-existing `#hapax` tag and `stand_in: 名専字`).

Rebuilt the malformed `## Notes` (an empty heading immediately followed by an unrelated `### Descendants` sub-section, two bare unlinked CC wikilinks) into the standard four-bullet format, preserving the genuine `## Descendants` content as its own top-level section. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 瓊 (8737; 62 characters remaining).

### 2026-08-24, iteration 2442 — [[characters/瓊|瓊]]

`graphemic_classification: 夐` (dual-source confirmed 形声, semantic 玉 + phonetic 夐, OC \*qʰʷeːns/\*qʰʷeŋs) reconfirmed correct via en.Wiktionary and zh.Wiktionary; 夐 has no independent vault page and isn't an alias, so the bare citation is correct as-is. `radical: 玉` reconfirmed correct — genuine listing (item 37) on `Lookup/Radicals/Radical 096.md`. `skip_number: 1-4-14` reconfirmed correct — genuine listing (item 6) on `Lookup/SKIP/SKIP-1/SKIP-1-4-14.md`. `stand_in: 瓊玉` reconfirmed correct — genuine citer, the word's own independent page. Already correctly cross-listed on `Lookup/Korean/Korean Name ㄱ.md`.

**`vietnamese` bug found and fixed — one fabricated reading among five genuine**: stored six readings; hvdic.thivien.net's genuine readings are exactly `quỳnh` (Hán Việt) + `quành, quầng, quềnh, quýnh` (Nôm) — `quạnh` appears in neither hvdic nor is corroborated as hvdic-genuine (only in en.Wiktionary's looser list) and was removed as unattested by this vault's sole Vietnamese authority.

**`japanese`/`japanese_native` bugs found and fixed — both incomplete**: `japanese` stored `[KEI]` (kan-on only); both en.Wiktionary and ja.Wiktionary independently confirm a go-on reading, `ギョウ` (GYOU), previously missing; added (ja.Wiktionary's further ゼン/セン candidates weren't corroborated by en.Wiktionary and were left out). `japanese_native` stored `たま` only; both sources also independently confirm kun'yomi `に` (NI); added (further single-sourced candidates — en.Wiktionary's Nanori, ja.Wiktionary's ぬ/うつくしい — were correctly left out).

**`mc_id` off-by-one bug found and fixed**: stored `2386`, which `CC 2000.md` actually assigns to `擬`; 瓊's own genuine exact-match entry is `2388. 瓊`. Corrected.

**`aliases` bug found and fixed — incomplete**: stored `[琼]` only; zh.Wiktionary also dual-confirms (alongside en.Wiktionary) two further genuine variants, `琁` and `瓗`, both with no independent vault page; added.

**`pos`, `joyo_level`, `hsk_level` filled — all three were blank**: `pos` filled as `名詞`. `joyo_level` filled as `表外字` (dual-source confirmed); added as item 608 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format, and added the missing stand-in note to `## Words`. Stamped `date-last-perfect: 2026-08-24` (initially missed on the first pass and corrected immediately).

Next never-perfected character by `danayo_id`: 覓 (8739; 61 characters remaining).

### 2026-08-24, iteration 2443 — [[characters/覓|覓]]

`graphemic_classification: 會意` reconfirmed correct — dual-source confirmed ideographic composition ⿱爫見, 爪 ("hand") + 見 ("to see") via en.Wiktionary and zh.Wiktionary. `radical: 見` reconfirmed correct — genuine listing (item 4) on `Lookup/Radicals/Radical 147.md`. `skip_number: 2-4-7` reconfirmed correct — genuine listing (item 1) on `Lookup/SKIP/SKIP-2/SKIP-2-4-7.md`. `mc_id: 0` reconfirmed correct — genuine sentinel, genuinely absent from all four `CC N000.md` files. `vietnamese: [mích, mạch, mịch]` reconfirmed complete and exact against hvdic.thivien.net. `stand_in: 名専字` reconfirmed correct — zero hits for 覓 anywhere in `words/`. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅁ.md`.

**`hsk_level` bug found and fixed — fabricated value**: stored `6`, but this character is genuinely absent from all six `Old HSK N.md` files (not even a colon-count mention). Corrected to `無` and added to `Lookup/HSK/HSK No.md`.

**`japanese_native` bug found and fixed — truncated**: stored `もと`, a truncation of the ja.Wiktionary-confirmed kun'yomi `もとめる` (MOTOMERU, "to seek"); en.Wiktionary gave no Japanese-reading data at all for this character, so this fix relies on ja.Wiktionary alone, but corrects an existing truncated value rather than adding new unsourced content.

**`aliases` bug found and fixed — incomplete**: stored `[觅]` only; zh.Wiktionary also dual-confirms (alongside en.Wiktionary) a second genuine variant, `覔`, with no independent vault page; added (en.Wiktionary's further single-sourced candidate 𥌚 wasn't corroborated by zh.Wiktionary and was left out).

**`pos`, `joyo_level` filled — both were blank**: `pos` filled as `動詞`. `joyo_level` filled as `表外字` — ja.Wiktionary confirms Hyōgai status explicitly (en.Wiktionary gave no classification at all, so effectively single-sourced); added as item 609 to `Lookup/Japanese/Hyōgai.md`.

Rebuilt the malformed frontmatter section (a duplicate `## Notes` heading with a sparse, incomplete second Notes block) into the standard single `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 𡿺 (8740; 60 characters remaining).

### 2026-08-24, iteration 2444 — [[characters/𡿺|𡿺]]

`radical: 巛` reconfirmed correct — genuine listing (item 5) on `Lookup/Radicals/Radical 047.md`. `skip_number: 2-3-5` reconfirmed correct — genuine listing (item 18) on `Lookup/SKIP/SKIP-2/SKIP-2-3-5.md`. `mc_id: 0` reconfirmed correct — genuine sentinel, genuinely absent from all four `CC N000.md` files. `japanese: [KYUU]` left unchanged as pre-existing, unconfirmable-but-uncontradicted — ja.Wiktionary 404'd for this character, and neither fetched source gave an explicit on'yomi list to check against. `vietnamese` (blank) reconfirmed correct — hvdic.thivien.net explicitly denies any reading ("chưa có giải nghĩa"), a positive absence corroborating the blank field. `aliases: [㐫, ⿱𭕄凶, 瑙, 碯]` reconfirmed correct — zh.Wiktionary explicitly confirms 㐫 as the PRC-simplified equivalent and ⿱𭕄凶 as the Japanese shinjitai form, while 瑙/碯 are confirmed derived/related characters, none with independent vault pages.

**`graphemic_classification`/Notes contradiction found and fixed**: frontmatter stored `會意` while the page's own pre-existing Notes prose instead framed the composition as `象形` ("[List of 象形]"); both en.Wiktionary and zh.Wiktionary describe the composition as combining two distinct semantic elements (巛 "hair" + 囟 "fontanel"), matching 會意 rather than a single pure pictograph. Rebuilt the Notes to match the correct 會意 framing.

**`english` bug found and fixed — etymological-source gloss mistaken for the character's actual meaning**: stored `[fontanel]` (the meaning of one of its own two semantic components, 囟, not of the whole character); both en.Wiktionary and zh.Wiktionary instead confirm 𡿺's own actual meaning is "a traditional variant form of 腦 (brain)." Corrected to `[brain]`, with the fontanel etymology preserved in Notes.

**`stand_in` bug found and fixed — real citer sitting unrecognized**: stored `名専字`, but [[馬𡿺]] genuinely cites 𡿺 in its own `characters:` field (as the vault's own chosen stand-in glyph for 瑪瑙/馬腦 "agate," matching this page's own `aliases: [瑙, 碯]` and `korean_native: 마노` "agate"). Corrected to `馬𡿺` and added a proper `## Words` section.

**`pos`, `joyo_level`, `hsk_level`, `boundedness` filled — all four were blank**: `pos` filled as `名詞`. `joyo_level` filled as `表外字` — zh.Wiktionary explicitly labels it 表外漢字, corroborated by en.Wiktionary's "hyōgai kanji" classification; added as item 610 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`. `boundedness` filled as `90`, consistent with similarly-bound characters with a single genuine stand-in citation.

Rebuilt the malformed frontmatter section (a duplicate `## Notes` heading with a sparse, contradictory second Notes block) into the standard single `## Notes` four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 㒼 (8741; 59 characters remaining).

### 2026-08-24, iteration 2445 — [[characters/㒼|㒼]]

`radical: 冂` reconfirmed correct — genuine listing (item 5) on `Lookup/Radicals/Radical 013.md`. `mc_id: 5921` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [MAN]` reconfirmed and left unchanged — en.Wiktionary also attests a go-on candidate ばん (BAN), but ja.Wiktionary 404'd, so this new candidate couldn't be dual-confirmed and was correctly left unadded. `joyo_level: 表外字`, `hsk_level: 無`, `hanmun_edu_level: 無` all reconfirmed correct — dual-source confirmed classification, genuinely absent from all six `Old HSK N.md` files. `vietnamese` (blank) reconfirmed correct — hvdic.thivien.net explicitly denies any reading ("chưa có giải nghĩa"), a positive absence corroborating the blank field. `stand_in: 名専字` reconfirmed correct — zero hits for 㒼 anywhere in `words/`.

**`stroke_count` investigated — a genuine three-way tension, resolved in favor of the vault's own internal consistency**: both en.Wiktionary and zh.Wiktionary explicitly state 11 total strokes, but this page's own `skip_number: 2-3-7` (a type-2 top-bottom split) mathematically implies exactly 10 strokes (3+7), matching the pre-existing, correctly-filed listing on `Lookup/SKIP/SKIP-2/SKIP-2-3-7.md` (whose own frontmatter independently states `stroke_count: 10`). Kept the pre-existing `10` to preserve consistency with this vault's own structural SKIP classification rather than the external sources, with the conflict documented in Notes.

**`aliases` bug found and fixed — incomplete**: stored `[⿱卄両]` (the Unicode-less shinjitai form) only; zh.Wiktionary also dual-confirms (alongside en.Wiktionary) two further genuine variants, `䓣` and `𬜯`, both with no independent vault page; added.

**`pos` filled — was blank**: filled as `性詞`.

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㅁ.md`'s `### 만` subsection despite the matching `korean: 만`; added. Also added the missing `Lookup/Japanese/Hyōgai.md` and `Lookup/HSK/HSK No.md` cross-references for the already-correct pre-existing `joyo_level`/`hsk_level` values.

**`boundedness` filled — was blank**: filled as `100` (fully bound — no word anywhere cites it, consistent with the pre-existing `#hapax` tag and `stand_in: 名専字`).

Rebuilt the malformed `## Notes` (a single bare bullet about the shinjitai form, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 㐬 (8742; 58 characters remaining).

### 2026-08-24, iteration 2446 — [[characters/㐬|㐬]]

`graphemic_classification: 象形` reconfirmed correct — dual-source confirmed pictograph (a newborn baby shown upside down) via en.Wiktionary and zh.Wiktionary; both sources also confirm 㐬 functions as a variant form of six distinct characters (荒, 不, 巟, 旒, 突, 育), with the page's own `english` gloss reflecting its use as a variant of 旒 specifically — no contradiction between the etymology and the gloss, just two complementary facts about a genuinely polyvalent variant character (matching the pattern already seen this session on 显/𡈼/屮). `radical: 亠` reconfirmed correct — genuine listing on `Lookup/Radicals/Radical 008.md`. `skip_number: 2-4-3` reconfirmed correct — genuine listing on `Lookup/SKIP/SKIP-2/SKIP-2-4-3.md`. `mc_id: 10378` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `vietnamese: [lưu]` reconfirmed complete and exact against hvdic.thivien.net. `joyo_level: 表外字`, `hsk_level: 無`, `hanmun_edu_level: 名` all reconfirmed correct. `stand_in: 名専字` reconfirmed correct — zero hits for 㐬 anywhere in `words/`. `aliases: [旒]` reconfirmed correct — the other five "variant of" relationships (荒, 不, 突, 育 all have independent vault pages; 巟 isn't dual-confirmed) were correctly excluded.

**`japanese`/`japanese_native` misfiled-reading bug found and fixed**: stored `japanese_native: とつ`, but en.Wiktionary's own reading table explicitly lists とつ under Kan-on (on'yomi), not kun'yomi — the same misfiling pattern found on 鸚 earlier this session. Moved it into `japanese` as `TOTSU`, and corrected `japanese_native` to `ø` (ja.Wiktionary 404'd, so the genuine kun'yomi candidates あらい/あれる/あらす/すさむ/あれ/はたあし couldn't be dual-confirmed and were correctly left unadded; a further single-sourced go-on candidate とち was likewise left out of `japanese`).

**`pos`, `boundedness` filled — both were blank**: `pos` filled as `名詞`. `boundedness` filled as `100` (fully bound — no word anywhere cites it, consistent with the pre-existing `#hapax` tag and `stand_in: 名専字`).

Rebuilt the malformed frontmatter section (a duplicate `## Notes` heading with a sparse second Notes block) into the standard single `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 磋 (8743; 57 characters remaining).

### 2026-08-24, iteration 2447 — [[characters/磋|磋]]

`graphemic_classification: 差` (dual-source confirmed 形声, semantic 石 + phonetic 差, OC \*sʰlaːl) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 石` reconfirmed correct — genuine listing on `Lookup/Radicals/Radical 112.md`. `skip_number: 1-5-10` reconfirmed correct — genuine listing on `Lookup/SKIP/SKIP-1/SKIP-1-5-10.md`. `mc_id: 4801` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [SA]` reconfirmed correct and complete — matches both go-on and kan-on さ exactly. `vietnamese: [gây, tha, xoay, xây]` reconfirmed complete and exact against hvdic.thivien.net (one Hán Việt + four Nôm, one overlapping). `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 127. `stand_in: 名専字` reconfirmed correct — zero hits for 磋 anywhere in `words/`. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅊ.md`.

**`hsk_level` bug found and fixed**: stored `4`, but `Old HSK 4.md`'s only mention is a non-genuine colon-count entry (`[[磋]]: 1`); the genuine plain-numbered entry (`81.  [[磋]]`) is on `Old HSK 6.md`. Corrected to `6`.

**`japanese_native` bug found and fixed — truncated**: stored `みが`, a truncation of the dual-confirmed kun'yomi `みがく` (MIGAKU, "to polish"). Corrected.

**`pos` filled — was blank**: filled as `動詞`.

Rebuilt the malformed `## Notes` (a messy phonetic gloss listing six redundant/malformed OC reconstructions, no SKIP/Stroke/mc_id-prose/four-links bullets, `## Chengyu` positioned before Notes was finished) into the standard four-bullet format, preserving the genuine `## Chengyu` entry. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 悖 (8744; 56 characters remaining).

### 2026-08-24, iteration 2448 — [[characters/悖|悖]]

`radical: 心` reconfirmed correct — genuine listing (item 40) on `Lookup/Radicals/Radical 061.md`. `skip_number: 2-3-7` reconfirmed correct — genuine listing (item 12) on `Lookup/SKIP/SKIP-2/SKIP-2-3-7.md`. `mc_id: 1625` reconfirmed exact match (`CC 1000.md`: `1625. 悖`). `japanese_native: もとる` reconfirmed correct and complete. `mandarin: "bèi, bó"` and `cantonese: "bui6, but6"` reconfirmed correct — this vault's own established multi-reading comma-string convention (precedent: `characters/桌 (char).md`, `characters/塔 (char).md`, `characters/排 (char).md`), not a formatting bug. `stand_in: 名専字` reconfirmed correct — zero hits for 悖 anywhere in `words/`. `aliases: [誖, 𢨋, 哱, 愂, 怫, 孛, 𢟥, 𢠜, 𢚦]` reconfirmed correct — zh.Wiktionary explicitly dual-confirms four of these (誖, 孛, 愂, 哱) as the page's own listed variants; the remaining five are pre-existing en.Wiktionary-only values, kept per established policy. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅍ.md`.

**`graphemic_classification` bug found and fixed**: stored the bare classification-type label `形声` instead of a component citation, inconsistent with this vault's established convention (cite the phonetic component itself, e.g. 匡→王, 擅→亶); corrected to `孛`, the dual-source-confirmed true phonetic, which is already hosted on this same page as its own alias.

**`japanese` malformed-YAML bug found and fixed, plus two missing dual-confirmed readings**: stored as a bare unlisted string `BAI, HAI, BOTSU`; converted to a proper list, and added two further genuine on'yomi, `BOCHI` and `HOTSU`, both independently dual-confirmed by en.Wiktionary and ja.Wiktionary (which gives an identical five-reading set: go-on バイ/ボチ/ボツ + kan-on ハイ/ホツ).

**`vietnamese` bug found and fixed — was a bare scalar missing a second reading**: stored `bội` as an unlisted scalar; hvdic.thivien.net also gives a second Hán Việt reading, `bột`; converted to a proper two-item list.

**`joyo_level`, `hsk_level` filled — both were blank**: `joyo_level` filled as `表外字` (dual-source confirmed; ja.Wiktionary also notes the character is now commonly replaced in writing by 背); added as item 612 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`.

Rebuilt the malformed frontmatter section (a stray unresolved editorial question left in Notes — "SHOULD WE GO FOR FOT/BƎT??" — a duplicate `## Notes` heading, and an empty semantic gloss) into the standard single `## Notes` four-bullet format, preserving the flagged secondary MC/Mandarin reading as a documented footnote. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 仗 (8745; 55 characters remaining).

### 2026-08-24, iteration 2449 — [[characters/仗|仗]]

`graphemic_classification: 丈` (dual-source confirmed 形声, semantic 亻+ phonetic [[丈]], OC \*daŋʔ with a departing-tone \*-s suffix) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 人` reconfirmed correct. `skip_number: 1-2-3` reconfirmed correct. `mc_id: 4654` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `hsk_level: 6` reconfirmed correct — genuine plain-numbered entry (`231.  [[仗]]`) on `Old HSK 6.md`. `vietnamese: [dượng, trượng]` reconfirmed complete and exact against hvdic.thivien.net. `joyo_level: 表外字` reconfirmed correct. `japanese: [JOU]` reconfirmed and left unchanged — both sources agree on go-on じょう(JOU), but disagree on the kan-on candidate (en gives しょう/SHOU, ja gives チョウ/CHOU), so neither was added given the direct contradiction. `aliases` (blank) reconfirmed correct — the wood-radical [[杖 (char)|杖]] ("staff, cane") is only phonetically related (same 丈-series) but semantically distinct, already independently paged in this vault, correctly excluded. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅈ.md`.

**`stand_in` bug found and fixed — real citer sitting unrecognized**: stored `名専字`, but [[儀仗]] genuinely cites 仗 in its own `characters:` field. Corrected to `儀仗` and added a proper `## Words` section.

**`japanese_native` bug found and fixed — badly incomplete**: stored `つえ` only; both en.Wiktionary and ja.Wiktionary independently confirm two further genuine kun'yomi, `つわもの` (TSUWAMONO, "warrior") and `よる` (YORU, "to rely on"); added (ja.Wiktionary's further single-sourced candidate まわり wasn't corroborated by en.Wiktionary and was left out).

**`pos` filled — was blank**: filled as `名詞`.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format plus a proper `## Words` section. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 啼 (8746; 54 characters remaining).

### 2026-08-24, iteration 2450 — [[characters/啼|啼]]

`graphemic_classification: 帝` (dual-source confirmed 形声, semantic 口 + phonetic [[帝]], OC \*teːɡs) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 口` reconfirmed correct. `skip_number: 1-3-9` reconfirmed correct. `japanese: [TEI]` reconfirmed correct — matches en.Wiktionary's kan-on てい exactly. `vietnamese: [đề]` reconfirmed complete and exact against hvdic.thivien.net. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 285. `stand_in: 名専字` reconfirmed correct — the sole grep hit, [[words/夜半|夜半]], is a false-positive prose mention. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅈ.md`.

**`hsk_level` bug found and fixed — fabricated value**: stored `5`, but this character is genuinely absent from all six `Old HSK N.md` files (not even a colon-count mention). Corrected to `無` and added to `Lookup/HSK/HSK No.md`.

**`mc_id` off-by-one bug found and fixed**: stored `2816`, which `CC 2000.md` actually assigns to `逡`; 啼's own genuine exact-match entry is `2818. 啼`. Corrected.

**`aliases` bug found and fixed — two fabricated entries, one genuine addition missing**: stored `[嗁, 㖒, 嚏, 㖷, 渧, 䶑]`; cross-checking against both sources found `嗁, 㖒, 㖷, 渧` genuinely dual-confirmed (kept), but `嚏` and `䶑` appear in neither en.Wiktionary nor zh.Wiktionary and were removed as unattested/fabricated; a newly dual-confirmed candidate, `諦`, was correctly left unadded since it already has its own independent vault page (`characters/諦 (char).md`), failing the alias-independence test.

**`japanese_native` bug found and fixed — truncated**: stored `な`, a truncation of the dual-confirmed kun'yomi `なく` (NAKU, "to cry"). Corrected.

**`pos` filled — was blank**: filled as `動詞`.

Rebuilt the malformed `## Notes` (a stray informal placeholder note about the conlang sound choice, malformed lowercase-path links, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard four-bullet format, preserving the conlang-sound-choice note as a clause within the first bullet. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 躁 (8747; 53 characters remaining).

### 2026-08-24, iteration 2451 — [[characters/躁|躁]]

`graphemic_classification: 喿` (dual-source confirmed 形声, semantic 足 + phonetic 喿) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 足` reconfirmed correct. `skip_number: 1-7-13` reconfirmed correct. `japanese: [SOU]` reconfirmed correct and complete — matches both go-on and kan-on そう exactly. `joyo_level: 表外字` reconfirmed correct. `stand_in: 名専字` reconfirmed correct — zero hits for 躁 anywhere in `words/`. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅈ.md`.

**`hsk_level` bug found and fixed**: stored `3`, but `Old HSK 3.md`'s only mention is a non-genuine colon-count entry (`[[躁]]: 1`); the genuine plain-numbered entry (`225.  [[躁]]`) is on `Old HSK 6.md`. Corrected to `6`.

**`vietnamese` bug found and fixed — one fabricated near-duplicate reading**: stored `[rão, rảo, tháo, táo]`; hvdic.thivien.net's genuine readings are exactly `táo` (Hán Việt) + `rảo, táo, tháo` (Nôm) — `rão` (a distinct diacritic from the genuine `rảo`, already separately present) appears in neither source and was removed as a fabrication/typo.

**`mc_id` off-by-one bug found and fixed**: stored `1986`, which `CC 1000.md` actually assigns to `借`; 躁's own genuine exact-match entry is `1987. 躁`. Corrected.

**`japanese_native` bug found and fixed — truncated**: stored `さわ`, a truncation of the dual-confirmed kun'yomi `さわぐ` (SAWAGU, "to be agitated, clamor"). Corrected.

**`aliases` bug found and fixed — was blank**: both en.Wiktionary and zh.Wiktionary dual-confirm `趮` as a genuine variant form with no independent vault page; added (zh.Wiktionary's further single-sourced candidate 懆 wasn't corroborated by en.Wiktionary and was left out).

**`pos` filled — was blank**: filled as `性詞`.

Rebuilt the malformed `## Notes` (two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 㐱 (8748; 52 characters remaining).

### 2026-08-24, iteration 2452 — [[characters/㐱|㐱]]

`radical: 人` reconfirmed correct — genuine listing (item 8) on `Lookup/Radicals/Radical 009.md`. `skip_number: 2-2-3` reconfirmed correct — genuine listing on `Lookup/SKIP/SKIP-2/SKIP-2-2-3.md`. `mc_id: 4879` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [SHIN]` reconfirmed correct and complete — matches both go-on and kan-on シン exactly. `aliases: [鬒]` reconfirmed correct — both sources explicitly confirm 㐱 as a genuine variant form of 鬒 ("此字是「鬒」的異體字"). `stand_in: 名専字` reconfirmed correct — zero hits for 㐱 anywhere in `words/`. `joyo_level` (blank) reconfirmed correct — neither en.Wiktionary nor ja.Wiktionary gives any Japanese classification for this rare Extension A character.

**`graphemic_classification` bug found and fixed**: stored `指事`, but both en.Wiktionary and zh.Wiktionary independently and explicitly classify this as `會意` (人 "person" + 彡 "hair"). Corrected.

**`vietnamese` bug found and fixed — one reading swapped for a distinct, unattested one**: stored `[chín, chỉn, xỉn]`; hvdic.thivien.net's genuine readings are exactly `chẩn` (Hán Việt) + `chín, xỉn` (Nôm) — `chỉn` (a different word entirely from the genuine `chẩn`) appears in neither source and was removed; the genuine `chẩn` reading, entirely missing from the stored set, was added.

**`pos`, `hsk_level`, `hanmun_edu_level` filled — all three were blank**: `pos` filled as `名詞`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`. `hanmun_edu_level` filled as `無`.

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㅈ.md`'s `### 진` subsection despite the matching `korean: 진`; added.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 冘 (8749; 51 characters remaining).

### 2026-08-24, iteration 2453 — [[characters/冘|冘]]

`graphemic_classification: 象形` investigated — en.Wiktionary explicitly describes a pictograph (a person carrying an object on their shoulder, original form of 儋); zh.Wiktionary doesn't corroborate this specific etymology but doesn't contradict it either (giving only a broader "people proceeding together" gloss without a stated classification type), so kept as single-sourced-but-uncontradicted. `radical: 冖` reconfirmed correct. `skip_number: 3-3-1` reconfirmed correct. `mc_id: 4486` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `stand_in: 名専字` reconfirmed correct — zero hits for 冘 anywhere in `words/`. `aliases` (blank) reconfirmed correct — en.Wiktionary's single-sourced 𢓕 candidate wasn't corroborated by zh.Wiktionary.

**`japanese` bug found and fixed — malformed reading**: stored `[IN, IU, YU]`; the bare `IU` didn't match any genuine reading in either source — both en.Wiktionary and ja.Wiktionary instead confirm `ゆう` (long vowel, romanized `YUU` per this vault's own doubled-letter convention), an evident typo. Corrected `IU` → `YUU`, now fully dual-confirmed alongside the pre-existing `IN`/`YU`.

**`japanese_native` bug found and fixed — explicitly denied by the authoritative source**: stored `おこた` (truncated from the single-sourced en.Wiktionary candidate おこたる); ja.Wiktionary explicitly lists no kun'yomi at all for this character, directly denying it (matching the established "explicit denial overrides single-sourced claim" precedent from 屮/彖/冘 this session). Corrected to `ø`.

**`vietnamese` bug found and fixed — two fabricated readings**: stored `[dâm, nhũng, đem, đăm, đơm]`; hvdic.thivien.net's genuine readings are exactly `dâm` (Hán Việt) + `dâm, đem, nhũng` (Nôm) — `đăm` and `đơm` appear in neither source and were removed as fabrications.

**`pos`, `joyo_level`, `hsk_level`, `hanmun_edu_level` filled — all four were blank**: `pos` filled as `動詞`. `joyo_level` filled as `表外字` (dual-source confirmed); added as item 613 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`. `hanmun_edu_level` filled as `名`.

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㅇ.md`'s `### 유` subsection despite the matching `korean: 유`; added.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format, preserving the genuine pre-existing `## Derived Characters` section. Stamped `date-last-perfect: 2026-08-24` (initially missed on the first pass and corrected immediately).

Next never-perfected character by `danayo_id`: 劦 (8750; 50 characters remaining).

### 2026-08-24, iteration 2454 — [[characters/劦|劦]]

`graphemic_classification: 會意` reconfirmed correct — dual-source confirmed ideographic composition (three 力 "plough" stacked together, symbolizing collective effort) via en.Wiktionary and zh.Wiktionary. `radical: 力` reconfirmed correct — genuine listing (item 5) on `Lookup/Radicals/Radical 019.md`. `skip_number: 2-2-4` reconfirmed correct — genuine listing (item 9) on `Lookup/SKIP/SKIP-2/SKIP-2-2-4.md`. `mc_id: 5587` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [KYOU, GYOU, RYOU]` reconfirmed and left unchanged — ja.Wiktionary confirms only KYOU/GYOU explicitly, but RYOU is a pre-existing single-sourced value (en.Wiktionary) that ja.Wiktionary merely omits rather than explicitly denies, so kept per established policy. `vietnamese: [hiệp]` reconfirmed complete and exact against hvdic.thivien.net. `pos: 名詞`, `joyo_level: 表外字`, `hsk_level: 無`, `hanmun_edu_level: 名` all reconfirmed correct. `stand_in: 名専字` reconfirmed correct — zero hits for 劦 anywhere in `words/`. `aliases` (blank) reconfirmed correct — both sources describe 劦 as "an alternate form of" [[協]], but 協 already has its own independent vault page, correctly excluded from `aliases`. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅎ.md`.

**`japanese_native` bug found and fixed — explicitly denied by the authoritative source**: stored `にわか` (single-sourced from en.Wiktionary); ja.Wiktionary explicitly lists no kun'yomi at all for this character, directly denying it (matching the established "explicit denial overrides single-sourced claim" precedent used repeatedly this session). Corrected to `ø`.

**Missing `Hyōgai.md` entry found and fixed**: `joyo_level: 表外字` (pre-existing, reconfirmed correct) was missing from `Lookup/Japanese/Hyōgai.md`'s own list; added as item 614.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 綽 (8751; 49 characters remaining).

### 2026-08-24, iteration 2455 — [[characters/綽|綽]]

`graphemic_classification: 卓` (dual-source confirmed 形声, semantic 糸 + phonetic [[卓]], OC \*tʰjewɢ) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 糸` reconfirmed correct. `skip_number: 1-6-8` reconfirmed correct. `japanese: [SHAKU]` reconfirmed correct and complete. `joyo_level: 表外字` reconfirmed correct — genuine at `Lookup/Japanese/Hyōgai.md` item 142. `stand_in: 綽約` reconfirmed correct — genuine citer, the word's own independent page. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅈ.md`.

**`aliases` bug found and fixed — two false aliases (cognates, not variants)**: stored `[淖, 婥, 绰]`; zh.Wiktionary explicitly distinguishes true 異體字 (𮈱, 繛, 𦅕, 𦈀 — all obscure/unencodable, single-sourced, correctly left unadded) from mere phonetic cognates sharing the same 卓-series root — 淖 and 婥 are only described as the latter, not genuine variants, by either source. Removed both, keeping only `绰` (the genuinely confirmed simplified form).

**`vietnamese` bug found and fixed — one fabricated reading**: stored `[trạo, xước, xược]`; hvdic.thivien.net's genuine readings are exactly `xước` (Hán Việt) + `trạo, xước` (Nôm) — `xược` appears in neither source and was removed as a fabrication.

**`japanese_native` bug found and fixed — badly incomplete**: stored `あだ` only; both en.Wiktionary and ja.Wiktionary independently confirm two further genuine kun'yomi, `しなやか` (SHINAYAKA) and `ゆるやか` (YURUYAKA); added.

**`mc_id` off-by-one bug found and fixed**: stored `3162`, which `CC 3000.md` actually assigns to `皙`; 綽's own genuine exact-match entry is `3163. 綽`. Corrected.

**`pos`, `hsk_level` filled — both were blank**: `pos` filled as `性詞`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`.

Rebuilt the malformed page structure (a `## Words` section positioned before a wrong-heading-level `# Notes`, two bare unlinked CC wikilinks) into the standard `## Notes` four-bullet format followed by `## Words`, and added the missing stand-in note. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 匕 (8752; 48 characters remaining).

### 2026-08-24, iteration 2456 — [[characters/匕|匕]]

`graphemic_classification: 象形` reconfirmed correct — dual-source confirmed pictograph (an ancient spoon) via en.Wiktionary and zh.Wiktionary. `radical: 匕` reconfirmed correct — 匕 is itself Radical 21 (self-radical). `skip_number: 3-1-1` reconfirmed correct. `japanese: [HI]` and `japanese_native: さじ` both reconfirmed correct and complete — dual-source confirmed exactly (a further ja.Wiktionary-only candidate ならぶ wasn't corroborated by en.Wiktionary and was correctly left unadded). `joyo_level: 表外字` reconfirmed correct (dual-source); was missing from `Lookup/Japanese/Hyōgai.md`'s own list — added as item 615. `pos: 名詞` reconfirmed correct. `stand_in: 名専字` reconfirmed correct — the sole grep hit, [[words/老|老]], is a false-positive prose mention. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅂ.md`.

**`vietnamese` bug found and fixed — badly incomplete**: stored `[chuỷ]` only; hvdic.thivien.net also gives two further Hán Việt readings, `truỷ` and `tỷ`, both missing. Added.

**`mc_id` off-by-one bug found and fixed**: stored `2091`, which `CC 2000.md` actually assigns to `埋`; 匕's own genuine exact-match entry is `2092. 匕`. Corrected.

**Missing `Hyōgai.md` and `HSK No.md` entries found and fixed**: both pre-existing correct field values (`joyo_level`, `hsk_level`) were missing from their respective lookup pages; added.

Rebuilt the malformed page structure (a duplicate `## Notes` heading with a second, sparse Notes block) into the standard single `## Notes` four-bullet format, and fixed a broken lowercase `lookup/` path in the page's own radical-disambiguation callout. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 厓 (8753; 47 characters remaining).

### 2026-08-24, iteration 2457 — [[characters/厓|厓]]

`graphemic_classification: 圭` (dual-source confirmed 形声, semantic 厂 + phonetic 圭) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 厂` reconfirmed correct. `skip_number: 3-2-6` reconfirmed correct. `mc_id: 4619` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [GAI, GE, GI]` reconfirmed and left unchanged — en.Wiktionary confirms GAI/GE explicitly, but ja.Wiktionary 404'd, so the pre-existing third value `GI` (unconfirmed by either fetched source, but not explicitly contradicted either) was kept per established policy. `japanese_native: がけ` reconfirmed correct — a further two en.Wiktionary-only candidates (きし, はて) weren't dual-confirmed and were left unadded. `stand_in: 名専字` reconfirmed correct — zero hits for 厓 anywhere in `words/`. `aliases` (blank) reconfirmed correct — zh.Wiktionary's most prominent listed variant, 崖, already has its own independent vault page (`characters/崖 (char).md`), correctly excluded; the remaining variants (涯, 崕, 漄, 睚, etc.) are either independently paged too or too obscure. Already correctly cross-listed on `Lookup/Korean/Korean Name ㅇ.md`.

**`vietnamese` bug found and fixed — badly incomplete**: stored `[day]` only; hvdic.thivien.net also gives the primary Hán Việt reading, `nhai`, entirely missing. Added.

**`pos`, `joyo_level`, `hsk_level`, `boundedness` filled — all four were blank**: `pos` filled as `名詞`. `joyo_level` filled as `表外字` (dual-source confirmed); added as item 616 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`. `boundedness` filled as `90`, consistent with similarly-bound characters with no genuine stand-in citation.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 叚 (8754; 46 characters remaining).

### 2026-08-24, iteration 2458 — [[characters/叚|叚]]

`graphemic_classification: 會意` reconfirmed correct — dual-source confirmed ideographic composition (爪+又+石) via en.Wiktionary and zh.Wiktionary. `radical: 又` reconfirmed correct. `skip_number: 1-5-4` reconfirmed correct. `japanese: [KA, KE, GE]` reconfirmed correct and complete — matches both go-on け/げ and kan-on か exactly. `pos: 性詞`, `joyo_level: 表外字`, `hanmun_edu_level: 無` all reconfirmed correct. `stand_in: 名専字` reconfirmed correct — the sole grep hit, [[words/石|石]], is a false-positive prose mention. `aliases: [𠭊]` reconfirmed correct — en.Wiktionary's confirmed genuine variant.

**`japanese_native` misfiled-reading bug found and fixed**: stored `か`, which is actually the character's own kan-on on'yomi reading (already correctly listed in `japanese`), not a kun'yomi at all — the same misfiling pattern found on 鸚/㐬 earlier this session. Both en.Wiktionary and ja.Wiktionary independently confirm the genuine kun'yomi are `かりる` (KARIRU, "to borrow") and `かす` (KASU, "to lend"); moved into `japanese_native` accordingly.

**`vietnamese` bug found and fixed — incomplete**: stored `[giả]` only; hvdic.thivien.net also gives a second Hán Việt reading, `giá`, missing. Added.

**`mc_id` off-by-one bug found and fixed**: stored `3685`, which `CC 3000.md` actually assigns to `郄`; 叚's own genuine exact-match entry is `3686. 叚`. Corrected.

**`hsk_level` filled — was blank**: filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`.

**Two missing lookup-page cross-references found and fixed**: `joyo_level: 表外字` (pre-existing, reconfirmed correct) was missing from `Lookup/Japanese/Hyōgai.md`'s own list — added as item 617. Absent from `Lookup/Korean/Korean Name ㄱ.md`'s `### 가` subsection despite the matching `korean: 가` — added.

Rebuilt the malformed `## Notes` (a broken lowercase `../lookup/` path link, two bare unlinked CC wikilinks, a wrong-level `### Derived Character` heading) into the standard `## Notes` four-bullet format, correcting the heading to `## Derived Characters` for consistency with this vault's convention. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 夌 (8756; 45 characters remaining).

### 2026-08-24, iteration 2459 — [[characters/夌|夌]]

`radical: 夂` investigated and reconfirmed correct — both en.Wiktionary and zh.Wiktionary describe the radical loosely as "夊" (a visually near-identical but distinct Kangxi radical), but this vault's own `Lookup/Radicals/Radical 034.md` already correctly lists 夌 as item 2, confirming internal consistency with the stored `夂` (Radical 34); trusted the vault's own established classification over the ambiguous external summaries. `graphemic_classification: 會意` reconfirmed correct — dual-source confirmed (Shuowen: 夊+高, "to exceed, surpass"). `skip_number: 2-5-3` reconfirmed correct. `mc_id: 5742` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [RYOU]` reconfirmed correct and complete — matches both go-on and kan-on りょう exactly. `stand_in: 名専字` reconfirmed correct — zero hits for 夌 anywhere in `words/`. `aliases` (blank) reconfirmed correct — both sources describe 夌 as the historical original form of [[凌]] and [[陵]] (both already independently paged in this vault), a derivation relationship rather than synchronic variant status; correctly excluded.

**`vietnamese` bug found and fixed — was blank**: hvdic.thivien.net (sole authority) gives `lăng`; added.

**`japanese_native` bug found and fixed — truncated and incomplete**: stored `しの`, a truncation of the genuine kun'yomi `しのぐ` (SHINOGU); both en.Wiktionary and ja.Wiktionary also independently confirm a second kun'yomi, `すたれる` (SUTARERU), previously missing entirely. Corrected to `[しのぐ, すたれる]`.

**`pos`, `joyo_level`, `hsk_level`, `hanmun_edu_level` filled — all four were blank**: `pos` filled as `動詞`. `joyo_level` filled as `表外字` (dual-source confirmed); added as item 618 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`. `hanmun_edu_level` filled as `名`.

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㄹ.md`'s `### 릉` subsection despite the matching `korean: 릉`; added.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 夗 (8757; 44 characters remaining).

### 2026-08-24, iteration 2460 — [[characters/夗|夗]]

`graphemic_classification: 象形` reconfirmed correct — dual-source confirmed pictograph ("an animal lying down about to die," per Ji Xusheng) via en.Wiktionary and zh.Wiktionary. `radical: 夕` reconfirmed correct. `skip_number: 1-3-2` reconfirmed correct. `mc_id: 5207` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [EN, ON]` reconfirmed correct and complete. `japanese_native: ø` reconfirmed correct — ja.Wiktionary explicitly lists no kun'yomi, correctly overriding en.Wiktionary's single-sourced claim (ころがりうす). `stand_in: 名専字` reconfirmed correct — zero hits for 夗 anywhere in `words/`.

**`vietnamese` bug found and fixed — was blank**: hvdic.thivien.net (sole authority) gives `uyển`; added.

**`aliases` bug found and fixed — was blank**: both en.Wiktionary and zh.Wiktionary dual-confirm `夘` as a genuine variant form with no independent vault page; added (en.Wiktionary's further single-sourced candidate 𡖅 wasn't corroborated by zh.Wiktionary and zh.Wiktionary's own further candidate 鴛 already has its own independent vault page, both correctly left out).

**`pos`, `joyo_level`, `hsk_level`, `hanmun_edu_level` filled — all four were blank**: `pos` filled as `動詞`. `joyo_level` filled as `表外字` (dual-source confirmed); added as item 619 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`. `hanmun_edu_level` filled as `名`.

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㅇ.md`'s `### 원` subsection despite the matching `korean: 원`; added.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 尃 (8758; 43 characters remaining).

### 2026-08-24, iteration 2461 — [[characters/尃|尃]]

`graphemic_classification: 甫` (dual-source confirmed 形声, semantic 寸 + phonetic [[甫]], OC \*paʔ) reconfirmed correct via en.Wiktionary and zh.Wiktionary. `radical: 寸` reconfirmed correct. `skip_number: 2-7-3` reconfirmed correct. `mc_id: 4626` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [FU, HO]` reconfirmed correct and complete — matches both sources' go-on/kan-on ふ/ほ exactly. `stand_in: 名専字` reconfirmed correct — zero hits for 尃 anywhere in `words/`. `aliases` (blank) reconfirmed correct — zh.Wiktionary confirms 尃 is "an alternative written form" of [[敷 (char)|敷]], but 敷 already has its own independent vault page, correctly excluded.

**`vietnamese` bug found and fixed — was blank**: hvdic.thivien.net (sole authority) gives `phu`; added.

**`japanese_native` bug found and fixed — badly incomplete**: stored `しく` only; both en.Wiktionary and ja.Wiktionary independently confirm three further genuine kun'yomi, `あまねし` (AMANESHI), `もと` (MOTO), and `はらう` (HARAU), all missing. Added all three.

**`pos`, `joyo_level`, `hsk_level`, `hanmun_edu_level` filled — all four were blank**: `pos` filled as `動詞`. `joyo_level` filled as `表外字` (dual-source confirmed); added as item 620 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`. `hanmun_edu_level` filled as `名`.

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㅍ.md`'s `### 포` subsection despite the matching `korean: 포`; added.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 尗 (8759; 42 characters remaining).

### 2026-08-24, iteration 2462 — [[characters/尗|尗]]

`radical: 小` reconfirmed correct (Kangxi radical 42, composed ⿱上小) via en.Wiktionary. `skip_number: 2-3-3` and `stroke_count: 6` reconfirmed correct against `SKIP-2-3-3.md` and `Stroke 06.md`, both of which already listed the character. `mc_id: 4159` reconfirmed as trusted long-tail (>4000, `CC 3000.md`'s own numbered list tops out at exactly 4000, confirming 4159 falls outside the checkable range per policy). `joyo_level: 表外字` reconfirmed correct (Hyōgai kanji, non-Jōyō). `hsk_level: 無` reconfirmed correct — absent from all six `Old HSK N.md` files. `vietnamese: [thúc, thảm]` reconfirmed correct — hvdic.thivien.net (sole authority) gives exactly these two: `thúc` under Âm Hán Việt, `thảm` under Âm Nôm. `stand_in: 名専字` reconfirmed correct — zero hits for 尗 anywhere in `words/`, so no `## Words` section needed. `aliases` (blank) reconfirmed correct — 尗 is cited by both sources as a variant/古字 of both [[叔]] and 菽, but 叔 already has its own independent vault page (correctly excluded) and 菽 has no vault page at all (nothing to alias to).

**Content-mismatch bug found and fixed — `english`/`korean_native` contradicted `japanese_native`**: the page carried `english: younger brother of husband` and `korean_native: 아저씨` ("uncle"), flatly contradicting its own pre-existing `japanese_native: まめ` ("bean"). Direct Shuowen quotation via zh.Wiktionary settles it unambiguously: "豆也。象尗豆生之形也" — "beans; depicts the shape of beans sprouting." 尗's true pictographic core meaning is "bean, legume"; "uncle/younger brother of husband" is a secondary phonetic-loan sense that properly belongs to [[叔]] (which uses 尗 as its phonetic component — corrected `叔.md`'s own Notes bullet in passing, which had mischaracterized 尗's original sense as "wooden stake" rather than "bean plant," a stale citation now contradicted by the primary Shuowen text). Changed `english` to `[bean, legume]` and `korean_native` to `콩`, matching `japanese_native: まめ`. Propagated the corrected gloss to the inline captions in `Radical 042.md` and `SKIP-2-3-3.md` (both previously read "younger brother of husband").

**`cantonese` bug found and fixed — internally inconsistent with its own `middle_chinese_initial`**: stored `suk6` (voiced-class/陽 tone reflex), but `middle_chinese_initial: ɕ` is voiceless, which regularly reflexes to a voiceless-class/陰 tone in Cantonese entering-tone syllables — confirmed against [[叔]] itself, which shares the identical MC reading (ɕ + ɨuk) and is independently verified as `suk1`. Corrected to `suk1`.

**Missing lookup entries found and fixed**: absent from `Lookup/Korean/Korean Name ㅅ.md`'s `### 숙` subsection despite `korean: 숙`; added. Absent from `Lookup/Japanese/Hyōgai.md`; added as item 621. Absent from `Lookup/HSK/HSK No.md`; added.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format, updating the etymology prose to reflect the corrected bean-plant pictogram sense. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 巠 (8760; 42 characters remaining).

### 2026-08-24, iteration 2463 — [[characters/巠|巠]]

`radical: 巛` reconfirmed correct (Kangxi radical 47, composed ⿳一巛工) via en.Wiktionary. `skip_number: 2-4-3` and `stroke_count: 7` reconfirmed correct against `SKIP-2-4-3.md` and `Stroke 07.md`, both already listing the character. `mc_id: 4116` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `japanese: [KEI, KYOU]` reconfirmed correct and complete — matches ja.Wiktionary's kan-on けい/goon きょう exactly. `japanese_native: ø` reconfirmed correct — ja.Wiktionary explicitly states no kun'yomi listed. `mandarin`, `cantonese`, `korean`, `middle_chinese_initial/final`, `graphemic_classification: 象形`, `stand_in: 名専字` all reconfirmed correct. Zero hits for 巠 anywhere in `words/`, confirming no `## Words` section needed.

**`aliases` bug found and fixed — false alias 圣 removed**: the page listed `坙`, `𢀖`, and `圣` as aliases. `坙` and `𢀖` are dual-source confirmed genuine 異體字 (both en.Wiktionary and zh.Wiktionary). `圣`, however, is unrelated: zh.Wiktionary's own entry for 圣 identifies it as either a non-standard Ming-dynasty variant of [[聖]] (which already correctly lists 圣 as its own alias) or a distinct archaic "to dig" character (又+土) — zh.Wiktionary's 巠 entry explicitly separates 圣-derived characters from the true 巠-derived phonetic series (經/経, 徑, 輕, 涇, etc.) and never documents 圣 as a variant of 巠. Removed the false alias.

**`vietnamese`, `joyo_level`, `hsk_level`, `hanmun_edu_level` filled — all four were blank**: `vietnamese` filled as `kinh` (hvdic.thivien.net sole authority, only Âm Hán Việt reading listed). `joyo_level` filled as `表外字` (dual-source confirmed Hyōgai kanji); added as item 622 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`. `hanmun_edu_level` filled as `無`.

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㄱ.md`'s `### 경` subsection despite `korean: 경`; added.

**Stray duplicate field removed**: `品詞: "名詞"` — a vestigial duplicate of the already-present `pos: "名詞"` field (found on only 10 character pages vault-wide, not part of the standard schema); removed.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Discovered that the etymological citation target for the true traditional ancestor character uses the vault's shinjitai-form filename `経 (char).md`, not `經 (char).md` (no such page exists) — cited correctly. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 昷 (8761; 41 characters remaining).

### 2026-08-24, iteration 2464 — [[characters/昷|昷]]

`radical: 日` reconfirmed correct (Kangxi radical 72, composed ⿱日皿). `skip_number: 2-4-5` and `stroke_count: 9` reconfirmed correct against `SKIP-2-4-5.md` and `Stroke 09.md`, both already listing the character. `mc_id: 0` reconfirmed as a genuine sentinel — absent from all four `CC N000.md` files, not a data gap. `graphemic_classification: 指事` and `aliases: [𥁕, 𣌬]` reconfirmed correct — dual-source confirmed 異體字 for both, per the "List of 指事" citation and zh.Wiktionary's variant-relationship documentation. `english: feed a prisoner` and the native glosses (`japanese_native`, `korean_native: 어질`) reconfirmed correct and mutually consistent — they trace a distinct semantic thread (via the 𥁕 "kind, benevolent" variant sense and Xu Shen's alternate compound theory) deliberately separate from 温's own "warm" gloss, since 昷 is also independently the pictographic ancestor of 溫/温 (explaining `vietnamese: ôn` and `korean: 온`, both purely phonetic continuations, not semantic duplicates). Zero hits for 昷 anywhere in `words/`, confirming no `## Words` section needed. Already correctly listed in `Lookup/List of 指事.md` (#75) and in `Lookup/Korean/Korean Name ㅇ.md`'s `### 온` subsection — no Korean lookup fix needed this iteration.

**`japanese_native` bug found and fixed — truncated**: stored `めぐ` (a fragment), should be `めぐむ` (megumu, "to show mercy/compassion") per en.Wiktionary. ja.Wiktionary's own entry for 昷 is an unreferenced stub (only 漢字/意義 sections, no 発音/読み section at all) — not an explicit denial, so the pre-existing single-sourced en.Wiktionary value is trusted and restored to its full form rather than wiped.

**`vietnamese`, `pos`, `joyo_level`, `hsk_level` filled — all four were blank**: `vietnamese` filled as `ôn` (hvdic.thivien.net sole authority, only Âm Hán Việt reading listed). `pos` filled as `動詞` (matching the verbal "feed a prisoner" gloss). `joyo_level` filled as `表外字` (single-sourced Hyōgai classification via en.Wiktionary — ja.Wiktionary's stub doesn't cover Joyo/Jinmeiyo/Hyōgai status but doesn't contradict either, and the classification is the residual default for an obscure non-list character); added as item 623 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`.

**`boundedness` filled — was blank**: set to `75`, consistent with comparable bound/hapax-tagged peer characters (60–80 range observed across 冘, 屮, 劦, 温).

Rebuilt the malformed Notes (missing standard SKIP/Stroke/mc_id-prose/four-links bullets, informal "Derived characters" heading) into the standard `## Notes` four-bullet format plus a properly-headed `## Derived Characters` section (ruby-formatted, matching the 屮.md precedent), retaining the two dual-source-confirmed derived characters already present ([[温 (char)|温]], [[腽]]) — the several dozen other component-users en.Wiktionary mentions (醖, 韞, etc.) have no independent vault pages, so excluded. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 雉 (char) (8762; 40 characters remaining).

### 2026-08-24, iteration 2465 — [[characters/雉 (char)|雉 (char)]]

`radical: 隹` reconfirmed correct (Kangxi radical 172). `skip_number: 1-5-8` and `stroke_count: 13` reconfirmed correct against `SKIP-1-5-8.md` and `Stroke 13.md`, both already listing the character. `japanese: [CHI, JI]` reconfirmed correct and complete — matches ja.Wiktionary's kan-on チ/goon ジ exactly. `japanese_native: きじ` reconfirmed correct — ja.Wiktionary's own kun'yomi list gives only きじ, not corroborating en.Wiktionary's extra single-sourced かき claim, so that was correctly left out (not added). `joyo_level: 表外字` and `hanmun_edu_level: 名` reconfirmed correct. `vietnamese` (all seven: dẽ, giẽ, rẽ, trĩ, trảy, trẩy, trễ) reconfirmed correct and complete — hvdic.thivien.net (sole authority) lists exactly these seven across its Âm Hán Việt and Âm Nôm sections, an unusually large but fully corroborated set. `stand_in: 雉` reconfirmed correct — this is a genuine dual-page character/word split (both `characters/雉 (char).md` and `words/雉.md` exist and correctly cross-reference each other via tip callouts), not a `名専字`-style bound character.

**`graphemic_classification` bug found and fixed — cited the semantic radical instead of the phonetic**: stored `隹`, but 隹 is confirmed by both en.Wiktionary and zh.Wiktionary to be the *semantic* component ("bird"); the actual phonetic is [[矢 (char)|矢]] ("arrow", OC \*l̥ilʔ), which has its own independent vault page. Corrected to `矢`, per the vault convention of citing the phonetic component.

**`mc_id` off-by-one bug found and fixed**: stored `1610`, which is actually 慢's rank in `CC 1000.md`; 雉's genuine entry is `1611. 雉`. Corrected to `1611`.

**`pos` and `hsk_level` filled — both were blank**: `pos` filled as `名詞`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`.

Built the missing `## Notes` section from scratch (previously just two bare unlinked CC wikilinks with no heading at all) into the standard four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 氐 (8764; 39 characters remaining).

### 2026-08-24, iteration 2466 — [[characters/氐|氐]]

`radical: 氏` reconfirmed correct (Kangxi radical 83). `skip_number: 2-4-1` and `stroke_count: 5` reconfirmed correct against `SKIP-2-4-1.md` and `Stroke 05.md`, both already listing the character. `aliases: [柢]` reconfirmed correct — zh.Wiktionary confirms 氐 as 異體字 of 低, 抵, 柢, and 底, but 低/抵/底 (char) all already have independent vault pages and are correctly excluded; only 柢 (no independent vault page) legitimately remains. `english: root` reconfirmed correct, matching the "variant of 柢" sense. Zero hits for 氐 anywhere in `words/`, confirming `stand_in: 名専字` and no `## Words` section needed.

**Major `japanese`/`japanese_native` conflict resolved — en.Wiktionary's broader single-sourced claims overridden by ja.Wiktionary's complete authoritative reading list**: the page stored `japanese: [TEI, TAI, SHI, CHI]` and `japanese_native: ふもと` ("foot of a mountain"), both sourced from en.Wiktionary. Direct ja.Wiktionary fetch (quoting the raw 発音 section) gives a completely different, internally coherent picture: on'yomi限定 to just 呉音タイ/漢音テイ (no ジ/シ/ダイ), and kun'yomi とも・なやむ・ひくい・ふす — none of which is ふもと. Critically, the ja.Wiktionary kun'yomi list directly matches the page's own documented meanings (低 "low" → ひくい; 抵 "reach/resist" → ふす; etc.), while ふもと corresponds to none of the seven listed senses, indicating the en.Wiktionary claim was spurious. Replaced `japanese` with `[TAI, TEI]` and `japanese_native` with `[とも, なやむ, ひくい, ふす]`.

**`graphemic_classification` bug found and fixed**: stored `象形`, but zh.Wiktionary directly quotes the Shuowen definition ("至也。从氏下箸一。一，地也") describing 氐 as 氏 with an indicative ground-stroke affixed below — the textbook structure of 指事, not a holistic pictogram. Corrected to `指事`.

**`mc_id` off-by-one bug found and fixed**: stored `2070`, which is actually 陂's rank in `CC 2000.md`; 氐's genuine entry is `2071. 氐`. Corrected to `2071`.

**`vietnamese` bug found and fixed — incomplete**: stored only `đê`; hvdic.thivien.net (sole authority) also lists `chi` and `để` under Âm Hán Việt. Added both.

**`pos`, `joyo_level`, `hsk_level`, `hanmun_edu_level` filled — all four were blank**: `pos` filled as `名詞`. `joyo_level` filled as `表外字` (dual-source confirmed); added as item 624 to `Lookup/Japanese/Hyōgai.md`. `hsk_level` filled as `無` — genuinely absent from all six `Old HSK N.md` files; added to `Lookup/HSK/HSK No.md`. `hanmun_edu_level` filled as `無`.

**Missing Korean lookup entry found and fixed**: absent from `Lookup/Korean/Korean Name ㅈ.md`'s `### 저` subsection despite `korean: 저`; added.

Rebuilt the malformed `# Notes` (wrong heading level, two bare unlinked CC wikilinks, no SKIP/Stroke/mc_id-prose/four-links bullets) into the standard `## Notes` four-bullet format. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 犮 (8765; 38 characters remaining).

### 2026-08-24, iteration 2467 — [[characters/犮|犮]]

`radical: 犬` reconfirmed correct (Kangxi radical 94). `skip_number: 4-5-4` and `stroke_count: 5` reconfirmed correct against `SKIP-4-5-4.md` and `Stroke 05.md`, both already listing the character. `japanese: [HATSU, BACHI]` reconfirmed correct and complete — matches ja.Wiktionary's kan-on ハツ/goon バチ exactly. `japanese_native: ø` reconfirmed correct — ja.Wiktionary explicitly states no kun'yomi listed. `mc_id: 4361` reconfirmed as trusted long-tail (>4000, not cross-checked per policy). `aliases: [叐, 𡗜, 𤝜]` reconfirmed correct — all three dual-source confirmed 異體字 with no independent vault pages, and already correctly cross-referenced from `Radical 094.md`'s own variant notes. `english: shape of running dog` reconfirmed correct. Zero hits for 犮 anywhere in `words/`, confirming `stand_in: 名専字` and no `## Words` section change needed. `## Derived Characters` (citing [[黻]]) reconfirmed correct and complete.

**`graphemic_classification` bug found and fixed — contradicted the page's own Notes prose**: frontmatter stored `象形`, but the pre-existing Notes bullet already correctly described the composition as `会意 of 犬 + 丿` (matching en.Wiktionary's explicit 會意 classification and zh.Wiktionary's Shuowen-based description of 犬+丿). Corrected the frontmatter field to `会意` to match.

**`vietnamese` filled — was blank**: filled as `bạt` (hvdic.thivien.net sole authority, only Âm Hán Việt reading listed).

**Missing lookup entries found and fixed**: absent from `Lookup/HSK/HSK No.md` despite `hsk_level: 無` already being correctly set; added. Absent from `Lookup/Korean/Korean Name ㅂ.md`'s `### 발` subsection despite `korean: 발`; added.

Rebuilt Notes into the standard four-bullet format (retaining and expanding the pre-existing terse "chosen as a graphemic touch point and given an unused sound" note, now integrated into the etymology bullet), preserving the existing `## Derived Characters` section. Stamped `date-last-perfect: 2026-08-24`.

Next never-perfected character by `danayo_id`: 畐 (8766; 37 characters remaining).
